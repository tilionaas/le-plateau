# Le plateau — pour modifier ton app avec Claude Code

Ce fichier est lu par Claude Code quand tu cliques « Modifier l'app ». Il
explique l'app à Claude pour qu'il la modifie sans la casser. Tu peux
l'enrichir : c'est TA copie.

Le plateau est un centre d'opérations UGC qui tourne sur ton Mac, dans le
navigateur (`127.0.0.1:8765`). Deux métiers dans une seule app :

1. **Monter des variantes de vidéos** — un clip tiré au sort par
   catégorie, assemblés par ffmpeg, textes incrustés façon TikTok.
2. **Piloter les deals** — comptes, objectifs par jour, calendrier,
   paiements, publication Instagram via Buffer.

## Où vivent les choses

- **Le code** : ce dossier (`~/Le plateau/App`). C'est lui que tu modifies.
- **Tes données** : `~/Le plateau` (la base `plateau.db`, `clips/`,
  `series/`, `output/`, tes clés). Le code les trouve par `chemins.py` :
  tout fichier que l'app ÉCRIT passe par `chemins.DONNEES`, jamais par
  `Path(__file__)`. Une mise à jour remplace le code, pas les données.
- **Les outils** (Python, ffmpeg, whisper, yt-dlp) sont DANS `Le
  plateau.app` : ne demande jamais d'installer quoi que ce soit avec
  Homebrew ou pip.

**Après une modification**, l'app doit redémarrer pour la prendre : menu
de l'app (clic sur « Le plateau » en haut à gauche) → « Redémarrer ».

**Les mises à jour** : quand une nouvelle version arrive, l'app voit que
tu as modifié des fichiers et le dit avant. Tes fichiers modifiés sont
copiés dans `~/Le plateau/Mes modifications/<date>/`, et toute l'ancienne
version reste dans `~/Le plateau/.versions/precedente/`. Rien n'est perdu :
demande à Claude de remettre tes changements par-dessus la nouvelle
version. Si une nouvelle version ne démarre pas, l'app revient toute seule
à la précédente.

## Modèle de données — deux niveaux, ne pas les confondre

```
CAMPAGNE (SQLite, table campaigns)     le DEAL : le client, les comptes,
   │                                   la paie, le rythme exigé
   ├── SÉRIE (dossier + serie.json)    la RECETTE de montage : catégories
   │     │                             de clips, textes, réglages
   │     └── VIDÉO (SQLite, videos)    un .mp4 + statut + date de publication
   └── VIDÉO (sans série : tournée à la main)
```

`campaign` dans le code = le niveau deal ; `serie` = le montage. Ne
réintroduis pas d'ambiguïté. Statuts d'une vidéo, dans l'ordre :
`Idée → À tourner → Monté → Prêt → Posté`.

Une SÉRIE = des CATÉGORIES (« slots ») : chacune est un dossier de clips
interchangeables, avec une durée, des textes, une position. L'ÉDITEUR est
une vue sur la même série (une frise façon CapCut) : ses blocs de texte
s'accrochent à une catégorie et à un décalage, jamais à une seconde, parce
que la longueur d'une vidéo change d'un tirage à l'autre.

## Les fichiers

| Fichier | Rôle |
|---|---|
| `server.py` | serveur HTTP, toutes les routes |
| `remixer.py` | le moteur ffmpeg : découpe, assemblage, encodage |
| `plateau.py` | couche SQLite : campagnes, vidéos, objectifs |
| `chemins.py` | où vivent le code et les données |
| `maj.py` | les mises à jour de l'app |
| `captions.py` | textes à l'écran via CoreText (macOS) |
| `captions_pil.py` | les mêmes textes via Pillow (ailleurs) |
| `transcription.py` | sous-titres automatiques via `whisper-cli` |
| `broll.py` | quelle image afficher, quand — d'après les mots prononcés |
| `detourage.py` | détoure la personne d'un clip (Vision, macOS) |
| `publisher.py` | publication Buffer + upload Cloudflare R2 |
| `brief.py` | le brief d'une campagne, lu dans Notion ou collé |
| `ia.py` | l'IA : le Claude Code de la machine |
| `qualite.py` | la qualité d'un clip mesurée sur l'image, sans IA |
| `web/index.html` | **toute** l'interface, un seul fichier |

## Règles

**Zéro dépendance.** Bibliothèque standard Python uniquement (`sqlite3`,
`http.server`, `urllib`…). Pas de Flask, pas de requests, pas de npm, pas
de build. Les outils externes (ffmpeg, whisper-cli, yt-dlp) sont des
programmes appelés comme des commandes. Le code doit rester compatible
Python 3.9 à 3.12.

**Le front est un seul fichier HTML.** Pas de framework, pas de bundler.
Du JS écrit à la main. Une nouvelle vue va dans `web/index.html`.

**Les icônes sont des SVG inline** dans l'objet `ICO`. Jamais d'emoji dans
l'interface.

**Pas de texte explicatif à l'écran.** Des libellés, des chiffres, des
avertissements quand l'état le justifie. Les explications vivent dans le
mode Tuto (tableau `TUTO`) : ajoute une étape plutôt qu'un paragraphe.

**Les commentaires sont en français** et expliquent *pourquoi*, pas
*quoi*. Ceux qui existent documentent souvent un piège déjà rencontré :
lis-les avant de modifier le code qu'ils entourent, ne les supprime pas.

**Les colonnes SQL passent par une liste blanche** (`CAMPAIGN_COLS`,
`VIDEO_COLS` dans `plateau.py`). Une nouvelle colonne s'ajoute à la liste ;
`plateau.init()` la crée au démarrage.

**Le thème** : blanc, accent mauve `#5b21b6` réservé à ce qui désigne
(action, état actif). L'éditeur et les vignettes restent sombres : ce sont
des surfaces d'image.

**Une seule tâche de fond : `boucle_auto`** (l'envoi quotidien vers
Buffer). N'ouvre pas un second fil pour une tâche répétée.

## Pièges déjà payés — ne pas les refaire

- **Un dossier temporaire par génération** (`_tmp/run-<uuid>/`) et un
  verrou par série : deux montages simultanés s'effaçaient leurs fichiers.
- **Les morceaux intermédiaires restent vidéo seule.** La voix est
  reconstruite dans `assemble`, bout par bout. Remettre l'audio dans les
  morceaux ramène les vidéos figées.
- **Un gestionnaire HTTP doit laisser la socket propre** : répondre sans
  lire le corps colle ses octets devant la requête suivante (501 sur une
  requête valide). `vider_corps()` est appelé dans un `finally` ; si tu
  lis `self.rfile` toi-même, pose `self._corps_lu = True`.
- **L'API Buffer est limitée** (quelques milliers d'appels par mois).
  Compte chaque appel avant d'en ajouter un ; tout affichage passe par un
  cache.
- **Le cache ffprobe est sur disque** (`.probe-cache.json`) : ne le
  contourne pas, ouvrir une grosse série prendrait des secondes.
- **`requestAnimationFrame` ne tourne pas dans un onglet en
  arrière-plan** : la lecture et le graphe passent par `setTimeout`.
- **Une `<canvas>` peut avoir une taille nulle au montage** : un
  `ResizeObserver` la rappelle.

## Vérifier

Avant de conclure qu'une modification marche : `python3 -m py_compile`
sur les modules touchés, redémarre l'app, et regarde la console du
navigateur.
