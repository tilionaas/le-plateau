#!/usr/bin/env python3
"""
Le brief d'une campagne — lu dans Notion, rangé par rubriques.
--------------------------------------------------------------
Un brief client arrive en vrac: une page Notion de trois écrans où le
pays est noyé entre deux paragraphes de bienvenue et où l'interdiction
qui fait perdre le deal est un point de liste au milieu. Ce module en
fait dix rubriques courtes qu'on lit avant de tourner.

DEUX ENTRÉES, une seule sortie:
  - une URL Notion, lue par l'API OFFICIELLE (jeton dans `notion.txt`);
  - du texte collé, pour tout le reste (un Drive, un courriel, un Slack).
Le tri est le même dans les deux cas: c'est `structurer()` qui travaille,
pas la source.

ON NE JETTE JAMAIS UNE LIGNE. Un brief est un contrat: une phrase perdue
au tri peut coûter le deal. Tout ce qui n'entre dans aucune rubrique
tombe dans « Reste », qui est affiché comme les autres.

Le texte BRUT est gardé à côté du texte trié. Même raison que le cache
des transcriptions: retrier est gratuit, retourner chercher la page ne
l'est pas, et un jour on voudra changer les mots-clés sans redemander
son jeton à l'utilisateur.
"""

import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path

from chemins import DONNEES as ROOT          # notion.txt est une cle: une donnee
CONF = ROOT / "notion.txt"
API = "https://api.notion.com/v1"
# Figée volontairement: l'API de Notion est versionnée par en-tête, et
# une version qui bouge toute seule casse un jour sans prévenir.
VERSION = "2022-06-28"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " \
     "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
DELAI = 20
# Un brief n'est pas un wiki: on descend dans les blocs imbriqués, mais
# pas indéfiniment. Trois niveaux couvrent « titre > liste > sous-liste ».
PROFONDEUR = 3
MAX_BLOCS = 600

MODELE_CONF = """# Brief Notion — une seule ligne à remplir.
#
# jeton : notion.so/my-integrations > New integration > Internal
#         Integration Secret (il commence par « ntn_ » ou « secret_ »).
#
#         Puis, SUR CHAQUE PAGE de brief : menu « ... » en haut à droite
#         > Connections > choisis ton intégration. Sans ce partage,
#         Notion répond « object_not_found » même avec un jeton valide —
#         une intégration ne voit que ce qu'on lui donne.
#
# Sans jeton, le brief se colle à la main : ça marche aussi, et pour
# un Google Doc ou un courriel c'est la seule façon.

jeton =
"""


class BriefError(Exception):
    pass


# ------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------
def jeton():
    """Le jeton d'intégration, lu dans notion.txt à chaque appel.

    Jamais mis en cache, comme `discord.txt`: corriger une faute de
    frappe doit prendre effet sans redémarrer le serveur."""
    if not CONF.exists():
        try:
            CONF.write_text(MODELE_CONF, "utf-8")
            os.chmod(str(CONF), 0o600)      # il contiendra un secret
        except OSError:
            pass
        return ""
    try:
        for ligne in CONF.read_text("utf-8").splitlines():
            ligne = ligne.strip()
            if ligne.startswith("#") or "=" not in ligne:
                continue
            cle, _, val = ligne.partition("=")
            if cle.strip().lower() == "jeton":
                return val.strip()
    except OSError:
        pass
    return ""


# ------------------------------------------------------------------
# Lecture d'une page Notion
# ------------------------------------------------------------------
_HEX32 = re.compile(r"([0-9a-fA-F]{32})")
_UUID = re.compile(r"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}"
                   r"-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})")


def id_page(url):
    """L'identifiant d'une page, quelle que soit la forme de l'URL.

    Notion colle le titre devant l'identifiant (« Mon-brief-1f2e…9 ») et
    sert aussi bien notion.so que <espace>.notion.site. On prend le
    DERNIER bloc de 32 hex: un titre peut contenir un mot de 32 lettres,
    l'identifiant est toujours en fin de chemin."""
    s = (url or "").strip()
    if not s:
        return ""
    s = s.split("?")[0].split("#")[0]
    m = _UUID.findall(s)
    if m:
        return m[-1].replace("-", "")
    m = _HEX32.findall(s)
    return m[-1] if m else ""


def _tirets(pid):
    return f"{pid[:8]}-{pid[8:12]}-{pid[12:16]}-{pid[16:20]}-{pid[20:]}"


def _get(chemin, tok):
    req = urllib.request.Request(
        API + chemin,
        headers={"Authorization": f"Bearer {tok}",
                 "Notion-Version": VERSION,
                 "User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=DELAI) as f:
            return json.loads(f.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        corps = ""
        try:
            corps = json.loads(e.read().decode("utf-8")).get("message") or ""
        except Exception:                                   # noqa: BLE001
            pass
        if e.code == 401:
            raise BriefError("Jeton Notion refusé — revois notion.txt")
        if e.code == 404:
            raise BriefError("Page introuvable : partage-la avec ton "
                             "intégration (menu « ... » > Connections)")
        if e.code == 429:
            raise BriefError("Notion limite les appels, réessaie dans une minute")
        raise BriefError(f"Notion : {corps or e.code}")
    except urllib.error.URLError as e:
        raise BriefError(f"Notion injoignable : {e.reason}")


def _plat(riches):
    """Le texte d'un `rich_text`, sans les couleurs ni les liens."""
    return "".join(x.get("plain_text") or "" for x in (riches or [])).strip()


# Les types de blocs qui portent du texte, et le niveau de titre qu'ils
# valent. 0 = ligne normale. Un titre sert d'EN-TÊTE au tri plus bas:
# c'est la structure que l'auteur du brief a déjà posée, on s'en sert
# plutôt que de la deviner.
_TITRES = {"heading_1": 1, "heading_2": 2, "heading_3": 3}
_TEXTE = ("paragraph", "bulleted_list_item", "numbered_list_item", "to_do",
          "toggle", "quote", "callout", "code", "child_page")


def _lignes_bloc(b, prof, tok, sortie, compteur):
    if len(sortie) >= MAX_BLOCS:
        return
    t = b.get("type") or ""
    corps = b.get(t) or {}
    if t == "child_page":
        titre = (corps.get("title") or "").strip()
        if titre:
            sortie.append((1, titre))
    elif t in _TITRES or t in _TEXTE:
        txt = _plat(corps.get("rich_text"))
        if t == "code":
            txt = _plat(corps.get("rich_text"))
        if t == "to_do":
            # La case cochée compte: dans un brief, « ✓ déjà fourni » et
            # « ☐ à faire » ne se lisent pas pareil.
            txt = ("✓ " if corps.get("checked") else "☐ ") + txt if txt else ""
        if txt:
            sortie.append((_TITRES.get(t, 0), txt))
    if b.get("has_children") and prof < PROFONDEUR:
        for e in _enfants(b.get("id") or "", tok):
            _lignes_bloc(e, prof + 1, tok, sortie, compteur)


def _enfants(bid, tok):
    out, curseur = [], None
    while True:
        q = f"/blocks/{bid}/children?page_size=100"
        if curseur:
            q += f"&start_cursor={curseur}"
        d = _get(q, tok)
        out.extend(d.get("results") or [])
        if not d.get("has_more") or len(out) >= MAX_BLOCS:
            return out
        curseur = d.get("next_cursor")
        if not curseur:
            return out


# ------------------------------------------------------------------
# Une page PARTAGÉE par lien, sans jeton
# ------------------------------------------------------------------
# Le brief d'un client est SA page: elle n'est jamais partagée avec notre
# intégration, donc l'API officielle répond « introuvable » même avec un
# jeton valide. Mais un client qui envoie un lien a rendu la page
# publique, et le site de Notion la lit sans compte par son API interne
# (`loadCachedPageChunk`, celle qu'utilise la page web elle-même). Elle
# n'est pas documentée: si elle change, on retombe sur le message qui
# demande de coller le texte — rien d'autre ne casse.
PUBLIC = "https://www.notion.so/api/v3"
_TITRES_PUBLICS = {"header": 1, "sub_header": 2, "sub_sub_header": 3}
_TEXTE_PUBLIC = ("text", "bulleted_list", "numbered_list", "to_do", "toggle",
                 "quote", "callout", "code")
# Sous-pages suivies: un brief d'onboarding range ses règles dans des
# sous-pages (« Payment structure », « Rules »…), un niveau suffit.
SOUS_PAGES = 2


def _post_public(chemin, corps):
    req = urllib.request.Request(
        PUBLIC + chemin, data=json.dumps(corps).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=DELAI) as f:
            return json.loads(f.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 429:
            raise BriefError("Notion limite les appels, réessaie dans une minute")
        raise BriefError(f"Notion : {e.code}")
    except urllib.error.URLError as e:
        raise BriefError(f"Notion injoignable : {e.reason}")


def _val(rec):
    """Un enregistrement de Notion: `{"value": {...}}`, parfois enveloppé
    une fois de plus (`{"value": {"value": {...}, "role": …}}`)."""
    x = (rec or {}).get("value") or {}
    return x["value"] if isinstance(x.get("value"), dict) else x


def _texte_public(b):
    segs = ((b.get("properties") or {}).get("title")) or []
    # « ‣ » marque une mention (personne, date, page): sans la donnée
    # derrière, c'est un caractère qui ne dit rien.
    return "".join(str(x[0]) for x in segs if x).replace("‣", "").strip()


def _charger_page(pid, blocs):
    cur, n = {"stack": []}, 0
    while n < 20:
        d = _post_public("/loadCachedPageChunk", {
            "page": {"id": pid}, "limit": 100, "cursor": cur,
            "chunkNumber": n, "verticalColumns": False})
        blocs.update((d.get("recordMap") or {}).get("block") or {})
        cur, n = d.get("cursor") or {}, n + 1
        if not cur.get("stack"):
            return


def _manquants(ids, blocs):
    ids = [i for i in ids if i not in blocs]
    for k in range(0, len(ids), 100):
        d = _post_public("/syncRecordValues", {"requests": [
            {"pointer": {"table": "block", "id": i}, "version": -1}
            for i in ids[k:k + 100]]})
        blocs.update((d.get("recordMap") or {}).get("block") or {})


def lire_public(url):
    """(titre, [(niveau, texte)]) d'une page Notion publiée par lien."""
    pid = id_page(url)
    if not pid or len(pid) != 32:
        raise BriefError("Ce lien ne ressemble pas à une page Notion")
    pid = _tirets(pid)
    blocs = {}
    _charger_page(pid, blocs)
    racine = _val(blocs.get(pid))
    if not racine:
        raise BriefError("Page Notion privée — demande au client de la publier "
                         "(Partager > Publier), ou colle le texte")
    sortie = []

    def marcher(bid, prof, pages):
        if len(sortie) >= MAX_BLOCS:
            return
        b = _val(blocs.get(bid))
        if not b or b.get("alive") is False:
            return
        t = b.get("type") or ""
        enfants = b.get("content") or []
        if t == "page" and bid != pid:
            titre = _texte_public(b)
            if titre:
                sortie.append((1, titre))
            if pages >= SOUS_PAGES:
                return
            _charger_page(bid, blocs)
            pages, prof = pages + 1, 0
        elif t in _TITRES_PUBLICS or t in _TEXTE_PUBLIC:
            txt = _texte_public(b)
            if t == "to_do" and txt:
                coche = ((b.get("properties") or {}).get("checked") or [[""]])[0][0] == "Yes"
                txt = ("✓ " if coche else "☐ ") + txt
            if txt:
                sortie.append((_TITRES_PUBLICS.get(t, 0), txt))
        elif t != "page":
            # Colonnes, listes de colonnes: des contenants sans texte,
            # on descend dedans sans compter un niveau.
            prof -= 1
        if prof >= PROFONDEUR:
            return
        _manquants(enfants, blocs)
        for e in enfants:
            marcher(e, prof + 1, pages)

    marcher(pid, 0, 0)
    if not sortie:
        raise BriefError("Page lue, mais vide")
    return _texte_public(racine), sortie


def lire_notion(url):
    """(titre, [(niveau, texte)]) d'une page Notion: par l'intégration si
    un jeton est là et que la page lui est partagée, sinon comme une page
    publiée par lien."""
    tok = jeton()
    if not tok:
        return lire_public(url)
    try:
        return _lire_integration(url, tok)
    except BriefError as e:
        if "introuvable" not in str(e):
            raise
        return lire_public(url)


def _lire_integration(url, tok):
    pid = id_page(url)
    if not pid or len(pid) != 32:
        raise BriefError("Ce lien ne ressemble pas à une page Notion")
    pid = _tirets(pid)
    titre = ""
    try:
        page = _get(f"/pages/{pid}", tok)
        for v in (page.get("properties") or {}).values():
            if v.get("type") == "title":
                titre = _plat(v.get("title"))
                break
    except BriefError:
        raise
    lignes = []
    for b in _enfants(pid, tok):
        _lignes_bloc(b, 1, tok, lignes, 0)
    if not lignes:
        raise BriefError("Page lue, mais vide")
    return titre, lignes


# Un titre collé depuis Notion ou un Doc a perdu sa taille. On le devine
# à sa forme: court, sans ponctuation finale, pas un point de liste. Mais
# ce n'est qu'une SUPPOSITION — d'où le niveau -1, que `structurer` traite
# autrement qu'un vrai titre Notion. Une consigne courte sans point
# (« No swearing ») ressemble exactement à un titre, et la jeter serait
# perdre une règle du contrat.
_PUCE = "#•-*–—▪◦‣·"
# Ce qui prouve qu'une ligne porte de l'information, donc qu'elle n'est
# pas une étiquette de section: un chiffre, un lien, une adresse, un
# montant, un pourcentage.
_CONTENU = re.compile(r"\d|https?://|www\.|@|[$€£%]")


def lire_texte(txt):
    """Le même format, à partir d'un texte collé."""
    lignes = []
    for brut in (txt or "").splitlines():
        nu = brut.strip()
        puce = bool(nu[:1] and nu[0] in _PUCE)
        s = nu.lstrip(_PUCE).strip()
        if not s:
            continue
        # Un titre est une ÉTIQUETTE: il ne porte ni chiffre, ni lien, ni
        # adresse, et il n'a rien après un deux-points. Sans cette règle,
        # « Brand kit: https://drive.google.com/... » passait pour un
        # titre (2 mots, pas de ponctuation finale) et se faisait jeter
        # dès qu'une ligne le suivait — un lien d'assets perdu en silence.
        porte = (_CONTENU.search(s) is not None
                 or (":" in s and s.split(":", 1)[1].strip()))
        # Un point de liste n'est jamais un titre, même court: c'est la
        # forme que prennent justement les consignes.
        titre = (not porte
                 and (nu.startswith("#") or s.endswith(":")
                      or (not puce and len(s) <= 60 and len(s.split()) <= 7
                          and s[-1:] not in ".!?,;" and not s[:1].islower())))
        lignes.append((-1 if titre else 0,
                       s.rstrip(":").strip() if titre else s))
    if not lignes:
        raise BriefError("Rien à lire dans ce texte")
    return "", lignes


# ------------------------------------------------------------------
# Le tri
# ------------------------------------------------------------------
# Chaque rubrique: (clé, titre affiché, mots-clés). Les mots sont en
# français ET en anglais — les briefs arrivent dans les deux langues, et
# souvent mélangés dans la même page.
#
# L'ordre compte: c'est celui de l'affichage, et il va du cadre (où, sur
# quoi) vers l'exécution (quoi faire, quoi éviter). « Reste » est dernier
# et attrape tout ce qui n'a pas trouvé sa place.
RUBRIQUES = [
    ("pays", "Pays & langue", (
        "pays", "country", "countries", "geo", "région", "region", "marché",
        "market", "langue", "language", "anglais", "english", "français",
        "french", "spanish", "espagnol", "usa", "us only", "états-unis",
        "canada", "uk", "royaume-uni", "europe", "worldwide", "audience",
        "ciblage", "targeting", "accent", "native", "locale")),
    ("plateformes", "Plateformes", (
        "tiktok", "instagram", "reels", "shorts", "youtube", "facebook",
        "snapchat", "twitter", " x ", "threads", "plateforme", "platform",
        "poster sur", "post on", "compte", "account", "handle", "profil",
        "profile", "bio", "lien en bio", "link in bio")),
    ("format", "Format & technique", (
        "format", "durée", "duration", "secondes", "seconds", "minutes",
        "9:16", "16:9", "vertical", "horizontal", "ratio", "résolution",
        "resolution", "1080", "4k", "talking head", "voix off", "voice over",
        "voiceover", "face cam", "sous-titre", "subtitle", "caption",
        "hook", "accroche", "cta", "call to action", "b-roll", "broll",
        "musique", "music", "son", "audio", "montage", "edit", "editing",
        "watermark", "filigrane", "logo", "police", "font")),
    ("volume", "Volume & cadence", (
        "par jour", "per day", "par semaine", "per week", "par mois",
        "per month", "quota", "cadence", "fréquence", "frequency",
        "vidéos par", "videos per", "minimum de", "at least", "combien",
        "how many", "volume", "upload", "publier", "publish", "posting")),
    ("paiement", "Paiement", (
        "paiement", "payment", "paie", "pay", "payout", "rémunération",
        "rate", "tarif", "cpm", "rpm", "par mille", "per 1000", "bonus",
        "prime", "$", "usd", "eur", "€", "facture", "invoice", "paypal",
        "wise", "virement", "stripe", "seuil", "threshold", "vues",
        "views", "palier", "tier", "commission", "affiliate", "affilié")),
    ("delais", "Délais", (
        "deadline", "délai", "échéance", "date limite", "avant le",
        "by the", "due", "livraison", "delivery", "démarrage", "start date",
        "fin de", "end date", "semaine du", "week of", "asap", "urgent")),
    ("faire", "À faire", (
        "must", "doit", "obligatoire", "mandatory", "required", "requis",
        "requirement", "il faut", "assure", "make sure", "toujours",
        "always", "inclure", "include", "mentionner", "mention", "montrer",
        "show", "utiliser", "use the", "respecter", "follow", "guideline",
        "règle", "rule", "do's", "dos and", "checklist")),
    ("eviter", "À éviter", (
        "ne pas", "don't", "do not", "dont's", "never", "jamais",
        "interdit", "forbidden", "banned", "avoid", "éviter", "proscrit",
        "pas de", "no ", "sans ", "without", "attention", "warning",
        "refus", "reject", "disqualif", "strike", "copyright", "droits")),
    ("acces", "Liens & accès", (
        "drive", "dropbox", "wetransfer", "lien", "link", "http", "www.",
        "accès", "access", "mot de passe", "password", "identifiant",
        "login", "code", "asset", "ressource", "matériel", "footage",
        "template", "brand kit", "contact", "@", "slack", "discord",
        "whatsapp", "telegram", "courriel", "email", "mail")),
]
RESTE = ("reste", "Reste")

# Les mots-clés sont cherchés en minuscules, sans accents: un brief écrit
# « duree » ou « DURÉE » doit tomber au même endroit.
_ACCENTS = str.maketrans("àâäáãéèêëíìîïóòôöõúùûüçñ", "aaaaaeeeeiiiiooooouuuucn")


def _norm(s):
    return s.lower().translate(_ACCENTS)


_RUB_NORM = [(cle, titre, tuple(_norm(m) for m in mots))
             for cle, titre, mots in RUBRIQUES]


def _score(texte):
    """(clé de rubrique, score) la mieux notée pour cette ligne, ou None.

    Un mot-clé long vaut plus qu'un mot-clé court: « talking head » qui
    apparaît est un signal sûr, « code » peut être n'importe quoi. Sans
    cette pondération, les rubriques aux mots courts avalaient tout."""
    t = _norm(texte)
    best, bscore = None, 0
    for cle, _titre, mots in _RUB_NORM:
        s = sum(len(m) for m in mots if m in t)
        if any(m in t for m in _DEC_NORM.get(cle, ())):
            s += SEUIL                   # un décisif passe la barre à lui seul
        if s > bscore:
            best, bscore = cle, s
    return best, bscore


# Certains mots sont courts mais ne laissent aucun doute. Le poids par
# longueur les enterrait: « Avoid political content. » ne valait que 5 et
# tombait dans « Reste », alors que c'est exactement une interdiction.
# Un seul suffit donc à ranger la ligne.
DECISIFS = {
    "pays": ("country", "countries", "pays", "geo", "native", "nationality"),
    "plateformes": ("tiktok", "instagram", "youtube", "reels", "shorts",
                    "facebook", "snapchat"),
    "format": ("9:16", "16:9", "talking head", "voiceover", "voice over",
               "b-roll", "broll", "hook", "cta", "subtitle", "caption"),
    "volume": ("per day", "par jour", "per week", "par semaine",
               "per month", "par mois", "quota"),
    "paiement": ("cpm", "rpm", "payout", "bonus", "invoice", "paypal",
                 "wise", "usd", "payment", "paiement"),
    "delais": ("deadline", "asap", "due by", "date limite", "echeance"),
    "faire": ("must", "mandatory", "required", "requirement", "obligatoire",
              "always", "toujours", "make sure"),
    "eviter": ("never", "jamais", "avoid", "eviter", "don't", "dont",
               "do not", "ne pas", "interdit", "forbidden", "banned",
               "no swearing", "disqualif", "prohibited"),
    "acces": ("http", "www.", "drive", "dropbox", "wetransfer", "slack",
              "discord", "@"),
}
_DEC_NORM = {c: tuple(_norm(m) for m in ms) for c, ms in DECISIFS.items()}

# Sous ce score, la ligne n'a pas vraiment parlé: un seul mot de trois
# lettres ne range pas une phrase. Mesuré sur un brief réel: à 0, les
# lignes de politesse (« hey, welcome aboard ») tombaient dans
# « Plateformes » pour un « compte » au passage.
SEUIL = 8


def structurer(lignes, titre=""):
    """[(niveau, texte)] -> {'titre', 'rubriques': [{cle,titre,lignes}], ...}

    Deux règles, dans cet ordre:
      1. un TITRE de section qui nomme une rubrique range tout ce qui
         suit — c'est la structure que l'auteur a déjà posée, elle vaut
         mieux que nos mots-clés;
      2. une ligne qui parle fort d'autre chose part quand même ailleurs.
    """
    paniers = {cle: [] for cle, _t, _m in RUBRIQUES}
    paniers[RESTE[0]] = []
    courant = None
    vus = set()
    # Un titre SUPPOSÉ (niveau -1, texte collé) est gardé de côté au lieu
    # d'être jeté. S'il est suivi d'une ligne normale, c'était bien un
    # titre et il disparaît. S'il n'a rien sous lui, c'était une consigne
    # courte prise pour un titre — et on la remet. Un vrai titre Notion
    # (niveau > 0) est un fait, lui part directement.
    suspens = None

    def poser(dest, texte):
        k = (dest, _norm(texte))
        if k in vus:                     # un brief se répète souvent
            return
        vus.add(k)
        paniers[dest].append(texte)

    def vider_suspens():
        if suspens is not None:
            d, t = suspens
            poser(d, t)

    for niveau, texte in lignes:
        texte = " ".join(texte.split())
        if not texte:
            continue
        cle, sc = _score(texte)
        if niveau:                       # un titre: il oriente la suite
            vider_suspens()              # le précédent n'avait rien sous lui
            suspens = ((cle if sc >= SEUIL else RESTE[0]), texte) \
                if niveau < 0 else None
            courant = cle if sc >= SEUIL else None
            continue
        suspens = None                   # le titre tenait: il avait du corps
        # Une ligne qui parle fort d'autre chose que sa section: on la
        # suit elle, pas la section. « Ne jamais montrer le logo » rangé
        # sous « Format » se lit comme une permission.
        dest = cle if sc >= SEUIL * 2 else (courant or (cle if sc >= SEUIL else None))
        poser(dest or RESTE[0], texte)
    vider_suspens()                      # un titre en toute fin de page
    noms = dict((c, t) for c, t, _m in RUBRIQUES)
    noms[RESTE[0]] = RESTE[1]
    rubs = [{"cle": c, "titre": noms[c], "lignes": paniers[c]}
            for c, _t, _m in RUBRIQUES + [(RESTE[0], RESTE[1], ())]
            if paniers[c]]
    return {"titre": titre, "rubriques": rubs,
            "n": sum(len(r["lignes"]) for r in rubs)}


def construire(url="", texte=""):
    """Le brief complet, prêt à ranger en base.

    Garde le BRUT à côté du trié: retrier plus tard ne doit pas obliger
    à redemander la page à Notion (ni le jeton à l'utilisateur)."""
    if texte and texte.strip():
        titre, lignes = lire_texte(texte)
        source = "texte"
    elif url and url.strip():
        titre, lignes = lire_notion(url)
        source = "notion"
    else:
        raise BriefError("Donne un lien Notion ou colle le texte")
    d = structurer(lignes, titre)
    d["source"] = source
    d["url"] = (url or "").strip()
    d["at"] = int(time.time())
    d["brut"] = lignes
    return d


# ------------------------------------------------------------------
# Le CONTRAT, deposé a cote du brief (13/11). Il dit souvent ce que le
# brief tait: les plateformes exigees, la paie, le rythme, les
# interdits. On n'en garde que le TEXTE pour Claude; le fichier, lui,
# reste attache a la campagne (`contrat`, dans contrats/).
#
# Zero dependance: un PDF se lit par PDFKit (PyObjC, deja la pour
# Vision), un Word/RTF/HTML par `textutil` du Mac. Un PDF scanne n'a pas
# de texte: on le dit plutot que d'envoyer une page vide a Claude.
# ------------------------------------------------------------------

CONTRAT_EXTS = {".pdf", ".docx", ".doc", ".rtf", ".odt", ".html", ".htm",
                ".txt", ".md", ".webarchive"}


def lire_contrat(chemin):
    """Le texte d'un contrat. -> str (vide si rien de lisible)."""
    p = Path(chemin)
    ext = p.suffix.lower()
    if ext in (".txt", ".md"):
        return p.read_text(encoding="utf-8", errors="replace").strip()
    if ext == ".pdf":
        try:
            import Quartz                                  # PyObjC, macOS
            from Foundation import NSURL
        except ImportError:
            raise BriefError("Lire un PDF demande macOS — colle le texte du contrat")
        doc = Quartz.PDFDocument.alloc().initWithURL_(NSURL.fileURLWithPath_(str(p)))
        if doc is None:
            raise BriefError("Ce PDF ne s'ouvre pas")
        pages = []
        for i in range(doc.pageCount()):
            t = doc.pageAtIndex_(i).string()
            if t:
                pages.append(str(t))
        return "\n".join(pages).strip()
    if ext in CONTRAT_EXTS:
        import subprocess
        try:
            r = subprocess.run(["textutil", "-convert", "txt", "-stdout", str(p)],
                               capture_output=True, timeout=60)
        except (OSError, subprocess.TimeoutExpired):
            raise BriefError("Lire un document Word demande macOS — colle le texte du contrat")
        return r.stdout.decode("utf-8", errors="replace").strip()
    raise BriefError(f"Format non lu : {ext or '?'} — dépose un PDF ou un Word")
