#!/usr/bin/env python3
"""
Images declenchees par ce qui est dit.
--------------------------------------
Une serie parlee peut poser une image AU-DESSUS de la tete quand une
phrase precise est prononcee: « quand je dis *coloring book*, montre une
couverture de livre ». Chaque declencheur a sa banque d'images, et on y
pioche sans remise — la meme image ne revient qu'une fois les autres
passees.

Tout repose sur la transcription mot a mot (transcription.py), qui donne
le debut et la fin de chaque mot. Ce module ne fait que du texte et des
temps: il ne touche ni a ffmpeg ni au disque.

Fin d'une image, au choix par regle:
  `phrase`   jusqu'a la fin de la phrase (le premier mot qui se termine
             par . ! ? … ou la fin du clip)
  `suivant`  jusqu'au declencheur suivant, quel qu'il soit
  `mot:xxx`  jusqu'a ce que le mot `xxx` soit prononce
"""

import re
import unicodedata


def normaliser(texte):
    """« Replit's, » -> « replits ». Sert a comparer ce qui est dit au
    declencheur tape a la main, sans se soucier des accents ni de la
    ponctuation."""
    texte = unicodedata.normalize("NFD", str(texte).lower())
    texte = "".join(c for c in texte if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9]+", "", texte)


_FIN_PHRASE = re.compile(r"[.!?…]$")


def segments(mots, regles, duree=None):
    """Quand afficher quoi: [(debut, fin, index_de_la_regle), ...].

    `mots` = [(texte, debut, fin)] de transcription.mots().
    `regles` = [{"mot": "...", "fin": "phrase"|"suivant"|"mot:xxx"}, ...]
    Les temps sont ceux de la transcription (temps du clip source).
    """
    if not mots or not regles:
        return []
    plats = [normaliser(m[0]) for m in mots]
    cibles = []
    for i, r in enumerate(regles):
        # Le declencheur est compare SANS espaces ni tirets: whisper ecrit
        # « part-time » une fois et « part time » la suivante, et les deux
        # doivent declencher la meme image.
        cible = normaliser(str(r.get("mot", "")).replace(" ", ""))
        if cible:
            cibles.append((i, cible, str(r.get("fin") or "phrase")))

    # 1) Ou commence chaque image.
    debuts = []
    j = 0
    while j < len(plats):
        trouve = None
        for i, cible, fin in cibles:
            accu = ""
            for k in range(j, min(j + 6, len(plats))):
                accu += plats[k]
                if accu == cible:
                    trouve = (j, k, i, fin)
                    break
                if not cible.startswith(accu):
                    break
            if trouve:
                break
        if trouve:
            debuts.append(trouve)
            j = trouve[1]
        j += 1

    # 2) Ou elle s'arrete.
    out = []
    for n, (j0, j1, i, fin) in enumerate(debuts):
        depart = mots[j0][1]
        if fin == "suivant":
            arret = mots[debuts[n + 1][0]][1] if n + 1 < len(debuts) else (duree or mots[-1][2])
        elif fin.startswith("mot:"):
            vise = normaliser(fin[4:])
            arret = None
            for k in range(j1 + 1, len(plats)):
                if plats[k] == vise:
                    arret = mots[k][1]
                    break
            if arret is None:
                arret = _fin_de_phrase(mots, j1, duree)
        else:
            arret = _fin_de_phrase(mots, j1, duree)
        # Deux images ne se chevauchent jamais: la precedente s'arrete la
        # ou la suivante commence.
        if n + 1 < len(debuts):
            arret = min(arret, mots[debuts[n + 1][0]][1])
        if arret > depart + 0.15:
            out.append((round(depart, 3), round(arret, 3), i))
    return out


def _fin_de_phrase(mots, depuis, duree):
    for k in range(depuis, len(mots)):
        if _FIN_PHRASE.search(mots[k][0]):
            return mots[k][2]
    return duree if duree else mots[-1][2]
