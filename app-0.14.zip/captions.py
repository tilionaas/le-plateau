#!/usr/bin/env python3
"""
Rendu des textes a l'ecran (style TikTok).
------------------------------------------
ffmpeg de Homebrew est compile sans libfreetype: le filtre `drawtext`
n'existe pas. On dessine donc le texte avec le moteur de rendu natif de
macOS (CoreText via PyObjC), on l'enregistre en PNG transparent, et on
l'incruste avec le filtre `overlay` de ffmpeg — qui, lui, marche partout.

Bonus par rapport a drawtext: le retour a la ligne est automatique, et on
peut dessiner une pastille arrondie derriere chaque ligne, comme sur TikTok.
"""

import hashlib
import os
from pathlib import Path

try:
    from AppKit import (NSBitmapImageRep, NSColor, NSFont, NSGraphicsContext,
                        NSMutableParagraphStyle, NSBezierPath, NSMakeRect,
                        NSAttributedString, NSCalibratedRGBColorSpace,
                        NSFontAttributeName, NSForegroundColorAttributeName,
                        NSParagraphStyleAttributeName, NSStrokeColorAttributeName,
                        NSStrokeWidthAttributeName, NSKernAttributeName)
    _OK = True
except ImportError:                                    # pas macOS / pas PyObjC
    _OK = False

# Jointure du trait de contour. Par defaut le trace est en MITER: sur les
# angles aigus d'un glyphe (la pointe du « w », le sommet du « A »), le
# raccord se prolonge en une pique noire qui depasse tres au-dessus de la
# lettre. Plus le contour est epais, plus la pique est longue.
# Facultatif: sans Quartz on garde le rendu d'avant plutot que d'echouer.
try:
    from Quartz import CGContextSetLineJoin, kCGLineJoinRound
    _JOIN_OK = True
except ImportError:
    _JOIN_OK = False

# Version du TRACE, pas du fichier. Elle entre dans la cle du cache des
# PNG de texte: l'incrementer suffit a rendre caducs les rendus precedents.
#   2 = jointure arrondie (fin des piques noires sur les angles aigus)
#   5 = interlettrage et interligne mesures sur un texte TikTok
_VERSION_RENDU = 5

# Repli quand CoreText n'est pas la: Windows, Linux, ou un Mac tournant sur
# un Python installe a la main (seul celui d'Apple embarque PyObjC).
# captions_pil refait le meme dessin avec Pillow.
try:
    import captions_pil as _PIL
except ImportError:
    _PIL = None

# Styles disponibles.
#   contour = texte blanc epais cerne de noir, sans fond -> le look TikTok/CapCut
#   pastille = bandeau sombre arrondi derriere chaque ligne
# `stroke` est un pourcentage de la taille de police (negatif = remplir ET cerner).
#
# `kern` et `lead` viennent d'une MESURE sur un texte TikTok de reference
# (« Imagine getting woken up… »), memes metriques sur la reference et sur
# nos rendus, a hauteur de capitale egale (48 px):
#   kern  0,018 x la taille — « Imagine » fait 236 px dans les deux. Sans
#         interlettrage le mot sortait 3 % plus etroit.
#   lead  1,22 x la taille d'une ligne de base a la suivante. Notre
#         interligne naturel (boite + marge) donnait 1,54: un bloc de deux
#         lignes etait 27 % trop aere.
# Ils valent pour TOUS les textes de l'app (series, split, templates,
# editeur, sous-titres), qui passent tous par ce style. Un `kern` ou un
# `lead` impose a l'appel l'emporte — les templates mesurent le leur dans
# le reel d'origine.
TIKTOK_KERN = 0.018
TIKTOK_LEAD = 1.22
STYLES = {
    "contour":  {"box": False, "text": (1, 1, 1), "stroke": -11.0, "stroke_rgb": (0, 0, 0),
                 "kern": TIKTOK_KERN, "lead": TIKTOK_LEAD},
    "nu":       {"box": False, "text": (1, 1, 1), "stroke": 0,
                 "kern": TIKTOK_KERN, "lead": TIKTOK_LEAD},
    "pastille": {"box": True,  "box_alpha": 0.55, "text": (1, 1, 1), "stroke": 0,
                 "kern": TIKTOK_KERN},
    "blanc":    {"box": False, "text": (1, 1, 1), "stroke": 0,
                 "kern": TIKTOK_KERN, "lead": TIKTOK_LEAD},
    "noir":     {"box": False, "text": (0, 0, 0), "stroke": 0,
                 "kern": TIKTOK_KERN, "lead": TIKTOK_LEAD},
}

# TikTok Sans est la police officielle de TikTok, publiee par TikTok Inc.
# sous licence SIL Open Font. Elle a remplace Proxima Nova, sur laquelle le
# style "Classic" etait historiquement base. Le fichier est livre avec le
# projet dans fonts/ et charge EN MEMOIRE, jamais installe dans le systeme.
_HERE = Path(__file__).resolve().parent

EXTRA_FONT_FILES = [
    str(_HERE / "fonts" / "TikTokSans[opsz,slnt,wdth,wght].ttf"),
    # Repli si le fichier a ete supprime: la police maison de CapCut
    # (meme editeur, ByteDance) s'en approche.
    "/Applications/CapCut.app/Contents/Resources/Font/SystemFont/CapCutSansText-Bold.otf",
]

# Graisses proposees dans les reglages.
#
# « Nom@poids » = une graisse ENTRE deux instances nommees de la police
# variable (axe `wght`). Medium+ (560) est la graisse par defaut: Medium
# (500) collait a la mesure du texte TikTok de reference mais se lisait un
# peu maigre a l'ecran; SemiBold (600) etait un saut de 15 %. 560 epaissit
# le fut de 9 % (0,170 -> 0,186 de la capitale), mesure sur le rendu.
FONT_CHOICES = {
    "TikTok Sans Medium+": "TikTokSans-Medium@560",
    "TikTok Sans Bold": "TikTokSans-Bold",
    "TikTok Sans SemiBold": "TikTokSans-SemiBold",
    "TikTok Sans ExtraBold": "TikTokSans-ExtraBold",
    "TikTok Sans Black": "TikTokSans-Black",
    "TikTok Sans Medium": "TikTokSans-Medium",
}

FONTS = ["TikTokSans-Bold", "CapCutSansText-Bold",
         "AvenirNext-Bold", "HelveticaNeue-Bold", "Helvetica-Bold"]


def _register_extra_fonts():
    """Rend disponibles des polices livrees avec d'autres apps, pour ce
    processus uniquement (aucune installation dans ~/Library/Fonts)."""
    if not _OK:
        return []
    loaded = []
    try:
        import objc
        from Foundation import NSURL
        bundle = objc.loadBundle(
            "CoreText", globals(),
            bundle_path="/System/Library/Frameworks/CoreText.framework")
        objc.loadBundleFunctions(
            bundle, globals(),
            [("CTFontManagerRegisterFontsForURL", b"Z@i^@")])
    except Exception:                                  # noqa: BLE001
        return []
    for path in EXTRA_FONT_FILES:
        if not Path(path).exists():
            continue
        try:
            # 1 = kCTFontManagerScopeProcess
            if CTFontManagerRegisterFontsForURL(          # noqa: F821
                    NSURL.fileURLWithPath_(path), 1, None):
                loaded.append(Path(path).name)
        except Exception:                              # noqa: BLE001
            pass
    return loaded


_EXTRA_LOADED = _register_extra_fonts()

# Positions verticales proposees dans l'interface.
POSITIONS = ("haut", "milieu", "bas")


def available():
    return _OK or bool(_PIL and _PIL.available())


def font_name(preferred=None):
    """Nom de la police reellement utilisee (pour l'afficher dans l'app)."""
    if not _OK:
        return _PIL.font_name() if _PIL else None
    f = _font(48, preferred)
    return f.fontName() if f else None


def available_fonts():
    """Graisses de FONT_CHOICES reellement chargees sur cette machine."""
    if not _OK:
        if not _PIL:
            return []
        dispo = set(_PIL.available_fonts())
        return [n for n, ps in FONT_CHOICES.items() if ps in dispo]
    # Une graisse « Nom@poids » existe si son instance de base existe: le
    # nom complet n'est pas un nom PostScript, et la chercher tel quel la
    # retirait du menu des reglages.
    return [n for n, ps in FONT_CHOICES.items()
            if NSFont.fontWithName_size_(ps.partition("@")[0], 48) is not None]


# Une graisse intermediaire se fabrique par CORETEXT, pas par AppKit.
# AppKit garde ses polices en cache et a renvoye la variante 560 quand on
# lui demandait 600 dans le meme processus — or le serveur dessine tout
# dans UN processus. CoreText rend la bonne graisse a chaque appel, dans
# n'importe quel ordre (mesure: 500, 560, 600, 500, 560 -> fut identique
# a chaque passage). Le CTFont est le meme objet qu'un NSFont.
_CT_VAR = False
if _OK:
    try:
        import objc as _objc
        _ctb = _objc.loadBundle("CoreText", {},
                                bundle_path="/System/Library/Frameworks/CoreText.framework")
        _ct = {}
        _objc.loadBundleFunctions(_ctb, _ct, [
            ("CTFontDescriptorCreateWithNameAndSize", b"@@d"),
            ("CTFontDescriptorCreateCopyWithVariation", b"@@@d"),
            ("CTFontCreateWithFontDescriptor", b"@@d^v"),
        ])
        from Foundation import NSNumber as _NSNumber
        _CT_VAR = len(_ct) == 3
    except Exception:                                  # noqa: BLE001
        _CT_VAR = False

_WGHT = 0x77676874                                     # l'axe 'wght'


def _variante(nom, size):
    """« TikTokSans-Medium@560 » -> la police a ce poids, ou None."""
    base, _, w = nom.partition("@")
    if NSFont.fontWithName_size_(base, size) is None:
        return None
    if not _CT_VAR:
        return NSFont.fontWithName_size_(base, size)   # au moins l'instance de base
    try:
        d = _ct["CTFontDescriptorCreateWithNameAndSize"](base, float(size))
        d = _ct["CTFontDescriptorCreateCopyWithVariation"](
            d, _NSNumber.numberWithUnsignedInt_(_WGHT), float(w))
        return _ct["CTFontCreateWithFontDescriptor"](d, float(size), None)
    except Exception:                                  # noqa: BLE001
        return NSFont.fontWithName_size_(base, size)


def _font(size, preferred=None):
    """Police demandee si elle existe, sinon la premiere disponible."""
    for name in ([preferred] if preferred else []) + FONTS:
        if not name:
            continue
        f = _variante(name, size) if "@" in name else NSFont.fontWithName_size_(name, size)
        if f is not None:
            return f
    return NSFont.boldSystemFontOfSize_(size)


def _attrs(font, st, stroke_only=False, kern=0.0):
    """Attributs de dessin.

    Le contour est fait en DEUX passes: une passe qui ne trace que le
    contour, puis le remplissage par-dessus. Une seule passe avec une
    epaisseur negative centre le trait sur le bord du glyphe et ronge donc
    l'interieur des lettres, ce qui les amincit visiblement."""
    para = NSMutableParagraphStyle.alloc().init()
    para.setAlignment_(2)                              # 2 = centre
    a = {NSFontAttributeName: font, NSParagraphStyleAttributeName: para}
    # L'INTERLETTRAGE va sur les DEUX passes, contour et remplissage: sur
    # une seule, le contour se decalerait de lettre en lettre et finirait
    # a cote du dernier glyphe.
    if kern:
        a[NSKernAttributeName] = float(kern)
    if stroke_only:
        a[NSStrokeWidthAttributeName] = abs(st.get("stroke", 0))
        a[NSStrokeColorAttributeName] = \
            NSColor.colorWithCalibratedRed_green_blue_alpha_(*st.get("stroke_rgb", (0, 0, 0)), 1.0)
        a[NSForegroundColorAttributeName] = NSColor.clearColor()
    else:
        a[NSForegroundColorAttributeName] = \
            NSColor.colorWithCalibratedRed_green_blue_alpha_(*st["text"], 1.0)
    return a


def _measure(text, attrs):
    return NSAttributedString.alloc().initWithString_attributes_(text, attrs).size()


# Saut de ligne force: « | » dans un texte. Le champ de saisie met un texte
# par ligne, un vrai retour a la ligne y creerait donc un second texte;
# Maj+Entree y insere « | » a la place (voir sautLigne dans index.html).
SAUT = "|"


def _wrap_force(text, wrap, vides=False):
    """Chaque morceau entre deux « | » commence une nouvelle ligne, puis est
    lui-meme coupe s'il deborde.

    UN VRAI RETOUR A LA LIGNE COMPTE AUSSI. Les templates relisent le
    texte d'un reel ligne par ligne et le stockent avec des « \n »: sans
    cette coupe, tout etait recolle puis redecoupe a la largeur du cadre,
    et un texte sur trois lignes etroites ressortait sur deux lignes
    larges — le bloc ne ressemblait plus au modele.

    `vides`: garder les lignes vides comme ESPACEMENT. Un reel qui separe
    deux paragraphes par une ligne blanche perdait sa respiration, et
    c'est elle qui fait qu'un texte long reste aere. Reserve a l'appelant
    qui impose deja sa mise en page (voir `lead`): ailleurs, « a||b » est
    une maladresse de saisie, pas une intention."""
    lignes = []
    for bout in text.replace("\r", "").replace("\n", SAUT).split(SAUT):
        if bout.strip():
            lignes += wrap(bout.strip())
        elif vides and lignes:
            lignes.append("")
    while vides and lignes and not lignes[-1]:
        lignes.pop()
    return lignes


def _wrap(text, attrs, max_width):
    """Coupe le texte en lignes qui tiennent dans max_width.

    Un mot plus long que la ligne entiere est coupe en deux plutot que de
    deborder (rare, mais sinon le texte sortirait du cadre)."""
    lines, current = [], ""
    for word in text.split():
        trial = f"{current} {word}".strip()
        if _measure(trial, attrs).width <= max_width or not current:
            current = trial
            while _measure(current, attrs).width > max_width and len(current) > 1:
                cut = len(current) - 1
                while cut > 1 and _measure(current[:cut], attrs).width > max_width:
                    cut -= 1
                lines.append(current[:cut])
                current = current[cut:]
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or [""]


def render(text, video_w, video_h, out_path, size=56, style="contour",
           font_ps=None, outline=None, lead=None, larg=None, kern=None):
    """Dessine `text` dans un PNG transparent de la largeur de la video.

    `outline` = epaisseur du contour en % de la taille de police.
    `larg` = largeur utile, en fraction de la largeur de la video (0,92
    par defaut). C'est elle qui decide OU le texte revient a la ligne:
    une colonne etroite donne beaucoup de lignes courtes, une large peu
    de lignes longues. Le PNG, lui, garde la largeur de la video — c'est
    `overlay` qui le pose a 0, et le texte est centre dedans.
    `lead` = ecart impose entre deux lignes, en pixels, d'un haut de
    ligne au suivant. Sans lui, l'ecart vient de la police et des marges
    du style. Les templates le mesurent dans le reel d'origine: a taille
    egale, un interligne 18 % trop large suffit a faire paraitre un bloc
    de quatre lignes « trop gros ».
    Retourne (chemin, hauteur_px) ou None si le rendu est impossible."""
    if not _OK:
        if not _PIL:
            return None
        # Pillow ne sait pas poser un interligne impose: le repli dessine
        # le texte a son espacement naturel plutot que rien.
        return _PIL.render(text, video_w, video_h, out_path, size, style,
                           font_ps, outline, styles=STYLES)
    if not text.strip():
        return None

    st = dict(STYLES.get(style, STYLES["contour"]))
    if outline is not None and st.get("stroke"):
        st["stroke"] = -abs(float(outline))
    font = _font(size, font_ps)
    # `kern` (fraction de la taille) l'emporte sur celui du style. Il est
    # proportionnel a la taille, comme l'interlettrage d'un editeur: un
    # ecart en pixels fixes serrerait les gros textes et aererait les
    # petits.
    k = (st.get("kern", 0.0) if kern is None else float(kern)) * size
    attrs = _attrs(font, st, kern=k)
    outline = _attrs(font, st, stroke_only=True, kern=k) if st.get("stroke") else None

    if st["box"]:
        pad_x, pad_y, gap = size * 0.42, size * 0.24, size * 0.16
    else:
        # Sans pastille, il faut quand meme de la marge pour que le contour
        # noir ne soit pas rogne par le bord de l'image.
        pad_x, pad_y, gap = size * 0.18, size * 0.10, size * 0.04
    utile = 0.92 if larg is None else max(0.15, min(float(larg), 1.0))
    max_text_w = video_w * utile - 2 * pad_x

    lines = _wrap_force(text, lambda b: _wrap(b, attrs, max_text_w),
                        vides=lead is not None) or [""]
    line_h = _measure("Ág", attrs).height
    box_h = line_h + 2 * pad_y
    # Le PAS d'une ligne a la suivante. Impose, il peut etre plus serre
    # que la boite elle-meme: deux lignes se chevauchent alors un peu,
    # ce que fait tout editeur video quand on reduit l'interligne.
    # Interligne impose a l'appel > celui du style (mesure sur TikTok) >
    # l'espacement naturel de la boite.
    pas = (float(lead) if lead
           else (st["lead"] * size if st.get("lead") else (box_h + gap)))
    total_h = int((len(lines) - 1) * pas + box_h + 4)

    rep = NSBitmapImageRep.alloc().\
        initWithBitmapDataPlanes_pixelsWide_pixelsHigh_bitsPerSample_samplesPerPixel_hasAlpha_isPlanar_colorSpaceName_bytesPerRow_bitsPerPixel_(
            None, int(video_w), total_h, 8, 4, True, False,
            NSCalibratedRGBColorSpace, 0, 0)
    if rep is None:
        return None

    ctx = NSGraphicsContext.graphicsContextWithBitmapImageRep_(rep)
    if ctx is None:
        return None
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.setCurrentContext_(ctx)
    # A poser APRES `setCurrentContext_`: c'est le contexte courant qui
    # sert au trace du contour.
    if _JOIN_OK:
        CGContextSetLineJoin(ctx.CGContext(), kCGLineJoinRound)

    # L'origine d'une NSBitmapImageRep est en bas a gauche: on dessine donc
    # la derniere ligne en premier.
    y = 2.0
    for line in reversed(lines):
        if not line:                    # ligne blanche: elle n'occupe que sa place
            y += pas
            continue
        tw = _measure(line, attrs).width
        bw = tw + 2 * pad_x
        x = (video_w - bw) / 2.0

        if st["box"]:
            NSColor.colorWithCalibratedRed_green_blue_alpha_(
                0, 0, 0, st["box_alpha"]).set()
            NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(
                NSMakeRect(x, y, bw, box_h), size * 0.22, size * 0.22).fill()

        rect = NSMakeRect(x + pad_x, y + pad_y * 0.7, tw + 2, line_h)
        if outline:
            NSAttributedString.alloc().initWithString_attributes_(line, outline).\
                drawInRect_(rect)
        NSAttributedString.alloc().initWithString_attributes_(line, attrs).\
            drawInRect_(rect)
        y += pas

    NSGraphicsContext.restoreGraphicsState()

    data = rep.representationUsingType_properties_(4, {})   # 4 = PNG
    if data is None:
        return None
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    if not data.writeToFile_atomically_(str(out_path), True):
        return None
    return str(out_path), total_h


def cached(text, video_w, video_h, cache_dir, size=56, style="contour",
           font_ps=None, outline=None, lead=None, larg=None, kern=None):
    """Comme render(), mais reutilise le PNG s'il a deja ete dessine."""
    # `_VERSION_RENDU` entre dans la cle: sans lui, changer la FACON de
    # dessiner (et pas le texte ni les reglages) laissait le cache resservir
    # les anciens PNG. Le passage a la jointure arrondie n'aurait rien
    # change tant qu'un texte deja rendu n'aurait pas ete modifie.
    # A incrementer des qu'on touche au trace.
    key = hashlib.sha1(
        f"{text}|{video_w}|{size}|{style}|{font_ps}|{outline}|{lead}|{larg}|{kern}"
        f"|v{_VERSION_RENDU}"
        .encode("utf-8")).hexdigest()[:16]
    path = Path(cache_dir) / f"cap_{key}.png"
    if path.exists() and path.stat().st_size > 0:
        if not _OK:
            h = _PIL.hauteur_png(path) if _PIL else None
            if h:
                return str(path), h
        else:
            rep = NSBitmapImageRep.imageRepWithContentsOfFile_(str(path))
            if rep is not None:
                return str(path), int(rep.pixelsHigh())
            try:
                os.remove(path)
            except OSError:
                pass
    return render(text, video_w, video_h, path, size, style, font_ps, outline,
                  lead, larg, kern)
