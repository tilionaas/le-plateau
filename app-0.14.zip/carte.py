#!/usr/bin/env python3
"""
Le classement dessine en IMAGE, pour Discord.
---------------------------------------------
Un bloc de code monospace fait le travail mais ne donne envie a personne
d'etre premier. Une carte, oui.

Aucune dependance ajoutee: on dessine avec AppKit/CoreText, exactement
comme `captions.py` dessine les textes incrustes dans les videos. Pas de
navigateur sans tete, pas de bibliotheque d'images.

La carte reprend la palette de l'app (« Atelier »): creme, jade pour
l'accent, bronze pour les trois premiers.
"""

import os
from pathlib import Path

try:
    from AppKit import (NSBitmapImageRep, NSColor, NSFont, NSGraphicsContext,
                        NSImage, NSBezierPath, NSMakeRect, NSMakePoint,
                        NSAttributedString, NSFontAttributeName,
                        NSForegroundColorAttributeName, NSCalibratedRGBColorSpace,
                        NSPNGFileType, NSData, NSCompositeSourceOver,
                        NSParagraphStyleAttributeName, NSMutableParagraphStyle,
                        NSRightTextAlignment)
    _OK = True
except Exception:                                   # noqa: BLE001
    _OK = False


LARGEUR = 1180
MARGE = 54
H_ENTETE = 186
H_LIGNE = 62
H_PIED = 76
MAX_LIGNES = 10


def disponible():
    return _OK


def _c(h, a=1.0):
    """« #1d7a5e » -> NSColor."""
    r, v, b = (int(h[i:i + 2], 16) / 255.0 for i in (1, 3, 5))
    return NSColor.colorWithCalibratedRed_green_blue_alpha_(r, v, b, a)


CREME = "#f3ede3"
CREME2 = "#e9e0d2"
ENCRE = "#241d15"
GRIS = "#8a7f70"
JADE = "#2f7259"
OR = "#b8894e"


def _texte(s, x, y, taille, couleur, gras=False, largeur=None, droite=False):
    """Pose une chaine. `largeur` + `droite` = aligne a droite dans cette
    largeur, ce qui est la seule facon d'avoir des montants qui tombent
    les uns sous les autres."""
    f = (NSFont.boldSystemFontOfSize_(taille) if gras
         else NSFont.systemFontOfSize_(taille))
    at = {NSFontAttributeName: f, NSForegroundColorAttributeName: couleur}
    a = NSAttributedString.alloc().initWithString_attributes_(str(s), at)
    # Alignement a droite calcule a la main plutot que par un style de
    # paragraphe: `drawInRect_` pose le texte en HAUT de son cadre alors
    # que `drawAtPoint_` le pose sur sa ligne de base, et les colonnes
    # alignees a droite flottaient deux pixels au-dessus des autres.
    if droite and largeur is not None:
        a.drawAtPoint_(NSMakePoint(x + largeur - a.size().width, y))
    else:
        a.drawAtPoint_(NSMakePoint(x, y))
    return a.size().width


def _pastille(rect, couleur, rayon):
    NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(
        rect, rayon, rayon).setClip() if False else None
    p = NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(rect, rayon, rayon)
    couleur.setFill()
    p.fill()


def _avatar(octets, x, y, d, secours):
    """Image de profil, decoupee en rond. Sans image: un disque de couleur
    avec l'initiale — une case vide dans une liste de visages se remarque
    plus qu'une pastille."""
    dessine = False
    if octets:
        data = NSData.dataWithBytes_length_(octets, len(octets))
        img = NSImage.alloc().initWithData_(data)
        if img is not None:
            NSGraphicsContext.saveGraphicsState()
            NSBezierPath.bezierPathWithOvalInRect_(NSMakeRect(x, y, d, d)).addClip()
            img.drawInRect_fromRect_operation_fraction_(
                NSMakeRect(x, y, d, d), NSMakeRect(0, 0, 0, 0),
                NSCompositeSourceOver, 1.0)
            NSGraphicsContext.restoreGraphicsState()
            dessine = True
    if not dessine:
        _c(JADE, .18).setFill()
        NSBezierPath.bezierPathWithOvalInRect_(NSMakeRect(x, y, d, d)).fill()
        f = NSFont.boldSystemFontOfSize_(d * .42)
        at = {NSFontAttributeName: f, NSForegroundColorAttributeName: _c(JADE, .9)}
        a = NSAttributedString.alloc().initWithString_attributes_(
            secours[:1].upper(), at)
        t = a.size()
        a.drawAtPoint_(NSMakePoint(x + (d - t.width) / 2, y + (d - t.height) / 2))


def rendre(lignes, chemin, titre="Classement", sous_titre="", pied="",
           avatars=None, total=None, semaine=None, jours=7):
    """Dessine la carte et renvoie son chemin, ou None.

    `lignes` = [{'nom','montant','semaine'(option)}], deja triees.
    `avatars` = {id: octets PNG}."""
    if not _OK:
        return None
    # Les totaux portent sur TOUT LE MONDE, pas seulement sur les lignes
    # affichees: le classement montre les quinze premiers, la somme compte
    # l'equipe entiere.
    if total is None:
        total = sum(l.get("montant", 0) for l in lignes)
    if semaine is None:
        semaine = sum(l["semaine"] for l in lignes if l.get("semaine") is not None)
    lignes = [l for l in lignes if l.get("montant", 0) > 0][:MAX_LIGNES]
    if not lignes:
        return None
    avatars = avatars or {}
    sem = any(l.get("semaine") for l in lignes)

    hauteur = int(H_ENTETE + len(lignes) * H_LIGNE + H_PIED)
    rep = NSBitmapImageRep.alloc().\
        initWithBitmapDataPlanes_pixelsWide_pixelsHigh_bitsPerSample_samplesPerPixel_hasAlpha_isPlanar_colorSpaceName_bytesPerRow_bitsPerPixel_(
            None, LARGEUR, hauteur, 8, 4, True, False,
            NSCalibratedRGBColorSpace, 0, 0)
    if rep is None:
        return None
    ctx = NSGraphicsContext.graphicsContextWithBitmapImageRep_(rep)
    if ctx is None:
        return None
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.setCurrentContext_(ctx)

    # Fond. Le repere d'AppKit part d'EN BAS: tout ce qui suit compte les y
    # a l'envers de ce qu'on lit, d'ou le `haut()`.
    _c(CREME).setFill()
    NSBezierPath.bezierPathWithRect_(NSMakeRect(0, 0, LARGEUR, hauteur)).fill()
    _pastille(NSMakeRect(0, hauteur - H_ENTETE + 24, LARGEUR, H_ENTETE), _c(CREME2), 0)

    def haut(y):
        return hauteur - y

    # --- entete ---
    _pastille(NSMakeRect(MARGE, haut(84), 10, 42), _c(JADE), 5)
    _texte(titre, MARGE + 26, haut(92), 40, _c(ENCRE), gras=True)
    if sous_titre:
        _texte(sous_titre, MARGE + 26, haut(124), 16, _c(GRIS))

    # Les deux chiffres qui comptent, en haut a droite: ce que l'equipe a
    # fait en tout, et ce qu'elle a ajoute cette semaine. Le second ne
    # s'affiche qu'une fois qu'on a de quoi comparer — avant, il vaudrait
    # zero et se lirait comme « personne n'a rien fait ».
    l_kpi = 230
    x_kpi = LARGEUR - MARGE - l_kpi
    if semaine:
        x_kpi -= l_kpi + 36
        _texte("CETTE SEMAINE" if jours >= 7 else f"DEPUIS {jours} JOUR"
               + ("S" if jours > 1 else ""),
               LARGEUR - MARGE - l_kpi, haut(78), 11, _c(GRIS),
               gras=True, largeur=l_kpi, droite=True)
        _texte(("+" if semaine > 0 else "−") + _sous(abs(semaine)),
               LARGEUR - MARGE - l_kpi, haut(112), 28, _c(JADE),
               gras=True, largeur=l_kpi, droite=True)
    _texte("TOTAL", x_kpi, haut(78), 11, _c(GRIS), gras=True,
           largeur=l_kpi, droite=True)
    _texte(_sous(total), x_kpi, haut(112), 28, _c(ENCRE), gras=True,
           largeur=l_kpi, droite=True)

    # Colonnes
    x_rang, x_av = MARGE, MARGE + 66
    x_nom = x_av + 56
    l_mt = 190
    x_mt = LARGEUR - MARGE - l_mt
    l_sem = 230
    if sem:
        x_mt = LARGEUR - MARGE - l_mt - l_sem
    y_t = haut(H_ENTETE - 30)
    _texte("RANG", x_rang, y_t, 12, _c(GRIS), gras=True, largeur=40, droite=True)
    _texte("CRÉATEUR", x_nom, y_t, 12, _c(GRIS), gras=True)
    _texte("MONTANT", x_mt, y_t, 12, _c(GRIS), gras=True, largeur=l_mt, droite=True)
    if sem:
        _texte(f"{jours} JOUR{'S' if jours > 1 else ''}",
               LARGEUR - MARGE - l_sem, y_t, 12, _c(GRIS),
               gras=True, largeur=l_sem, droite=True)

    # --- lignes ---
    for i, l in enumerate(lignes):
        y = H_ENTETE + i * H_LIGNE
        bas = haut(y + H_LIGNE - 8)
        podium = i < 3
        _pastille(NSMakeRect(MARGE - 14, bas, LARGEUR - 2 * (MARGE - 14), H_LIGNE - 10),
                  _c(OR, .10) if podium else _c("#ffffff", .55), 14)
        cy = bas + (H_LIGNE - 10) / 2

        _texte(f"{i + 1}", x_rang, cy - 11, 19, _c(OR) if podium else _c(GRIS),
               gras=True, largeur=40, droite=True)
        _avatar(avatars.get(l.get("id")), x_av, cy - 19, 38, l["nom"])
        _texte(l["nom"][:26], x_nom, cy - 11, 19, _c(ENCRE), gras=podium)
        _texte(_sous(l["montant"]), x_mt, cy - 12, 20, _c(ENCRE),
               gras=True, largeur=l_mt, droite=True)
        if sem and l.get("semaine"):
            v = l["semaine"]
            base = l["montant"] - v
            pc = (f" · {'+' if v > 0 else '−'}{abs(v) / base * 100:.0f} %"
                  if base > 0 else "")
            _texte(("+" if v > 0 else "−") + _sous(abs(v)) + pc,
                   LARGEUR - MARGE - l_sem, cy - 10, 15,
                   _c(JADE) if v > 0 else _c(GRIS), gras=True,
                   largeur=l_sem, droite=True)

    # --- pied ---
    if pied:
        _texte(pied, MARGE, haut(hauteur - 30), 14, _c(GRIS))

    NSGraphicsContext.restoreGraphicsState()
    data = rep.representationUsingType_properties_(NSPNGFileType, None)
    if data is None:
        return None
    Path(chemin).parent.mkdir(parents=True, exist_ok=True)
    data.writeToFile_atomically_(str(chemin), True)
    return str(chemin) if os.path.exists(chemin) else None


def _sous(n):
    return f"{int(round(n)):,}".replace(",", "\u00a0") + "\u00a0$"
