"""Ou vit le CODE, ou vivent les DONNEES.

Jusqu'ici les deux etaient le meme dossier: on lancait `python3 server.py`
a cote de `plateau.db`, de `clips/` et de `series/`. C'est toujours le cas
par defaut — rien ne change pour la copie de travail.

L'APP INSTALLEE les separe (`PLATEAU_DONNEES`, pose par le lanceur de
« Le plateau.app ») : le code est REMPLACE a chaque mise a jour, les
donnees ne doivent jamais l'etre. Une mise a jour qui ecrase un dossier
ou vivent aussi les campagnes, c'est une mise a jour qui finit par les
effacer.

Regle pour tout module : ce qui est LIVRE avec l'app (web/, fonts/,
modeles/) se lit dans CODE ; tout ce que l'app ECRIT (base, clips,
series, videos, caches, cles) va dans DONNEES.
"""
import os
from pathlib import Path

CODE = Path(__file__).resolve().parent

_d = os.environ.get("PLATEAU_DONNEES", "").strip()
DONNEES = Path(_d).expanduser().resolve() if _d else CODE
DONNEES.mkdir(parents=True, exist_ok=True)

# Vrai quand l'app tourne depuis l'installateur (code et donnees separes).
INSTALLEE = DONNEES != CODE

# WINDOWS : le serveur tourne sans console (pythonw), et chaque programme
# qu'il lance (ffmpeg, ffprobe, whisper — des dizaines par video) ouvrait
# alors SA fenetre noire, un clignotement par appel. CREATE_NO_WINDOW par
# defaut sur tout subprocess ; qui veut une fenetre (le Terminal de Claude)
# passe ses propres `creationflags`. Pose ici parce que chemins.py est
# importe par tous les modules, avant tout appel.
if os.name == "nt":
    import subprocess as _sp
    _init = _sp.Popen.__init__

    def _sans_fenetre(self, *a, **k):
        k.setdefault("creationflags", 0x08000000)       # CREATE_NO_WINDOW
        _init(self, *a, **k)
    _sp.Popen.__init__ = _sans_fenetre
