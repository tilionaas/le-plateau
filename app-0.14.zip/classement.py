#!/usr/bin/env python3
"""
Classement des membres, lu dans leurs pseudos Discord.
------------------------------------------------------
Aucune dependance: urllib et la bibliotheque standard, comme le reste.

Le suivi de l'argent se fait a la main et doit le rester: les gens
envoient une capture d'ecran dans un groupe, on verifie, puis on renomme
le membre en « Marc 1240$ ». Ce renommage EST la donnee — il n'y a pas de
seconde saisie a tenir a jour, pas de base a reconcilier, et une erreur se
corrige la ou on l'a faite.

Ce module ne fait donc que trois choses: lire les pseudos du serveur,
extraire le montant de chacun, et ecrire le tableau dans un salon. Le
tableau est TOUJOURS le meme message, modifie en place: un classement qui
se re-poste chaque jour noie le salon et oblige a chercher le dernier.

L'API REST suffit — pas de connexion permanente (« gateway »), donc pas de
bibliotheque de bot. Il faut en revanche que l'intention privilegiee
« Server Members » soit cochee sur le bot, sinon la liste des membres
revient vide (Discord repond 200, pas une erreur: voir `MembresRefuses`).
"""

import json
import re
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

API = "https://discord.com/api/v10"
# Discord coupe un message a 2000 caracteres. On garde de la marge pour
# l'en-tete et la ligne de date.
MAX_CAR = 1900
# Au-dela, le tableau ne tient plus dans un message et personne ne lit
# jusqu'en bas de toute facon.
MAX_LIGNES = 40


class ClassementError(Exception):
    """Erreur affichable telle quelle dans l'interface."""


class MembresRefuses(ClassementError):
    """Le bot n'a pas l'intention « Server Members »."""


# ------------------------------------------------------------------
# Appels Discord
# ------------------------------------------------------------------

def _api(methode, chemin, token, corps=None, timeout=20):
    data = json.dumps(corps).encode() if corps is not None else None
    req = urllib.request.Request(API + chemin, data=data, method=methode)
    req.add_header("Authorization", "Bot " + str(token).strip())
    req.add_header("User-Agent", "LePlateau (https://127.0.0.1, 1.0)")
    if data:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            brut = r.read().decode("utf-8", "replace")
        return json.loads(brut) if brut.strip() else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:400]
        try:
            msg = json.loads(detail).get("message") or detail
        except ValueError:
            msg = detail
        if e.code == 401:
            raise ClassementError("Jeton du bot refusé par Discord") from e
        if e.code == 403:
            raise ClassementError(f"Permission refusée : {msg}") from e
        if e.code == 404:
            raise ClassementError(f"Introuvable : {msg}") from e
        if e.code == 429:
            raise ClassementError("Discord limite les appels, réessaie dans une minute") from e
        raise ClassementError(f"Discord : {msg}") from e
    except (urllib.error.URLError, OSError) as e:
        raise ClassementError(f"Discord injoignable : {e}") from e


def membres(token, guild):
    """Tous les membres du serveur: [{'nom': pseudo affiche, 'id': ...}].

    Pagine par 1000, trie par identifiant: c'est le seul ordre que
    Discord accepte pour `after`."""
    out, apres = [], None
    for _ in range(20):                       # 20 000 membres, large
        q = "?limit=1000" + (f"&after={apres}" if apres else "")
        lot = _api("GET", f"/guilds/{guild}/members{q}", token)
        if not isinstance(lot, list):
            raise ClassementError("Réponse inattendue de Discord")
        for m in lot:
            u = m.get("user") or {}
            if u.get("bot"):
                continue
            # Le pseudo de serveur prime: c'est celui qu'on renomme. Les
            # deux suivants sont les retours de Discord quand le membre
            # n'a pas de pseudo propre a ce serveur.
            nom = m.get("nick") or u.get("global_name") or u.get("username") or ""
            # L'avatar sert a la carte en image. Celui du SERVEUR prime
            # (un membre peut en avoir un different ici), sinon celui du
            # compte, sinon rien et on dessinera une pastille de couleur.
            out.append({"id": u.get("id") or "", "nom": nom,
                        "avatar": m.get("avatar") or u.get("avatar") or "",
                        "avatar_serveur": bool(m.get("avatar"))})
        if len(lot) < 1000:
            break
        apres = (lot[-1].get("user") or {}).get("id")
        if not apres:
            break
        time.sleep(0.2)                       # on reste loin des limites
    if not out:
        raise MembresRefuses(
            "Aucun membre lu. Coche « Server Members Intent » sur le bot "
            "dans le portail Discord, puis réessaie.")
    return out


# ------------------------------------------------------------------
# Lire un montant dans un pseudo
# ------------------------------------------------------------------

# « Marc 1240$ », « Marc 1 240 $ », « Marc — $1,240 », « Marc 1.2k »,
# « Marc $4.1k + ». Tout ce qui suit le montant et n'est ni lettre ni
# chiffre est ignore: la convention du serveur ajoute un « + » apres les
# gros montants, et l'exiger en toute fin faisait disparaitre du classement
# exactement ceux qui gagnent le plus.
# Le montant est toujours en FIN de pseudo: c'est la convention de
# renommage, et la chercher ailleurs ferait passer « Marc 2.0 » pour un
# gain de 2 $.
_MONTANT = re.compile(r"""
    ^(?P<nom>.*?)                 # le nom, le plus court possible
    [\s |•\-–—:]*            # separateurs usuels avant le montant
    (?P<devise>[$€])?\s*
    (?P<val>\d{1,3}(?:[  .,]\d{3})*(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)
    \s*(?P<k>[kK])?\s*
    (?P<devise2>[$€])?
    [^\w]*$                      # decorations de fin: « + », emoji, points...
""", re.X)


def lire(pseudo):
    """(nom, montant) d'un pseudo, ou (pseudo, None) s'il n'en porte pas.

    Un pseudo sans montant n'est pas une erreur: la plupart des membres
    n'ont encore rien declare. Ils sortent simplement du classement."""
    texte = unicodedata.normalize("NFKC", str(pseudo or "")).strip()
    m = _MONTANT.match(texte)
    if not m:
        return texte, None
    nom = m.group("nom").strip("  |•-–—:")
    brut = m.group("val").replace(" ", "").replace(" ", "")
    # « 1,240 » est un millier a l'anglaise, « 1,24 » une decimale. Le
    # nombre de chiffres apres le separateur tranche.
    if "," in brut and "." in brut:
        brut = brut.replace(",", "")
    elif "," in brut:
        brut = brut.replace(",", "" if len(brut.split(",")[-1]) == 3 else ".")
    elif "." in brut and len(brut.split(".")[-1]) == 3:
        brut = brut.replace(".", "")
    try:
        val = float(brut)
    except ValueError:
        return texte, None
    if m.group("k"):
        val *= 1000
    # Un pseudo qui finit par un chiffre seul et petit (« Marc 2 ») est
    # presque toujours un homonyme numerote, pas un gain. Sans marque de
    # devise ni « k », on exige trois chiffres.
    if not (m.group("devise") or m.group("devise2") or m.group("k")) and val < 100:
        return texte, None
    return (nom or texte), val


def classer(gens):
    """[{'id','nom','montant'}] trie du plus gros au plus petit.

    `gens` = la sortie de `membres()`. Les pseudos sans montant sont
    ecartes. L'IDENTIFIANT est conserve: c'est la seule cle stable pour
    suivre quelqu'un d'une semaine a l'autre — le pseudo, lui, change a
    chaque mise a jour de son montant, c'est tout le principe."""
    out = []
    for g in gens:
        nom, montant = lire(g.get("nom"))
        if montant is None:
            continue
        out.append({"id": str(g.get("id") or ""), "nom": nom, "montant": montant,
                    "avatar": g.get("avatar") or "",
                    "avatar_serveur": bool(g.get("avatar_serveur"))})
    out.sort(key=lambda x: (-x["montant"], x["nom"].lower()))
    return out


# ------------------------------------------------------------------
# Le tableau
# ------------------------------------------------------------------

def _sous(n):
    """1240.0 -> « 1 240 $ ». Espace insecable fine: le montant ne doit
    jamais se couper en fin de ligne."""
    ent = int(round(n))
    txt = f"{ent:,}".replace(",", " ")
    return txt + " $"


def _delta(v):
    """« +320 $ », ou rien si la personne n'a pas bouge / est nouvelle."""
    if not v:
        return ""
    return ("+" if v > 0 else "−") + _sous(abs(v))


def tableau(lignes, titre="Classement"):
    """Le message, en bloc de code: c'est la seule facon d'aligner des
    colonnes dans Discord — le markdown normal n'a pas de tableau
    monospace, et les montants partiraient en escalier.

    Une colonne « semaine » apparait des qu'au moins une ligne porte un
    `semaine`. Avant la premiere semaine d'historique il n'y en a aucun:
    la colonne ne s'affiche pas plutot que de montrer une colonne de
    tirets, qui ferait croire a zero."""
    # Les montants a zero sortent de l'AFFICHAGE: la convention du serveur
    # met tout le monde a « $0 » au depart, et vingt-trois lignes de zeros
    # repoussent hors du tableau ceux qui vendent. Ils restent comptes en
    # bas, et surtout ils restent dans l'historique — sans quoi leur
    # premiere vente n'apparaitrait pas comme un gain de la semaine.
    zeros = sum(1 for l in lignes if l["montant"] <= 0)
    lignes = [l for l in lignes if l["montant"] > 0][:MAX_LIGNES]
    if not lignes:
        return (f"**{titre}**\n```\naucun montant déclaré pour l'instant\n```")
    larg_nom = max(6, min(22, max(len(l["nom"]) for l in lignes)))
    larg_val = max(len(_sous(l["montant"])) for l in lignes)
    sem = any(l.get("semaine") is not None for l in lignes)
    larg_sem = max([len(_delta(l.get("semaine"))) for l in lignes] + [8]) if sem else 0
    corps = []
    for i, l in enumerate(lignes, 1):
        nom = l["nom"][:larg_nom]
        bout = f"  {_delta(l.get('semaine')):>{larg_sem}}" if sem else ""
        corps.append(f"{i:>2}  {nom:<{larg_nom}}  {_sous(l['montant']):>{larg_val}}{bout}")
    if sem:
        corps.insert(0, f"{'':>2}  {'':<{larg_nom}}  {'':>{larg_val}}  {'7 jours':>{larg_sem}}")
    total = _sous(sum(l["montant"] for l in lignes))
    gains = [l["semaine"] for l in lignes if l.get("semaine") is not None]
    bout_t = f"  {_delta(sum(gains)):>{larg_sem}}" if sem and gains else ("  " + " " * larg_sem if sem else "")
    txt = (f"**{titre}**\n```\n" + "\n".join(corps)
           + f"\n{'':>2}  {'':<{larg_nom}}  {'─' * larg_val}"
           + f"\n{'':>2}  {'total':<{larg_nom}}  {total:>{larg_val}}{bout_t}\n```"
           + (f"\n-# {zeros} membre{'s' if zeros > 1 else ''} encore à 0 $" if zeros else ""))
    # Si ca deborde malgre le plafond de lignes (des noms tres longs), on
    # coupe par la fin plutot que de laisser Discord refuser le message.
    while len(txt) > MAX_CAR and len(corps) > 1:
        corps.pop()
        txt = f"**{titre}**\n```\n" + "\n".join(corps) + "\n```"
    return txt


def url_avatar(ligne, guild=None, taille=64):
    """Adresse de l'image de profil, ou None.

    Un avatar pose SUR LE SERVEUR vit a une autre adresse que celui du
    compte: ce sont deux ressources differentes chez Discord."""
    av = ligne.get("avatar")
    if not av or not ligne.get("id"):
        return None
    if ligne.get("avatar_serveur") and guild:
        return (f"https://cdn.discordapp.com/guilds/{guild}/users/"
                f"{ligne['id']}/avatars/{av}.png?size={taille}")
    return f"https://cdn.discordapp.com/avatars/{ligne['id']}/{av}.png?size={taille}"


def telecharger(url, timeout=12):
    """Octets d'une image, ou None. Un avatar manquant ne doit jamais
    empecher la carte de sortir."""
    try:
        req = urllib.request.Request(url)
        req.add_header("User-Agent", "LePlateau (https://127.0.0.1, 1.0)")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except (urllib.error.URLError, OSError):
        return None


def _multipart(champs, fichier):
    """Corps multipart ecrit a la main — Discord n'accepte un fichier que
    comme ca, et urllib ne sait pas le fabriquer."""
    import uuid
    front = "----leplateau" + uuid.uuid4().hex
    corps = b""
    for cle, val in champs.items():
        corps += (f"--{front}\r\nContent-Disposition: form-data; name=\"{cle}\"\r\n"
                  f"Content-Type: application/json\r\n\r\n").encode()
        corps += json.dumps(val).encode() + b"\r\n"
    if fichier:
        nom, octets = fichier
        corps += (f"--{front}\r\nContent-Disposition: form-data; "
                  f"name=\"files[0]\"; filename=\"{nom}\"\r\n"
                  f"Content-Type: image/png\r\n\r\n").encode()
        corps += octets + b"\r\n"
    corps += f"--{front}--\r\n".encode()
    return corps, "multipart/form-data; boundary=" + front


def _api_fichier(methode, chemin, token, champs, fichier, timeout=60):
    req = urllib.request.Request(API + chemin, method=methode)
    corps, ctype = _multipart(champs, fichier)
    req.data = corps
    req.add_header("Authorization", "Bot " + str(token).strip())
    req.add_header("Content-Type", ctype)
    req.add_header("User-Agent", "LePlateau (https://127.0.0.1, 1.0)")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            brut = r.read().decode("utf-8", "replace")
        return json.loads(brut) if brut.strip() else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:400]
        try:
            msg = json.loads(detail).get("message") or detail
        except ValueError:
            msg = detail
        raise ClassementError(f"Discord : {msg}") from e
    except (urllib.error.URLError, OSError) as e:
        raise ClassementError(f"Discord injoignable : {e}") from e


def publier_image(token, salon, png, message_id=None, texte=""):
    """Poste (ou remplace) la carte. Renvoie l'identifiant du message.

    `attachments: []` dans la charge utile est obligatoire a la
    modification: sans lui Discord GARDE l'ancienne image et ajoute la
    nouvelle, et le message grossit d'une carte par jour."""
    octets = Path(png).read_bytes()
    champs = {"payload_json": {"content": texte, "attachments": []}}
    if message_id:
        try:
            r = _api_fichier("PATCH", f"/channels/{salon}/messages/{message_id}",
                             token, champs, ("classement.png", octets))
            return str(r.get("id") or message_id)
        except ClassementError:
            pass                              # message efface: on en refait un
    r = _api_fichier("POST", f"/channels/{salon}/messages", token, champs,
                     ("classement.png", octets))
    ident = r.get("id")
    if not ident:
        raise ClassementError("Discord n'a pas renvoyé d'identifiant de message")
    return str(ident)


def publier(token, salon, texte, message_id=None):
    """Ecrit le tableau dans le salon. Renvoie l'identifiant du message.

    Avec `message_id`, le message existant est MODIFIE: le classement
    reste a la meme place et le salon ne se remplit pas d'historique. Si
    ce message a ete supprime a la main, on en recree un."""
    if message_id:
        try:
            r = _api("PATCH", f"/channels/{salon}/messages/{message_id}",
                     token, {"content": texte})
            return str(r.get("id") or message_id)
        except ClassementError:
            pass                              # efface: on repart a neuf
    r = _api("POST", f"/channels/{salon}/messages", token, {"content": texte})
    ident = r.get("id")
    if not ident:
        raise ClassementError("Discord n'a pas renvoyé d'identifiant de message")
    return str(ident)
