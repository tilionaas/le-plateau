#!/usr/bin/env python3
"""
Detourer la personne d'un clip, sans fond vert.
-----------------------------------------------
macOS sait le faire tout seul: le framework Vision contient un modele de
segmentation de personne (celui de Portrait/Center Stage). Aucun paquet a
installer, la regle du zero dependance tient — on charge le framework
systeme a la main, PyObjC n'expose pas Vision par defaut.

Le resultat est une VIDEO DE MASQUE en niveaux de gris (blanc = la
personne), de meme duree et meme cadence que la source. ffmpeg la
recolle ensuite en canal alpha (`alphamerge`) pour incruster le clip
par-dessus un autre.

Mesure (M2, un clip 1080x1920):
  qualite `accurate` : 183 ms/image, masque a la taille de la source
  qualite `balanced` :  14 ms/image, masque 384x512 etire a la source
  qualite `fast`     : inutilisable, ne garde que la tete
`balanced` est le reglage par defaut: 13 fois plus rapide, et le masque
sert a une incrustation de 35 % de large, ou personne ne voit la
difference. Un clip de 4 s en 60 im/s prend ~4 s.

Le masque est mis en cache (cle chemin|mtime|taille, comme les autres
caches du projet): un clip qui revient dans dix variantes n'est detoure
qu'une fois.
"""

import hashlib
import json
import os
import subprocess
import threading
from pathlib import Path

from chemins import DONNEES as ROOT
CACHE_DIR = ROOT / ".detourages"

# Largeur a laquelle on analyse. Vision redimensionne de toute facon en
# interne; descendre sous 540 ne change ni la vitesse ni la qualite du
# masque, mais 540 garde des contours propres apres agrandissement.
LARGEUR_ANALYSE = 540

_verrou = threading.Lock()
_vision = {}


def _charger_vision():
    """Charge Vision une fois pour toutes. None si indisponible."""
    if _vision:
        return _vision.get("req")
    try:
        import objc
        from Quartz import CIContext
        ns = {}
        objc.loadBundle("Vision", ns,
                        bundle_path="/System/Library/Frameworks/Vision.framework")
        _vision["VNGeneratePersonSegmentationRequest"] = ns["VNGeneratePersonSegmentationRequest"]
        _vision["VNImageRequestHandler"] = ns["VNImageRequestHandler"]
        _vision["ctx"] = CIContext.contextWithOptions_(None)
        _vision["req"] = True
    except Exception:                                       # noqa: BLE001
        _vision["req"] = None
    return _vision.get("req")


def disponible():
    return bool(_charger_vision())


def _masque_image(rgb, w, h):
    """Masque (bytes, largeur, hauteur) d'une image RGB brute."""
    from Quartz import (CGColorSpaceCreateDeviceRGB, CGDataProviderCreateWithData,
                        CGImageCreate, CIImage, kCGBitmapByteOrderDefault,
                        kCGImageAlphaNone, kCGRenderingIntentDefault,
                        CVPixelBufferLockBaseAddress, CVPixelBufferUnlockBaseAddress,
                        CVPixelBufferGetBaseAddress, CVPixelBufferGetBytesPerRow,
                        CVPixelBufferGetWidth, CVPixelBufferGetHeight)
    fournisseur = CGDataProviderCreateWithData(None, rgb, len(rgb), None)
    cg = CGImageCreate(w, h, 8, 24, w * 3, CGColorSpaceCreateDeviceRGB(),
                       kCGBitmapByteOrderDefault | kCGImageAlphaNone,
                       fournisseur, None, False, kCGRenderingIntentDefault)
    req = _vision["VNGeneratePersonSegmentationRequest"].alloc().init()
    req.setQualityLevel_(1)                 # balanced
    handler = _vision["VNImageRequestHandler"].alloc().initWithCGImage_options_(cg, {})
    handler.performRequests_error_([req], None)
    res = req.results()
    if not res:
        return None, 0, 0
    pb = res[0].pixelBuffer()
    CVPixelBufferLockBaseAddress(pb, 1)
    try:
        mw, mh = CVPixelBufferGetWidth(pb), CVPixelBufferGetHeight(pb)
        pas = CVPixelBufferGetBytesPerRow(pb)
        base = CVPixelBufferGetBaseAddress(pb)
        brut = base.as_buffer(pas * mh)
        # Le tampon peut avoir des octets de bourrage en fin de ligne.
        if pas == mw:
            data = bytes(brut)
        else:
            data = b"".join(bytes(brut[y * pas:y * pas + mw]) for y in range(mh))
    finally:
        CVPixelBufferUnlockBaseAddress(pb, 1)
    return data, mw, mh


def tete(path, debut=0.0, fin=None, pas=0.4):
    """Ou est la tete entre `debut` et `fin`, en coordonnees 0..1.

    Renvoie (haut, centre_x): `haut` = le point le plus haut atteint par la
    personne sur l'extrait (0 = bord haut de l'image), `centre_x` = le
    milieu de sa largeur. Sert a poser une image AU-DESSUS de la tete sans
    la couvrir, meme si la personne bouge pendant la phrase.

    Une image toutes les 0,4 s suffit: le haut du crane ne bouge pas par
    a-coups, et analyser 60 images par seconde couterait 25 fois plus cher
    pour le meme resultat. Tout l'extrait est decode en UN seul appel a
    ffmpeg — un processus par image coutait 0,5 s piece."""
    if not disponible():
        return None
    infos = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
         "stream=width,height", "-of", "json", str(path)],
        capture_output=True, text=True)
    try:
        st = json.loads(infos.stdout)["streams"][0]
        src_w, src_h = int(st["width"]), int(st["height"])
    except (ValueError, KeyError, IndexError):
        return None
    w = LARGEUR_ANALYSE if src_w > LARGEUR_ANALYSE else src_w
    h = int(round(src_h * w / src_w / 2)) * 2

    cmd = ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, debut):.3f}"]
    if fin is not None and fin > debut:
        cmd += ["-t", f"{fin - debut:.3f}"]
    cmd += ["-i", str(path), "-an", "-vf", f"fps=1/{pas},scale={w}:{h}",
            "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    r = subprocess.run(cmd, capture_output=True)
    taille = w * h * 3
    if r.returncode != 0 or len(r.stdout) < taille:
        return None

    haut, gauche, droite, vu = 1.0, 1.0, 0.0, False
    for i in range(len(r.stdout) // taille):
        data, mw, mh = _masque_image(r.stdout[i * taille:(i + 1) * taille], w, h)
        if data is None:
            continue
        y0, x0, x1 = _bornes(data, mw, mh)
        if y0 is None:
            continue
        vu = True
        haut = min(haut, y0 / mh)
        gauche = min(gauche, x0 / mw)
        droite = max(droite, x1 / mw)
    if not vu:
        return None
    return haut, (gauche + droite) / 2


def _bornes(data, w, h):
    """(premiere ligne non vide, x min, x max) du masque."""
    seuil = 128
    y0 = None
    xmin, xmax = w, 0
    for y in range(h):
        ligne = data[y * w:(y + 1) * w]
        if max(ligne) < seuil:
            continue
        if y0 is None:
            y0 = y
        for x, v in enumerate(ligne):
            if v >= seuil:
                if x < xmin:
                    xmin = x
                if x > xmax:
                    xmax = x
        # Une fois la tete trouvee, quelques lignes suffisent pour la
        # largeur du haut du corps: inutile de parcourir tout le buste.
        if y - y0 > h // 6:
            break
    return (y0, xmin, xmax) if y0 is not None else (None, None, None)


def _cle(path):
    st = os.stat(path)
    return hashlib.sha1(f"{path}|{st.st_mtime}|{st.st_size}|v1".encode()).hexdigest()[:20]


def masque(path, progress=None):
    """Video de masque du clip, ou None si le detourage est impossible.

    Le fichier est garde en cache: meme clip, meme masque."""
    try:
        cache = CACHE_DIR / (_cle(path) + ".mp4")
    except OSError:
        return None
    with _verrou:
        if cache.exists() and cache.stat().st_size > 0:
            return str(cache)
        if not disponible():
            return None
        CACHE_DIR.mkdir(exist_ok=True)
        tmp = cache.with_suffix(".part.mp4")
        ok = _fabriquer(path, tmp, progress)
        if not ok:
            tmp.unlink(missing_ok=True)
            return None
        os.replace(str(tmp), str(cache))
        return str(cache)


def _fabriquer(src, dst, progress=None):
    from Quartz import CIImage
    infos = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
         "stream=width,height,r_frame_rate,nb_frames", "-of", "json", str(src)],
        capture_output=True, text=True)
    try:
        st = json.loads(infos.stdout)["streams"][0]
        num, den = (st.get("r_frame_rate") or "30/1").split("/")
        fps = float(num) / float(den or 1)
        src_w, src_h = int(st["width"]), int(st["height"])
    except (ValueError, KeyError, IndexError, ZeroDivisionError):
        return False

    w = LARGEUR_ANALYSE if src_w > LARGEUR_ANALYSE else src_w
    h = int(round(src_h * w / src_w / 2)) * 2

    lecteur = subprocess.Popen(
        ["ffmpeg", "-v", "error", "-i", str(src), "-an",
         "-vf", f"scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
        stdout=subprocess.PIPE)
    ecrivain = None
    n = 0
    try:
        taille = w * h * 3
        while True:
            brut = lecteur.stdout.read(taille)
            if not brut or len(brut) < taille:
                break
            data, mw, mh = _masque_image(brut, w, h)
            if data is None:
                # Aucune personne trouvee: image entierement transparente.
                data, mw, mh = b"\x00" * (w * h), w, h
            if ecrivain is None:
                # La taille du masque est fixee par Vision (384x512 en
                # `balanced`), pas par la source: on l'etire ensuite a la
                # taille du clip, ce que ffmpeg fait au montage.
                ecrivain = subprocess.Popen(
                    ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "gray",
                     "-s", f"{mw}x{mh}", "-r", f"{fps:.6f}", "-i", "-",
                     "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                     "-pix_fmt", "yuv420p", str(dst)],
                    stdin=subprocess.PIPE)
            ecrivain.stdin.write(data)
            n += 1
            if progress and n % 30 == 0:
                progress(n)
    finally:
        try:
            lecteur.stdout.close()
        except OSError:
            pass
        lecteur.wait()
        if ecrivain is not None:
            try:
                ecrivain.stdin.close()
            except OSError:
                pass
            ecrivain.wait()
    return n > 0 and Path(dst).exists() and Path(dst).stat().st_size > 0
