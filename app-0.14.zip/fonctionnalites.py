"""MES FONCTIONNALITES : ce que la personne ajoute a SON app en la decrivant.

Demande du 21/11 : « que les gens puissent modifier leur propre
fonctionnalite… modifiable a partir de l'app ». Le Monteur IA ne sait
regler que ce qui existe ; quand une demande depasse l'app (« une banque
d'images quand tel mot est dit », un nouvel effet…), c'est ici qu'on la
CONSTRUIT : Claude Code tourne dans le dossier du code, avec le droit de
lire et d'ecrire des fichiers et rien d'autre (pas de terminal), sur
l'abonnement Claude de la personne — comme le reste de l'IA du plateau.

Trois filets, parce que c'est du code qui s'ecrit tout seul chez quelqu'un
qui ne le lira pas :
  1. une PHOTO des fichiers du code avant chaque construction ;
  2. une VERIFICATION apres : le Python se compile, le JavaScript de
     l'interface passe `checkSyntax` de JavaScriptCore (dans macOS) ; une
     erreur repart a Claude une fois, puis on remet la photo ;
  3. « Annuler la derniere » remet la photo a la main, aussi depuis
     /secours — une page servie par le serveur seul, qui marche meme si
     l'interface est cassee.

Les MISES A JOUR remplacent le code. Ce qu'on garde, c'est la DEMANDE (ce
registre, dans les donnees) : apres une mise a jour, « Refaire » la
redonne a Claude sur la nouvelle version, avec l'ancien fichier modifie
pour reference. Refaire depuis la description tient mieux qu'un melange
de deux versions de code.
"""
import json
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from pathlib import Path

import ia
import maj
from chemins import CODE, DONNEES

REGISTRE = DONNEES / "fonctionnalites.json"
PHOTOS = DONNEES / ".fonctionnalites"
JSC = "/System/Library/Frameworks/JavaScriptCore.framework/Versions/Current/Helpers/jsc"
# Le code de l'app, et seulement lui : la copie de travail a ses donnees
# dans le meme dossier (clips/, series/…), elles ne sont ni photographiees
# ni regardees.
MOTIFS = ("*.py", "web/*.html", "CLAUDE*.md")
DELAI = 25 * 60
_verrou = threading.Lock()


class Erreur(Exception):
    pass


# ------------------------------------------------------------------
# Le registre
# ------------------------------------------------------------------
def liste():
    try:
        return json.loads(REGISTRE.read_text("utf-8"))
    except (OSError, ValueError):
        return []


def _ecrire(lst):
    tmp = REGISTRE.with_suffix(".tmp")
    tmp.write_text(json.dumps(lst, ensure_ascii=False, indent=1), "utf-8")
    tmp.replace(REGISTRE)


def a_refaire():
    """Celles qui ont ete construites sur une autre version du code : une
    mise a jour est passee dessus."""
    v = maj.version()
    return [f for f in liste() if f.get("version") != v and not f.get("retiree")]


# ------------------------------------------------------------------
# Photos du code
# ------------------------------------------------------------------
def _fichiers():
    out = {}
    for m in MOTIFS:
        for p in CODE.glob(m):
            if p.is_file() and ".bak" not in p.name:
                out[str(p.relative_to(CODE))] = p
    return out


def _empreintes():
    import hashlib
    return {r: hashlib.sha1(p.read_bytes()).hexdigest() for r, p in _fichiers().items()}


def _photographier(fid):
    d = PHOTOS / fid
    if d.exists():
        shutil.rmtree(d)
    for r, p in _fichiers().items():
        dest = d / r
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
    (d / ".liste.json").write_text(json.dumps(sorted(_fichiers())), "utf-8")
    return d


def _remettre(fid):
    """Remet le code tel qu'il etait avant la construction `fid` : les
    fichiers changes reprennent leur contenu, les fichiers crees partent."""
    d = PHOTOS / fid
    if not d.is_dir():
        raise Erreur("Plus de photo pour revenir en arrière")
    avant = set(json.loads((d / ".liste.json").read_text("utf-8")))
    for r, p in _fichiers().items():
        if r not in avant:
            p.unlink()
    for r in avant:
        src = d / r
        if src.is_file():
            (CODE / r).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, CODE / r)


# ------------------------------------------------------------------
# Verifier ce que Claude a ecrit
# ------------------------------------------------------------------
def verifier(changes):
    """-> texte de l'erreur, ou "" si tout passe."""
    for r in changes:
        p = CODE / r
        if not p.is_file():
            continue
        if r.endswith(".py"):
            try:
                compile(p.read_text("utf-8"), str(p), "exec")
            except SyntaxError as e:
                return f"{r}, ligne {e.lineno} : {e.msg}"
        elif r.endswith(".html") and Path(JSC).is_file():
            err = _verifier_js(p)
            if err:
                return f"{r} : {err}"
    return ""


def _verifier_js(p):
    """Le JavaScript des <script> de la page, passe a JavaScriptCore. Sans
    lui (Windows), seul le Python est verifie."""
    import re
    html = p.read_text("utf-8")
    blocs = re.findall(r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", html, re.S | re.I)
    if not blocs:
        return ""
    with tempfile.TemporaryDirectory() as t:
        for i, b in enumerate(blocs):
            f = Path(t) / f"s{i}.js"
            f.write_text(b, "utf-8")
            r = subprocess.run([JSC, "-e", f'try{{checkSyntax("{f}");print("ok")}}'
                                f'catch(e){{print("ERR "+e)}}'],
                               capture_output=True, text=True, timeout=60)
            sortie = (r.stdout or "").strip()
            if sortie.startswith("ERR"):
                return "JavaScript — " + sortie[4:][:200]
    return ""


# ------------------------------------------------------------------
# Claude Code, avec le droit d'ecrire
# ------------------------------------------------------------------
CONSIGNES = """Tu modifies l'app « Le plateau », dans ce dossier, pour la personne qui
l'utilise. Elle n'est pas développeuse : elle décrit ce qu'elle veut, toi
tu l'écris. Lis d'abord CLAUDE.md : il explique l'app et ses règles.

Règles :
- Python 3 bibliothèque standard seulement, aucune installation (ni pip,
  ni Homebrew). L'interface est TOUTE dans web/index.html, en JavaScript
  écrit à la main.
- Le plus petit changement qui fait ce qui est demandé. Ne réécris pas ce
  qui marche, ne change pas le style de l'app.
- Ne touche jamais aux données (plateau.db, clips/, series/, output/,
  les fichiers .json et .txt de clés) ni au dossier outils/.
- Un réglage nouveau d'une série va dans son `settings` (et dans
  `remixer.DEFAULT_SETTINGS` avec une valeur qui ne change RIEN aux séries
  existantes) ; une option d'une catégorie va sur la catégorie (slot).
- Si tu ajoutes un RÉGLAGE de montage, rends-le aussi demandable en mots :
  ajoute-le à `ia.POUVOIRS` (ce que le plateau sait faire), et au Monteur
  IA (`SCHEMA_PARLER` dans ia.py, `ia_traduire` dans server.py) — sinon
  « Décris le montage » et le Monteur le croiront absent.
- Mets un commentaire en français au-dessus de ce que tu ajoutes :
  « Fonctionnalité ajoutée : … ».
- Tu n'as pas de terminal : l'app vérifie elle-même que le code compile.

Quand tu as fini, réponds en 1 à 3 phrases simples, en français : ce que tu
as ajouté et OÙ le trouver dans l'app (quel écran, quel bouton)."""


def _claude(texte, dit):
    b = ia.binaire()
    if not b:
        raise Erreur(ia.disponible()[1])
    cmd = [b, "-p", texte, "--output-format", "stream-json", "--verbose",
           "--model", ia.SOIGNE, "--permission-mode", "acceptEdits",
           "--tools", "Read,Edit,Write,Glob,Grep",
           "--allowedTools", "Read,Edit,Write,Glob,Grep",
           "--setting-sources", "project", "--strict-mcp-config",
           "--no-session-persistence"]
    p = subprocess.Popen(cmd, cwd=str(CODE), stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True)
    minuteur = threading.Timer(DELAI, p.kill)
    minuteur.start()
    fin, verbes = None, {"Read": "Lit", "Edit": "Modifie", "Write": "Écrit",
                         "Glob": "Cherche", "Grep": "Cherche"}
    try:
        for ligne in p.stdout:
            try:
                d = json.loads(ligne)
            except ValueError:
                continue
            if d.get("type") == "assistant":
                for c in (d.get("message") or {}).get("content") or []:
                    if c.get("type") == "tool_use":
                        inp = c.get("input") or {}
                        cible = Path(str(inp.get("file_path") or inp.get("pattern") or "")).name
                        dit(f"{verbes.get(c.get('name'), c.get('name'))} {cible}".strip() + "…")
            elif d.get("type") == "result":
                fin = d
        p.wait()
    finally:
        minuteur.cancel()
    if not fin:
        err = (p.stderr.read() if p.stderr else "").strip()[-300:]
        raise Erreur(ia._traduire(err) or "Claude Code s'est arrêté sans répondre")
    if fin.get("is_error"):
        raise Erreur(ia._traduire(str(fin.get("result") or "")) or "Erreur de Claude Code")
    return str(fin.get("result") or "").strip()


def _travailler(fid, texte, dit):
    """Construit, verifie, et revient en arriere si ca ne passe pas.
    -> (reponse de Claude, fichiers changes)."""
    _photographier(fid)
    avant = _empreintes()
    try:
        dit("Claude lit l'app…")
        rep = _claude(texte, dit)
        apres = _empreintes()
        changes = sorted(r for r in set(avant) | set(apres) if avant.get(r) != apres.get(r))
        err = verifier(changes)
        if err:
            dit("Une erreur dans le code — Claude la corrige…")
            rep = _claude(texte + "\n\nTu viens de faire ce changement, mais le code ne "
                          "passe pas la vérification :\n" + err + "\nCorrige-le.", dit)
            apres = _empreintes()
            changes = sorted(r for r in set(avant) | set(apres) if avant.get(r) != apres.get(r))
            err = verifier(changes)
            if err:
                raise Erreur("Le code écrit ne marche pas (" + err + ") — rien n'a changé")
    except Exception:
        _remettre(fid)
        raise
    return rep, changes


# ------------------------------------------------------------------
# Ce que l'app appelle
# ------------------------------------------------------------------
def construire(demande, dit, fid=None):
    """Ajoute (ou, avec `fid`, MODIFIE) une fonctionnalite.
    -> {"id", "reponse", "redemarrer"}."""
    demande = str(demande or "").strip()[:4000]
    if not demande:
        raise Erreur("Décris ce que tu veux")
    if not _verrou.acquire(blocking=False):
        raise Erreur("Une construction est déjà en cours")
    try:
        lst = liste()
        ancienne = next((f for f in lst if f["id"] == fid), None) if fid else None
        nid = uuid.uuid4().hex[:10]
        if ancienne:
            texte = (CONSIGNES + "\n\nUne fonctionnalité que tu as ajoutée avant :\n« "
                     + ancienne["demande"] + " »\n\nLa personne veut la CHANGER ainsi :\n"
                     + demande)
        else:
            texte = CONSIGNES + "\n\nCe que la personne veut :\n" + demande
        rep, changes = _travailler(nid, texte, dit)
        if not changes:
            raise Erreur(rep or "Claude n'a rien changé")
        f = {"id": ancienne["id"] if ancienne else nid,
             "photo": nid,
             "demande": (ancienne["demande"] + "\nPuis : " + demande) if ancienne else demande,
             "reponse": rep[:1500], "fichiers": changes,
             "version": maj.version(), "date": time.strftime("%Y-%m-%d %H:%M")}
        if ancienne:
            # « Annuler la derniere » apres une modification remet la
            # fonctionnalite d'avant, pas rien du tout.
            f["avant"] = {k: v for k, v in ancienne.items() if k != "avant"}
        lst = [x for x in lst if x["id"] != f["id"]] + [f]
        _ecrire(lst)
        return {"id": f["id"], "reponse": rep,
                "redemarrer": any(r.endswith(".py") for r in changes)}
    finally:
        _verrou.release()


def retirer(fid, dit):
    """Claude enleve la fonctionnalite du code. (Annuler la derniere remet
    une photo ; ici on peut retirer une ancienne sans perdre celles d'apres.)"""
    if not _verrou.acquire(blocking=False):
        raise Erreur("Une construction est déjà en cours")
    try:
        lst = liste()
        f = next((x for x in lst if x["id"] == fid), None)
        if not f:
            raise Erreur("Fonctionnalité introuvable")
        nid = uuid.uuid4().hex[:10]
        rep, changes = _travailler(nid, CONSIGNES + "\n\nRETIRE proprement cette "
                                   "fonctionnalité, que tu avais ajoutée (cherche les "
                                   "commentaires « Fonctionnalité ajoutée ») :\n« "
                                   + f["demande"] + " »\nRemets l'app comme avant elle, "
                                   "sans toucher au reste.", dit)
        _ecrire([x for x in lst if x["id"] != fid])
        return {"reponse": rep, "redemarrer": any(r.endswith(".py") for r in changes)}
    finally:
        _verrou.release()


def annuler_derniere():
    """Remet le code d'avant la derniere construction. Sans Claude : c'est
    le bouton de secours."""
    with _verrou:
        lst = liste()
        if not lst:
            raise Erreur("Rien à annuler")
        f = lst[-1]
        _remettre(f["photo"])
        _ecrire(lst[:-1] + ([f["avant"]] if f.get("avant") else []))
        return {"retiree": f["demande"][:200], "redemarrer": True}


def refaire(dit):
    """Apres une mise a jour : chaque fonctionnalite construite sur une
    autre version est redonnee a Claude, avec l'ancien fichier modifie
    pour reference (« Mes modifications »)."""
    faites, ratees = 0, []
    for f in a_refaire():
        garde = sorted((DONNEES / "Mes modifications").glob("*"))
        ref = f"\nL'ancien code modifié est dans « {garde[-1]} » si besoin." if garde else ""
        dit(f"Refait : {f['demande'][:60]}…")
        if not _verrou.acquire(blocking=False):
            raise Erreur("Une construction est déjà en cours")
        try:
            nid = uuid.uuid4().hex[:10]
            _, changes = _travailler(nid, CONSIGNES + "\n\nL'app vient d'être mise à jour. "
                                     "Cette fonctionnalité existait sur l'ancienne version ; "
                                     "REFAIS-LA sur celle-ci (si elle existe déjà, ne fais "
                                     "rien) :\n« " + f["demande"] + " »" + ref, dit)
            lst = liste()
            for x in lst:
                if x["id"] == f["id"]:
                    x.update(version=maj.version(), photo=nid,
                             fichiers=sorted(set(x.get("fichiers") or []) | set(changes)))
            _ecrire(lst)
            faites += 1
        except Exception as e:                                  # noqa: BLE001
            ratees.append(f"{f['demande'][:60]} ({e})")
        finally:
            _verrou.release()
    return {"faites": faites, "ratees": ratees, "redemarrer": True}
