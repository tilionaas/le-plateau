"""L'IA du plateau — Claude Code, celui qui est DEJA sur la machine.

Pas de cle d'API ni de SDK: on appelle le programme `claude` comme on
appelle `ffmpeg` ou `whisper-cli`. Il passe par le compte Claude de la
personne (son abonnement), et la regle « zero dependance » tient: rien a
installer cote Python.

Mesure le 09/11 sur le Mac de Tilio: une image + une question, 3,9 s de
bout en bout, reponse JSON validee par un schema. Ce qui coute ce temps,
c'est le DEMARRAGE de Claude Code, pas la reponse: on regroupe donc les
questions (un appel pour trier six clips, pas six appels).

Trois choix qui comptent, tous dans `demander`:
  --system-prompt   remplace le prompt de Claude Code (~20 000 jetons) par
                    le notre (~300). Sans ca, chaque question puisait dans
                    les limites de l'abonnement pour rien.
  --tools ""        aucun outil: Claude ne lit pas le disque, ne lance
                    rien. Il regarde ce qu'on lui donne et repond.
  --setting-sources "" et un dossier de travail neutre: le CLAUDE.md du
                    projet et celui de l'utilisateur ne sont pas charges —
                    ils parlent a un developpeur, pas a l'assistant.
Les images partent DANS le message (`--input-format stream-json`), en
base64: pas besoin d'ouvrir l'outil de lecture de fichiers, et pas de
tour de boucle par image.
"""
import base64
import json
import math
import os
import re
import shutil
import subprocess
import time
import tempfile
from pathlib import Path


class IAError(Exception):
    pass


# Ou chercher `claude` quand le PATH du serveur ne le voit pas: lance
# depuis le Finder (un .command), le PATH est celui de launchd, sans
# ~/.local/bin.
CANDIDATS = ("~/.local/bin/claude", "~/.local/bin/claude.exe",
             "~/AppData/Roaming/npm/claude.cmd", "/opt/homebrew/bin/claude",
             "/usr/local/bin/claude", "~/.claude/local/claude")

# Deux modeles, choisis par tache. Haiku pour le tri et les questions:
# rapide, et ca menage les limites de l'abonnement. Sonnet pour monter une
# campagne: un seul appel, et c'est lui qui decide de toute la recette.
RAPIDE = "haiku"
# OPUS pour tout ce qui decide d'un montage (23/11, « utilise opus je
# pense ») : lire l'exemple, ranger les clips, le Monteur, la relecture,
# les bons moments. C'est le modele le plus fort de l'abonnement, et la
# difference avec une conversation Claude venait en partie de la. Il
# puise plus vite dans les limites, et tous les forfaits ne le donnent
# pas : s'il est refuse, `demander` repart sur SECOURS et s'en souvient
# une heure (`_SANS_SOIGNE`) pour ne pas payer l'echec a chaque question.
SOIGNE = "opus"
SECOURS = "sonnet"
_SANS_SOIGNE = [0.0]

SYSTEME = (
    "Tu es l'assistant du plateau, une app locale de création de vidéos UGC "
    "(TikTok, Reels). Tu parles français québécois simple, direct, sans "
    "jargon technique: l'utilisateur n'est pas développeur. Tu ne promets "
    "jamais une fonction qui n'existe pas dans le plateau.")

# Taille des images envoyees. 360 px de large suffisent pour reconnaitre
# un plan et lire un texte a l'ecran, et une image de 360 x 640 coute
# ~300 jetons: trente plans tiennent dans un seul message.
LARGEUR = 360


def binaire():
    b = shutil.which("claude")
    if b:
        return b
    for c in CANDIDATS:
        p = Path(os.path.expanduser(c))
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    return None


def disponible():
    """(oui/non, raison). Ne lance rien: savoir si Claude Code est
    CONNECTE coute un appel, on l'apprend au premier vrai."""
    if not binaire():
        return False, ("Claude Code n'est pas installé sur cet ordinateur "
                       "(claude.com/claude-code)")
    return True, ""


def _neutre():
    d = Path(tempfile.gettempdir()) / "plateau-ia"
    d.mkdir(exist_ok=True)
    return str(d)


def demander(texte, images=(), schema=None, modele=RAPIDE, systeme=None,
             delai=300):
    """Voir `_demander`. Ici seulement le repli : SOIGNE refuse (forfait
    sans Opus, limite d'Opus atteinte, panne) -> la meme question a
    SECOURS. Un delai depasse ne se rejoue pas : ce serait attendre deux
    fois."""
    if modele != SOIGNE or SOIGNE == SECOURS:
        return _demander(texte, images, schema, modele, systeme, delai)
    if time.time() < _SANS_SOIGNE[0]:
        return _demander(texte, images, schema, SECOURS, systeme, delai)
    try:
        return _demander(texte, images, schema, SOIGNE, systeme, delai)
    except IAError as e:
        if "à temps" in str(e):
            raise
        r = _demander(texte, images, schema, SECOURS, systeme, delai)
        _SANS_SOIGNE[0] = time.time() + 3600     # SECOURS a marche : c'etait bien Opus
        return r


def _demander(texte, images=(), schema=None, modele=RAPIDE, systeme=None,
              delai=300):
    """Une question a Claude. `images` = [(legende, octets jpeg)], posees
    AVANT le texte, chacune precedee de sa legende: « Plan 3 (2,4 s) »
    ne se devine pas sur l'image. Rend le JSON valide par `schema`, ou le
    texte de la reponse sans schema."""
    b = binaire()
    if not b:
        raise IAError(disponible()[1])
    contenu = []
    for legende, octets in images:
        if not octets:
            continue
        if legende:
            contenu.append({"type": "text", "text": legende})
        contenu.append({"type": "image", "source": {
            "type": "base64", "media_type": "image/jpeg",
            "data": base64.b64encode(octets).decode()}})
    contenu.append({"type": "text", "text": texte})
    msg = {"type": "user", "message": {"role": "user", "content": contenu}}
    cmd = [b, "-p", "--output-format", "stream-json", "--verbose",
           "--input-format", "stream-json", "--model", modele,
           "--system-prompt", systeme or SYSTEME,
           "--tools", "", "--setting-sources", "", "--strict-mcp-config",
           "--no-session-persistence"]
    if schema:
        cmd += ["--json-schema", json.dumps(schema)]
    try:
        p = subprocess.run(cmd, input=json.dumps(msg) + "\n", text=True,
                           capture_output=True, timeout=delai, cwd=_neutre())
    except subprocess.TimeoutExpired:
        raise IAError("Claude n'a pas répondu à temps — réessaie")
    fin = None
    for ligne in p.stdout.splitlines():
        try:
            d = json.loads(ligne)
        except ValueError:
            continue
        if d.get("type") == "result":
            fin = d
    if not fin:
        err = (p.stderr or p.stdout or "").strip()[-300:]
        raise IAError(_traduire(err) or "Claude Code n'a rien répondu")
    if fin.get("is_error"):
        raise IAError(_traduire(str(fin.get("result") or "")) or "Erreur de Claude Code")
    if schema:
        so = fin.get("structured_output")
        if so is None:
            try:
                so = json.loads(fin.get("result") or "")
            except ValueError:
                raise IAError("Réponse de Claude illisible — réessaie")
        return so
    return (fin.get("result") or "").strip()


def _traduire(err):
    """Les erreurs de Claude Code qu'on sait expliquer."""
    e = err.lower()
    if "login" in e or "api key" in e or "authenticat" in e or "oauth" in e:
        return ("Claude Code n'est pas connecté. Ouvre le Terminal, tape "
                "« claude », connecte-toi, puis réessaie.")
    if "usage limit" in e or "rate limit" in e or "limit reached" in e:
        return ("Limite de ton abonnement Claude atteinte pour l'instant — "
                "réessaie plus tard.")
    return err


# ------------------------------------------------------------------
# Images d'une video
# ------------------------------------------------------------------
def image(chemin, t, largeur=LARGEUR):
    """Une image du film a l'instant `t`, en JPEG."""
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t):.3f}", "-i", str(chemin),
         "-frames:v", "1", "-vf", f"scale={largeur}:-2",
         "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "5", "pipe:1"],
        capture_output=True)
    return p.stdout or None


def duree(chemin):
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "format=duration", "-of", "csv=p=0", str(chemin)],
                       capture_output=True, text=True)
    try:
        return float(p.stdout.strip())
    except ValueError:
        return 0.0


_SCD = re.compile(r"lavfi\.scd\.time:\s*([0-9.]+)")
# Memes reglages que l'atelier des templates (template.py, qui n'est pas
# dans la copie partagee — d'ou cette version a part): seuil 10 mesure sur
# des reels montes a la main, et un plan de moins de 0,25 s est un flash.
COUPE_SEUIL = 10.0
PLAN_MINI = 0.25
# Pour l'IA, le seuil est PLUS BAS que celui des templates. Un UGC filme
# souvent un ECRAN puis un autre ecran : la coupe change peu de pixels. Sur
# la reference TrueCurrent (« No way I've traded… »), deux des cinq coupes
# mesuraient 9,8 et 7,9 : a 10, la video sortait en 4 plans au lieu de 6.
# Une coupe en trop ne coute rien (Claude regroupe deux plans qui montrent
# la meme chose) ; une coupe manquee fond deux categories en une.
COUPE_SEUIL_IA = 5.0
# Au-dela, la video exemple est un tuto de dix minutes, pas un reel: on ne
# montre a Claude que les premiers plans.
PLANS_MAX = 30


# ------------------------------------------------------------------
# UNE COUPE DOIT ETRE UNE COUPE (23/11)
# ------------------------------------------------------------------
# La premiere version des « coupes douces » comptait tout changement etale
# sur trois images. Or une personne calme qui fait une GROSSE REACTION
# puis redevient calme, c'est exactement ca — et c'est UNE prise. Mesure
# le jour meme sur trois clips de reaction filmes d'une traite : 3 a 5
# « coupes » chacun, toutes fausses ; chez un etudiant, une video en une
# prise sortait en trois categories, dont une « fondu ».
#
# Regle depuis : UN MOUVEMENT N'EST JAMAIS UNE COUPE. Une coupe douce n'est
# comptee que si on RECONNAIT la transition, et chacune a une signature
# qu'un mouvement n'a pas :
#   fondu enchaine : chaque image du passage est un MELANGE exact du plan
#     d'avant et du plan d'apres (ce qui reste d'inexplique : 7 % sur un
#     vrai fondu, 37 a 81 % sur les mouvements mesures) ;
#   glissement : chaque image est le plan d'avant POUSSE par le plan
#     d'apres, d'un cran de plus a chaque image (ecart 8 a 11 % sur un
#     vrai, 21 % et plus sur un mouvement) ;
#   fondu par le noir / flash : un creux noir ou un eclair, ET une autre
#     scene de l'autre cote (une main devant l'objectif revient sur la
#     meme scene : ce n'est pas une coupe).
# Une transition qui n'est aucune de celles-la (volet, zoom, glitch) n'est
# donc plus vue ici ; la plupart contiennent une image qui change d'un
# coup, que `scdet` attrape. On prefere manquer une transition rare que
# decouper une prise.
PW, PH = 32, 57              # les images du profil du film


def _dif(a, b):
    return sum(abs(x - y) for x, y in zip(a, b)) / float(len(a))


def _est_fondu(F, a, b):
    """Les images a..b-1 sont-elles des melanges de F[a-1] et F[b] ?"""
    P, Q = F[a - 1], F[b]
    base = _dif(P, Q) or 1.0
    den = sum((p - q) ** 2 for p, q in zip(P, Q)) or 1
    parts, reste = [], []
    for i in range(a, b):
        al = min(1.0, max(0.0, sum((f - q) * (p - q) for f, p, q in zip(F[i], P, Q)) / den))
        parts.append(al)
        reste.append(_dif(F[i], bytes(int(al * p + (1 - al) * q) for p, q in zip(P, Q))))
    if len(parts) < 2:
        return False
    # Le plan d'avant doit s'effacer REGULIEREMENT, de presque tout a
    # presque rien — un passage ou sa part reste a 95 % n'est pas un fondu.
    regulier = all(parts[k] >= parts[k + 1] - 0.05 for k in range(len(parts) - 1))
    return regulier and parts[0] - parts[-1] >= 0.4 and sum(reste) / len(reste) < base * 0.15


def _est_glisse(F, a, b):
    """Les images a..b-1 sont-elles le plan d'avant POUSSE par le suivant ?"""
    P, Q = F[a - 1], F[b]
    base = _dif(P, Q) or 1.0
    px = PW * PH
    suivi = []
    for i in range(a, b):
        mieux = (9e9, 0, "")
        for sens in "gdhb":
            for d in range(1, PW if sens in "gd" else PH):
                if sens == "g":
                    e = sum(sum(abs(x - y) for x, y in zip(F[i][r:r + PW], P[r + d:r + PW] + Q[r:r + d]))
                            for r in range(0, px, PW))
                elif sens == "d":
                    e = sum(sum(abs(x - y) for x, y in
                                zip(F[i][r:r + PW], Q[r + PW - d:r + PW] + P[r:r + PW - d]))
                            for r in range(0, px, PW))
                elif sens == "h":
                    e = sum(abs(x - y) for x, y in zip(F[i], P[d * PW:] + Q[:d * PW]))
                else:
                    e = sum(abs(x - y) for x, y in zip(F[i], Q[(PH - d) * PW:] + P[:(PH - d) * PW]))
                if e < mieux[0]:
                    mieux = (e, d, sens)
        suivi.append((mieux[0] / px / base, mieux[1], mieux[2]))
    if len(suivi) < 2 or any(x[0] >= 0.18 for x in suivi):
        return False
    # Toujours dans le meme sens, et d'un cran de plus a chaque image.
    return len({x[2] for x in suivi}) == 1 and all(suivi[k][1] <= suivi[k + 1][1]
                                                    for k in range(len(suivi) - 1))


def _transition(F, a, b):
    """Le passage a..b (images du profil) : "fondu", "glisse", ou None si ce
    n'est qu'un mouvement."""
    if b - a < 2 or a < 1 or b >= len(F):
        return None
    if _est_fondu(F, a, b):
        return "fondu"
    if _est_glisse(F, a, b):
        return "glisse"
    return None


def _meme_scene(A, B, y0=0, y1=None):
    """La part du DETAIL de l'image (lignes y0..y1) qui se retrouve de l'une
    a l'autre, a un petit glissement pres : haute = la meme scene (le decor
    est toujours la), basse = une autre scene. Images de `_gris`. Le plus
    petit des deux sens ; None s'il n'y a pas assez de detail pour le dire.
    Mesure : 0,04 a 0,16 de part et d'autre d'une vraie coupe, 0,45 a 0,76
    dans une meme prise."""
    y1 = GH if y1 is None else y1

    def sens(X, Y):
        m = bytearray(_detail(Y, GW, GH))
        for y in range(GH):
            if not y0 <= y < y1:
                m[y * GW:(y + 1) * GW] = bytes(GW)
        if sum(m) < 60:
            return None
        m = bytes(m)
        return max(_accord(X, Y, GW, GH, 1.0, dx, dy, masque=m)
                   for dx in (-4, -2, -1, 0, 1, 2, 4) for dy in (-4, -2, -1, 0, 1, 2, 4))
    u, v = sens(A, B), sens(B, A)
    return None if u is None or v is None else min(u, v)


def _profil(chemin):
    """Tout le film en petites images grises (15 par seconde, 32x57)."""
    cad, px = 15, PW * PH
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-t", "180", "-i", str(chemin),
         "-vf", f"fps={cad},scale={PW}:{PH},format=gray", "-f", "rawvideo", "pipe:1"],
        capture_output=True)
    n = len(p.stdout) // px
    return [p.stdout[i * px:(i + 1) * px] for i in range(n)], cad


def coupes_douces(chemin, fin):
    """Les changements de plan qui NE SONT PAS une coupe seche — fondu
    enchaine, fondu par le noir, flash, glissement — que `scdet` ne voit
    pas (il compare deux images qui se suivent ; dans un fondu aucune paire
    ne change assez). Seulement les transitions RECONNUES : voir le bloc
    au-dessus. -> les instants, a ajouter aux coupes de scdet."""
    F, cad = _profil(chemin)
    n = len(F)
    if n < 8:
        return []
    L = [sum(f) / float(len(f)) for f in F]
    D = [0.0] + [_dif(F[i], F[i - 1]) for i in range(1, n)]
    out, pris = [], [False] * n
    voisin = int(cad * 0.6)
    # Creux noir / eclair blanc, avec de l'image normale des deux cotes
    # (un film qui s'OUVRE du noir n'est pas une coupe).
    for i in range(1, n - 1):
        g, d = L[max(0, i - voisin):i], L[i + 1:i + 1 + voisin]
        if not g or not d or pris[i]:
            continue
        if (L[i] < 22 and L[i] <= min(g + d) and max(g) > L[i] + 20 and max(d) > L[i] + 20) \
                or (L[i] > 215 and L[i] >= max(g + d) and min(g) < L[i] - 35
                    and min(d) < L[i] - 35):
            for j in range(max(0, i - voisin), min(n, i + voisin + 1)):
                pris[j] = True
            # ... et une AUTRE scene de l'autre cote du creux.
            A, B = _gris(chemin, max(0.0, i / cad - 0.5)), _gris(chemin, i / cad + 0.5)
            m = _meme_scene(A, B) if A and B else None
            if m is None or m < 0.25:
                out.append(i / cad)
    # Changement etale, juge contre le mouvement HABITUEL du film (la
    # mediane) — puis RECONNU, sinon ce n'est qu'un mouvement.
    seuil = max(3.5, 1.8 * sorted(D)[n // 2])
    i = 1
    while i < n:
        if D[i] > seuil and not pris[i]:
            j = i
            while j + 1 < n and D[j + 1] > seuil and not pris[j + 1]:
                j += 1
            if 3 <= j - i + 1 <= int(cad * 1.2) and _dif(F[i - 1], F[j]) > 20 \
                    and _transition(F, i, j):
                out.append((i - 1) / cad)
            i = j + 1
        else:
            i += 1
    return sorted(round(t, 3) for t in out if 0.25 < t < fin - 0.25)


# Les coupes partielles du dernier film lu par `plans()` : {chemin:
# [(instant, moitie qui CONTINUE)]}. En memoire, pour `lire_exemple`.
PARTIELLES = {}


def coupe_partielle(chemin, t):
    """La coupe a l'instant `t` ne touche-t-elle qu'UNE MOITIE de l'image ?
    -> "haut" ou "bas" (la moitie qui CONTINUE), ou "".

    Dans un split screen, la video du bas (un match, une demo) a ses
    propres coupes pendant que la personne du haut continue sa prise. Ce
    n'est pas un nouveau plan a filmer : compte comme tel, la prise du haut
    etait decoupee en categories. Mesure : la moitie qui continue se
    retrouve a 0,63, celle qui coupe a 0,06–0,10."""
    A, B = _gris(chemin, max(0.0, t - 0.15)), _gris(chemin, t + 0.15)
    if not A or not B:
        return ""
    haut, bas = _meme_scene(A, B, 0, GH // 2), _meme_scene(A, B, GH // 2, GH)
    if haut is None or bas is None:
        return ""
    if haut >= 0.5 and bas <= 0.25:
        return "haut"
    if bas >= 0.5 and haut <= 0.25:
        return "bas"
    return ""


def plans(chemin):
    """[(debut, fin)] de chaque plan de la video exemple."""
    fin = duree(chemin)
    if fin <= 0:
        raise IAError("La vidéo exemple est illisible")
    p = subprocess.run(["ffmpeg", "-v", "info", "-i", str(chemin), "-vf",
                        f"scdet=threshold={COUPE_SEUIL_IA}", "-f", "null", "-"],
                       capture_output=True, text=True)
    cs = sorted({round(float(t), 3) for t in _SCD.findall(p.stderr)})
    # Une coupe qui ne touche qu'une moitie de l'image n'est pas un plan
    # (voir `coupe_partielle`) — PAR DEFAUT. Elle n'est pas jetee en
    # silence : `PARTIELLES` la garde, `lire_exemple` la DIT a Claude, et
    # une consigne explicite peut lui faire decouper quand meme (« ca peut
    # changer si dans les consignes il indique autrement », 23/11).
    try:
        part = [(t, coupe_partielle(chemin, t)) for t in cs]
        PARTIELLES[str(chemin)] = [(t, m) for t, m in part if m]
        cs = [t for t, m in part if not m]
    except Exception:                                   # noqa: BLE001
        PARTIELLES[str(chemin)] = []
    # Les coupes douces, sauf la ou scdet a deja coupe (a 0,3 s pres : un
    # flash se voit des deux facons, et une seule coupe suffit).
    try:
        for t in coupes_douces(chemin, fin):
            if all(abs(t - c) > 0.3 for c in cs):
                cs.append(t)
        cs.sort()
    except Exception:                                   # noqa: BLE001
        pass
    bornes = [0.0] + [t for t in cs if 0 < t < fin] + [fin]
    out = []
    for a, b in zip(bornes, bornes[1:]):
        if out and (b - a) < PLAN_MINI:
            out[-1] = (out[-1][0], b)
        else:
            out.append((a, b))
    if len(out) > 1 and out[0][1] - out[0][0] < PLAN_MINI:
        out[1] = (out[0][0], out[1][1])
        out.pop(0)
    return [(round(a, 3), round(b, 3)) for a, b in out][:PLANS_MAX]


# ------------------------------------------------------------------
# Monter une campagne depuis un brief et une video exemple
# ------------------------------------------------------------------
SCHEMA_CAMPAGNE = {
    "type": "object", "additionalProperties": False,
    "required": ["resume", "campagne", "serie", "reglages", "tournage", "questions"],
    "properties": {
        "resume": {"type": "string"},
        "campagne": {
            "type": "object", "additionalProperties": False,
            "required": ["nom", "plateformes", "objectif_jour", "paie_par_video",
                         "cycle_paie", "base_pay", "min_vues", "bonus", "cpm",
                         "frequence", "notes"],
            "properties": {
                "nom": {"type": "string"},
                "plateformes": {"type": "array", "items": {
                    "type": "string", "enum": ["ig", "tt", "yt", "fb"]}},
                "objectif_jour": {"type": "integer"},
                "paie_par_video": {"type": "number"},
                "cycle_paie": {"type": "string", "enum": ["", "hebdo", "2sem", "mensuel"]},
                "base_pay": {"type": "string"},
                "min_vues": {"type": "integer"},
                "bonus": {"type": "string"},
                "cpm": {"type": "string"},
                "frequence": {"type": "string"},
                "notes": {"type": "string"}}},
        "serie": {
            "type": "object", "additionalProperties": False,
            "required": ["nom", "format", "parle", "prise", "categories", "calage"],
            "properties": {
                "calage": {"type": "object", "additionalProperties": False,
                           "required": ["moment_bas", "moment_haut"],
                           "properties": {"moment_bas": {"type": "string"},
                                          "moment_haut": {"type": "string"}}},
                "nom": {"type": "string"},
                "format": {"type": "string", "enum": ["plein", "split"]},
                "parle": {"type": "boolean"},
                "prise": {"type": "boolean"},
                "categories": {"type": "array", "items": {
                    "type": "object", "additionalProperties": False,
                    "required": ["nom", "role", "plans", "duree", "delta",
                                 "texte", "position", "son", "complet", "consigne", "script",
                                 "silences", "musique_ici", "miroir",
                                 "zoom_de", "zoom_a", "transition", "transition_duree",
                                 "vitesse"],
                    "properties": {
                        "nom": {"type": "string"},
                        "role": {"type": "string", "enum": ["", "haut", "bas", "etape"]},
                        "plans": {"type": "array", "items": {"type": "integer"}},
                        "duree": {"type": "number"},
                        "delta": {"type": "number"},
                        "texte": {"type": "string"},
                        "position": {"type": "string", "enum": ["haut", "milieu", "bas"]},
                        "son": {"type": "boolean"},
                        "complet": {"type": "boolean"},
                        "consigne": {"type": "string"},
                        "script": {"type": "string"},
                        "silences": {"type": "string", "enum": ["", "bords", "tous"]},
                        "musique_ici": {"type": "boolean"},
                        "miroir": {"type": "boolean"},
                        "zoom_de": {"type": "number"},
                        "zoom_a": {"type": "number"},
                        "transition": {"type": "string",
                                       "enum": ["", "fondu", "noir", "flash", "glisse"]},
                        "transition_duree": {"type": "number"},
                        "vitesse": {"type": "number"}}}}}},
        "reglages": {"type": "object", "additionalProperties": False,
                     "required": ["taille_texte", "style_texte", "musique", "musique_volume",
                                  "melanger_ordre"],
                     "properties": {
                         "taille_texte": {"type": "integer"},
                         "style_texte": {"type": "string", "enum": ["contour", "pastille", "nu"]},
                         "musique": {"type": "boolean"},
                         "musique_volume": {"type": "number"},
                         "melanger_ordre": {"type": "boolean"}}},
        "tournage": {"type": "array", "items": {"type": "string"}},
        "questions": {"type": "array", "items": {"type": "string"}},
    }}

CONSIGNES_CAMPAGNE = """\
Monte une campagne du plateau à partir du BRIEF du client et de la VIDÉO EXEMPLE
(ses plans sont au-dessus, une image par plan, avec leur durée).

Comment le plateau fabrique les vidéos: une SÉRIE est une suite de CATÉGORIES.
Chaque catégorie est un dossier de clips interchangeables que l'utilisateur
filme; à chaque vidéo, le plateau tire UN clip par catégorie, le coupe à la
durée de la catégorie, et pose le texte de la catégorie par-dessus. Des dizaines
de variantes sortent ainsi des mêmes clips.

LA VIDÉO EXEMPLE FAIT FOI POUR LE MONTAGE. Quand il y en a une, c'est ELLE
que tu refais : ses parties, leur ordre, leurs durées, où le texte apparaît
et où il n'apparaît pas, split screen ou non, musique ou voix. Le brief ne
décide PAS du montage : il sert au deal (paie, pays, plateformes, règles) et
à savoir de quel produit on parle pour adapter les mots. S'ils se
contredisent sur la forme de la vidéo, suis l'exemple.

Règles:
- Une catégorie = un plan. Regroupe deux plans consécutifs (« plans » liste
  leurs numéros) SEULEMENT si c'est la même prise coupée en deux : même cadre,
  même écran. Deux écrans différents de l'app, même filmés pareil, sont deux
  catégories : on doit pouvoir filmer chacun à part. Garde l'ordre.
- UNE PRISE = UNE CATÉGORIE, quoi que fasse la personne dedans. Les plans
  qu'on te donne sont séparés par de VRAIES coupes, mesurées. Quelqu'un qui
  est calme, puis fait une grosse réaction, puis redevient calme SANS coupe,
  c'est UN plan et UNE catégorie : ne le découpe jamais d'après son jeu
  (« accroche », « réaction », « retour au calme »). Décris ce
  déroulement dans la « consigne » de la catégorie. Tu ne crées jamais plus
  de catégories filmées qu'il n'y a de plans.
- COUPES PARTIELLES. Dans un split, une moitié de l'image peut changer de
  plan pendant que l'autre continue : on te les signale à part, avec leur
  instant et la moitié qui change. Regarde QUELLE moitié change :
  · la moitié de la PERSONNE filmée (presque toujours le haut) change de
    prise pendant que l'autre vidéo continue (« une réaction en haut les
    4-5 premières secondes, puis un AUTRE clip en haut, le même clip en bas
    tout le long ») : ce sont DEUX prises à filmer, donc DEUX catégories
    role « haut », dans l'ordre. Elles se relaient dans la moitié haute.
    « duree » d'une catégorie « haut » = combien de secondes elle tient
    avant de passer la main à la suivante (l'instant mesuré de la coupe,
    compté depuis le début du split) ; 0 pour la dernière, qui va jusqu'au
    bout. C'est le cas le plus courant : ne le rate pas.
  · la moitié qui est un clip DÉJÀ MONTÉ (un match, une démo d'app, presque
    toujours le bas) change de plan pendant que la personne continue sa
    prise : PAR DÉFAUT ce n'est PAS une nouvelle catégorie — ce clip passe
    en entier et la personne n'a qu'une prise à filmer. Découpe là
    SEULEMENT si le brief, les règles de la campagne ou l'utilisateur le
    demandent en toutes lettres (« une réaction différente pour chaque
    action du match ») : alors une catégorie « haut » par tronçon, avec
    pour « duree » l'écart entre deux de ces instants, et dis-le dans
    « resume ».
- « duree » = la durée du plan dans l'exemple (somme si plusieurs plans), en
  secondes. « delta » = la variation permise, 0,2 par défaut (0 si le plan doit
  durer exactement ça, par exemple calé sur la musique).
- « texte » = le texte à l'écran du plan, RÉÉCRIT pour le produit du brief si
  l'exemple parle d'autre chose, en gardant le ton et la longueur. Garde la
  LANGUE des textes de l'exemple (le public visé est le même), sauf si le
  brief en demande une autre. Saut de ligne: « | ». Vide s'il n'y a pas de
  texte.
- « position » = où est le texte (haut, milieu, bas).
- « son » = vrai seulement si on doit entendre le son du clip (quelqu'un qui
  parle, une réaction). Sinon la musique remplace le son.
- « complet » = vrai si le clip doit passer en entier (une démo d'app, un
  enregistrement d'écran), faux sinon.
- « consigne » = ce que l'utilisateur doit FILMER pour cette catégorie, en une
  ou deux phrases concrètes (cadrage, action, expression, durée à filmer — un
  peu plus long que « duree », pour laisser du choix). Pas de consigne vague.
- « script » = les mots EXACTS à dire dans ce plan, MOT POUR MOT, prêts à être
  lus avant de filmer. Si les PAROLES DE L'EXEMPLE sont données, reprends
  celles de ce plan telles quelles, adaptées au produit du brief seulement
  là où elles parlent d'autre chose. Sinon, reprends TELLES QUELLES les
  répliques que le brief donne (entre guillemets, « script starters »,
  formules imposées : nom du produit, « free to play », « link in bio »…),
  et complète dans son ton en respectant ses mots interdits. Dans la LANGUE
  que la personne parlera (celle du public visé, l'anglais sauf si le brief
  dit autre chose). Plusieurs personnes : une réplique par ligne, séparées
  par « | », chacune précédée de qui parle (« Toi : … | Ton ami : … »). Une
  action sans parole entre parenthèses. Vide si personne ne parle dans ce
  plan (enregistrement d'écran muet, plan de décor).
- « parle » = vrai si la vidéo repose sur quelqu'un qui parle à la caméra
  (sous-titres automatiques).
- « prise » = vrai quand la vidéo est UN talking head filmé d'une traite et
  utilisé une seule fois (on dépose la prise du jour, on récupère la vidéo
  montée) — pas des clips qu'on mélange. Alors : la PREMIÈRE catégorie est
  la prise (son gardé, silences "tous"), et les catégories suivantes, s'il
  y en a, sont ce qui se réutilise d'un jour à l'autre (un plan de fin, une
  démo). Faux pour tout ce qui se remixe, et toujours faux en split.

LIRE LE MONTAGE COMME UN MONTEUR — le but n'est pas de copier CETTE vidéo,
c'est d'en comprendre la recette pour la refaire avec D'AUTRES clips, qui
n'auront ni la même durée ni les mêmes mots. Pour chaque plan, regarde ses
images (début, milieu, fin), ce qui y est DIT et le niveau du son, et dis
ce qui DÉCIDE DE SA LONGUEUR :
  • la PAROLE (quelqu'un parle et le plan coupe quand la phrase finit) →
    « son » vrai, « silences » "bords" (le clip ira du premier au dernier
    mot, quelle que soit sa durée) ; "tous" si l'exemple saute déjà les
    pauses en jump cuts à l'intérieur du plan. « duree » reste celle de
    l'exemple, comme repère ;
  • la MUSIQUE ou un rythme (coupes sur le beat, plans de même longueur) →
    durée fixe, « delta » 0 ;
  • une DÉMO / un écran qu'on doit voir en entier → « complet » vrai ;
  • sinon → la durée de l'exemple ± « delta ».
  « musique_ici » vrai sur la catégorie où la musique ENTRE si elle n'est
  pas là dès le début (le niveau du son monte sans parole). « miroir »
  faux. Le texte à l'écran se LIT sur les images : recopie-le tel quel
  (adapté au produit seulement s'il parle d'un autre), avec sa place.
  « parle » vrai seulement si l'exemple montre des SOUS-TITRES mot à mot de
  ce qui est dit ; une voix sans sous-titres = « son » vrai sur la
  catégorie, « parle » faux.
- ZOOM et TRANSITION de chaque catégorie. LA PLUPART DU TEMPS IL N'Y EN A
  PAS : une coupe sèche et un plan fixe. N'en mets que si la MESURE donnée
  avec le plan le dit, ou si tu le VOIS sur ses images — jamais « pour
  faire joli ».
  « zoom_de » / « zoom_a » = l'échelle de l'image au début et à la fin du
  plan (1 = l'image entière ; 1 et 1 = pas de zoom). Zoom avant lent :
  1 → 1,1 à 1,2. Zoom arrière : 1,15 → 1. Plan RESSERRÉ d'un coup (le
  « punch-in » d'un jump cut : même prise que le plan d'avant, en plus
  gros) : la même valeur aux deux, par exemple 1,2 et 1,2. Jamais plus de
  1,6. Un rapprochement de la PERSONNE vers la caméra n'est pas un zoom.
  « transition » = comment ce plan ENTRE, depuis le plan d'avant : ""
  (coupe sèche), "fondu" (fondu enchaîné, les deux plans se superposent),
  "noir" (fondu par le noir), "flash" (éclair blanc), "glisse" (le plan
  d'avant est poussé hors du cadre par celui-ci). « transition_duree » en
  secondes (0,3 par défaut, 0 sans transition). Sur la PREMIÈRE catégorie,
  seul "noir" a un sens (la vidéo s'ouvre du noir). Une transition qui
  n'est aucune de celles-là (zoom-transition, rotation, glitch, volet…) :
  prends la plus proche et DIS-LE dans « resume ».
- « vitesse » = 1 (vitesse normale) PRESQUE TOUJOURS. Mets autre chose
  (1,5 ; 2 ; jusqu'à 4 — jamais moins de 1, le plateau ne ralentit pas)
  SEULEMENT si le brief ou l'utilisateur DIT qu'un plan est accéléré
  (« sped up 2x », « timelapse », « en accéléré »). Tu ne peux PAS le
  voir : sur des images fixes, un clip accéléré ressemble à un clip où ça
  bouge vite — testé, on se trompe plus d'une fois sur deux. Si tu
  soupçonnes un accéléré sans que rien ne le dise, laisse 1 et pose la
  question dans « questions » (« Le plan 2 a l'air accéléré : à quelle
  vitesse ? »).
- « reglages » : taille_texte = la taille du texte de l'exemple (70 =
  taille TikTok habituelle, 85–100 = gros, 55 = petit) ; style_texte
  « contour » (texte blanc cerné de noir, le plus courant), « pastille »
  (texte sur un fond plein) ou « nu » ; musique = vrai s'il y a une musique
  de fond ; musique_volume 1 (0,1 si on parle par-dessus) ; melanger_ordre
  faux. Sans vidéo exemple : 70, contour, musique vrai, 1, faux.
- FORMAT « split »: seulement si l'exemple montre DEUX vidéos empilées (une en
  haut, une en bas) avec une bande de texte entre les deux. Alors: d'abord les
  plans plein cadre (role ""), puis une ou plusieurs catégories role « haut »
  (plusieurs = elles se relaient, voir COUPES PARTIELLES), UNE catégorie role
  « bas », et les textes de la bande en catégories role « etape » (texte +
  durée, sans clip, consigne vide). Avec plusieurs « haut » : la bande tient
  le « texte » de la PREMIÈRE catégorie « haut » tant qu'elle est à l'écran,
  et les étapes commencent quand la deuxième prend la main — mets donc
  l'accroche dans le « texte » de la première « haut », pas dans une étape.
  « son » vrai sur chaque catégorie « haut » où la personne PARLE. Sinon
  format « plein » et role "" partout.
- Le nom des catégories est court (2-4 mots) et dit ce qu'on y voit.
- « plateformes » = où le deal exige de POSTER, d'après le brief et le
  contrat: ig = Instagram, tt = TikTok, yt = YouTube (Shorts), fb = Facebook.
  Seulement celles qui sont demandées (« Instagram only » → ["ig"]). Si rien
  n'est dit, liste vide et mets la question dans « questions ».
- PLUSIEURS « bas » : quand la moitié basse enchaîne des vidéos de NATURE
  différente que la personne fournit à part (un extrait de match, PUIS un
  enregistrement d'écran de l'app), ce sont plusieurs catégories role
  « bas », dans l'ordre : chacune passe EN ENTIER, l'une après l'autre, et
  le haut change au même instant (une catégorie « haut » par catégorie
  « bas », dans le même ordre). Un simple changement d'angle dans la même
  vidéo (deux plans du même match) reste UNE catégorie « bas ».
- « calage » (split seulement, sinon deux chaînes vides) : le RENDEZ-VOUS
  entre le haut et le bas. Si, dans l'exemple, la réaction de la personne
  part au moment précis d'un événement de la vidéo du bas (le touchdown, le
  but, la balle attrapée, le gain qui s'affiche), « moment_bas » = cet
  événement, décrit pour qu'on le retrouve dans N'IMPORTE QUEL clip du même
  genre (« l'instant où le joueur attrape la balle dans l'en-but »), et
  « moment_haut » = ce qui doit tomber dessus (« l'instant où ils explosent
  de joie »). L'app retrouvera ces deux instants dans chaque clip déposé.
  Pas de rendez-vous visible : "" et "".
- Si un CONTRAT suit le brief, il fait foi sur la paie, le rythme et les
  plateformes quand les deux ne disent pas la même chose.
- CAMPAGNE: nom du client/produit; « objectif_jour » = vidéos par jour exigées
  par le brief (0 si rien n'est dit); la paie seulement si le brief la donne
  (0 / "" sinon). CHAQUE CHIFFRE DANS SON CHAMP, jamais une phrase qui mélange
  tout — l'app les affiche et les corrige séparément :
    « paie_par_video » = le montant de base par vidéo (nombre, toutes
      plateformes comprises : 10 $ × 2 plateformes = 20) ;
    « base_pay » = la paie de base en TRÈS court (≤ 60 caractères), ex.
      « 10 $ par plateforme » ou « 750 $/mois » ;
    « min_vues » = les vues minimum pour être payé (0 si rien n'est dit) ;
    « bonus » = les bonus aux vues, en court (« +50 $ à 50K, +100 $ à 100K,
      par plateforme »), "" s'il n'y en a pas ;
    « cycle_paie » et « frequence » comme d'habitude.
  « notes » = les règles du client à ne pas oublier (interdits, mots à dire,
  hashtags, mentions), UNE RÈGLE PAR LIGNE, courte — et rien de ce qui est
  déjà dans les champs de paie ci-dessus.
- « tournage » = la liste de tournage, dans l'ordre: une ligne par chose à
  filmer, avec le nombre de prises conseillé (au moins 3 par catégorie pour que
  les vidéos varient).
- « questions » = ce que le brief ne dit pas et qu'il faudrait demander au
  client (vide si rien).
- « resume » = deux phrases: ce que montre la vidéo exemple et l'idée à garder.
"""


# La regle du script, partagee avec `ecrire_scripts` : une seule source,
# sinon les series creees et celles completees apres coup divergeraient.
SCRIPT_REGLE = " ".join(CONSIGNES_CAMPAGNE.split("lus avant de filmer.", 1)[1]
                        .split("plan de décor).", 1)[0].split()) + " plan de décor)."


# Sans video exemple, la campagne se monte sur le brief seul: la forme
# d'un UGC qui marche est assez connue pour partir d'elle, et l'exemple
# arrive souvent apres le brief (« je t'envoie une ref demain »). Il
# remplacera ces categories quand il arrivera (`/api/series/<id>/exemple`).
SANS_EXEMPLE = """
PAS DE VIDÉO EXEMPLE pour l'instant. Monte la série d'après le BRIEF seul :
la forme d'un UGC court qui marche sur TikTok/Reels pour ce produit (en
général : une accroche de 1 à 2 s, le problème ou la situation, la démo du
produit, le résultat, un appel à l'action), 4 à 7 catégories, des durées
typiques de ce format, « plans » vide partout, format « plein » sauf si le
brief décrit un split screen. Les textes à l'écran en anglais sauf si le
brief dit une autre langue. « resume » = deux phrases sur l'idée de la vidéo
et le fait que la structure sera recalée sur l'exemple quand il arrivera.
"""


def paroles_par_plan(chemin, pl):
    """Ce qui se DIT dans la video exemple, range par plan : la source du
    script mot pour mot. Vide si whisper manque ou si personne ne parle —
    le script vient alors du brief. Un mot va au plan ou il commence."""
    try:
        import transcription
        if not transcription.disponible():
            return ""
        mots = transcription.mots(chemin)
    except Exception:
        return ""
    if not mots or not pl:
        return ""
    lignes = []
    for i, (a, b) in enumerate(pl, 1):
        dit = " ".join(str(m[0]).strip() for m in mots
                       if a - 0.05 <= float(m[1]) < b - 0.05 or (i == len(pl) and float(m[1]) >= a))
        if dit.strip():
            lignes.append(f"Plan {i}: {dit.strip()}")
    return "\n".join(lignes)


SCHEMA_SCRIPTS = {
    "type": "object", "additionalProperties": False, "required": ["scripts"],
    "properties": {"scripts": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["id", "script"],
        "properties": {"id": {"type": "string"}, "script": {"type": "string"}}}}}}


def ecrire_scripts(brief, categories, paroles=""):
    """Le script mot pour mot de chaque categorie d'une serie DEJA creee
    (20/11 : les series d'avant n'en avaient pas). `categories` =
    [{"id", "nom", "consigne", "texte", "son"}]. Rend {id: script}."""
    liste = "\n".join(
        f"- id {c['id']} — « {c['nom']} »"
        + (f" ; à filmer : {c['consigne']}" if c.get("consigne") else "")
        + (f" ; texte à l'écran : {c['texte']}" if c.get("texte") else "")
        + ("" if c.get("son") else " ; (son du clip coupé : la musique passe dessus)")
        for c in categories)
    texte = ("Écris le SCRIPT de chaque catégorie de cette série UGC : ce que la "
             "personne dit dans ce plan.\n\nCatégories, dans l'ordre de la vidéo:\n"
             + liste + "\n\nRègle — « script » = les mots EXACTS à dire dans ce plan, "
             "MOT POUR MOT, prêts à être lus avant de filmer. " + SCRIPT_REGLE + "\n"
             "Les catégories se suivent : la vidéo doit se tenir d'un plan à l'autre."
             + ("\n\nPAROLES DE L'EXEMPLE (transcrites, plan par plan):\n" + paroles if paroles else "")
             + "\n\nBRIEF DU CLIENT:\n" + (brief or "(aucun brief)"))
    r = demander(texte, schema=SCHEMA_SCRIPTS, modele=SOIGNE, delai=300)
    return {str(x.get("id") or ""): str(x.get("script") or "").strip()
            for x in r.get("scripts") or []}


def niveaux_par_plan(chemin, pl):
    """Le niveau du son de chaque plan, en dB (0 = le maximum), ou []. Une
    seule extraction pour tout le film."""
    import audioop
    import tempfile
    import wave
    with tempfile.TemporaryDirectory() as t:
        wav = os.path.join(t, "s.wav")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(chemin), "-vn", "-ac", "1",
                            "-ar", "8000", "-c:a", "pcm_s16le", wav], capture_output=True)
        if r.returncode != 0 or not os.path.exists(wav):
            return []
        try:
            w = wave.open(wav)
            sr, data = w.getframerate(), w.readframes(w.getnframes())
            w.close()
        except (OSError, wave.Error):
            return []
    out = []
    for a, b in pl:
        bloc = data[int(a * sr) * 2:int(b * sr) * 2]
        if len(bloc) < 200:
            out.append(None)
            continue
        out.append(round(20 * math.log10((audioop.rms(bloc, 2) + 1) / 32768), 1))
    return out


# ------------------------------------------------------------------
# ZOOMS ET TRANSITIONS DE L'EXEMPLE : MESURES, PAS DEVINES (23/11)
# ------------------------------------------------------------------
# Trois images par plan ne suffisent pas a Claude pour dire « zoom avant
# de 12 % » : une personne qui s'avance d'un pas fait le meme effet a
# l'oeil. Meme regle que `qualite.py` — ce qui se mesure ne se demande
# pas. On mesure donc, sans dependance (des images grises de 64x114 lues
# dans ffmpeg, comparees en Python) :
#
#   le ZOOM d'un plan : l'echelle qui recale au mieux sa derniere image
#     sur sa premiere. Un zoom de montage agrandit TOUTE l'image, fond
#     compris ; une personne qui bouge ne recale rien, et on ne dit rien.
#   le PUNCH-IN : la meme mesure entre la fin d'un plan et le debut du
#     suivant — meme prise, resserree d'un coup.
#   la COUPE : sur une seconde autour d'elle, la luminosite (un creux noir,
#     un eclair blanc) et le nombre d'images sur lesquelles le changement
#     s'etale (une coupe seche tient en UNE image).
#
# Claude recoit ces chiffres avec les plans, et une PLANCHE d'images pour
# chaque coupe qui n'est pas seche : c'est lui qui nomme la transition,
# sur ce qu'il voit, avec la mesure pour garde-fou.
GW, GH = 64, 114


def _gris(chemin, t):
    """L'image a l'instant `t`, en gris GWxGH (bytes), ou None."""
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t):.3f}", "-i", str(chemin),
         "-frames:v", "1", "-vf", f"scale={GW}:{GH},format=gray",
         "-f", "rawvideo", "pipe:1"], capture_output=True)
    return p.stdout if len(p.stdout) == GW * GH else None


def _moitie(img, w, h):
    """La meme image deux fois plus petite (moyenne de 2x2)."""
    out = bytearray((w // 2) * (h // 2))
    k = 0
    for y in range(0, h - 1, 2):
        a, b = y * w, (y + 1) * w
        for x in range(0, w - 1, 2):
            out[k] = (img[a + x] + img[a + x + 1] + img[b + x] + img[b + x + 1]) >> 2
            k += 1
    return bytes(out), w // 2, h // 2


def _detail(img, w, h, mini=14):
    """Les pixels qui ont du DETAIL (un bord, une texture) : les seuls qui
    disent quelque chose de l'echelle. Un mur uni ou un ciel noir
    « s'aligne » a n'importe quel zoom — sur un plan de nuit, il faisait
    monter l'accord de partout et le danseur decidait seul (deux faux
    zooms, ×1,18 et ×0,90, le 23/11). -> un masque de 0/1, bords exclus."""
    m = bytearray(w * h)
    for y in range(1, h - 1):
        r0, r1, r2 = (y - 1) * w, y * w, (y + 1) * w
        for x in range(1, w - 1):
            if abs(img[r1 + x + 1] - img[r1 + x - 1]) + abs(img[r2 + x] - img[r0 + x]) >= mini:
                m[r1 + x] = 1
    return bytes(m)


def _accord(A, B, w, h, ech, dx, dy, tol=10, masque=None):
    """La part des pixels de B qui retrouvent leur valeur dans « A agrandi
    de `ech` puis glisse de (dx, dy) », a `tol` niveaux de gris pres.

    On COMPTE ce qui s'aligne au lieu de moyenner l'ecart : dans un plan,
    la personne bouge et le decor non. Un ecart moyen est domine par la
    personne (mesure : un zoom de 16 % ressortait a 4 %) ; un compte ne
    regarde que ce qui tient — le decor, qui, lui, ne grossit que si le
    CADRE grossit."""
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    xs = [int(round(cx + (x - cx) / ech + dx)) for x in range(w)]
    cols = [(x, xs[x]) for x in range(w) if 0 <= xs[x] < w]
    ok = n = 0
    for y in range(h):
        ya = int(round(cy + (y - cy) / ech + dy))
        if not 0 <= ya < h:
            continue
        ra, rb = A[ya * w:(ya + 1) * w], B[y * w:(y + 1) * w]
        if masque is None:
            ok += sum(1 for x, xa in cols if -tol <= rb[x] - ra[xa] <= tol)
            n += len(cols)
        else:
            mk = masque[y * w:(y + 1) * w]
            for x, xa in cols:
                if mk[x]:
                    n += 1
                    if -tol <= rb[x] - ra[xa] <= tol:
                        ok += 1
    if masque is not None:
        return ok / n if n > w * h * 0.06 else 0.0     # trop peu de detail : rien a dire
    return ok / n if n > w * h * 0.5 else 0.0


def _recale(A, B):
    """-> (echelle, accord au mieux, accord sans zoom). echelle > 1 : B est
    A en plus gros (zoom avant) ; < 1 : zoom arriere. Recherche grossiere
    sur des images de 32x57, affinee en 64x114. L'accord ne compte que les
    pixels qui ont du detail (`_detail`)."""
    a2, w2, h2 = _moitie(A, GW, GH)
    b2, _, _ = _moitie(B, GW, GH)
    ma2, mb2 = _detail(a2, w2, h2), _detail(b2, w2, h2)
    mA, mB = _detail(A, GW, GH), _detail(B, GW, GH)
    mieux = (0.0, 1.0, 0, 0)
    for k in range(0, 21):                       # 1,00 -> 1,40
        e = 1.0 + 0.02 * k
        for sens in ((1,) if k == 0 else (1, -1)):
            X, Y, M = (a2, b2, mb2) if sens == 1 else (b2, a2, ma2)
            for dx in (-2, -1, 0, 1, 2):
                for dy in (-2, -1, 0, 1, 2):
                    v = _accord(X, Y, w2, h2, e, dx, dy, masque=M)
                    if v > mieux[0]:
                        mieux = (v, e if sens == 1 else -e, dx, dy)
    _, e0, dx0, dy0 = mieux
    sens = 1 if e0 > 0 else -1
    X, Y, M = (A, B, mB) if sens == 1 else (B, A, mA)
    fin = (0.0, abs(e0))
    for de in (-0.02, -0.01, 0.0, 0.01, 0.02):
        e = max(1.0, abs(e0) + de)
        for dx in (2 * dx0 - 1, 2 * dx0, 2 * dx0 + 1):
            for dy in (2 * dy0 - 1, 2 * dy0, 2 * dy0 + 1):
                v = _accord(X, Y, GW, GH, e, dx, dy, masque=M)
                if v > fin[0]:
                    fin = (v, e)
    # « Sans zoom » a la MEME taille et sur le MEME masque, en laissant
    # l'image glisser : un cadre qui bouge sans grossir n'est pas un zoom.
    sans = max(_accord(X, Y, GW, GH, 1.0, dx, dy, masque=M)
               for dx in (-4, -2, -1, 0, 1, 2, 4) for dy in (-4, -2, -1, 0, 1, 2, 4))
    ech = fin[1] if sens == 1 else 1.0 / fin[1]
    return round(ech, 3), fin[0], sans


# Les seuils, regles le 23/11 sur 6 mesures dont on connait la reponse et
# 20 vrais clips sans zoom :
#   - sous 3,5 % on ne dit rien, c'est le tremblement d'une main ;
#   - le recalage doit aligner au moins 8 points de plus que l'image telle
#     quelle. Un plan sans zoom donne EXACTEMENT 0 (16 clips sur 20) ; les
#     vrais zooms, +15 a +21 ;
#   - et aligner au moins la moitie du detail de l'image. En dessous, c'est
#     la CAMERA qui se deplace (plan filme en marchant) : les 4 faux zooms
#     restants mesuraient 0,37 a 0,42, les vrais 0,54 a 0,65.
# La valeur est INDICATIVE : un indice pour Claude, qui tranche avec les
# images. Mesures : ×1,04 pour 1,055 reel, ×1,17 pour 1,16, ×1,22 pour 1,22.
ZOOM_MINI = 0.035
ZOOM_GAIN = 0.08
ZOOM_ACCORD = 0.5


def _zoom(A, B):
    if not A or not B:
        return None
    ech, accord, sans = _recale(A, B)
    if abs(ech - 1.0) < ZOOM_MINI or accord < ZOOM_ACCORD or accord - sans < ZOOM_GAIN:
        return None
    return ech


def mesurer_zoom(chemin, ta, tb, progressif=True):
    """L'echelle de l'image a `tb` par rapport a celle a `ta`, ou None si
    rien ne se recale (pas de zoom, ou trop de mouvement pour le dire).

    `progressif` (le zoom d'un plan) : mesure en DEUX MOITIES d'abord. Sur
    une demi-duree la personne a moins bouge et la lumiere moins change —
    un zoom de 16 % sur un plan ou la personne gesticule ne se recalait
    pas d'un bout a l'autre (accord 0,36), mais chaque moitie donnait
    ×1,08, accord 0,65. Deux moities dans le meme sens = un zoom continu."""
    A, B = _gris(chemin, ta), _gris(chemin, tb)
    if progressif and tb - ta >= 0.6:
        M = _gris(chemin, (ta + tb) / 2)
        z1, z2 = _zoom(A, M), _zoom(M, B)
        if z1 and z2 and (z1 > 1) == (z2 > 1):
            return round(z1 * z2, 3)
    return _zoom(A, B)


def mesurer_coupe(chemin, t):
    """Ce qui se passe autour de la coupe a l'instant `t` :
    {"type": "seche" | "noir" | "flash" | "fondu" | "glisse", "duree": s}.
    Memes criteres que `coupes_douces` : une transition n'est annoncee que
    RECONNUE. Un mouvement autour d'une coupe seche reste une coupe seche."""
    cad = 15
    t0 = max(0.0, t - 0.45)
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{t0:.3f}", "-t", "1.05", "-i", str(chemin),
         "-vf", f"fps={cad},scale={PW}:{PH},format=gray", "-f", "rawvideo", "pipe:1"],
        capture_output=True)
    px = PW * PH
    n = len(p.stdout) // px
    seche = {"type": "seche", "duree": 0.0}
    if n < 6:
        return seche
    F = [p.stdout[i * px:(i + 1) * px] for i in range(n)]
    L = [sum(f) / float(px) for f in F]
    bords = min(L[0], L[-1])
    creux, pic = min(L), max(L)
    if creux < 22 and bords > creux + 20:
        k = sum(1 for v in L if v < creux + (bords - creux) * 0.6)
        return {"type": "noir", "duree": round(min(1.0, max(0.2, k / cad)), 2)}
    if pic > 215 and max(L[0], L[-1]) < pic - 35:
        k = sum(1 for v in L if v > pic - (pic - max(L[0], L[-1])) * 0.6)
        return {"type": "flash", "duree": round(min(1.0, max(0.2, k / cad)), 2)}
    D = [0.0] + [_dif(F[i], F[i - 1]) for i in range(1, n)]
    im = max(range(n), key=lambda i: D[i])
    # L'etendue du passage : ce qui change au moins moitie autant que le pic.
    seuil = max(D[im] * 0.55, 3.0)
    a = b = im
    while a > 1 and D[a - 1] > seuil:
        a -= 1
    while b < n - 1 and D[b + 1] > seuil:
        b += 1
    k = b - a + 1
    if k < 3 or D[im] < 6:
        return seche
    typ = _transition(F, a, b)
    if not typ:
        return seche
    return {"type": typ, "duree": round(min(1.0, max(0.2, k / cad)), 2)}


def planche(chemin, t):
    """Six images cote a cote autour de la coupe, pour que Claude VOIE la
    transition : une seule image a envoyer."""
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t - 0.3):.3f}", "-t", "0.9",
         "-i", str(chemin), "-vf", "fps=7,scale=150:-2,tile=6x1", "-frames:v", "1",
         "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "6", "pipe:1"],
        capture_output=True)
    return p.stdout or None


TRANSITION_NOM = {"noir": "fondu par le noir", "flash": "flash blanc",
                  "fondu": "fondu enchaîné", "glisse": "glissement"}


def mouvements(chemin, pl, coupes=True):
    """Zoom de chaque plan et nature de chaque coupe.
    -> ({numero de plan: phrase a ajouter a ses faits}, [(legende, image)])."""
    faits, images = {}, []
    nombre = lambda x: f"{x:.2f}".replace(".", ",")              # noqa: E731
    # Les coupes d'abord : le zoom d'un plan se mesure HORS de ses
    # transitions (une image prise dans un fondu par le noir ne se recale
    # sur rien, et le zoom du plan passait inapercu).
    entree = {}
    if coupes:
        for i in range(2, len(pl) + 1):
            entree[i] = mesurer_coupe(chemin, pl[i - 1][0])
    for i, (a, b) in enumerate(pl, 1):
        bouts = []
        e, sortie = entree.get(i), entree.get(i + 1)
        da = a + (e["duree"] + 0.05 if e and e["type"] != "seche" else 0.0)
        db = b - (sortie["duree"] / 2 + 0.1 if sortie and sortie["type"] in ("noir", "flash")
                  else 0.0)
        if db - da >= 0.5:
            m = min(0.12, (db - da) * 0.15)
            z = mesurer_zoom(chemin, da + m, db - m)
            if z:
                bouts.append(f"ZOOM MESURÉ ×{nombre(z)} entre le début et la fin du plan ("
                             + ("zoom avant" if z > 1 else "zoom arrière")
                             + ", valeur indicative)")
        if e and e["type"] != "seche":
            bouts.append(f"ENTRÉE MESURÉE : {TRANSITION_NOM[e['type']]}, "
                         f"~{nombre(e['duree'])} s")
            img = planche(chemin, a)
            if img:
                images.append((f"Coupe entre le plan {i - 1} et le plan {i} "
                               f"(à {a:.2f} s) : six images qui se suivent, de "
                               "gauche à droite", img))
        elif e:
            # Coupe seche : la meme prise, resserree d'un coup ?
            pa = pl[i - 2][0]
            z = mesurer_zoom(chemin, max(pa, a - 0.1), min(b, a + 0.1), False)
            if z:
                bouts.append(f"MÊME PRISE que le plan {i - 1}, "
                             + (f"RESSERRÉE ×{nombre(z)} d'un coup" if z > 1
                                else f"élargie ×{nombre(z)} d'un coup"))
        if bouts:
            faits[i] = " ; ".join(bouts)
    return faits, images


def lire_exemple(chemin, pl, progres=None, coupes=True):
    """Ce que Claude regarde pour comprendre le montage de l'exemple :
    (images, faits). Trois images par plan (debut, milieu, fin — deux au-
    dela de 12 plans, le message reste raisonnable), en 480 de large pour
    lire le texte a l'ecran ; et par plan, ce qui est DIT et le niveau du
    son. C'est ce qu'on regarde a la main quand on refait un reel."""
    if progres:
        progres(f"{len(pl)} plans — j'écoute la vidéo…")
    paroles = {}
    for ligne in paroles_par_plan(chemin, pl).splitlines():
        m = re.match(r"Plan (\d+): (.*)", ligne)
        if m:
            paroles[int(m.group(1))] = m.group(2)
    niveaux = niveaux_par_plan(chemin, pl)
    if progres:
        progres(f"{len(pl)} plans — je regarde chaque plan…")
    fractions = (0.12, 0.5, 0.88) if len(pl) <= 12 else (0.2, 0.8)
    images, faits = [], []
    for i, (a, b) in enumerate(pl, 1):
        for f in fractions:
            t = a + (b - a) * f
            images.append((f"Plan {i} ({a:.2f}–{b:.2f} s), image à {t:.2f} s",
                           image(chemin, t, 480)))
        db = niveaux[i - 1] if i - 1 < len(niveaux) else None
        son = ("silence" if db is not None and db < -50 else
               f"{db} dB" if db is not None else "?")
        faits.append(f"Plan {i} : {a:.2f}–{b:.2f} s ({b - a:.2f} s) ; son {son} ; dit : "
                     + (f"« {paroles[i]} »" if i in paroles else "rien"))
    # Zooms et transitions, MESURES (voir plus haut). `coupes=False` pour
    # les tranches d'une prise : leurs bords ne sont pas des coupes.
    if progres:
        progres(f"{len(pl)} plans — je mesure les zooms et les coupes…")
    try:
        mv, planches = mouvements(chemin, pl, coupes)
    except Exception:                                   # noqa: BLE001
        mv, planches = {}, []       # une mesure ratee ne bloque pas la lecture
    for i in mv:
        faits[i - 1] += " ; " + mv[i]
    if coupes:
        faits.append("Zooms et coupes : ce qui n'est PAS signalé ci-dessus a été mesuré "
                     "sans zoom et en coupe sèche.")
        part = PARTIELLES.get(str(chemin)) or []
        if part:
            faits.append(
                "COUPES PARTIELLES (une seule moitié de l'image change, l'autre continue SA "
                "prise — elles ne séparent PAS les plans ci-dessus) : "
                + " ; ".join(f"à {t:.2f} s la moitié {'basse' if m == 'haut' else 'haute'} change, "
                             f"la moitié {'haute' if m == 'haut' else 'basse'} continue"
                             for t, m in part[:12]))
    return images + planches, "\n".join(faits)


# ------------------------------------------------------------------
# LE MONTAGE SE DECIDE AVEC LES CLIPS (23/11)
# ------------------------------------------------------------------
# « Tu essaies encore de faire des categories puis de placer les clips
# dans des cases. Tu mets un exemple, tu rentres tous tes clips, ensuite
# toi tu vois quoi faire avec quel clip pour que ca ressemble le plus
# possible a la demo. » Avant : l'exemple donnait des cases, et le tri y
# rangeait les clips sans jamais remettre les cases en question — une
# case de trop, une case qui manque, et tout le lot etait faux. Quand des
# clips sont deja la, Claude les regarde EN MEME TEMPS que l'exemple : il
# decide du montage en sachant avec quoi il sera fait, et dit lui-meme
# quel clip joue quel role (`rangement`). Les categories restent la forme
# que le moteur connait ; ce n'est plus a la personne de les remplir.
SCHEMA_RANGEMENT = {"type": "array", "items": {
    "type": "object", "additionalProperties": False,
    "required": ["clip", "categorie", "remarque"],
    "properties": {
        "clip": {"type": "string"},
        "categorie": {"type": "integer"},
        "remarque": {"type": "string"}}}}

CONSIGNES_CLIPS = """

CLIPS DÉJÀ FILMÉS. La personne a déposé ses clips : on te les montre après
les images de l'exemple (deux images chacun, leur durée, et ce qui y est dit
quand on le sait). Le montage sera fait AVEC EUX. Tu es le monteur : regarde
ce que chaque clip EST (une réaction, quelqu'un qui explique, un écran
filmé, une démo, un plan de décor…) et quel rôle il peut jouer pour que la
vidéo ressemble le plus possible à l'exemple.
- Les catégories que tu rends décrivent le montage de l'EXEMPLE, mais
  pensées pour ces clips : si l'exemple a deux prises en haut (une
  réaction puis une explication) et que tu vois une réaction et une
  explication parmi les clips, ce sont bien deux catégories et chacun va
  dans la sienne. Si un seul clip couvre d'une traite ce que l'exemple
  montre en deux plans de la même prise, c'est UNE catégorie.
- « rangement » : UNE ligne par clip, sans en oublier. « clip » = son nom
  exact. « categorie » = le NUMÉRO de la catégorie où il va, en comptant à
  partir de 1 dans l'ordre de ta liste « categories » (les étapes
  comptent dans la numérotation mais ne reçoivent jamais de clip).
  LES CLIPS N'ONT PAS À RESSEMBLER À L'EXEMPLE : une autre personne, un
  autre décor, un autre produit, une idée un peu différente, c'est NORMAL —
  la personne refait la vidéo à sa façon. Range chaque clip dans la
  catégorie dont il peut jouer le RÔLE, même de loin, et dis ton doute dans
  « remarque ». 0 est réservé au clip dont tu ne vois vraiment pas quoi
  faire : elle le placera elle-même. Ne mets jamais 0 parce qu'un clip
  « n'est pas comme l'exemple ».
  Plusieurs clips qui jouent le même rôle vont dans la MÊME catégorie :
  ils seront tirés au sort d'une vidéo à l'autre.
- Un clip va là où il RESSEMBLE au plan de l'exemple (même cadrage, même
  type d'action), pas là où son nom de fichier ou sa case actuelle le
  suggère : la case actuelle peut être fausse, c'est pour ça qu'on te
  demande.
- Une catégorie dont l'exemple a besoin mais qu'aucun clip ne remplit reste
  dans la liste (elle sera à filmer) ; dis-le dans « tournage ».
- « remarque » = 12 mots maximum, seulement s'il y a un problème que l'image
  montre (mauvais cadrage, ne suit pas l'exemple), sinon "". Jamais de
  durée, de lumière ni de netteté : l'app les mesure déjà.
"""


def proposer_campagne(brief, exemple=None, progres=None, clips=None):
    """La campagne, la serie et la liste de tournage proposees par Claude.
    Rien n'est cree: c'est une proposition que l'utilisateur relit.
    `exemple` facultatif: sans lui, tout part du brief."""
    pl, images = [], []
    if exemple:
        if progres:
            progres("Lecture de la vidéo exemple…")
        pl = plans(exemple)
        images, faits = lire_exemple(exemple, pl, progres)
        if progres:
            progres(f"{len(pl)} plans — Claude comprend le montage…")
        fin = (f"\n\nLa vidéo exemple dure {duree(exemple):.1f} s et a {len(pl)} plans. "
               "PAROLES DE L'EXEMPLE et son, plan par plan (le son en dB : 0 = le "
               "plus fort, sous −50 = silence) :\n" + faits)
    else:
        if progres:
            progres("Claude prépare la campagne à partir du brief…")
        fin = "\n" + SANS_EXEMPLE
    schema = SCHEMA_CAMPAGNE
    if clips:
        # `clips` = [{"nom", "duree", "dit", "ou", "images": [(titre, jpeg)]}]
        schema = json.loads(json.dumps(SCHEMA_CAMPAGNE))
        schema["properties"]["rangement"] = SCHEMA_RANGEMENT
        schema["required"] = schema["required"] + ["rangement"]
        lignes = []
        for k in clips:
            images = list(images) + list(k.get("images") or [])
            lignes.append(f"- « {k['nom']} » : {k.get('duree') or 0:.1f} s"
                          + (f" ; rangé pour l'instant dans « {k['ou']} »" if k.get("ou") else "")
                          + (f" ; on y dit : « {k['dit'][:300]} »" if k.get("dit") else ""))
        fin += CONSIGNES_CLIPS + "\nLes clips (" + str(len(clips)) + ") :\n" + "\n".join(lignes)
        if progres:
            progres(f"Claude regarde l'exemple et tes {len(clips)} clips…")
    texte = (CONSIGNES_CAMPAGNE + "\n\nBRIEF DU CLIENT:\n" + (brief or "(aucun brief)") + fin)
    r = demander(texte, images, schema=schema, modele=SOIGNE, delai=600)
    r["plans"] = [{"debut": a, "fin": b, "duree": round(b - a, 3)} for a, b in pl]
    return r


# ------------------------------------------------------------------
# Une serie DECRITE en mots (21/11)
# ------------------------------------------------------------------
# Ce que le moteur sait faire. Sert a deux choses : que Claude traduise la
# description en reglages qui existent, et qu'il dise HONNETEMENT ce qui
# n'existe pas (`manque`) — c'est ce que « Le construire » ajoute ensuite
# (fonctionnalites.py). Une fonctionnalite construite qui ajoute un
# reglage doit aussi l'ajouter ici, sinon Claude la croira absente.
# ------------------------------------------------------------------
# LES REPRISES D'UNE PRISE (22/11)
# ------------------------------------------------------------------
# Une prise de talking head filmee d'une traite contient presque toujours
# une phrase recommencee. Couper les silences ne l'enleve pas : elle est
# PARLEE. C'est le seul endroit du montage ou il faut COMPRENDRE ce qui
# est dit — donc Claude, sur la transcription seule (pas d'image : la
# question est dans les mots).
SCHEMA_REPRISES = {
    "type": "object", "additionalProperties": False, "required": ["retirer"],
    "properties": {"retirer": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["de", "a", "pourquoi"],
        "properties": {"de": {"type": "integer"}, "a": {"type": "integer"},
                       "pourquoi": {"type": "string"}}}}}}

CONSIGNES_REPRISES = """\
Voici la transcription MOT PAR MOT d'une prise de talking head, filmée
d'une traite pour une vidéo courte (TikTok / Reels). Chaque mot porte son
numéro ; « ‖0,8 s‖ » est une pause.

La personne ne coupe pas la caméra quand elle se trompe : elle recommence
sa phrase. Rends les passages à RETIRER pour qu'il reste UNE seule bonne
version de chaque phrase, dans l'ordre :
- une phrase (ou un début de phrase) dite plusieurs fois : garde la
  DERNIÈRE version complète, retire les précédentes — sauf si la dernière
  est elle-même coupée, alors garde la dernière qui va au bout ;
- un faux départ, un bafouillage repris tout de suite (« je veux, je veux
  te montrer » : retire le premier « je veux ») ;
- ce qui n'est pas la vidéo : « ok c'est parti », « attends », « je
  recommence », « merde », « c'est bon », un rire ou un commentaire entre
  deux prises, ce qui est dit avant de commencer ou après avoir fini.
« de » et « a » sont des numéros de mots, bornes COMPRISES.

Ne retire JAMAIS un mot au milieu d'une phrase gardée, ni une répétition
VOULUE (« très, très bon »), ni un « euh » isolé. Une prise propre : liste
vide. Dans le doute, garde — un mot en trop se voit moins qu'une phrase
coupée."""


def reprises(mots, script="", notes=""):
    """Les passages a retirer d'une prise. `mots` = [(mot, debut, fin)] en
    secondes. Rend [(de, a, pourquoi)], numeros de mots bornes comprises.
    `notes` = les precisions ecrites pour le monteur sur la serie : elles
    valent pour CHAQUE prise (« enleve quand je dis le nom du client »)."""
    if len(mots) < 4:
        return []
    bouts = []
    for n, (w, x, _y) in enumerate(mots):
        if n and x - mots[n - 1][2] >= 0.35:
            bouts.append("‖" + f"{x - mots[n - 1][2]:.1f}".replace(".", ",") + " s‖")
        bouts.append(f"{n}:{w}")
    texte = (CONSIGNES_REPRISES
             + ("\n\nLE SCRIPT PRÉVU (ce que la vidéo finie doit dire, à peu près) :\n"
                + script.strip() if (script or "").strip() else "")
             + ("\n\nPRÉCISIONS DE LA PERSONNE pour le monteur (elles l'emportent sur les "
                "règles ci-dessus pour ce qu'on garde ou retire ; ignore celles qui ne "
                "parlent pas des coupes) :\n" + notes.strip() if (notes or "").strip() else "")
             + "\n\nLA PRISE :\n" + " ".join(bouts))
    r = demander(texte, schema=SCHEMA_REPRISES, modele=SOIGNE, delai=180)
    out = []
    for x in r.get("retirer") or []:
        try:
            de, a = int(x.get("de")), int(x.get("a"))
        except (TypeError, ValueError):
            continue
        if 0 <= de <= a < len(mots):
            out.append((de, a, str(x.get("pourquoi") or "").strip()))
    return sorted(out)


POUVOIRS = """\
Ce que le plateau sait faire pour le montage d'une série :
- une suite de CATÉGORIES (un clip tiré au sort par catégorie), chacune avec
  sa durée (min/max), ses textes à l'écran (tirés au sort, position haut /
  milieu / bas), garder ou couper le son du clip, passer le clip en entier,
  miroir, faire entrer la musique à partir de cette catégorie ;
- les textes façon TikTok : taille, style (contour noir, pastille, nu) ;
- musique de fond tirée au sort (dossier de musiques), volume, ou aucune ;
- mélanger l'ordre des catégories à chaque vidéo ;
- SÉRIE PARLÉE : sous-titres automatiques mot à mot (whisper) de ce qui est
  dit, et une BANQUE D'IMAGES par mot déclencheur (quand la personne dit
  « argent », une image du dossier « argent » s'affiche jusqu'à la fin de
  la phrase ou jusqu'au mot suivant) ;
- COUPER LES SILENCES d'une catégorie où l'on parle : chaque clip commence
  au premier mot et finit au dernier (quelle que soit sa longueur), ou en
  plus les pauses du milieu sautent en jump cut ;
- LA PARTIE UTILE de chaque clip : le monteur regarde le clip et enlève
  l'installation de la caméra au début et la fin ratée ; ou garde un moment
  précis qu'on lui décrit ; ou coupe un nombre de secondes donné ;
- SPLIT SCREEN : un clip en haut, un en bas, des étapes de texte dans la
  bande entre les deux ; PLUSIEURS clips peuvent se relayer en haut
  (plusieurs catégories « haut », chacune tient sa durée de relais puis
  passe la main), chacun avec sa voix ; PLUSIEURS clips peuvent s'enchaîner
  en bas (plusieurs catégories « bas », chacune passe en entier, et le haut
  change au même instant que le bas) ; le CALAGE : le début de la réaction
  du haut posé sur un événement du bas, et les textes de la bande posés sur
  ce qui se passe dans l'enregistrement d'écran ;
- la frise de l'éditeur (textes posés sur des catégories), les voix off.
- ZOOM d'une catégorie : zoom avant ou arrière progressif sur toute la
  durée du plan, ou plan resserré d'un coup (« punch-in ») ;
- TRANSITION à l'entrée d'une catégorie : fondu enchaîné, fondu par le
  noir, flash blanc, glissement (le plan d'avant est poussé hors du cadre).
  Sans transition : coupe sèche.
- VITESSE d'une catégorie : ses clips passent en ACCÉLÉRÉ, de ×1 à ×4
  (la durée de la catégorie reste celle qu'on voit à l'écran). Pas de
  ralenti.
- UNE PRISE PAR VIDÉO (« prise ») : pour un talking head filmé chaque jour
  et utilisé UNE fois. On dépose la prise du jour, le plateau retire les
  phrases recommencées et les silences, applique le montage de la série et
  rend UNE vidéo par prise — rien n'est tiré au sort dans cette catégorie ;
Ce qui N'EXISTE PAS (exemples) : les autres transitions (zoom-transition,
rotation, glitch, volet), un zoom qui change À CHAQUE jump cut à
l'intérieur d'un même clip, un zoom qui suit le visage, effets sonores sur
un mot, textes animés mot par mot en couleur, filtres de couleur, émojis
animés, compteur à l'écran, fond flouté…
"""

SCHEMA_DECRIRE = json.loads(json.dumps({
    "type": "object", "additionalProperties": False,
    "required": ["nom", "resume", "serie", "reglages", "images_mots", "tournage", "manque"],
    "properties": {
        "nom": {"type": "string"},
        "resume": {"type": "string"},
        "serie": SCHEMA_CAMPAGNE["properties"]["serie"],
        "reglages": {"type": "object", "additionalProperties": False,
                     "required": ["taille_texte", "style_texte", "musique", "musique_volume",
                                  "melanger_ordre"],
                     "properties": {
                         "taille_texte": {"type": "integer"},
                         "style_texte": {"type": "string", "enum": ["contour", "pastille", "nu"]},
                         "musique": {"type": "boolean"},
                         "musique_volume": {"type": "number"},
                         "melanger_ordre": {"type": "boolean"}}},
        "images_mots": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["mot", "fin"],
            "properties": {"mot": {"type": "string"},
                           "fin": {"type": "string", "enum": ["phrase", "suivant"]}}}},
        "tournage": {"type": "array", "items": {"type": "string"}},
        "manque": {"type": "array", "items": {"type": "string"}}}}))
_cat = SCHEMA_DECRIRE["properties"]["serie"]["properties"]["categories"]["items"]
# (Les options miroir / musique_ici / silences sont deja dans le schema de
# campagne depuis le 22/11 : la lecture d'une video exemple les remplit.)
assert {"miroir", "musique_ici", "silences", "zoom_de", "transition"} <= set(_cat["required"])

CONSIGNES_DECRIRE = """\
L'utilisateur DÉCRIT en mots le montage qu'il veut pour une nouvelle série du
plateau. Traduis sa description en série : catégories, textes, réglages.

""" + POUVOIRS + """
Règles :
- Les catégories, durées, textes, « son », « complet », « consigne » et
  « script » suivent les mêmes règles que pour une campagne (ci-dessous).
  « plans » vide partout. « miroir » faux sauf demande. « musique_ici » vrai
  sur UNE catégorie seulement si la musique doit entrer en cours de vidéo.
  « silences » : "bords" ou "tous" sur les catégories où l'on parle quand il
  veut couper les silences (talking head : "bords" par défaut, "tous" s'il
  veut un montage serré / jump cuts), "" sinon.
  « zoom_de » / « zoom_a » 1 et 1, « transition » "" et « transition_duree »
  0, SAUF s'il demande un zoom ou une transition (voir plus bas).
  « vitesse » 1, sauf s'il demande un passage accéléré (1,5 ; 2 ; …).
- « prise » = vrai quand la vidéo est UN talking head filmé d'une traite et
  utilisé une seule fois (on dépose la prise du jour, on récupère la vidéo
  montée) — pas des clips qu'on mélange. Alors : la PREMIÈRE catégorie est
  la prise (son gardé, silences "tous"), et les catégories suivantes, s'il
  y en a, sont ce qui se réutilise d'un jour à l'autre (un plan de fin, une
  démo). Faux pour tout ce qui se remixe, et toujours faux en split.
- « parle » = vrai si la vidéo repose sur quelqu'un qui parle (sous-titres
  automatiques). Une banque d'images par mot (« images_mots ») n'a de sens
  QUE dans une série parlée : « mot » = le mot dit (un seul mot, minuscule),
  « fin » = « phrase » (l'image reste jusqu'à la fin de la phrase) ou
  « suivant » (jusqu'au mot suivant).
- « reglages » : taille_texte 70 par défaut (plus gros = 85–100), style
  « contour » par défaut, musique vrai sauf « sans musique », volume 1 (une
  série parlée : 0,1, la voix passe devant), melanger_ordre faux sauf
  demande.
- « manque » = ce que la description demande et que le plateau NE SAIT PAS
  faire, une phrase claire par chose, écrite comme une demande de
  fonctionnalité (« Un effet sonore quand un mot précis est dit »).
  Vide si tout existe. N'invente pas de réglage pour le remplacer.
- Il n'y a PAS de vidéo exemple : « duree » = ce qu'il dit, sinon une durée
  typique d'un UGC court ; le format split se choisit si SA DESCRIPTION
  parle de deux vidéos l'une sur l'autre.
- « nom » : court, si l'utilisateur n'en donne pas.
- « resume » : deux phrases sur la série obtenue.
- « tournage » : la liste de tournage, au moins 3 prises par catégorie.

Rappel des règles d'une campagne, pour les catégories :
""" + CONSIGNES_CAMPAGNE.split("Règles:", 1)[1].split("- « plateformes »", 1)[0]


def decrire_serie(description, brief="", progres=None):
    """-> la serie decrite, prete a etre creee (rien n'est cree ici)."""
    if progres:
        progres("Claude monte la série…")
    texte = (CONSIGNES_DECRIRE + "\n\nCE QUE L'UTILISATEUR VEUT :\n" + description
             + ("\n\nBRIEF DE LA CAMPAGNE (le produit, ses règles) :\n" + brief[:30000]
                if brief.strip() else ""))
    return demander(texte, schema=SCHEMA_DECRIRE, modele=SOIGNE, delai=600)


# ------------------------------------------------------------------
# Trier les clips deposes en vrac
# ------------------------------------------------------------------
SCHEMA_TRI = {
    "type": "object", "additionalProperties": False, "required": ["clips"],
    "properties": {"clips": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["clip", "categorie", "confiance", "remarque"],
        "properties": {
            "clip": {"type": "string"},
            "categorie": {"type": "string"},
            "confiance": {"type": "number"},
            "remarque": {"type": "string"}}}}}}

# Six clips par appel: deux images chacun plus les categories, ~5 000
# jetons — et un seul demarrage de Claude Code pour six.
TRI_LOT = 6


def trier(categories, clips, progres=None):
    """`categories` = [{"id", "nom", "consigne", "image": jpeg|None}],
    `clips` = [chemin]. Rend {nom du clip: {"categorie": id|"", "confiance",
    "remarque"}}."""
    refs = []
    for c in categories:
        if c.get("image"):
            refs.append((f"Exemple de la catégorie « {c['nom']} » (id {c['id']})", c["image"]))
    liste = "\n".join(f"- id {c['id']} — « {c['nom']} » : {c.get('consigne') or '(pas de consigne)'}"
                      for c in categories)
    out = {}
    for k in range(0, len(clips), TRI_LOT):
        lot = clips[k:k + TRI_LOT]
        if progres:
            progres(f"Tri des clips {k + 1} à {k + len(lot)} sur {len(clips)}…")
        images = list(refs)
        for ch in lot:
            d = duree(ch) or 1.0
            nom = os.path.basename(str(ch))
            images.append((f"Clip « {nom} » ({d:.1f} s) — début", image(ch, d * 0.25)))
            images.append((f"Clip « {nom} » — fin", image(ch, d * 0.75)))
        texte = (
            "Range chaque clip dans la catégorie de la série qui lui correspond.\n"
            "Catégories:\n" + liste + "\n\n"
            "Pour chaque clip: « categorie » = l'id de la catégorie la PLUS PROCHE. "
            "Les clips n'ont PAS à ressembler à l'exemple (autre personne, autre décor, "
            "autre produit, autre idée : c'est normal) : range chacun dans la catégorie "
            "dont il peut jouer le rôle, même de loin. \"\" seulement si tu ne vois "
            "vraiment aucune catégorie possible. Un clip qui ne suit pas bien la consigne va quand "
            "même dans sa catégorie, et tu le dis dans la remarque. « confiance » entre "
            "0 et 1. « remarque » = 12 mots maximum, SEULEMENT s'il y a un problème "
            "que l'image montre (ne suit pas la consigne, mauvais cadrage, on ne voit "
            "pas le produit, contenu à risque pour le client), sinon \"\". Ne parle "
            "jamais de durée, de lumière ni de netteté: l'app les mesure déjà. "
            "Réponds pour chacun de ces clips: "
            + ", ".join(f"« {os.path.basename(str(c))} »" for c in lot))
        r = demander(texte, images, schema=SCHEMA_TRI, modele=RAPIDE)
        for x in r.get("clips") or []:
            out[str(x.get("clip") or "")] = {
                "categorie": str(x.get("categorie") or ""),
                "confiance": float(x.get("confiance") or 0),
                "remarque": str(x.get("remarque") or "")}
    return out


# ------------------------------------------------------------------
# LES BONS MOMENTS D'UN CLIP (23/11)
# ------------------------------------------------------------------
# « Il faut que Claude prenne les bons moments de la video : pendant qu'on
# setup la camera, ou a la fin quand c'est plus pertinent, ca choisit pas
# ca. » Un clip filme au telephone commence presque toujours par la
# personne qui recule de l'objectif et finit par elle qui revient
# l'arreter. Le moteur prenait le clip depuis sa premiere image. Claude
# regarde donc chaque clip comme une PELLICULE — une image toutes les
# demi-secondes aux deux bouts, la ou sont les dechets, et quelques-unes
# au milieu — et rend la partie utile (`debut`, `fin`), que le moteur
# connait deja (`par_clip`, `remixer.plage_utile` : rien n'est jamais pris
# en dehors). Une consigne de la personne (« prends le moment ou je leve
# les bras ») passe par le meme chemin.
PELLICULE_PAS = 0.5
PELLICULE_BOUT = 4.0        # secondes regardees de pres a chaque bout
PELLICULE_MAX = 24          # images par clip
MOMENTS_LOT = 3             # clips par appel


def pellicule(chemin, d=None):
    """[(instant, jpeg)] du clip : une image par demi-seconde dans les
    premieres et les dernieres secondes, six au milieu. UN seul passage de
    ffmpeg (une image par appel coutait vingt demarrages par clip)."""
    d = d or duree(chemin)
    if d <= 0:
        return []
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(chemin),
         "-vf", f"fps={1 / PELLICULE_PAS:g},scale=200:-2",
         "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "6", "pipe:1"],
        capture_output=True)
    brut = p.stdout or b""
    debuts = [m.start() for m in re.finditer(b"\xff\xd8\xff", brut)]
    images = [brut[a:b] for a, b in zip(debuts, debuts[1:] + [len(brut)])]
    tout = [(round(k * PELLICULE_PAS, 2), im) for k, im in enumerate(images)
            if k * PELLICULE_PAS <= d + 0.01]
    if len(tout) <= PELLICULE_MAX:
        return tout
    tete = [x for x in tout if x[0] < PELLICULE_BOUT]
    queue = [x for x in tout if x[0] > d - PELLICULE_BOUT]
    milieu = [x for x in tout if x not in tete and x not in queue]
    # Le milieu, reparti sur TOUTE sa longueur (un pas entier laissait un
    # trou de quatre secondes avant la fin sur un clip de 20 s).
    n = max(2, PELLICULE_MAX - len(tete) - len(queue))
    choisis = sorted({min(len(milieu) - 1, int((i + 0.5) * len(milieu) / n)) for i in range(n)})
    return tete + [milieu[i] for i in choisis] + queue


SCHEMA_MOMENTS = {
    "type": "object", "additionalProperties": False, "required": ["clips"],
    "properties": {"clips": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["clip", "ce_qu_on_voit", "debut", "fin", "sur", "raison"],
        "properties": {
            "clip": {"type": "string"},
            "ce_qu_on_voit": {"type": "string"},
            "debut": {"type": "number"},
            "fin": {"type": "number"},
            "sur": {"type": "number"},
            "raison": {"type": "string"}}}}}}

CONSIGNES_MOMENTS = """\
Tu es monteur. Pour chaque clip, on te montre sa PELLICULE : des images
datées (l'instant en secondes dans le clip), serrées au début et à la fin,
plus espacées au milieu. Trouve la PARTIE UTILE de chaque clip : ce qu'un
monteur garderait.

À ENLEVER au début : la personne qui vient de lancer l'enregistrement (main
ou visage collé à l'objectif, bras tendu vers le téléphone), qui recule ou
va se placer, qui replace le téléphone, qui regarde l'écran pour vérifier le
cadre, qui attend immobile avant de commencer ; l'image qui bouge pendant
qu'on pose le téléphone.
À ENLEVER à la fin : la personne qui sort de son jeu (elle arrête de jouer,
rit, regarde ailleurs), qui s'avance vers le téléphone ou tend le bras pour
arrêter, l'image qui bascule ; sur un écran filmé, le retour à l'accueil ou
le centre de contrôle.
Au MILIEU on ne coupe rien : une seule partie, d'un seul tenant.

- « ce_qu_on_voit » : D'ABORD, décris en une phrase le déroulement du clip
  avec les instants (« 0–1,5 s il recule de la caméra ; 1,5–7 s la
  réaction ; 7–8,7 s il vient arrêter »). C'est ce qui te fait choisir.
- « debut » = l'instant de la PREMIÈRE image où l'action utile a commencé.
  « fin » = l'instant de la DERNIÈRE image encore bonne. Si le clip est bon
  d'un bout à l'autre : debut 0 et fin = sa durée. Dans le doute, garde :
  couper une bonne seconde coûte plus cher qu'en laisser une moyenne.
- Si on te donne ce qui est DIT avec ses instants, la partie utile contient
  toutes les paroles utiles : ne coupe jamais un mot.
- « La partie doit durer N s » : garde au moins N secondes quand le clip les
  a ; s'il faut choisir, garde les N meilleures secondes d'un seul tenant
  (le moment le plus fort, pas forcément le début).
- Si la personne a donné une CONSIGNE (« le moment où je lève les bras »,
  « pas le bout où je ris »), elle passe avant tout le reste : la partie
  utile est le passage qu'elle décrit.
- « sur » entre 0 et 1 : ta certitude sur ces deux instants. « raison » = 10
  mots maximum sur ce que tu as enlevé (« installation de la caméra au
  début »), "" si tu gardes tout.
"""


def bons_moments(clips, consigne="", progres=None):
    """`clips` = [{"nom", "duree", "partie", "attendu", "voulu", "dit",
    "images": [(t, jpeg)]}]. Rend {nom: {"debut", "fin", "sur", "raison",
    "vu"}}. Sonnet : c'est un jugement de monteur, et une mauvaise coupe
    s'ecrit dans toutes les videos de la serie."""
    out = {}
    for k in range(0, len(clips), MOMENTS_LOT):
        lot = clips[k:k + MOMENTS_LOT]
        if progres:
            progres("Je cherche les bons moments"
                    + (f" ({k + 1} à {k + len(lot)} sur {len(clips)})…" if len(clips) > MOMENTS_LOT else "…"))
        images, lignes = [], []
        for c in lot:
            for t, im in c.get("images") or []:
                images.append((f"« {c['nom']} » à {t:.1f} s", im))
            lignes.append(
                f"- « {c['nom']} » : dure {c['duree']:.1f} s ; partie « {c.get('partie') or '?'} »"
                + (f" ; ce qu'il faut y voir : {c['attendu'][:300]}" if c.get("attendu") else "")
                + (f" ; la partie doit durer {c['voulu']:.1f} s" if c.get("voulu") else "")
                + (f" ; ce qui est dit : {c['dit'][:400]}" if c.get("dit") else ""))
        texte = (CONSIGNES_MOMENTS + "\nLes clips :\n" + "\n".join(lignes)
                 + (f"\n\nCONSIGNE DE LA PERSONNE : {consigne[:600]}" if consigne else ""))
        r = demander(texte, images, schema=SCHEMA_MOMENTS, modele=SOIGNE, delai=300)
        for x in r.get("clips") or []:
            out[os.path.basename(str(x.get("clip") or ""))] = {
                "debut": float(x.get("debut") or 0), "fin": float(x.get("fin") or 0),
                "sur": float(x.get("sur") or 0), "raison": str(x.get("raison") or "")[:120],
                "vu": str(x.get("ce_qu_on_voit") or "")[:300]}
    return out


# ------------------------------------------------------------------
# LE CALAGE : RETROUVER UN INSTANT DANS UN CLIP (23/11)
# ------------------------------------------------------------------
# « Le clip de moi et mon ami avec la reaction doit etre time avec quand,
# dans le clip du bas, ils attrapent la balle » et « le texte du milieu
# sync avec les clips d'en bas ». Le moteur sait caler (`ancre` sur le clip
# du bas, `depart` sur celui du haut, `etapes` sur l'ecran filme) mais ces
# reperes se notaient a la main, clip par clip. Claude les retrouve : une
# pellicule reguliere pour situer l'instant, puis — pour un instant unique
# — un second regard image par image (un dixieme de seconde) autour.
SCHEMA_INSTANTS = {
    "type": "object", "additionalProperties": False, "required": ["clips"],
    "properties": {"clips": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["clip", "ce_qu_on_voit", "instants", "sur"],
        "properties": {
            "clip": {"type": "string"},
            "ce_qu_on_voit": {"type": "string"},
            "instants": {"type": "array", "items": {"type": "number"}},
            "sur": {"type": "number"}}}}}}

CONSIGNES_INSTANTS = """\
Tu es monteur et tu poses des REPÈRES sur des clips. Pour chaque clip on te
montre des images datées (l'instant en secondes dans le clip) et on te dit
quoi chercher. Réponds par des instants en secondes, lus sur les dates des
images.
- « ce_qu_on_voit » : D'ABORD, décris le déroulement du clip avec ses
  instants. C'est ce qui te fait choisir.
- UN instant demandé : « instants » = [l'instant]. L'événement tombe souvent
  ENTRE deux images : donne la date de la première image où il a eu lieu.
- PLUSIEURS instants demandés (une liste d'étapes) : « instants » = un
  instant par étape, dans le MÊME ordre, chacun étant le moment où l'écran
  qui correspond à l'étape APPARAÎT. Ils sont croissants. La première étape
  commence là où la question le dit (le début du clip, ou l'instant où la
  séquence des étapes commence). Un écran qui change = presque toujours une
  « coupe franche » mesurée : sers-t'en. Si une étape n'a pas d'écran à
  elle, répartis-la entre ses voisines.
- « sur » entre 0 et 1 : ta certitude. Si ce qu'on cherche n'est PAS dans le
  clip, « instants » vide et « sur » 0 — n'invente pas.
- « MESURÉ dans ce clip » : des instants relevés par l'app, au centième, là
  où l'image se met à bouger d'un coup, où le son monte d'un coup, où il y
  a une coupe franche. Les images t'aident à comprendre CE QUI se passe ;
  ces mesures disent QUAND, bien plus précisément que tes yeux sur des
  images espacées d'une demi-seconde. Quand ce qu'on cherche correspond à
  l'un de ces instants (une réaction qui démarre = l'image se met à bouger
  puis le cri monte ; un but = la foule monte ; un changement de sujet =
  une coupe franche), réponds CET instant mesuré. Attention aux faux amis :
  quelqu'un qui parle ou s'agite un peu AVANT sa vraie réaction fait aussi
  monter le son — la vraie réaction est celle où l'image ET le son partent
  ensemble et où, sur les images, la personne a vraiment changé.
"""


def pellicule_reguliere(chemin, d, maxi=40):
    """[(instant, jpeg)] a pas constant : 0,5 s jusqu'a 20 s de clip, plus
    large au-dela pour tenir en `maxi` images."""
    pas = 0.5
    while d / pas > maxi:
        pas += 0.5
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(chemin),
         "-vf", f"fps={1 / pas:g},scale=200:-2",
         "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "6", "pipe:1"],
        capture_output=True)
    brut = p.stdout or b""
    debuts = [m.start() for m in re.finditer(b"\xff\xd8\xff", brut)]
    return [(round(k * pas, 2), brut[a:b])
            for k, (a, b) in enumerate(zip(debuts, debuts[1:] + [len(brut)]))
            if k * pas <= d + 0.01][:maxi + 1]


def loupe(chemin, t, d, marge=0.6):
    """Les images autour de `t`, une tous les dixiemes de seconde."""
    a = max(0.0, t - marge)
    b = min(d, t + marge)
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{a:.3f}", "-t", f"{b - a:.3f}", "-i", str(chemin),
         "-vf", "fps=10,scale=240:-2",
         "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "5", "pipe:1"],
        capture_output=True)
    brut = p.stdout or b""
    debuts = [m.start() for m in re.finditer(b"\xff\xd8\xff", brut)]
    return [(round(a + k * 0.1, 2), brut[x:y])
            for k, (x, y) in enumerate(zip(debuts, debuts[1:] + [len(brut)]))]


# ------------------------------------------------------------------
# CLAUDE SITUE, LA MESURE PRECISE (23/11, « c'est mal sync, c'est juste mal
# analyse »). Sur des images Claude trouve un instant a 0,2-0,5 s pres ; or
# un calage faux de deux images se voit. Mesure sur les clips NFL Win dont
# les reperes avaient ete notes a la main : ces reperes tombent sur le SON.
# Le bas est muet jusqu'au touchdown puis la foule entre d'un coup (-90 dB
# -> -15 dB : 3,49 / 2,92 / 3,19 s, les valeurs notees au centieme) ; et le
# « depart » d'une reaction est le debut du CRI (2,9 et 3,2 s sur IMG_8984
# et 8986), pas le premier geste, qui le devance de 0,15 a 0,35 s. Quant a
# la coupe d'un clip du bas deja monte (le match, puis la demo), `scdet`
# la donne a l'image pres avec un score de 50 a 63, la ou un mouvement de
# camera fait 5 a 7. Donc : Claude dit OU regarder (a une seconde pres), et
# l'instant exact est LU dans le son ou dans la coupe. Sans attaque nette
# ni coupe franche a cet endroit, on garde ce que Claude a vu.
def enveloppe(chemin, pas=0.02):
    """Le niveau du son en dB, une valeur toutes les `pas` secondes ([] si
    le clip n'a pas de piste audio)."""
    import audioop
    p = subprocess.run(["ffmpeg", "-v", "error", "-i", str(chemin), "-vn", "-ac", "1",
                        "-ar", "8000", "-f", "s16le", "-"], capture_output=True)
    b, n = p.stdout or b"", int(8000 * pas) * 2
    return [20 * math.log10(max(audioop.rms(b[i:i + n], 2), 1) / 32768)
            for i in range(0, len(b) - n + 1, n)]


ATTAQUE_MINI = 10.0         # dB gagnes d'un coup pour parler d'une attaque
ATTAQUE_PAS = 0.02


def attaque_son(env, autour, avant=0.8, apres=0.9):
    """L'instant, pres de `autour`, ou le son MONTE d'un coup : le niveau
    des 0,2 s qui suivent contre celui des 0,3 s d'avant. -> secondes, ou
    None s'il n'y a pas d'attaque nette (moins de ATTAQUE_MINI dB, ou un son
    qui reste sous -45 dB)."""
    if not env:
        return None
    a = max(15, int((autour - avant) / ATTAQUE_PAS))
    b = min(len(env) - 10, int((autour + apres) / ATTAQUE_PAS))
    mieux, ou = 0.0, None
    for i in range(a, b):
        apres_ = sum(env[i:i + 10]) / 10
        avant_ = sum(env[i - 15:i]) / 15
        if apres_ > -45 and apres_ - avant_ > mieux:
            mieux, ou = apres_ - avant_, i
    if ou is None or mieux < ATTAQUE_MINI:
        return None
    # L'attaque elle-meme : la premiere trame de la montee qui depasse le
    # milieu entre « avant » et « apres ».
    seuil = (sum(env[ou - 15:ou]) / 15 + sum(env[ou:ou + 10]) / 10) / 2
    for i in range(max(a, ou - 8), ou + 10):
        if env[i] >= seuil:
            return round(i * ATTAQUE_PAS, 2)
    return round(ou * ATTAQUE_PAS, 2)


def mouvement(chemin):
    """Combien l'image bouge, 15 fois par seconde : la difference moyenne
    entre deux images qui se suivent (32x57, en gris). [] si illisible."""
    p = subprocess.run(["ffmpeg", "-v", "error", "-i", str(chemin),
                        "-vf", "fps=15,scale=32:57,format=gray", "-f", "rawvideo", "-"],
                       capture_output=True)
    brut, n = p.stdout or b"", 32 * 57
    F = [brut[i:i + n] for i in range(0, len(brut) - n + 1, n)]
    return [sum(abs(x - y) for x, y in zip(F[i], F[i - 1])) / n for i in range(1, len(F))]


def departs_mouvement(m):
    """Les instants ou l'image se met a BOUGER D'UN COUP apres un moment
    plus calme (une reaction, un geste, un ecran qui change) : la valeur
    depasse 2,2 fois le calme d'avant et y RESTE un tiers de seconde. Le
    geste devance le cri de 0,15 a 0,35 s. -> [(instant, force)]."""
    out, i = [], 6
    while i < len(m) - 5:
        calme = sorted(m[max(0, i - 10):i])
        base = calme[len(calme) // 2]
        seuil = max(base * 2.2, base + 6.0)
        if m[i] >= seuil and sum(1 for v in m[i:i + 5] if v >= seuil * 0.8) >= 4:
            out.append((round((i + 1) / 15.0, 2), round(sum(m[i:i + 5]) / 5 - base, 1)))
            i += 15                      # pas deux departs dans la meme seconde
        else:
            i += 1
    return out


def attaques_son(env):
    """Les instants ou le son MONTE D'UN COUP et tient : 12 dB de plus sur
    les 0,4 s qui suivent que sur les 0,4 s d'avant. -> [(instant, dB)]."""
    out, i, k = [], 20, 20
    while i < len(env) - k:
        gain = sum(env[i:i + k]) / k - sum(env[i - k:i]) / k
        if gain >= 12 and sum(env[i:i + k]) / k > -40:
            # le sommet de cette montee
            j = max(range(i, min(i + 15, len(env) - k)),
                    key=lambda x: sum(env[x:x + k]) / k - sum(env[x - k:x]) / k)
            t = attaque_son(env, j * ATTAQUE_PAS, 0.25, 0.25)
            if t is not None:
                out.append((t, round(sum(env[j:j + k]) / k - sum(env[j - k:j]) / k, 0)))
            i = j + 25
        else:
            i += 1
    return out


def reperes_mesures(chemin, d):
    """Tout ce qui se MESURE dans un clip et peut servir de repere : les
    departs de mouvement, les attaques du son, les coupes franches. C'est
    la liste que Claude recoit avant de choisir."""
    env = enveloppe(chemin)
    return {"env": env,
            "mouvement": [x for x in departs_mouvement(mouvement(chemin)) if x[0] < d][:8],
            "son": [x for x in attaques_son(env) if x[0] < d][:8],
            "coupe": [x for x in coupes_fortes(chemin) if 0.2 < x[0] < d - 0.2][:8]}


def au_plus_pres(liste, t, marge):
    """L'instant de `liste` [(instant, force)] le plus proche de `t`."""
    pres = [(abs(x[0] - t), x[0]) for x in liste if abs(x[0] - t) <= marge]
    return min(pres)[1] if pres else None


COUPE_FORTE = 15.0          # score de scdet d'une vraie coupe de montage


def coupes_fortes(chemin):
    """[(instant, score)] des coupes FRANCHES d'un clip : un vrai changement
    d'image (score de 15 et plus), pas un mouvement de camera (5 a 7)."""
    p = subprocess.run(["ffmpeg", "-v", "info", "-i", str(chemin), "-vf",
                        f"scdet=threshold={COUPE_FORTE}", "-f", "null", "-"],
                       capture_output=True, text=True)
    return [(round(float(t), 3), float(sc)) for sc, t in re.findall(
        r"lavfi\.scd\.score:\s*([0-9.]+),\s*lavfi\.scd\.time:\s*([0-9.]+)", p.stderr)]


def coupe_pres(coupes, autour, marge=1.2):
    """La coupe franche la plus FORTE a moins de `marge` de `autour`."""
    pres = [(sc, t) for t, sc in coupes if abs(t - autour) <= marge]
    return max(pres)[1] if pres else None


def _instants(lot, loupes=False):
    images, lignes = [], []
    for c in lot:
        for t, im in c["images"]:
            images.append((f"« {c['nom']} » à {t:.1f} s", im))
        m = c.get("reperes") or {}
        f2 = lambda xs: ", ".join(f"{x[0]:.2f}" for x in xs)
        mesure = " ; ".join(x for x in (
            f"l'image se met à bouger d'un coup à {f2(m['mouvement'])} s" if m.get("mouvement") else "",
            f"le son monte d'un coup à {f2(m['son'])} s" if m.get("son") else "",
            f"coupe franche à {f2(m['coupe'])} s" if m.get("coupe") else "") if x)
        lignes.append(f"- « {c['nom']} » (dure {c['duree']:.1f} s) — cherche : {c['question']}"
                      + (f"\n  MESURÉ dans ce clip : {mesure}." if mesure else ""))
    texte = (CONSIGNES_INSTANTS
             + ("\nCes images sont un GROS PLAN dans le temps (une tous les dixièmes de "
                "seconde) autour de l'instant déjà repéré : donne l'instant EXACT.\n"
                if loupes else "")
             + "\nLes clips :\n" + "\n".join(lignes))
    r = demander(texte, images, schema=SCHEMA_INSTANTS, modele=SOIGNE, delai=300)
    out = {}
    for x in r.get("clips") or []:
        out[os.path.basename(str(x.get("clip") or ""))] = {
            "instants": [float(v) for v in (x.get("instants") or [])],
            "sur": float(x.get("sur") or 0), "vu": str(x.get("ce_qu_on_voit") or "")[:300]}
    return out


def reperer(clips, progres=None):
    """`clips` = [{"nom", "chemin", "duree", "question", "precis"}]. Rend
    {nom: {"instants", "sur", "vu"}}. `precis` = UN instant, affine au
    dixieme par un second regard. Deux clips par appel, les appels EN MEME
    TEMPS (trois de front) : huit clips l'un apres l'autre prenaient deux
    minutes."""
    from concurrent.futures import ThreadPoolExecutor
    def prepare(c):
        c["images"] = pellicule_reguliere(c["chemin"], c["duree"], c.get("images_max") or 40)
        c["reperes"] = reperes_mesures(c["chemin"], c["duree"]) if c.get("mesures") else {}
    with ThreadPoolExecutor(max_workers=4) as ex:
        list(ex.map(prepare, clips))
    lots = [clips[k:k + 2] for k in range(0, len(clips), 2)]
    if progres:
        progres(f"Je cherche les repères dans {len(clips)} clip{'s' if len(clips) > 1 else ''}…")
    out = {}
    with ThreadPoolExecutor(max_workers=3) as ex:
        for r in ex.map(lambda lot: _essai(_instants, lot), lots):
            out.update(r)
    # LA MESURE (voir plus haut) : chaque instant demande dit comment il se
    # precise — `mesures` = une entree par instant : "son" (l'attaque du son
    # la plus proche), "coupe" (la coupe franche la plus proche) ou "".
    # Ce qui a ete mesure ne passe pas par la loupe.
    fins = []
    for c in clips:
        r = out.get(c["nom"])
        if not r or not r["instants"] or r["sur"] < 0.5:
            continue
        mes = c.get("mesures") or []
        rp = c.get("reperes") or {}
        r["mesure"] = []
        for k, t in enumerate(list(r["instants"])):
            comment = mes[k] if k < len(mes) else ""
            exact, par = None, ""
            if comment == "attaque":
                # Claude a choisi ; on RECALE sur la mesure la plus proche.
                # Un depart de mouvement est suivi de son cri : c'est le cri
                # qu'on garde (les reperes notes a la main tombent dessus).
                tm = au_plus_pres(rp.get("mouvement") or [], t, 0.6)
                ts = au_plus_pres(rp.get("son") or [], t, 0.6)
                if tm is not None:
                    # Le cri = une attaque NETTE du son (12 dB qui tiennent)
                    # dans la demi-seconde qui suit le geste. Une petite
                    # montee dans un clip ou ca parle deja n'en est pas une
                    # (IMG_8980 : elle decalait le depart de 0,4 s).
                    cri = au_plus_pres(rp.get("son") or [], tm + 0.25, 0.35)
                    exact, par = (cri, "son") if cri is not None else (tm, "mouvement")
                elif ts is not None:
                    exact, par = ts, "son"
            elif comment == "coupe":
                exact, par = coupe_pres(rp.get("coupe") or [], t, 0.8), "coupe"
            elif comment == "ecran":
                # Un ecran qui change : la coupe la plus PROCHE (pas la plus
                # forte — il y en a une par changement d'ecran).
                exact, par = au_plus_pres(rp.get("coupe") or [], t, 0.7), "coupe"
            if exact is not None:
                r["instants"][k] = exact
            r["mesure"].append(par if exact is not None else "")
        if c.get("precis") and not r["mesure"][0]:
            fins.append(dict(c, images=loupe(c["chemin"], r["instants"][0], c["duree"])))
    if fins:
        if progres:
            progres("Je regarde image par image…")
        lots = [fins[k:k + 4] for k in range(0, len(fins), 4)]
        with ThreadPoolExecutor(max_workers=3) as ex:
            for r in ex.map(lambda lot: _essai(_instants, lot, True), lots):
                for nom, x in r.items():
                    # Le gros plan ne remplace le premier regard que s'il
                    # reste dans sa fenetre : sinon il s'est perdu.
                    if (x["instants"] and nom in out and out[nom]["instants"]
                            and abs(x["instants"][0] - out[nom]["instants"][0]) <= 0.75):
                        out[nom]["instants"][0] = x["instants"][0]
    return out


def _essai(f, *a):
    """Un lot en panne ne fait pas tomber les autres."""
    try:
        return f(*a)
    except IAError:
        return {}


# ------------------------------------------------------------------
# Repondre a une question
# ------------------------------------------------------------------
# ------------------------------------------------------------------
# UNE QUESTION SUR LA CAMPAGNE (23/11)
# ------------------------------------------------------------------
# « Si on a une question sur la campagne on lui pose, et si la reponse est
# dans le brief il peut la trouver » — et dans le contrat : les deux sont
# lus EN MEME TEMPS, avec la fiche du deal. Un brief est un contrat : une
# reponse inventee sur la paie ou sur un interdit coute plus cher que pas
# de reponse. Donc Claude doit CITER le passage, mot pour mot, et le
# serveur verifie que la citation est bien dans le document
# (`server.camp_question`) ; ce qui n'y est pas se dit (« trouve » faux).
SCHEMA_QUESTION = {
    "type": "object", "additionalProperties": False,
    "required": ["reponse", "trouve", "sources"],
    "properties": {
        "reponse": {"type": "string"},
        "trouve": {"type": "boolean"},
        "sources": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["ou", "extrait"],
            "properties": {
                "ou": {"type": "string", "enum": ["brief", "contrat", "fiche"]},
                "extrait": {"type": "string"}}}}}}

CONSIGNES_QUESTION = """\
Tu réponds à une question sur UNE campagne UGC, à partir de ses documents :
le BRIEF du client, le CONTRAT et la FICHE du deal tenue dans le plateau.
Tu les lis tous les trois avant de répondre.

Règles :
- Réponds SEULEMENT avec ce qui est écrit dans ces documents. Rien de ta
  culture générale, rien de « habituellement ». Si la réponse n'y est pas,
  « trouve » = faux et « reponse » dit en une phrase que les documents ne
  le disent pas, et ce qu'il faudrait demander au client. Ne devine jamais
  un chiffre, une date, une règle.
- « reponse » : en français, courte et directe (1 à 4 phrases, ou une
  petite liste avec « • » si la question appelle plusieurs points ; du
  texte simple, AUCUN markdown : ni **gras**, ni #, ni tableau). Donne
  le chiffre, la règle ou le lien lui-même, pas « voir le brief ». Garde
  dans leur langue les mots à dire, les hashtags, les noms et les liens.
- « sources » : pour chaque fait de ta réponse, le passage qui le prouve,
  RECOPIÉ MOT POUR MOT depuis le document (« extrait », une phrase ou une
  ligne, 200 caractères au plus, sans rien changer ni traduire), avec
  « ou » = brief, contrat ou fiche. Une à quatre sources. Aucune si
  « trouve » est faux.
- Si le brief et le contrat ne disent pas la même chose, dis-le : donne les
  deux, et rappelle que le CONTRAT fait foi. Si la fiche du plateau
  contredit le brief ou le contrat, signale-le aussi (la fiche a pu être
  saisie de travers).
- Une question vague (« c'est quoi les règles ? ») : l'essentiel en quelques
  points, pas tout le document.
"""


def question_campagne(question, brief="", contrat="", fiche="", historique=()):
    """-> {"reponse", "trouve", "sources": [{"ou", "extrait"}]}."""
    passe = "\n".join(f"{'Utilisateur' if q == 'moi' else 'Toi'}: {t}"
                      for q, t in list(historique)[-6:])
    texte = (CONSIGNES_QUESTION
             + "\n\n===== FICHE DU DEAL (dans le plateau) =====\n" + (fiche or "(vide)")
             + "\n\n===== BRIEF DU CLIENT =====\n" + (brief or "(pas de brief)")
             + "\n\n===== CONTRAT =====\n" + (contrat or "(pas de contrat)")
             + ("\n\n===== CONVERSATION JUSQU'ICI =====\n" + passe if passe else "")
             + "\n\n===== QUESTION =====\n" + question)
    return demander(texte, schema=SCHEMA_QUESTION, modele=SOIGNE, delai=180)


def repondre(question, contexte, historique=()):
    """`contexte` = ce que le plateau sait de l'etat (texte), `historique`
    = [(qui, texte)] des derniers echanges."""
    passe = "\n".join(f"{'Utilisateur' if q == 'moi' else 'Toi'}: {t}"
                      for q, t in list(historique)[-8:])
    texte = (
        "ÉTAT ACTUEL DU PLATEAU (ce que l'app sait, à jour):\n" + contexte +
        ("\n\nCONVERSATION JUSQU'ICI:\n" + passe if passe else "") +
        "\n\nQUESTION: " + question +
        "\n\nRéponds en 1 à 5 phrases courtes, concrètes, en nommant les boutons "
        "et les écrans du plateau tels qu'ils sont décrits plus haut. Si la "
        "question demande quoi faire ensuite, donne UNE prochaine étape.")
    return demander(texte, modele=RAPIDE, systeme=SYSTEME + "\n\n" + GUIDE)


# ------------------------------------------------------------------
# Le monteur et le chef de campagne: une demande -> des changements
# ------------------------------------------------------------------
# Claude ne touche a rien lui-meme (aucun outil, `--tools ""`): il rend une
# LISTE D'ACTIONS, que le serveur traduit en requetes sur les routes
# existantes — celles de l'interface, avec leurs gardes — et que
# l'utilisateur applique d'un clic. Un objet plat plutot qu'une union par
# type: le schema reste lisible pour le modele, et le serveur ne lit que
# les champs qui ont un sens pour le type.
SCHEMA_PARLER = {
    "type": "object",
    "properties": {
        # EN PREMIER, et c'est voulu : la reponse s'ecrit dans l'ordre du
        # schema, donc Claude decompose la demande AVANT d'ecrire la
        # moindre action (voir METHODE).
        "raisonnement": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["demande", "comment"],
            "properties": {"demande": {"type": "string"},
                           "comment": {"type": "string"}}}},
        "reponse": {"type": "string"},
        "manque": {"type": "string"},
        "actions": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "type": {"type": "string", "enum": [
                    "categorie", "nouvelle_categorie", "ordre", "serie",
                    "campagne", "generer", "tache", "texte_video", "moments",
                    "calage", "buffer", "ranger"]},
                "compte": {"type": "string"},
                "moment_bas": {"type": "string"},
                "moment_haut": {"type": "string"},
                "caler_etapes": {"type": "boolean"},
                "clip": {"type": "string"},
                "moment": {"type": "string"},
                "coupe_debut": {"type": "number"},
                "coupe_fin": {"type": "number"},
                "entier": {"type": "boolean"},
                "bloc": {"type": "string"},
                "de_categorie": {"type": "string"},
                "jusqua_categorie": {"type": "string"},
                "decalage_debut": {"type": "number"},
                "decalage_fin": {"type": "number"},
                "supprimer": {"type": "boolean"},
                "serie": {"type": "string"},
                "categorie": {"type": "string"},
                "nom": {"type": "string"},
                "dur_min": {"type": "number"},
                "dur_max": {"type": "number"},
                "textes": {"type": "array", "items": {"type": "string"}},
                "position_texte": {"type": "string", "enum": ["haut", "milieu", "bas"]},
                "son": {"type": "boolean"},
                "complet": {"type": "boolean"},
                "mise_de_cote": {"type": "boolean"},
                "consigne": {"type": "string"},
                "script": {"type": "string"},
                "miroir": {"type": "boolean"},
                "musique_ici": {"type": "boolean"},
                "role": {"type": "string", "enum": ["", "haut", "bas", "etape"]},
                "silences": {"type": "string", "enum": ["", "bords", "tous"]},
                "zoom_de": {"type": "number"},
                "zoom_a": {"type": "number"},
                "transition": {"type": "string",
                               "enum": ["", "fondu", "noir", "flash", "glisse"]},
                "transition_duree": {"type": "number"},
                "vitesse": {"type": "number"},
                "relais": {"type": "number"},
                "split": {"type": "boolean"},
                "parle": {"type": "boolean"},
                "prise": {"type": "boolean"},
                "images_mots": {"type": "array", "items": {
                    "type": "object", "properties": {
                        "mot": {"type": "string"},
                        "fin": {"type": "string", "enum": ["phrase", "suivant"]}},
                    "required": ["mot"]}},
                "ordre": {"type": "array", "items": {"type": "string"}},
                "envoi_auto_jour": {"type": "integer"},
                "taille_texte": {"type": "integer"},
                "style_texte": {"type": "string", "enum": ["contour", "pastille", "nu"]},
                "melanger_ordre": {"type": "boolean"},
                "musique_volume": {"type": "number"},
                "sans_musique": {"type": "boolean"},
                "legendes_post": {"type": "array", "items": {"type": "string"}},
                "objectif_jour": {"type": "integer"},
                "paie_video": {"type": "number"},
                "cycle_paie": {"type": "string"},
                "date_paie": {"type": "string"},
                "notes": {"type": "string"},
                "statut": {"type": "string"},
                "pause": {"type": "boolean"},
                "nombre": {"type": "integer"},
                "texte": {"type": "string"},
            },
            "required": ["type"],
        }},
    },
    "required": ["raisonnement", "reponse", "actions"],
}

CONSIGNES_PARLER = """Tu es à la fois le MONTEUR et le CHEF DE CAMPAGNE de l'utilisateur. Il te
parle comme à un collègue : « raccourcis l'accroche », « mets le texte plus
gros », « passe cette campagne à 5 vidéos par jour », « exporte-m'en une ».

Si sa demande se traduit en changements, mets-les dans `actions` : l'app
les APPLIQUE TOUT DE SUITE, sans lui demander (il peut annuler d'un clic),
sauf l'envoi auto et la pause d'une campagne, qu'il confirme. Dans
`reponse`, dis en 1 à 3 phrases ce que tu as changé (ou réponds à sa
question s'il n'y a rien à changer, et laisse `actions` vide). Il veut que
ce soit FAIT : traduis la demande en actions plutôt que de lui expliquer
où cliquer.

Les types d'action et leurs champs :
- categorie (serie, categorie = son nom EXACT dans l'état) : nom (renommer),
  dur_min/dur_max (secondes ; une durée fixe = les deux égaux), textes (la
  liste COMPLÈTE des textes à l'écran de la catégorie, tirés au sort — elle
  remplace l'ancienne : recopie ceux à garder), position_texte, son (garder
  le son du clip), complet (passer chaque clip en entier), mise_de_cote
  (true = ne sort plus au tirage, false = revient), consigne (ce qu'il faut
  filmer), script (les mots exacts à dire dans ce plan, mot pour mot,
  répliques séparées par « | »), miroir, musique_ici (la musique entre à
  partir de cette catégorie), role (split screen : "" = plan plein cadre
  avant le split, « haut » = le clip du haut, « bas » = le clip du bas,
  « etape » = un texte de la bande du milieu, sans clip, avec sa durée),
  silences ("bords" = chaque clip commence au premier mot et finit au
  dernier, quelle que soit sa longueur ; "tous" = en plus, les pauses au
  milieu sautent en jump cut ; "" = rien n'est coupé). Pour un talking
  head, « enlève les silences » = silences sur CHAQUE catégorie où l'on
  parle (son gardé ou série parlée).
  zoom_de / zoom_a (l'échelle de l'image au début et à la fin du plan :
  1 → 1,15 = zoom avant lent, 1,15 → 1 = zoom arrière, 1,2 et 1,2 = plan
  resserré d'un coup ; 1 et 1 = retire le zoom ; donne TOUJOURS les deux),
  transition (comment la catégorie ENTRE depuis le plan d'avant : "fondu",
  "noir", "flash", "glisse" ; "" = coupe sèche) et transition_duree
  (secondes, 0,3 par défaut), vitesse (1,5 = accéléré une fois et demie,
  2 = deux fois plus vite, jusqu'à 4 ; 1 = vitesse normale ; jamais moins
  de 1). « La partie 2 est accélérée », sans chiffre = 1,5.
  relais (SEULEMENT pour une catégorie « haut » d'un split qui en a
  plusieurs : combien de secondes ce clip tient en haut avant de passer la
  main au clip « haut » suivant ; 0 = jusqu'au bout de son clip). C'est LE
  réglage de « la réaction dure 4 s puis ça change pour l'autre clip » :
  dur_min/dur_max n'ont aucun effet sur un « haut » ni sur un « bas ».
  RETIRER une partie ou une étape (« enlève le step 5 ») = mise_de_cote
  true sur elle : il n'y a pas d'autre façon, et sans cette action elle
  reste dans la vidéo.
- nouvelle_categorie (serie, nom, + les mêmes champs que categorie).
- ordre (serie, ordre = les noms des catégories dans le nouvel ordre).
- serie (serie) : envoi_auto_jour (vidéos envoyées à Buffer par jour),
  taille_texte (taille des textes, 70 par défaut), style_texte,
  melanger_ordre, musique_volume (1 = normal), sans_musique, legendes_post
  (les légendes du post Instagram, liste complète), parle (série parlée :
  sous-titres automatiques), prise (true = UNE PRISE PAR VIDÉO : la
  première catégorie reçoit la prise du jour, reprises et silences retirés,
  une vidéo par prise — pour un talking head qu'on ne remixe pas), images_mots (la liste COMPLÈTE des mots
  déclencheurs d'images, [{mot, fin: phrase|suivant}] — seulement dans une
  série parlée ; chaque mot a son dossier où déposer les images), split
  (true = passer la série en SPLIT SCREEN). Pour passer une série en split :
  split true, ET des rôles sur les catégories — au moins une « haut » et UNE
  « bas » (crée-les avec nouvelle_categorie si besoin ; PLUSIEURS « bas »
  s'enchaînent l'une après l'autre, chacune en entier — un clip de match
  puis l'enregistrement d'écran = deux « bas »), les plans d'accroche
  gardent role "", et les textes de la bande deviennent des catégories
  « etape » (texte + dur_min = dur_max). Repasser en plein cadre : split
  false et role "" partout.
- campagne : nom, objectif_jour, paie_video, cycle_paie (hebdo, 2sem,
  mensuel), date_paie (AAAA-MM-JJ, un jour de paiement connu), notes (le
  texte COMPLET des notes), statut (ce qu'il reste à faire pour cette
  campagne, une phrase — "" pour le retirer), pause (true = arrêter de
  publier).
- generer (serie, nombre) : exporter des vidéos pour voir le résultat. Ajoute
  une action generer d'1 vidéo après un changement de montage quand il veut
  voir le résultat.
- moments (serie) : QUEL BOUT de chaque clip est utilisé. Un clip filmé au
  téléphone commence par la personne qui installe la caméra et finit par
  elle qui vient l'arrêter ; le plateau garde pour chaque clip sa « partie
  utile » et ne prend jamais rien en dehors. categorie (nom exact ; vide =
  toutes les catégories filmées) ; clip (le nom du fichier, seulement s'il
  parle d'UN clip précis ; vide = tous ceux de la catégorie) ; puis UN de :
  · moment = ce qu'il faut garder ou enlever, dit avec ses mots (« le moment
    où je lève les bras », « enlève quand j'installe la caméra », « juste la
    fin quand je montre l'écran », ou "bons moments" pour le laisser
    choisir) : le monteur REGARDE alors chaque clip image par image et
    choisit. C'est l'action pour tout ce qui se décrit par ce qu'on VOIT.
  · coupe_debut / coupe_fin = des secondes à enlever au début / à la fin de
    chaque clip, quand il donne un CHIFFRE (« coupe les 2 premières
    secondes ») : exact, sans regarder.
  · entier true = reprendre les clips en entier (annule un choix d'avant).
  « Ça commence trop tôt », « on me voit installer le téléphone », « la fin
  est poche », « prends le meilleur bout » → moments. Ce n'est PAS la durée
  de la catégorie (dur_min/dur_max = combien de temps le plan reste à
  l'écran, pas quel bout du clip).
- calage (serie) : en SPLIT, SYNCHRONISER le haut, le bas et les textes du
  milieu. Le monteur REGARDE alors chaque clip et pose les repères lui-même.
  moment_bas = l'événement de la vidéo du BAS qui sert de rendez-vous, dit
  pour qu'on le retrouve dans chaque clip (« l'instant où la balle est
  attrapée / où le jeu est réussi ») ; moment_haut = ce qui, dans le clip
  du HAUT, doit tomber dessus (« le début de la réaction ») ; les deux vides
  = pas de rendez-vous. caler_etapes true = chaque texte de la bande du
  milieu apparaît quand l'écran qui lui correspond arrive dans
  l'enregistrement du bas (au lieu d'une durée fixe). « Time la réaction
  avec le moment où… », « sync les textes avec la démo », « le texte du
  milieu suit pas l'écran » → calage. Quand le clip du haut n'a pas assez
  d'avance avant sa réaction, c'est le DÉBUT du clip du bas qui est rogné
  pour que les deux tombent ensemble ; sinon le clip du bas passe en entier.
- ranger (serie, clip = le nom du fichier, categorie = le nom exact) : METTRE
  un clip dans une catégorie, ou le changer de catégorie. C'est l'action
  quand il t'explique à quoi servent ses clips (« le clip où je suis assis
  va dans la partie 2 », « IMG_0360 c'est pour la fin », « les deux derniers
  sont des réactions ») : une action ranger PAR clip. Les clips « PAS ENCORE
  PLACÉS » de l'état attendent exactement ça, et on te montre une image de
  chacun. Un clip n'a PAS à ressembler à la vidéo exemple : autre personne,
  autre décor, autre idée, c'est son choix — range-le où IL le dit, sans
  discuter. S'il veut s'en servir d'une façon que les catégories ne
  prévoient pas, crée la catégorie (nouvelle_categorie) puis range le clip
  dedans.
- buffer (serie) : BRANCHER BUFFER pour cette campagne, c'est-à-dire la relier
  au compte Instagram sur lequel ses vidéos seront publiées. L'état a un
  bloc « PUBLICATION » : lis-le AVANT de répondre. compte = le pseudo du
  compte, pris dans « Comptes connectés dans Buffer » (vide = celui de la
  campagne, ou le seul compte connecté) ; envoi_auto_jour = combien de
  vidéos par jour envoyer tout seul, seulement s'il le demande. L'app relie
  alors la campagne et toutes ses séries à ce compte ; il CONFIRME d'un
  clic, parce que ça décide où ses vidéos partent en ligne. L'envoi auto
  exige au moins une légende du post : si l'état dit « 0 légende(s) »,
  ajoute aussi une action serie avec legendes_post (trois légendes courtes
  écrites pour ce produit), sinon rien ne partira.
  QUAND IL MANQUE UN BRANCHEMENT (« MANQUE » dans le bloc PUBLICATION, ou
  son compte n'est pas dans la liste), tu ne mets PAS d'action buffer : tu
  le GUIDES, avec le guide ci-dessous.
  POUR TOUT CE QUI TOUCHE BUFFER, RÉPONSE COURTE, SANS BLABLA (« ça marche
  oui ou non, et si non je fais quoi ») :
  · 1re ligne = le verdict : « Oui, c'est branché sur @compte. » / « Oui,
    à confirmer : … » / « Non, pas encore : il manque la clé Buffer. »
  · ensuite SEULEMENT ce qu'il doit FAIRE, en lignes numérotées, une action
    par ligne, 10 mots environ chacune. Rien d'autre : pas d'introduction,
    pas de pourquoi, pas de rappel, pas de remarque sur autre chose (clips,
    légendes) sauf si c'est CE QUI BLOQUE.
  · une seule chose manquante à la fois : s'il manque la clé ET Cloudflare,
    donne les étapes de la clé Buffer, puis une dernière ligne « Ensuite
    il restera Cloudflare R2 : redemande-moi. »
  · rien ne manque et rien à changer : la ligne du verdict, c'est tout.
- tache (texte) : une ligne dans sa todo.
- texte_video (serie) : un texte de la FRISE DE L'ÉDITEUR — seulement si
  l'état dit « FRISE DE L'ÉDITEUR : ACTIVE » ; c'est alors elle qui dessine
  les textes de la vidéo, pas les catégories (n'utilise PAS `textes` d'une
  catégorie dans ce cas, ça ne se verrait pas). bloc = l'id du bloc dans
  l'état (vide = nouveau texte) ; texte (le nouveau texte) ; de_categorie
  (où il commence, nom exact ; obligatoire pour un nouveau) ;
  jusqua_categorie (il s'arrête au DÉBUT de cette catégorie ; « fin » =
  jusqu'au bout) ; decalage_debut / decalage_fin (secondes, + = plus tard) ;
  position_texte ; taille_texte (70 par défaut) ; style_texte ;
  supprimer (true = retirer le bloc). EN SPLIT, les textes de la BANDE du
  milieu ne sont jamais des blocs : l'accroche est le premier des `textes`
  de la première catégorie « haut », et chaque étape a les siens — change-
  les par une action categorie avec `textes`.

Si la demande veut quelque chose que le plateau NE SAIT PAS faire (voir
ci-dessous), ne bricole pas avec un autre réglage : décris-le dans
`manque` (une phrase claire, écrite comme une demande de fonctionnalité),
et dis dans `reponse` que ça n'existe pas encore et qu'il peut le faire
construire. L'app lui proposera le bouton.

MÉTHODE — c'est elle qui fait qu'une demande est VRAIMENT faite. Les gens
écrivent vite, en vrac, avec des fautes, plusieurs choses dans la même
phrase, et des mots à eux (« le step », « le clip où on est à l'ordi »,
« le hook », « la partie du début »). Avant toute action, remplis
`raisonnement` : UNE ligne par chose demandée, sans en sauter une seule,
même glissée en fin de phrase (« ah pis… »).
- « demande » = ce qu'il veut, redit clairement, en disant de QUELLE
  catégorie, quel texte ou quel réglage de l'état il parle (retrouve-la par
  ce qu'elle montre, sa place, son rôle, son texte — pas seulement son nom).
- « comment » = le réglage EXACT qui le fait dans CE plateau, avec la
  valeur d'avant et celle d'après ; ou « impossible : … » si rien ne le
  fait (alors ça va dans `manque`) ; ou « déjà le cas » si l'état le dit.
  Vérifie que le réglage a un effet sur CETTE catégorie : une durée ne fait
  rien sur un clip « haut » ou « bas » d'un split (c'est `relais`), un
  texte de catégorie ne se voit pas si la frise est active (sauf la bande
  d'un split), un zoom ne se pose ni sur un rail ni sur une étape.
Ensuite seulement, `actions` : CHAQUE ligne du raisonnement qui n'est ni
« impossible » ni « déjà le cas » a au moins une action, et aucune action
n'existe sans sa ligne. Enfin `reponse` : elle ne dit « c'est fait » QUE
pour ce qui est dans `actions`. Annoncer un changement sans son action est
la pire erreur possible : la personne exporte, ne voit rien de changé, et
ne fait plus confiance au monteur. Ce que tu n'as pas pu faire, dis-le.

Règles :
- `serie` = le nom exact d'une série de l'état ; vide = la série ouverte.
- N'invente jamais une catégorie, une série ou une valeur que l'état ne
  donne pas. Si la demande est floue, pose UNE question dans `reponse` et
  ne propose rien.
- Une durée en dessous de 0,5 s ne se lit pas ; garde ±0,2 s d'écart entre
  dur_min et dur_max sauf s'il veut une durée exacte.
- `reponse` est du TEXTE SIMPLE : pas de Markdown (ni **gras**, ni titres
  en #). Pour un guide, des lignes numérotées, une par étape, séparées par
  des retours à la ligne.
- Garde la langue des textes à l'écran telle qu'elle est (souvent l'anglais).
  Pas d'emoji dans un texte à l'écran, sauf s'il en écrit un lui-même.
- Ne mets en pause une campagne ou ne coupe l'envoi auto que s'il le demande.
- Si des images de sa dernière vidéo sont jointes, sers-t'en pour comprendre
  de quoi il parle (« le texte du début », « le deuxième plan »).
"""


# LE GUIDE DES CLES (23/11, « il peut nous guider s'il a besoin d'API key »).
# Le Monteur ne saisit aucune cle — elles ne doivent passer ni par Claude
# ni par l'historique de la conversation — mais il sait dire, pas a pas, ou
# les obtenir et dans quel champ les coller. Les etapes sont celles du
# README (« Publier sur Instagram »), ecrites pour quelqu'un qui ne l'a
# jamais fait.
GUIDE_PUBLIER = """
GUIDE POUR BRANCHER LA PUBLICATION (à donner quand il manque quelque chose).
Où ça se colle, toujours au même endroit : ouvrir la série → bouton
« Avancé » en haut à droite → onglet « Publier » → « Publier sur
Instagram » → remplir les champs → « Enregistrer » → « Tester la
connexion ». Ces clés servent pour TOUTES ses séries : c'est à faire une
seule fois.

A. LA CLÉ BUFFER (c'est Buffer qui publie sur Instagram, même ordinateur
   éteint) :
   1. Créer un compte sur buffer.com (le gratuit suffit pour commencer).
   2. Y connecter son Instagram (« Channels » → ajouter Instagram). Le compte
      Instagram doit être Professionnel (Créateur ou Business) : ça se
      change dans les réglages d'Instagram, c'est gratuit.
   3. Dans Buffer : Settings → API → créer une clé, et la copier.
   4. La coller dans le champ « Clé API Buffer » de l'onglet Publier.
B. LE STOCKAGE CLOUDFLARE R2 (obligatoire : Buffer ne reçoit pas la vidéo,
   il la lit à une adresse publique ; 10 Go gratuits) :
   1. Créer un compte sur dash.cloudflare.com, ouvrir « R2 », créer un
      bucket (n'importe quel nom, ex. « plateau »).
   2. Dans le bucket : Settings → activer « Public Development URL ». Elle
      commence par https://pub- : c'est l'« URL publique ».
   3. R2 → « Manage API Tokens » → créer un jeton avec lecture ET écriture.
      Noter l'« Access Key ID » et la « Secret Access Key » tout de suite :
      le secret ne s'affiche qu'une fois.
   4. L'« Account ID » est écrit sur la page R2 de Cloudflare.
   5. Reporter les cinq valeurs dans l'onglet Publier : Account ID, nom du
      bucket, Access Key ID, Secret Access Key, URL publique.
C. SON COMPTE N'EST PAS DANS « Comptes connectés dans Buffer » : le connecter
   dans Buffer (étape A2), puis redemander — le plateau relit la liste.

Les menus de Buffer et de Cloudflare bougent parfois : s'il ne trouve pas
un bouton, dis-lui de chercher le mot (« API », « Manage API Tokens »,
« Public Development URL ») dans les réglages.
NE LUI DEMANDE JAMAIS de coller une clé, un jeton ou un mot de passe dans
cette conversation, et ne propose pas de le faire pour lui : les clés vont
dans les champs de l'onglet Publier, nulle part ailleurs. S'il en écrit une
ici, dis-lui de la mettre dans l'onglet et de ne plus l'écrire ici.
"""

CONSIGNES_PARLER += "\n" + GUIDE_PUBLIER
CONSIGNES_PARLER += "\n" + POUVOIRS


# La case « Decris le montage » d'une serie (22/11) : on lui ecrit son
# montage comme a un monteur humain, souvent sans etre precis. Il VOIT la
# matiere (images et paroles jointes) et DEDUIT au lieu de demander.
AUTONOME = """
MODE MONTEUR AUTONOME — les images et les paroles jointes sont la VRAIE
matière de cette série : la vidéo exemple du client (la référence à
imiter), un clip de chaque catégorie avec ce qui y est dit, et la dernière
vidéo exportée. Sers-t'en pour comprendre ce qu'il veut quand il n'est pas
précis : « mets une accroche » → écris-la d'après ce que montrent les clips
et ce que dit la personne ; « fais comme l'exemple » → reprends le rythme,
la place et le ton des textes de l'exemple ; « coupe le blabla » → raccourcis
les catégories où il ne se passe rien. Ne pose PAS de question pour un
détail : choisis ce que tu jugerais le mieux pour une vidéo qui marche,
FAIS-le, et dis en une phrase ce que tu as déduit (il corrigera). Une
question seulement si deux lectures opposées sont aussi probables et que se
tromper casserait la série.
"""


def parler(demande, contexte, historique=(), images=(), autonome=False):
    """-> {"reponse", "actions"}. Sonnet et pas Haiku: une action mal
    comprise touche une serie qui publie, et c'est un seul appel par
    message."""
    passe = "\n".join(f"{'Utilisateur' if q == 'moi' else 'Toi'}: {t}"
                      for q, t in list(historique)[-10:])
    texte = (
        "ÉTAT ACTUEL DU PLATEAU (à jour) :\n" + contexte +
        ("\n\nCONVERSATION JUSQU'ICI :\n" + passe if passe else "") +
        "\n\nDEMANDE : " + demande)
    r = demander(texte, images, schema=SCHEMA_PARLER, modele=SOIGNE,
                 systeme=SYSTEME + "\n\n" + GUIDE + "\n\n" + CONSIGNES_PARLER
                 + (AUTONOME if autonome else ""))
    if not isinstance(r, dict):
        raise IAError("Réponse de Claude illisible — réessaie")
    r.setdefault("actions", [])
    return r


# ------------------------------------------------------------------
# LA RELECTURE (23/11)
# ------------------------------------------------------------------
# « Quand tu decris ton montage, ca devrait marcher parfaitement. » Mesure
# sur une demande ecrite comme un etudiant (cinq choses en vrac) : le
# Monteur a repondu « c'est fait » pour deux choses qui ne l'etaient pas —
# une duree posee sur un rail de split (sans effet) et une etape
# « retiree » sans aucune action. Un seul jet ne se relit pas. Le serveur
# traduit donc les actions, puis Claude RELIT : la demande, ce que l'app a
# compris action par action (« avant -> apres »), ce qu'elle a REFUSE, et
# sa propre reponse. Tout y est : `ok`. Sinon il rend la liste complete
# corrigee, une seule fois (pas de boucle : deux relectures qui se
# contredisent ne valent pas mieux qu'une).
SCHEMA_RELIRE = json.loads(json.dumps(SCHEMA_PARLER))
SCHEMA_RELIRE["properties"] = dict({"ok": {"type": "boolean"},
                                    "oublis": {"type": "array", "items": {"type": "string"}}},
                                   **SCHEMA_RELIRE["properties"])
SCHEMA_RELIRE["required"] = ["ok", "oublis", "raisonnement", "reponse", "actions"]

CONSIGNES_RELIRE = """
RELECTURE. Tu viens de répondre à la demande ci-dessous. Voici ton
raisonnement, ta réponse, et — le plus important — CE QUE L'APP A
RÉELLEMENT COMPRIS de tes actions, une ligne chacune (« avant → après »),
avec celles qu'elle a REFUSÉES et pourquoi. Ce que l'app n'a pas listé NE
SERA PAS FAIT, quoi que dise ta réponse.

Reprends la demande mot par mot et vérifie, pour CHAQUE chose demandée :
1. a-t-elle une ligne « comprise » qui la fait vraiment (le bon réglage,
   sur la bonne catégorie, avec un effet réel dans la vidéo) ?
2. ta réponse annonce-t-elle quelque chose qui n'est PAS dans les lignes
   comprises ?
3. une action refusée (nom introuvable…) peut-elle être corrigée avec les
   noms EXACTS de l'état ?
4. une action fait-elle quelque chose qu'il n'a PAS demandé ?

« oublis » = la liste de ce qui cloche (vide si rien). Si tout est juste :
`ok` true, `actions` vide, et recopie ta réponse. Sinon `ok` false, et
rends `raisonnement`, `actions` et `reponse` COMPLETS et corrigés — la
liste d'actions remplace l'ancienne en entier, donc recopie aussi celles
qui étaient bonnes.
"""


def relire(demande, contexte, premier, compris, refuse, autonome=False):
    """Deuxieme passe : Claude verifie que chaque chose demandee est
    vraiment faite. -> None si tout est bon, sinon la reponse corrigee
    (meme forme que `parler`). Sans image : il juge une liste, pas une
    video — et ca tient la passe sous dix secondes."""
    rais = "\n".join(f"- {x.get('demande')} → {x.get('comment')}"
                     for x in (premier.get("raisonnement") or []) if isinstance(x, dict))
    texte = (
        "ÉTAT ACTUEL DU PLATEAU (avant tes actions) :\n" + contexte +
        "\n\nDEMANDE : " + demande +
        "\n\nTON RAISONNEMENT :\n" + (rais or "(aucun)") +
        "\n\nTA RÉPONSE : " + str(premier.get("reponse") or "") +
        ("\n\nTU AS AUSSI DIT QUE ÇA N'EXISTE PAS : " + str(premier["manque"])
         if premier.get("manque") else "") +
        "\n\nCE QUE L'APP A COMPRIS (sera fait) :\n"
        + ("\n".join("- " + x for x in compris) or "(rien)") +
        "\n\nCE QUE L'APP A REFUSÉ (ne sera pas fait) :\n"
        + ("\n".join("- " + x for x in refuse) or "(rien)"))
    r = demander(texte, (), schema=SCHEMA_RELIRE, modele=SOIGNE,
                 systeme=SYSTEME + "\n\n" + GUIDE + "\n\n" + CONSIGNES_PARLER
                 + (AUTONOME if autonome else "") + CONSIGNES_RELIRE)
    if not isinstance(r, dict) or r.get("ok"):
        return None
    r.setdefault("actions", [])
    return r


# Ce que l'assistant sait de l'app. Court: c'est envoye a chaque question.
GUIDE = """\
Le plateau, en bref:
- Barre de gauche: Vue d'ensemble, Éditeur (les projets), File d'attente, Todo,
  Contenu, Prospection, Onboarding, puis la liste des CAMPAGNES et « Nouvelle
  campagne ».
- Une CAMPAGNE = un deal avec un client (comptes, paie, objectif par jour). Elle
  contient des SÉRIES. Une série = la recette de montage: des CATÉGORIES de clips.
- « Nouvelle campagne » → « Avec l'IA »: on colle le brief, on dépose la vidéo
  exemple, l'IA propose la campagne, la série et la liste de tournage.
- Dans une série, onglet « Clips »: chaque catégorie a sa case, avec ce qu'il
  faut y filmer. « Déposer tous les clips » envoie les clips d'un coup et l'IA
  les range dans la bonne catégorie, avec des avertissements (trop sombre, flou,
  horizontal, trop court, ne ressemble pas à la consigne).
- Onglet « Générer »: fabriquer des vidéos. Onglet « Vidéos »: les voir.
  Onglet « Publier »: Buffer, envoi automatique par jour.
- L'Éditeur: un projet = une série, montée comme dans CapCut (frise, textes,
  aperçu, Exporter).
- Le bouton « Tuto » en haut à droite explique chaque écran.
L'ordre normal: créer la campagne → filmer la liste de tournage → déposer les
clips → générer une vidéo pour vérifier → brancher Buffer → envoi automatique.
"""
