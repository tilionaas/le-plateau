#!/usr/bin/env python3
"""Relève le texte à l'écran d'un dossier de reels, pour en faire une
réserve de citations.

Pourquoi ici et pas dans `template.py` : celui-ci analyse UN reel pour en
refaire le montage (coupes, durées, zooms). Ici on ne veut que les
phrases, sur des dizaines de fichiers, sans rien monter du tout.

On échantillonne quelques images par vidéo plutôt que de détecter les
coupes : une citation reste affichée plusieurs secondes, trois ou quatre
coups d'œil suffisent à l'attraper, et la détection de coupes coûte une
passe ffmpeg complète par fichier.

    python3 lire_textes.py <dossier> [> citations.txt]
"""
import sys
from pathlib import Path

import template as T

ECHANTILLONS = 5          # images lues par video
LARGEUR = T.OCR_LARGEUR
VIDEOS = {".mp4", ".mov", ".m4v", ".webm"}

# UNE PHRASE, PAS UNE ETIQUETTE. Vision lit tout ce qui est ecrit a
# l'ecran: un chrono (« 7:13 /km »), un bouton (« Go to Claude »), une
# etape de tutoriel. Mesure sur onze reels: en dessous de six mots, tout
# ce qui sortait etait de l'interface; au-dessus, tout etait une vraie
# phrase. Le seuil est grossier et c'est assume — il degrossit, il ne
# choisit pas a ta place.
MOTS_MINI = 6


def ressemble_a_une_phrase(t):
    mots = [m for m in t.replace("|", " ").split() if any(c.isalpha() for c in m)]
    if len(mots) < MOTS_MINI:
        return False
    # Un bloc majoritairement chiffre est une mesure, pas une citation.
    chiffres = sum(1 for c in t if c.isdigit())
    return chiffres <= len(t) * 0.25


def textes_du_fichier(chemin):
    """Les phrases incrustees lues dans une video, sans doublon."""
    vus, out = set(), []
    try:
        duree = T.duree(str(chemin))
    except Exception:                                       # noqa: BLE001
        return out
    if duree <= 0:
        return out
    for i in range(ECHANTILLONS):
        # On evite la toute premiere et la toute derniere image: fondu au
        # noir et ecran de fin n'ont presque jamais le texte du reel.
        t = duree * (i + 1) / (ECHANTILLONS + 1)
        rgb, w, h = T._image_rgb(str(chemin), t, LARGEUR)
        if not w:
            continue
        texte, _pos, _bande, _hl, lignes = T.caption_du_plan(T.lire_texte(rgb, w, h))
        if not texte:
            continue
        cle = "".join(texte.split()).lower()
        if cle in vus:
            continue
        vus.add(cle)
        out.append(texte)
    return out


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    d = Path(sys.argv[1]).expanduser()
    # Les deux messages disent QUOI FAIRE, pas seulement ce qui cloche:
    # la premiere fois, le dossier n'existe simplement pas encore.
    if not d.is_dir():
        sys.exit(f"Le dossier {d} n'existe pas.\n"
                 f"  Cree-le et depose tes reels dedans :  mkdir -p '{d}'")
    fichiers = sorted(f for f in d.iterdir() if f.suffix.lower() in VIDEOS)
    if not fichiers:
        sys.exit(f"Aucune video dans {d}\n"
                 f"  Depose des .mp4 ou .mov dedans, puis relance.")
    print(f"# {len(fichiers)} vidéos lues dans {d}", file=sys.stderr)
    # Le dedoublonnage est GLOBAL, pas par fichier: la meme phrase revient
    # d'un reel a l'autre (une serie de variantes, un repost), et on veut
    # une liste a coller telle quelle.
    vus, gardes, jetes = set(), 0, 0
    for f in fichiers:
        print(f"#   {f.name}", file=sys.stderr)
        for t in textes_du_fichier(f):
            # Une ligne par citation: c'est le format du champ « Textes »
            # d'une serie, ou « | » marque un retour a la ligne force.
            ligne = t.replace("\n", "|")
            # La cle ignore la ponctuation: l'OCR ajoute un tiret ou un
            # point parasite d'une image a l'autre, et deux lectures de la
            # MEME phrase ressortaient comme deux citations.
            cle = "".join(c for c in ligne.lower() if c.isalnum())
            if cle in vus:
                continue
            vus.add(cle)
            if not ressemble_a_une_phrase(ligne):
                jetes += 1
                continue
            print(ligne)
            gardes += 1
    print(f"# {gardes} phrases gardées, {jetes} écartées (interface, chiffres)",
          file=sys.stderr)


if __name__ == "__main__":
    main()
