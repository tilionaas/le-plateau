"""Les mises a jour de l'app installee (« Le plateau.app »).

Le CODE ACTIF vit dans `~/Le plateau/App/`, pas dans le .app : c'est un
dossier qu'on peut ouvrir et modifier avec Claude Code (« Modifier
l'app »), et qu'une mise a jour remplace sans toucher aux donnees, qui
vivent a cote (voir chemins.py).

Le partage des roles, et pourquoi :
  - ICI (Python, dans le serveur) : savoir s'il y a une version plus
    recente, la telecharger, verifier son empreinte, la deballer a cote,
    et dire « prete ». Rien n'est remplace pendant que le serveur tourne :
    on ne scie pas la branche sur laquelle on est assis.
  - LE LANCEUR (bash, dans le .app) : au redemarrage, il fait l'echange
    (App -> .versions/precedente, la neuve -> App) et, si la neuve ne
    demarre pas, il remet la precedente tout seul. Une mise a jour cassee
    ne doit bloquer personne : c'est le lanceur, pas le code qu'on vient
    d'installer, qui juge si elle marche.

Ce qui est publie (`publier.command`) : `version.json`
{version, zip, sha256, notes} et le zip du code. L'adresse se lit dans
`PLATEAU_MAJ_URL`, sinon dans `maj-url.txt` a cote du code. Vide = pas de
mise a jour (la copie de travail n'en a pas).

Stdlib seulement, comme le reste.
"""
import hashlib
import json
import os
import shutil
import time
import urllib.request
import zipfile
from pathlib import Path

from chemins import CODE, DONNEES, INSTALLEE

PREPA = DONNEES / ".maj"                  # ou la nouvelle version attend
PRETE = PREPA / "prete.json"              # lu par le lanceur au redemarrage
EMPREINTES = ".empreintes.json"           # le code tel que livre
USER_AGENT = "Le-plateau-maj"

_CACHE = {"t": 0.0, "info": None, "erreur": ""}


def version():
    try:
        return (CODE / "VERSION").read_text().strip() or "0"
    except OSError:
        return "0"


def _cle(v):
    """« 1.10 » passe apres « 1.9 » : on compare des nombres, pas du texte."""
    out = []
    for x in str(v).split("."):
        try:
            out.append(int(x))
        except ValueError:
            out.append(0)
    return out


def url():
    u = os.environ.get("PLATEAU_MAJ_URL", "").strip()
    if not u:
        try:
            u = (CODE / "maj-url.txt").read_text().strip()
        except OSError:
            u = ""
    return u.rstrip("/")


def _lire(adresse, timeout=15):
    req = urllib.request.Request(adresse, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def verifier(forcer=False):
    """{version, actuelle, nouvelle (bool), notes, erreur}. Une heure de
    cache : la page est relue a chaque ouverture de l'app, et un hebergeur
    gratuit n'a pas a recevoir un appel par clic."""
    base = {"actuelle": version(), "active": bool(INSTALLEE and url()),
            "nouvelle": False, "version": "", "notes": "", "erreur": ""}
    if not base["active"]:
        return base
    if not forcer and time.time() - _CACHE["t"] < 3600 and (_CACHE["info"] or _CACHE["erreur"]):
        info, err = _CACHE["info"], _CACHE["erreur"]
    else:
        try:
            info, err = json.loads(_lire(url() + "/version.json")), ""
        except Exception as e:                                  # noqa: BLE001
            # Hors ligne n'est pas une panne : l'app marche sans.
            info, err = None, f"Pas de réponse du site des mises à jour ({e.__class__.__name__})"
        _CACHE.update(t=time.time(), info=info, erreur=err)
    if info:
        base.update(version=str(info.get("version") or ""),
                    notes=str(info.get("notes") or "")[:2000])
        base["nouvelle"] = _cle(base["version"]) > _cle(base["actuelle"])
        # Une version qui n'a pas demarre ici (le lanceur l'a remplacee par
        # la precedente) n'est pas reproposee : on attend la suivante.
        try:
            if (PREPA / "refusee").read_text().strip() == base["version"]:
                base["nouvelle"] = False
                base["refusee"] = base["version"]
        except OSError:
            pass
    base["erreur"] = err
    base["prete"] = prete()
    base["modifs"] = modifications() if base["nouvelle"] else []
    return base


def _empreinte(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


def fichiers_du_code(dossier):
    """Les fichiers qui FONT l'app : ceux que l'empreinte surveille."""
    d = Path(dossier)
    out = []
    for p in sorted(d.rglob("*")):
        if not p.is_file():
            continue
        r = p.relative_to(d).as_posix()
        if (r.startswith(".") or "/." in r or "__pycache__" in r
                or r in (EMPREINTES, "maj-url.txt")):
            continue
        out.append(r)
    return out


def ecrire_empreintes(dossier):
    """Appele a l'emballage : l'etat du code TEL QUE LIVRE."""
    d = Path(dossier)
    e = {r: _empreinte(d / r) for r in fichiers_du_code(d)}
    (d / EMPREINTES).write_text(json.dumps(e, indent=0, sort_keys=True))
    return e


def modifications():
    """Ce que la personne a change dans SON code depuis la livraison (avec
    Claude Code, typiquement). Une mise a jour l'ecraserait : on le dit
    avant, et on le met de cote au lieu de le perdre."""
    try:
        ref = json.loads((CODE / EMPREINTES).read_text())
    except (OSError, ValueError):
        return []
    actuels = set(fichiers_du_code(CODE))
    out = [r for r in sorted(actuels) if r not in ref or _empreinte(CODE / r) != ref[r]]
    out += [r + " (supprimé)" for r in sorted(set(ref) - actuels)]
    return out


def prete():
    try:
        return json.loads(PRETE.read_text()).get("version", "")
    except (OSError, ValueError):
        return ""


def preparer(progres=None):
    """Telecharge et deballe la nouvelle version A COTE. -> version.
    L'echange se fait au redemarrage, par le lanceur."""
    info = verifier(forcer=True)
    if not info["nouvelle"]:
        raise ValueError(info["erreur"] or "Déjà à jour")
    meta = json.loads(_lire(url() + "/version.json"))
    v = str(meta["version"])
    PREPA.mkdir(parents=True, exist_ok=True)
    zf = PREPA / f"app-{v}.zip"
    if progres:
        progres("Téléchargement…")
    req = urllib.request.Request(url() + "/" + meta["zip"], headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=60) as r, open(zf, "wb") as f:
        shutil.copyfileobj(r, f, 1 << 20)
    # L'empreinte publiee: un zip tronque (wifi coupe) ou remplace ne
    # s'installe pas.
    if _empreinte(zf) != meta.get("sha256"):
        zf.unlink()
        raise ValueError("Le fichier téléchargé est abîmé — réessaie")
    if progres:
        progres("Préparation…")
    dest = PREPA / f"app-{v}"
    shutil.rmtree(dest, ignore_errors=True)
    with zipfile.ZipFile(zf) as z:
        for n in z.namelist():
            # Jamais en dehors du dossier prevu (« ../ » dans un nom).
            if n.startswith("/") or ".." in Path(n).parts:
                raise ValueError("Mise à jour refusée : chemin suspect dans le zip")
        z.extractall(dest)
    zf.unlink()
    if not (dest / "server.py").is_file():
        raise ValueError("Mise à jour incomplète (server.py absent)")
    # Les modifications de la personne : mises de cote, jamais effacees.
    modifs = [m for m in modifications() if not m.endswith("(supprimé)")]
    if modifs:
        garde = DONNEES / "Mes modifications" / time.strftime("%Y-%m-%d %H-%M")
        for r in modifs:
            (garde / r).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(CODE / r, garde / r)
    PRETE.write_text(json.dumps({"version": v, "dossier": str(dest),
                                 "modifs_gardees": len(modifs)}))
    return v
