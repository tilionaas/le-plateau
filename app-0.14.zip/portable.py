#!/usr/bin/env python3
"""
Ce qui change d'un systeme a l'autre.
-------------------------------------
Le plateau a ete ecrit sur un Mac et s'appuyait sur trois outils maison:
`open` pour reveler un fichier dans le Finder, `sips` pour convertir les
images, et CoreText pour dessiner les textes. Aucun des trois n'existe
ailleurs.

Tout est regroupe ici, avec une chaine de repli par besoin. La regle du
projet — zero dependance — tient toujours sur un Mac; ailleurs, Pillow
(`pip install pillow`) debloque ce que le systeme ne sait pas faire seul.
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

MAC = sys.platform == "darwin"
WINDOWS = os.name == "nt"


def systeme():
    return "macOS" if MAC else ("Windows" if WINDOWS else "Linux")


# ------------------------------------------------------------------
# Ouvrir / reveler un fichier dans l'explorateur du systeme
# ------------------------------------------------------------------

def ouvrir(chemin):
    """Ouvre un fichier ou un dossier avec l'application par defaut."""
    chemin = str(chemin)
    try:
        if MAC:
            subprocess.run(["open", chemin], check=True, capture_output=True)
        elif WINDOWS:
            os.startfile(chemin)                        # noqa: S606
        else:
            subprocess.run(["xdg-open", chemin], check=True, capture_output=True)
        return None
    except (OSError, subprocess.CalledProcessError, AttributeError) as e:
        return f"Impossible d'ouvrir : {e}"


def reveler(chemin):
    """Ouvre l'explorateur en selectionnant ce fichier.

    Sous Linux il n'y a pas de commande standard pour ca: on se rabat sur
    l'ouverture du dossier parent, ce qui rend le meme service."""
    chemin = str(chemin)
    try:
        if MAC:
            subprocess.run(["open", "-R", chemin], check=True, capture_output=True)
        elif WINDOWS:
            # explorer renvoie 1 meme quand il reussit: on ignore le code.
            subprocess.run(["explorer", "/select,", os.path.normpath(chemin)],
                           capture_output=True)
        else:
            subprocess.run(["xdg-open", str(Path(chemin).parent)],
                           check=True, capture_output=True)
        return None
    except (OSError, subprocess.CalledProcessError, AttributeError) as e:
        return f"Impossible d'ouvrir : {e}"


# ------------------------------------------------------------------
# Convertir une image en PNG carre-compatible
# ------------------------------------------------------------------

def a_la_corbeille(chemin, secours):
    """Met un fichier a la CORBEILLE au lieu de l'effacer (23/11, le « × »
    sur un clip) : un clip filme ne se refait pas, et un clic a cote ne doit
    rien couter. Sur Mac, la vraie Corbeille (NSFileManager, sans passer par
    le Finder : pas de permission a demander). Ailleurs, ou si ca echoue, le
    dossier `secours` — la corbeille du plateau, qu'on vide a la main.
    -> "corbeille", "plateau" ou "" (rien n'a bouge)."""
    chemin = Path(chemin)
    if not chemin.is_file():
        return ""
    if sys.platform == "darwin":
        try:
            from Foundation import NSFileManager, NSURL
            ok, _url, _err = NSFileManager.defaultManager().trashItemAtURL_resultingItemURL_error_(
                NSURL.fileURLWithPath_(str(chemin)), None, None)
            if ok and not chemin.exists():
                return "corbeille"
        except Exception:                                       # noqa: BLE001
            pass
    try:
        secours = Path(secours)
        secours.mkdir(parents=True, exist_ok=True)
        dest, i = secours / chemin.name, 1
        while dest.exists():
            dest = secours / f"{chemin.stem}-{i}{chemin.suffix}"
            i += 1
        shutil.move(str(chemin), str(dest))
        return "plateau"
    except OSError:
        return ""


def convertir_image(src, dest, cote):
    """Convertit `src` en PNG d'au plus `cote` pixels de cote.

    Trois moyens, du plus capable au plus courant:
      1. `sips`   — livre avec macOS, seul a lire le HEIC de l'iPhone
      2. Pillow   — si installe, lit tout sauf le HEIC
      3. ffmpeg   — deja requis par l'app, lit PNG/JPEG/WebP/GIF/TIFF

    Renvoie None si ca marche, sinon un message affichable."""
    src, dest = str(src), str(dest)
    erreurs = []

    if MAC and shutil.which("sips"):
        r = subprocess.run(
            ["sips", "-s", "format", "png", "-Z", str(cote), src, "--out", dest],
            capture_output=True, text=True)
        if r.returncode == 0 and Path(dest).exists():
            return None
        # `sips` renvoie « Try 'sips --help' », qui n'aide personne: on
        # garde la premiere ligne utile s'il y en a une.
        lignes = [l.strip() for l in (r.stderr or r.stdout or "").splitlines()
                  if l.strip() and "--help" not in l]
        erreurs.append(lignes[0][:120] if lignes else "sips a refuse le fichier")

    try:
        from PIL import Image                           # noqa: PLC0415
        with Image.open(src) as im:
            im = im.convert("RGBA")
            im.thumbnail((cote, cote))
            im.save(dest, "PNG")
        return None
    except ImportError:
        pass
    except Exception as e:                              # noqa: BLE001
        erreurs.append(str(e)[:120])

    if shutil.which("ffmpeg"):
        r = subprocess.run(
            ["ffmpeg", "-y", "-v", "error", "-i", src,
             "-vf", f"scale='min({cote},iw)':-2", "-frames:v", "1", dest],
            capture_output=True, text=True)
        if r.returncode == 0 and Path(dest).exists():
            return None
        erreurs.append((r.stderr or "").strip().splitlines()[-1][:120]
                       if r.stderr else "ffmpeg a refuse le fichier")

    detail = f" : {erreurs[0]}" if erreurs else ""
    if not MAC:
        detail += ("\nLe HEIC de l'iPhone n'est lisible que sur macOS. "
                   "Convertis la photo en PNG ou JPEG d'abord.")
    return f"Ce fichier n'a pas pu être lu comme une image{detail}"


# ------------------------------------------------------------------
# Diagnostic de demarrage
# ------------------------------------------------------------------

def diagnostic():
    """Ce qui manque sur cette machine, en clair. Liste vide = tout va bien."""
    manques = []
    for outil, quoi, ou in (
            ("ffmpeg",  "monter les vidéos", None),
            ("ffprobe", "mesurer les vidéos", None)):
        if shutil.which(outil) is None:
            manques.append(f"{outil} est introuvable — il sert à {quoi}. "
                           + ("Installe-le : https://ffmpeg.org/download.html"
                              if ou is None else ou))
    return manques
