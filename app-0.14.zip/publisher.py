#!/usr/bin/env python3
"""
Publication automatique vers Instagram, via Buffer.
---------------------------------------------------
Aucune dependance: uniquement la bibliotheque standard.

Le probleme a resoudre: Buffer ne prend pas d'upload direct. Son API veut
une URL PUBLIQUE, et cette URL doit rester joignable jusqu'a la
publication -- pas seulement au moment ou on cree le post. Or l'app tourne
sur 127.0.0.1, invisible depuis Internet.

D'ou la chaine en deux temps:
  1. la video est deposee sur Cloudflare R2 (stockage public, 10 Go
     gratuits, pas de frais de sortie quand Instagram vient la chercher)
  2. l'URL publique obtenue est passee a Buffer, qui gere la file
     d'attente et publie meme si le Mac est eteint

R2 parle le protocole S3. Plutot que de tirer boto3 (~50 Mo de
dependances) on signe les requetes a la main en SigV4 avec hmac/hashlib:
c'est une centaine de lignes et ca garde le projet a zero dependance,
comme le reste de l'app.
"""

import hashlib
import hmac
import json
import mimetypes
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from chemins import DONNEES as ROOT          # cles et compteurs: des donnees
CONFIG_FILE = ROOT / "publish_config.json"

BUFFER_ENDPOINT = "https://api.buffer.com"
R2_REGION = "auto"
R2_SERVICE = "s3"

# Instagram refuse les Reels de plus de 90 s via l'API (l'app native va
# jusqu'a 3 min, mais l'API n'a pas suivi). Au-dela, Buffer accepte le
# post mais Instagram le publie en video classique, hors onglet Reels.
REELS_MAX_SECONDS = 90
REELS_MIN_SECONDS = 3
# Buffer refuse les fichiers au-dela de cette taille pour Instagram.
MAX_BYTES = 300 * 1024 * 1024

# urllib s'annonce par defaut comme "Python-urllib/3.x", et le pare-feu de
# Cloudflare bloque cet agent sur les domaines r2.dev (403 alors que le
# fichier est bien la). On se presente donc comme un client normal.
USER_AGENT = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
              "AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/126.0.0.0 Safari/537.36")


class PublishError(Exception):
    """Erreur cote publication, avec un message affichable tel quel."""


class ReseauError(PublishError):
    """Le reseau a flanche: DNS, delai depasse, machine injoignable.

    A DISTINGUER d'une erreur de l'API. Une cle refusee ou un post
    invalide ne se repareront pas en reessayant; une coupure de wifi, si.
    Le 15/10, le Mac n'a plus resolu api.buffer.com pendant l'apres-midi,
    et la penalite d'une heure appliquee a toute erreur a transforme une
    panne passagere en douze vidéos non publiees."""


# ------------------------------------------------------------------
# Configuration (cle Buffer + identifiants R2)
# ------------------------------------------------------------------

def load_config():
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_config(cfg):
    tmp = CONFIG_FILE.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(str(tmp), str(CONFIG_FILE))
    # Le fichier contient des secrets: lisible par le proprietaire seul.
    try:
        os.chmod(str(CONFIG_FILE), 0o600)
    except OSError:
        pass
    return cfg


def status(cfg=None):
    """Ce qui est configure, SANS jamais renvoyer les secrets eux-memes."""
    cfg = load_config() if cfg is None else cfg
    r2 = cfg.get("r2") or {}
    return {
        "buffer": bool(cfg.get("buffer_api_key")),
        "r2": all(r2.get(k) for k in
                  ("account_id", "bucket", "access_key_id",
                   "secret_access_key", "public_base_url")),
    }


# ------------------------------------------------------------------
# Cloudflare R2 -- signature AWS SigV4 ecrite a la main
# ------------------------------------------------------------------

def _sign(key, msg):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def _signing_key(secret, datestamp, region, service):
    """Cle derivee en cascade, comme l'exige SigV4."""
    k = _sign(("AWS4" + secret).encode("utf-8"), datestamp)
    k = _sign(k, region)
    k = _sign(k, service)
    return _sign(k, "aws4_request")


def _r2_request(cfg, method, key, body=b"", content_type=None, timeout=300,
                query=""):
    """Requete S3 signee vers R2. Retourne le corps de la reponse."""
    r2 = cfg.get("r2") or {}
    missing = [k for k in ("account_id", "bucket", "access_key_id",
                           "secret_access_key") if not r2.get(k)]
    if missing:
        raise PublishError(f"Configuration R2 incomplète : {', '.join(missing)}")

    host = f"{r2['account_id']}.r2.cloudflarestorage.com"
    # Chaque segment du chemin doit etre encode, mais pas les slashs.
    path = "/" + urllib.parse.quote(f"{r2['bucket']}/{key}", safe="/")

    now = datetime.now(timezone.utc)
    amzdate = now.strftime("%Y%m%dT%H%M%SZ")
    datestamp = now.strftime("%Y%m%d")
    payload_hash = hashlib.sha256(body).hexdigest()

    headers = {
        "host": host,
        "x-amz-content-sha256": payload_hash,
        "x-amz-date": amzdate,
    }
    if content_type:
        headers["content-type"] = content_type

    signed_names = ";".join(sorted(headers))
    canonical_headers = "".join(
        f"{k}:{headers[k]}\n" for k in sorted(headers))
    canonical_request = "\n".join([
        method, path, query, canonical_headers, signed_names, payload_hash])

    scope = f"{datestamp}/{R2_REGION}/{R2_SERVICE}/aws4_request"
    string_to_sign = "\n".join([
        "AWS4-HMAC-SHA256", amzdate, scope,
        hashlib.sha256(canonical_request.encode("utf-8")).hexdigest()])

    signature = hmac.new(
        _signing_key(r2["secret_access_key"], datestamp, R2_REGION, R2_SERVICE),
        string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

    headers["Authorization"] = (
        f"AWS4-HMAC-SHA256 Credential={r2['access_key_id']}/{scope}, "
        f"SignedHeaders={signed_names}, Signature={signature}")

    req = urllib.request.Request(
        f"https://{host}{path}" + (f"?{query}" if query else ""),
        data=body or None, method=method)
    req.add_header("User-Agent", USER_AGENT)
    for k, v in headers.items():
        if k != "host":                       # urllib pose Host lui-meme
            req.add_header(k, v)

    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:400]
        raise PublishError(f"R2 a répondu {e.code} : {detail}") from e
    except urllib.error.URLError as e:
        raise PublishError(f"R2 injoignable : {e.reason}") from e


def r2_put(cfg, key, filepath):
    """Depose un fichier sur R2 et renvoie son URL publique."""
    filepath = Path(filepath)
    body = filepath.read_bytes()
    ctype = mimetypes.guess_type(str(filepath))[0] or "application/octet-stream"
    _r2_request(cfg, "PUT", key, body, content_type=ctype)
    base = (cfg.get("r2") or {}).get("public_base_url", "").rstrip("/")
    return f"{base}/{urllib.parse.quote(key)}"


def r2_delete(cfg, key):
    """Supprime un objet. Sert au menage une fois la video publiee."""
    _r2_request(cfg, "DELETE", key, timeout=60)
    return True


def r2_list(cfg):
    """Tout ce qui dort dans le bucket: [(cle, octets, date), ...].

    Sert a savoir ce que le stockage coute vraiment, et a faire le menage
    des videos deja publiees."""
    out, suite = [], None
    while True:
        q = "list-type=2&max-keys=1000"
        if suite:
            q += "&continuation-token=" + urllib.parse.quote(suite, safe="")
        # Les parametres doivent etre tries pour la signature.
        q = "&".join(sorted(q.split("&")))
        xml = _r2_request(cfg, "GET", "", query=q, timeout=60).decode("utf-8", "replace")
        for bloc in re.findall(r"<Contents>(.*?)</Contents>", xml, re.S):
            cle = re.search(r"<Key>(.*?)</Key>", bloc, re.S)
            taille = re.search(r"<Size>(\d+)</Size>", bloc)
            quand = re.search(r"<LastModified>(.*?)</LastModified>", bloc)
            if cle:
                out.append((cle.group(1), int(taille.group(1)) if taille else 0,
                            quand.group(1) if quand else ""))
        suite = re.search(r"<NextContinuationToken>(.*?)</NextContinuationToken>", xml, re.S)
        if not suite:
            break
        suite = suite.group(1)
    return out


def r2_check(cfg):
    """Verifie que les identifiants marchent, en ecrivant puis relisant un
    petit fichier temoin. Plus fiable qu'un simple test d'authentification:
    ca valide aussi que l'URL publique est bien ouverte."""
    key = f"_test_{int(time.time())}.txt"
    marker = b"repurposer-test"
    url = r2_put(cfg, key, _tmp_file(marker))
    try:
        probe = urllib.request.Request(url)
        probe.add_header("User-Agent", USER_AGENT)
        with urllib.request.urlopen(probe, timeout=30) as r:
            got = r.read()
        if got != marker:
            raise PublishError(
                "Le fichier a été déposé mais son contenu public ne correspond pas.")
    except urllib.error.HTTPError as e:
        raise PublishError(
            f"Dépôt réussi, mais l'URL publique renvoie {e.code}. "
            f"Vérifie que l'accès public (r2.dev) est activé sur le bucket.") from e
    except urllib.error.URLError as e:
        raise PublishError(f"URL publique injoignable : {e.reason}") from e
    finally:
        try:
            r2_delete(cfg, key)
        except PublishError:
            pass
    return url


def _tmp_file(content):
    p = ROOT / ".r2_probe.tmp"
    p.write_bytes(content)
    return p


# ------------------------------------------------------------------
# Buffer -- API GraphQL
# ------------------------------------------------------------------

# ------------------------------------------------------------------
# Le quota d'API de Buffer
# ------------------------------------------------------------------
# Buffer compte TROIS seaux: 100 par 15 min, 250 par jour, et surtout
# 3000 PAR 30 JOURS — soit 100 appels par jour en moyenne. Le 12/10 a
# 8 h, le seau de 30 jours est tombe a zero et plus rien n'est parti
# pendant huit jours: le plateau en consommait environ 390 par jour,
# dont 240 rien que pour demander toutes les 5 minutes si la file etait
# pleine.
#
# Tant que le seau est vide, chaque appel echoue MAIS COMPTE QUAND MEME
# dans les seaux plus courts. On garde donc la date de reprise et on ne
# touche plus au reseau avant: sans ca, le plateau brulait une
# cinquantaine d'appels par jour pour se faire refuser cinquante fois.
#
# Range sur DISQUE: un redemarrage ne doit pas faire oublier le mur.
PAUSE_FICHIER = ROOT / ".buffer-pause.json"
_LIMITE = {"jusqua": 0.0, "message": ""}


def _pause_charger():
    try:
        d = json.loads(PAUSE_FICHIER.read_text("utf-8"))
        _LIMITE["jusqua"] = float(d.get("jusqua") or 0)
        _LIMITE["message"] = d.get("message") or ""
    except (OSError, ValueError, TypeError):
        pass


def _pause_poser(jusqua, message):
    _LIMITE["jusqua"], _LIMITE["message"] = jusqua, message
    try:
        PAUSE_FICHIER.write_text(json.dumps(
            {"jusqua": jusqua, "message": message}), "utf-8")
    except OSError:
        pass


def quota_pause():
    """(secondes restantes, message) si Buffer nous a coupes, sinon (0, "")."""
    if not _LIMITE["jusqua"]:
        _pause_charger()
    reste = _LIMITE["jusqua"] - time.time()
    return (max(0, int(reste)), _LIMITE["message"]) if reste > 0 else (0, "")


def _quota_depuis(headers):
    """(date de reprise, message lisible) lus dans les en-tetes d'un 429.

    Buffer envoie `x-ratelimit-reset` (horodatage absolu) et `Retry-After`
    (secondes). On prend le premier s'il est credible, l'autre sinon."""
    maintenant = time.time()
    quand = 0.0
    try:
        v = float(headers.get("x-ratelimit-reset") or 0)
        if maintenant < v < maintenant + 40 * 86400:
            quand = v
    except (TypeError, ValueError):
        pass
    if not quand:
        try:
            quand = maintenant + max(60.0, float(headers.get("Retry-After") or 900))
        except (TypeError, ValueError):
            quand = maintenant + 900
    heures = (quand - maintenant) / 3600.0
    quand_txt = (datetime.fromtimestamp(quand).strftime("%d/%m à %Hh%M")
                 if heures > 20 else f"dans {int(heures * 60) or 1} min")
    limite = headers.get("x-ratelimit-limit") or "?"
    return quand, (f"Buffer a coupé l'API : quota de {limite} appels atteint. "
                   f"Reprise {quand_txt}.")


# ------------------------------------------------------------------
# Le budget restant, lu chez Buffer a chaque reponse
# ------------------------------------------------------------------
# Compter nos appels de notre cote serait une estimation; Buffer, lui,
# envoie le chiffre exact dans CHAQUE reponse. On le lit, on le garde, et
# on s'en sert comme garde-fou plutot que de faire confiance a un calcul.
#
# Le 12/10, le seau de 30 jours est tombe a zero et huit jours de
# publication sont tombes avec. La reserve existe pour que ca ne puisse
# plus arriver: sous ce seuil, seules les PUBLICATIONS passent encore.
# Le reste (etat de la file, menage, rattrapage) attend le renouvellement.
BUDGET_FICHIER = ROOT / ".buffer-budget.json"
RESERVE = 300           # appels gardes pour publier, quoi qu'il arrive
_BUDGET = {"reste": None, "limite": None, "reset": 0.0, "t": 0.0}


def _budget_noter(headers):
    # On COMPTE nos appels, jour par jour, en plus de lire le restant.
    # « Environ soixante par jour » etait une estimation, et elle etait
    # fausse des qu'un second compte s'est ajoute: ce qui est mesure ne
    # se discute pas.
    jour = time.strftime("%Y-%m-%d")
    j = _BUDGET.setdefault("jours", {})
    j[jour] = int(j.get(jour) or 0) + 1
    for vieux in [d for d in j if d < time.strftime("%Y-%m-%d",
                  time.localtime(time.time() - 40 * 86400))]:
        j.pop(vieux, None)              # on gardeuniquement la fenetre utile
    try:
        reste = int(headers.get("x-ratelimit-remaining"))
        limite = int(headers.get("x-ratelimit-limit") or 0)
    except (TypeError, ValueError):
        return
    _BUDGET.update(reste=reste, limite=limite, t=time.time())
    try:
        _BUDGET["reset"] = float(headers.get("x-ratelimit-reset") or 0)
    except (TypeError, ValueError):
        pass
    try:
        BUDGET_FICHIER.write_text(json.dumps(_BUDGET), "utf-8")
    except OSError:
        pass


def appels_par_jour():
    """{jour: nombre d'appels}, mesure et non estime."""
    budget()                             # force la lecture du fichier
    return dict(_BUDGET.get("jours") or {})


def budget():
    """(reste, limite, horodatage du renouvellement). None si inconnu."""
    if _BUDGET["reste"] is None:
        try:
            _BUDGET.update(json.loads(BUDGET_FICHIER.read_text("utf-8")))
        except (OSError, ValueError, TypeError):
            pass
    return _BUDGET["reste"], _BUDGET["limite"], _BUDGET["reset"]


def budget_serre():
    """Reste-t-il si peu qu'il faut economiser ?"""
    reste, _l, reset = budget()
    if reste is None or (reset and time.time() > reset):
        return False                 # inconnu, ou fenetre renouvelee
    return reste < RESERVE


# PLAFOND LOCAL, par heure glissante.
#
# Le budget lu chez Buffer dit ou on en est; il ne protege pas d'une
# boucle emballee, qui peut bruler mille appels avant qu'on s'en
# apercoive. Ce plafond-ci est un COUPE-CIRCUIT: il compte nos propres
# appels et refuse au-dela, quoi qu'il arrive.
#
# 60 par heure alors qu'on en attend ~30 par JOUR: il ne se declenchera
# jamais en usage normal. C'est voulu — un garde-fou qui gene est un
# garde-fou qu'on finit par retirer. Buffer en autorise 100 par 15 min,
# on reste donc tres en dessous meme en le saturant.
PLAFOND_HEURE = 60
_APPELS = []
_APPELS_VERROU = threading.Lock()


def _compter_appel():
    """False si le plafond horaire est atteint."""
    with _APPELS_VERROU:
        limite = time.time() - 3600
        while _APPELS and _APPELS[0] < limite:
            _APPELS.pop(0)
        if len(_APPELS) >= PLAFOND_HEURE:
            return False
        _APPELS.append(time.time())
        return True


def appels_derniere_heure():
    with _APPELS_VERROU:
        limite = time.time() - 3600
        return sum(1 for t in _APPELS if t >= limite)


def buffer_query(api_key, query, variables=None, timeout=60, vital=True):
    """`vital=False` pour un appel de CONFORT (etat de la file, menage):
    il est abandonne quand la reserve est entamee, pour que les appels
    qui publient vraiment aient toujours de quoi passer."""
    if not api_key:
        raise PublishError("Aucune clé API Buffer enregistrée.")
    reste, msg = quota_pause()
    if reste:
        # On n'appelle meme pas: un appel refuse compte quand meme.
        raise PublishError(msg)
    if not vital and budget_serre():
        r, l, _ = budget()
        raise PublishError(
            f"Budget Buffer presque épuisé ({r} sur {l}) — "
            "seules les publications continuent")
    if not _compter_appel():
        raise PublishError(
            f"Coupe-circuit : {PLAFOND_HEURE} appels à Buffer dans la "
            "dernière heure, c'est anormal. Rien n'est envoyé le temps "
            "que ça se calme.")
    payload = json.dumps({"query": query,
                          "variables": variables or {}}).encode("utf-8")
    req = urllib.request.Request(BUFFER_ENDPOINT, data=payload, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("User-Agent", USER_AGENT)
    req.add_header("Authorization", f"Bearer {api_key}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            _budget_noter(r.headers)
            body = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:400]
        if e.code == 401:
            raise PublishError("Clé API Buffer refusée (401). Vérifie-la.") from e
        if e.code == 429:
            quand, msg = _quota_depuis(e.headers)
            _pause_poser(quand, msg)
            raise PublishError(msg) from e
        raise PublishError(f"Buffer a répondu {e.code} : {detail}") from e
    except urllib.error.URLError as e:
        raise ReseauError(f"Buffer injoignable : {e.reason}") from e

    if body.get("errors"):
        msg = "; ".join(e.get("message", "?") for e in body["errors"])
        raise PublishError(f"Buffer : {msg}")
    return body.get("data") or {}


_ORG = {}
ORG_FILE = ROOT / ".buffer-org.json"


def buffer_organization_id(api_key):
    """Identifiant de l'organisation Buffer, demande UNE fois.

    Il ne change pas, et chaque helper le redemandait: ca doublait le
    nombre d'appels a l'API, jusqu'a l'avertissement de rate limit recu le
    24/09."""
    if api_key in _ORG:
        return _ORG[api_key]
    # GARDE SUR DISQUE (23/11) : il ne change jamais, et la memoire le
    # perdait a chaque redemarrage du plateau — un appel a chaque fois. Le
    # fichier est range sous une EMPREINTE de la cle, jamais la cle.
    marque = hashlib.sha256(str(api_key).encode("utf-8")).hexdigest()[:16]
    try:
        d = json.loads(ORG_FILE.read_text("utf-8"))
        if d.get("cle") == marque and d.get("org"):
            _ORG[api_key] = d["org"]
            return _ORG[api_key]
    except (OSError, ValueError):
        pass
    _ORG[api_key] = _buffer_organization_id(api_key)
    try:
        ORG_FILE.write_text(json.dumps({"cle": marque, "org": _ORG[api_key]}), "utf-8")
    except OSError:
        pass
    return _ORG[api_key]


def _buffer_organization_id(api_key):
    data = buffer_query(api_key, """
        query GetOrganizations { account { organizations { id name } } }
    """)
    orgs = ((data.get("account") or {}).get("organizations")) or []
    if not orgs:
        raise PublishError("Aucune organisation Buffer trouvée sur ce compte.")
    return orgs[0]["id"]


def buffer_channels(api_key, org_id=None, service="instagram"):
    """Comptes connectes a Buffer. Filtre sur Instagram par defaut."""
    org_id = org_id or buffer_organization_id(api_key)
    # L'identifiant vient de Buffer lui-meme, pas de l'utilisateur: on le
    # verifie quand meme avant de l'inserer dans la requete. La forme
    # inline evite d'avoir a deviner le nom du type d'entree GraphQL.
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", str(org_id or "")):
        raise PublishError(f"Identifiant d'organisation inattendu : {org_id!r}")
    data = buffer_query(api_key, """
        query GetChannels {
          channels(input: {organizationId: "%s"}) {
            id name displayName service avatar isQueuePaused isDisconnected
          }
        }
    """ % org_id)
    chans = data.get("channels") or []
    if service:
        chans = [c for c in chans
                 if (c.get("service") or "").lower() == service.lower()]
    return chans


CREATE_POST = """
mutation CreatePost($input: CreatePostInput!) {
  createPost(input: $input) {
    ... on PostActionSuccess { post { id status dueAt } }
    ... on MutationError { message }
  }
}
"""


def buffer_create_video_post(api_key, channel_id, video_url, text="",
                             mode="addToQueue", due_at=None,
                             thumbnail_offset_ms=1000):
    """Cree le post video. `mode`:
         addToQueue      -> prochain creneau libre de la file Buffer
         customScheduled -> a l'heure exacte donnee par due_at (ISO 8601)
         shareNow        -> tout de suite
    """
    post_input = {
        "channelId": channel_id,
        "text": text or "",
        "schedulingType": "automatic",
        "mode": mode,
        "assets": [{"video": {
            "url": video_url,
            "metadata": {"thumbnailOffset": int(thumbnail_offset_ms)},
        }}],
        # Instagram exige un TYPE de post. Sans lui Buffer refusait tout:
        # « Invalid post: Instagram posts require a type (post, story, or
        # reel) » — le seul envoi jamais tente (26 aout 2026) a echoue la.
        # Reel, et partage aussi dans le fil du profil. Champs verifies par
        # introspection du schema GraphQL (InstagramPostMetadataInput).
        "metadata": {"instagram": {"type": "reel", "shouldShareToFeed": True}},
    }
    if mode == "customScheduled":
        if not due_at:
            raise PublishError("Une date est nécessaire pour une publication programmée.")
        post_input["dueAt"] = due_at

    data = buffer_query(api_key, CREATE_POST, {"input": post_input})
    res = data.get("createPost") or {}
    if res.get("message"):                    # branche MutationError
        raise PublishError(f"Buffer a refusé le post : {res['message']}")
    post = res.get("post") or {}
    if not post.get("id"):
        raise PublishError(f"Réponse inattendue de Buffer : {json.dumps(res)[:300]}")
    return post


def buffer_etat_file(api_key, channel_id):
    """(nb de posts en attente, heures deja prises).

    Un SEUL appel pour les deux: le compteur de la file et les horaires a
    eviter viennent de la meme liste. Les posts deja publies sont inclus
    dans les heures prises — on ne veut pas programmer une video cinq
    minutes apres une autre, publiee ou non."""
    org = buffer_organization_id(api_key)
    data = buffer_query(api_key, """
        query File($i: PostsInput!) {
          posts(first: 100, input: $i) { edges { node { id status dueAt } } }
        }
    """, {"i": {"organizationId": org,
                "filter": {"channelIds": [channel_id],
                           "status": ["scheduled", "sent"]}}}, vital=False)
    attente, heures = 0, []
    for e in ((data.get("posts") or {}).get("edges")) or []:
        n = e.get("node") or {}
        if n.get("status") == "scheduled":
            attente += 1
        if n.get("dueAt"):
            heures.append(n["dueAt"])
    return attente, heures


def buffer_posts_rates(api_key, channel_id):
    """Identifiants des posts que Buffer n'a pas reussi a publier."""
    org = buffer_organization_id(api_key)
    data = buffer_query(api_key, """
        query Rates($i: PostsInput!) {
          posts(first: 50, input: $i) { edges { node { id dueAt } } }
        }
    """, {"i": {"organizationId": org,
                "filter": {"channelIds": [channel_id], "status": ["error"]}}}, vital=False)
    return {(e.get("node") or {}).get("id")
            for e in ((data.get("posts") or {}).get("edges")) or []}


def buffer_posts_publies(api_key, channel_id):
    """Identifiants des posts deja publies sur ce compte."""
    org = buffer_organization_id(api_key)
    data = buffer_query(api_key, """
        query Publies($i: PostsInput!) {
          posts(first: 100, input: $i) { edges { node { id } } }
        }
    """, {"i": {"organizationId": org,
                "filter": {"channelIds": [channel_id], "status": ["sent"]}}}, vital=False)
    return {(e.get("node") or {}).get("id")
            for e in ((data.get("posts") or {}).get("edges")) or []}


def buffer_en_attente(api_key, channel_id):
    return buffer_etat_file(api_key, channel_id)[0]


# ------------------------------------------------------------------
# Orchestration
# ------------------------------------------------------------------

def check_video(video_path, duration=None):
    """Refuse tot ce qu'Instagram refusera de toute facon, avec un message
    clair -- plutot que de laisser Buffer echouer sans explication."""
    p = Path(video_path)
    if not p.is_file():
        raise PublishError(f"Fichier introuvable : {p.name}")
    size = p.stat().st_size
    if size > MAX_BYTES:
        raise PublishError(
            f"{p.name} fait {size/1048576:.0f} Mo, au-delà de la limite de 300 Mo.")
    warnings = []
    if duration:
        if duration < REELS_MIN_SECONDS:
            raise PublishError(
                f"{p.name} dure {duration:.1f} s : Instagram refuse les Reels "
                f"de moins de {REELS_MIN_SECONDS} s.")
        if duration > REELS_MAX_SECONDS:
            warnings.append(
                f"{duration:.0f} s dépasse les {REELS_MAX_SECONDS} s de l'API : "
                f"la vidéo sera publiée en post vidéo, pas dans l'onglet Reels.")
    return warnings


def publish_video(cfg, video_path, channel_id, caption="",
                  mode="addToQueue", due_at=None, duration=None):
    """Depose la video sur R2 puis la met dans la file Buffer.

    Retourne de quoi retrouver le post ET l'objet stocke, pour pouvoir
    faire le menage plus tard."""
    st = status(cfg)
    if not st["buffer"]:
        raise PublishError("Clé API Buffer manquante.")
    if not st["r2"]:
        raise PublishError("Stockage R2 non configuré.")

    warnings = check_video(video_path, duration)

    key = f"{int(time.time())}-{Path(video_path).name}"
    url = r2_put(cfg, key, video_path)

    try:
        post = buffer_create_video_post(
            cfg["buffer_api_key"], channel_id, url, caption, mode, due_at)
    except PublishError:
        # Buffer n'a pas voulu du post: inutile de garder le fichier.
        try:
            r2_delete(cfg, key)
        except PublishError:
            pass
        raise

    return {
        "status": "queued" if mode != "shareNow" else "posted",
        "post_id": post.get("id"),
        "due_at": post.get("dueAt"),
        "video_url": url,
        "r2_key": key,
        "channel_id": channel_id,
        "at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "warnings": warnings,
    }
