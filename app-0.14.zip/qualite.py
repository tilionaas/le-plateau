"""La qualite d'un clip, mesuree sur l'image — sans IA, sans rien payer.

Ce qui se MESURE ne se demande pas a Claude: un clip trop sombre, flou,
filme a l'horizontale ou trop court se lit dans les pixels et dans
ffprobe, de facon fiable et en une fraction de seconde. Claude, lui,
juge ce qui ne se mesure pas (« ca ne ressemble pas a la consigne ») au
moment du tri.

Trois images par clip (a 20, 50 et 80 %), en gris, a 270 px de large:
assez pour la lumiere et la nettete, et le calcul tient en Python pur.

Resultat mis en cache sur disque (`.qualite-cache.json`, cle
chemin|mtime|taille, comme `.probe-cache.json`): une serie de 80 clips
se remesure en une seconde.
"""
import json
import os
import subprocess
import threading
from pathlib import Path

from chemins import DONNEES as ICI
CACHE = ICI / ".qualite-cache.json"
_verrou = threading.Lock()
_cache = None

LARG, HAUT = 270, 480
# Seuils mesures sur les clips des series en cours (voir README): un clip
# filme le soir dans une piece eclairee a la lampe tourne autour de 70-90
# de luminosite moyenne; sous 45 le visage se perd. La nettete est la
# variance du laplacien: les clips nets mesurent 60 a 400, un clip ou la
# mise au point a decroche tombe sous 15.
SOMBRE = 45
CLAIR = 215
FLOU = 15
# Un clip sombre dont le 99,5e centile depasse ca a des zones vraiment
# claires: un ecran en mode sombre (son texte), une scene de nuit voulue.
# Mesure: 179 et 226 sur les deux ecrans sombres de « replit dark mode »
# et « Reaction » (moyennes 27 et 21), 87 sur un clip de Voyager assombri
# pour simuler une piece sans lumiere (moyenne 28).
CLAIRS_MIN = 150
LARGEUR_MIN = 720


def _sonde(chemin):
    p = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "stream=codec_type,width,height:stream_side_data=rotation:format=duration",
         "-of", "json", str(chemin)], capture_output=True, text=True)
    try:
        d = json.loads(p.stdout or "{}")
    except ValueError:
        return None
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), None)
    if not v:
        return None
    w, h = int(v.get("width") or 0), int(v.get("height") or 0)
    rot = 0
    for sd in v.get("side_data_list") or []:
        if "rotation" in sd:
            rot = abs(int(sd["rotation"])) % 180
    if rot == 90:
        w, h = h, w
    son = any(s.get("codec_type") == "audio" for s in d.get("streams", []))
    try:
        dur = float((d.get("format") or {}).get("duration") or 0)
    except ValueError:
        dur = 0.0
    return {"w": w, "h": h, "duree": round(dur, 2), "son": son}


def _gris(chemin, t):
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{t:.2f}", "-i", str(chemin),
         "-frames:v", "1",
         "-vf", f"scale={LARG}:{HAUT}:force_original_aspect_ratio=decrease,"
                f"pad={LARG}:{HAUT}:(ow-iw)/2:(oh-ih)/2,format=gray",
         "-f", "rawvideo", "pipe:1"], capture_output=True)
    return p.stdout if len(p.stdout) == LARG * HAUT else None


def _mesures(px):
    n = len(px)
    moy = sum(px) / n
    # Les zones CLAIRES (99,5e centile): un ecran en mode sombre filme a une
    # moyenne de 21 a 27 — plus noir qu'un clip rate — mais son texte reste
    # blanc. Un clip sous-expose, lui, est sombre partout.
    hist = [0] * 256
    for v in px:
        hist[v] += 1
    cumul, haut = 0, 255
    for v in range(256):
        cumul += hist[v]
        if cumul >= n * 0.995:
            haut = v
            break
    # Laplacien sur une grille d'un pixel sur deux: la moitie du calcul,
    # et le flou (qui s'etale sur plusieurs pixels) se voit tout autant.
    vals = []
    w = LARG
    for y in range(2, HAUT - 2, 2):
        r = y * w
        for x in range(2, w - 2, 2):
            i = r + x
            vals.append(4 * px[i] - px[i - 1] - px[i + 1] - px[i - w] - px[i + w])
    m = sum(vals) / len(vals)
    lap = sum((v - m) ** 2 for v in vals) / len(vals)
    return moy, lap, haut


def mesurer(chemin):
    """{"w","h","duree","son","lumiere","nettete"} — ou None si illisible."""
    s = _sonde(chemin)
    if not s:
        return None
    lum, net, hauts = [], [], []
    for f in (0.2, 0.5, 0.8):
        g = _gris(chemin, max(0.0, s["duree"] * f))
        if g:
            a, b, c = _mesures(g)
            lum.append(a)
            net.append(b)
            hauts.append(c)
    s["lumiere"] = round(sum(lum) / len(lum), 1) if lum else None
    s["clairs"] = round(sum(hauts) / len(hauts)) if hauts else None
    # La MEILLEURE des trois images: un mouvement brusque rend une image
    # floue dans un clip net; c'est un clip entier flou qu'on veut signaler.
    s["nettete"] = round(max(net), 1) if net else None
    return s


def avertissements(m, duree_voulue=0.0, son_voulu=False):
    """Les phrases a afficher. Vide = rien a dire."""
    if not m:
        return ["Vidéo illisible"]
    out = []
    if m["w"] > m["h"]:
        out.append("Filmé à l'horizontale")
    if min(m["w"], m["h"]) and min(m["w"], m["h"]) < LARGEUR_MIN:
        out.append(f"Basse résolution ({m['w']}×{m['h']})")
    if m.get("lumiere") is not None:
        if m["lumiere"] < SOMBRE and (m.get("clairs") or 0) < CLAIRS_MIN:
            out.append("Trop sombre")
        elif m["lumiere"] > CLAIR:
            out.append("Surexposé")
    if m.get("nettete") is not None and m["nettete"] < FLOU:
        out.append("Flou")
    if duree_voulue and m["duree"] + 0.05 < duree_voulue:
        out.append(f"Trop court ({m['duree']:.1f} s, il en faut {duree_voulue:.1f})")
    if son_voulu and not m["son"]:
        out.append("Pas de son")
    return out


def _charger():
    global _cache
    if _cache is None:
        try:
            _cache = json.loads(CACHE.read_text())
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _cle(chemin):
    st = os.stat(chemin)
    return f"{chemin}|{int(st.st_mtime)}|{st.st_size}"


def mesure_en_cache(chemin):
    chemin = str(chemin)
    try:
        cle = _cle(chemin)
    except OSError:
        return None
    with _verrou:
        c = _charger()
        if cle in c:
            return c[cle]
    m = mesurer(chemin)
    with _verrou:
        c = _charger()
        c[cle] = m
        try:
            tmp = CACHE.with_suffix(".tmp")
            tmp.write_text(json.dumps(c))
            os.replace(tmp, CACHE)
        except OSError:
            pass
    return m
