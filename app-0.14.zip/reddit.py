#!/usr/bin/env python3
"""
Trouver sur Reddit les gens qui cherchent un createur UGC.
-----------------------------------------------------------
Lecture seule, sans compte: Reddit sert les subreddits publics en JSON a
qui le demande poliment. Pas de cle, pas d'OAuth, rien a configurer — et
donc rien a casser le jour ou un jeton expire.

Le prix de cette simplicite: une dizaine de requetes par minute maximum.
Un passage par heure sur une quinzaine de subreddits tient largement
dedans.

Ce module ne fait que lire et trier. Il n'ecrit rien, ne repond a
personne, et ne decide rien: c'est `server.py` qui range les trouvailles
et c'est l'utilisateur qui tranche.
"""

import html
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime, timezone

NS = {"a": "http://www.w3.org/2005/Atom"}

# Reddit refuse l'agent par defaut d'urllib (429 immediat). Il demande un
# agent qui dit qui on est — c'est ecrit dans leurs regles d'usage.
AGENT = "macos:le-plateau:1.0 (prospection UGC, usage personnel)"

# On lit les FLUX ATOM, pas le JSON. Mesure du 3 octobre 2026, meme
# requete a la seconde pres:
#   www.reddit.com/.../new.json  -> 403
#   api.reddit.com/...           -> 403
#   old.reddit.com/.../new.json  -> 200 mais du HTML, pas du JSON
#   www.reddit.com/.../new/.rss  -> 200, un vrai flux
# Reddit a ferme ses lectures JSON anonymes mais sert toujours les flux.
# Ils donnent tout ce dont on a besoin: titre, texte, auteur, date, lien.
BASE = "https://www.reddit.com"

# La ou les gens cherchent quelqu'un. Volontairement court: mieux vaut
# quinze subreddits lus a fond qu'une centaine survolee.
SUBS = ("forhire", "hiring", "freelance_forhire", "DigitalMarketing",
        "InfluencerMarketing", "UGCcreators", "ugcCreator", "socialmedia",
        "AdvertisingMarketing", "marketing", "startups", "Entrepreneur",
        "smallbusiness", "ecommerce", "shopify")

# Recherches globales, pour attraper ce qui tombe hors de ces subreddits.
# Deux suffisent: elles ramenent largement les memes annonces.
RECHERCHES = ("UGC creator", "hiring UGC")

DELAI = 4.0          # entre deux requetes

# Reddit compte les requetes, pas les passages. Quinze subreddits lus un par
# un, c'etaient quinze appels par tour — de quoi se faire bloquer en une
# journee de mise au point. Reddit sait combiner les subreddits dans UN seul
# flux (`/r/a+b+c/new/.rss`), ce qui ramene le tour a trois appels:
# un flux groupe et deux recherches. A raison d'un tour toutes les trois
# heures, c'est vingt-quatre appels par jour.
# La pause est ECRITE SUR DISQUE: en memoire seule, un redemarrage du
# serveur la effacait et le tour suivant repartait aussitot taper sur un
# Reddit qui venait justement de nous bloquer — exactement ce qui rallonge
# la punition.
from chemins import DONNEES
PAUSE_FICHIER = DONNEES / ".reddit-pause"
PAUSE_429 = 3600      # bloque: on ne retente pas avant une heure


def _pause_jusqua():
    try:
        return float(PAUSE_FICHIER.read_text().strip() or 0)
    except (OSError, ValueError):
        return 0.0


def _poser_pause(secondes=PAUSE_429):
    try:
        PAUSE_FICHIER.write_text(str(time.time() + secondes))
    except OSError:
        pass


class RedditError(Exception):
    pass


def _lire(url, timeout=25):
    """Le flux Atom d'une page Reddit. [] si Reddit refuse."""
    req = urllib.request.Request(url)
    req.add_header("User-Agent", AGENT)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            brut = r.read()
    except urllib.error.HTTPError as e:
        if e.code == 429:
            raise RedditError("Reddit limite les appels, on repassera") from e
        raise RedditError(f"Reddit : {e.code}") from e
    except (urllib.error.URLError, OSError) as e:
        raise RedditError(f"Reddit injoignable : {e}") from e
    try:
        racine = ET.fromstring(brut)
    except ET.ParseError as e:
        raise RedditError("Reddit a renvoyé autre chose qu'un flux") from e
    return racine.findall("a:entry", NS)


def _posts(entrees):
    for e in entrees:
        lien = e.find("a:link", NS)
        url = lien.get("href") if lien is not None else ""
        ident = (e.findtext("a:id", "", NS) or "").split("_")[-1]
        quand = 0.0
        d = e.findtext("a:updated", "", NS) or e.findtext("a:published", "", NS)
        if d:
            try:
                quand = datetime.strptime(d[:19], "%Y-%m-%dT%H:%M:%S").replace(
                    tzinfo=timezone.utc).timestamp()
            except ValueError:
                pass
        # Le contenu est du HTML echappe: on en retire les balises, le texte
        # suffit — on ne cherche que des mots et des montants.
        contenu = e.findtext("a:content", "", NS) or ""
        contenu = html.unescape(re.sub(r"<[^>]+>", " ", html.unescape(contenu)))
        auteur = (e.findtext("a:author/a:name", "", NS) or "").lstrip("/u/")
        # r/truc/comments/... -> truc
        m = re.search(r"/r/([^/]+)/", url or "")
        yield {
            "id": ident,
            "titre": (e.findtext("a:title", "", NS) or "").strip(),
            "texte": re.sub(r"\s+", " ", contenu).strip()[:4000],
            "auteur": auteur.replace("u/", ""),
            "sub": m.group(1) if m else "",
            "url": url,
            "quand": quand,
        }


def moissonner(heures=336, subs=SUBS, recherches=RECHERCHES, limite=100):
    """Les annonces recentes, sans tri ni filtre. [{...}]

    `limite=100` est le maximum que Reddit sert par flux. Sur un subreddit
    tres actif comme r/forhire, cent messages ne couvrent pas deux semaines:
    la fenetre reelle y est plus courte, et ce sont les recherches globales
    qui rattrapent le reste."""
    depuis = time.time() - heures * 3600
    vus, out = set(), []
    attente = _pause_jusqua() - time.time()
    if attente > 0:
        raise RedditError(
            f"Reddit nous a bloqués — nouvelle tentative dans {int(attente / 60)} min")
    groupe = "+".join(subs)
    sources = [f"{BASE}/r/{groupe}/new/.rss?limit={limite}"]
    sources += [f"{BASE}/search.rss?q=" + urllib.parse.quote(q)
                + "&sort=new&t=month&limit=" + str(limite) for q in recherches]
    for u in sources:
        try:
            entrees = _lire(u)
        except RedditError as e:
            # Un subreddit mort ne doit rien casser — mais si Reddit nous
            # bloque, insister aggrave la punition: on se met en pause et on
            # rend ce qu'on a deja.
            if "limite" in str(e):
                _poser_pause()
                break
            continue
        for p in _posts(entrees):
            if p["quand"] < depuis or p["id"] in vus:
                continue
            vus.add(p["id"])
            out.append(p)
        time.sleep(DELAI)
    return out


# ------------------------------------------------------------------
# Le tri
# ------------------------------------------------------------------

# Ce dont l'annonce doit parler. Sans ca, une offre a 3000 $ pour du
# developpement passerait le filtre du montant sans nous concerner.
UGC = re.compile(r"\b(ugc|user[\s-]?generated|content creator|creators? needed|"
                 r"short[\s-]?form|tiktok|reels?|faceless|talking head|"
                 r"video creator|content for (our|my) brand)\b", re.I)

# Ce qui dit qu'on CHERCHE quelqu'un, par opposition a quelqu'un qui se
# propose: les deux cohabitent dans les memes subreddits.
CHERCHE = re.compile(r"\[hiring\]|\bhiring\b|looking for|we need|i need|"
                     r"searching for|seeking|recruit", re.I)
PROPOSE = re.compile(r"\[for ?hire\]|\bfor hire\b|available for|my portfolio|"
                     r"i'?m a (ugc|content)", re.I)

# « talking head », « face to camera »: le tarif plancher n'est pas le meme.
PARLE = re.compile(r"talking[\s-]?head|face[\s-]?to[\s-]?camera|on[\s-]?camera|"
                   r"voice ?over|speaking", re.I)

# Paiement a la vue (CPM, rev-share) plutot qu'au forfait. Ce n'est pas la
# meme affaire: un CPM peut rapporter beaucoup ou rien, un forfait est su
# d'avance.
CPM = re.compile(r"\bcpm\b|per\s*1[,.]?0?0?0\s*views|/\s*1k\s*views|"
                 r"per\s*thousand|rev(?:enue)?[\s-]?share|per\s*view", re.I)

# Poster SOI-MEME, et sur quelle plateforme. Livrer des rushes ou tenir un
# compte TikTok sont deux metiers differents.
TIKTOK = re.compile(r"\btiktok\b|\btik[\s-]?tok\b", re.I)
POSTER = re.compile(r"post(?:ing)?\s+(?:on|to|from)\s+your|your\s+(?:own\s+)?account|"
                    r"your\s+(?:tiktok|instagram|ig)\b|from\s+your\s+profile", re.I)

# Les sommes. On accepte « $600 », « 600$ », « 600 usd », « 1k », « 1,500 ».
_MONTANT = re.compile(r"""
    (?:(?P<dev>[$€£])\s*)?
    (?P<val>\d{1,3}(?:[,\s]\d{3})+|\d+(?:\.\d+)?)
    \s*(?P<k>k\b)?
    \s*(?P<dev2>\$|usd|cad|eur|€|£)?
""", re.I | re.X)

# Ce qui suit un montant et le qualifie, pour ramener a un mois.
_PAR_MOIS = re.compile(r"(?:\b(?:per|a)\b|/)\s*(month|mo|mois)\b", re.I)
_PAR_SEM = re.compile(r"(?:\b(?:per|a)\b|/)\s*(week|wk|semaine)\b", re.I)
_PAR_VID = re.compile(r"(?:\b(?:per|a|each)\b|/)\s*(video|vid|clip|post|piece)s?\b", re.I)


def montants(texte):
    """Toutes les sommes du texte, ramenees au MOIS quand c'est dit.

    Renvoie [(valeur_mensuelle, brut)]. Un tarif par video est multiplie
    par 20: c'est l'ordre de grandeur d'un contrat mensuel, et ca evite de
    jeter une offre a 50 $ la video qui vaut 1000 $ par mois."""
    out = []
    for m in _MONTANT.finditer(texte):
        suite = texte[m.end():m.end() + 24]
        # Un nombre nu n'est pas un prix... sauf quand il est suivi de
        # « /month », « per video » et compagnie: « budget is 1000/month »
        # est la formulation la plus courante des annonces, et l'exiger
        # avec un symbole faisait rater les meilleures.
        qualifie = bool(_PAR_MOIS.search(suite) or _PAR_SEM.search(suite)
                        or _PAR_VID.search(suite))
        if not (m.group("dev") or m.group("dev2") or m.group("k") or qualifie):
            continue
        brut = m.group(0).strip()
        try:
            v = float(m.group("val").replace(",", "").replace(" ", ""))
        except ValueError:
            continue
        if m.group("k"):
            v *= 1000
        if v <= 0:
            continue
        if _PAR_SEM.search(suite):
            v *= 4
        elif _PAR_VID.search(suite):
            v *= 20
        avant = texte[max(0, m.start() - 30):m.start()]
        if _SOMMET.search(avant):
            v = -v                        # garde en reserve, voir `juger`
        out.append((v, brut, qualifie))
    return out


# Au-dela, ce n'est plus un salaire: c'est un nombre de vues, un chiffre
# d'affaires ou une coquille. Mesure sur les 28 premieres annonces reelles:
# « 50 250 000 $ », « 100 000 $ » — des nombres attrapes au vol dans le
# corps du texte, pas des tarifs.
PLAFOND = 50000

# Ce qui annonce un PLAFOND et non une paie: « up to $10k », « bonuses up
# to », « earn as much as ». Mesure sur les premieres annonces reelles:
# « $600/Month + Bonuses » et « $750/month guaranteed + view bonuses (up to
# $10k) » ressortaient tous les deux a 10 000 $ — le chiffre qui fait rever,
# jamais celui qu'on touche.
# Les terminaisons comptent: « earning $10k » doit matcher comme « earn ».
_SOMMET = re.compile(r"(up\s*to|as\s*much\s*as|jusqu\w*|bonus\w*|potential\w*|"
                     r"max\w*|earn\w*|gagn\w*)\W{0,14}$", re.I)


def juger(post, seuil_simple=500, seuil_parle=800):
    """None si l'annonce ne nous concerne pas, sinon ce qu'on en retient.

    Le montant retenu est le PLUS GROS du texte: une annonce qui dit
    « 50 $ la video, 1500 $ par mois » parle bien de 1500."""
    texte = f"{post['titre']}\n{post['texte']}"
    if not UGC.search(texte):
        return None
    # Quelqu'un qui se propose n'est pas un client. Le titre tranche: les
    # balises [Hiring] / [For Hire] y sont, par convention des subreddits.
    if PROPOSE.search(post["titre"]) and not CHERCHE.search(post["titre"]):
        return None
    if not CHERCHE.search(texte):
        return None
    parle = bool(PARLE.search(texte))
    seuil = seuil_parle if parle else seuil_simple
    trouves = montants(texte)
    # Une somme QUALIFIEE (« 600/month ») vaut mieux que la plus grosse du
    # texte: prendre le maximum faisait passer « $600/Month + bonuses » pour
    # 10 000 $ parce que le corps parlait de 10 000 abonnes.
    # Le plafond s'applique AVANT de choisir, pas apres: une annonce qui dit
    # « $750/month + bonus up to $300k in views » a deux sommes qualifiees,
    # et rejeter sur la plus grosse jetait l'annonce au lieu de retenir le
    # salaire. Mesure: c'est arrive sur quatre des vingt-huit premieres.
    # Les plafonds sont marques en negatif par `montants`: on ne les retient
    # que si l'annonce ne donne aucune autre somme.
    fermes = [t for t in trouves if t[0] > 0]
    trouves = fermes or [(-v, b, q) for v, b, q in trouves]
    sains = [t for t in trouves if t[0] <= PLAFOND]
    qualifies = [t for t in sains if t[2]]
    pool = qualifies or sains
    if not pool:
        return None
    val, brut, _ = max(pool, key=lambda x: x[0])
    if val < seuil:
        return None
    return {**post, "montant": round(val), "montant_brut": brut,
            "parle": 1 if parle else 0,
            "cpm": 1 if CPM.search(texte) else 0,
            "tiktok": 1 if TIKTOK.search(texte) else 0,
            "doit_poster": 1 if POSTER.search(texte) else 0}


def scruter(heures=336, seuil_simple=500, seuil_parle=800, **kw):
    """Tout le travail: moissonner puis trier."""
    gardes = []
    for p in moissonner(heures=heures, **kw):
        g = juger(p, seuil_simple, seuil_parle)
        if g:
            gardes.append(g)
    gardes.sort(key=lambda x: -x["montant"])
    return gardes
