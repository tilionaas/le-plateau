#!/usr/bin/env python3
"""
Moteur de remix video.
----------------------
Contient toute la logique ffmpeg. Utilise par le serveur web (server.py)
et par le script en ligne de commande (video_remixer.py).

Une SERIE = un dossier avec:
  serie.json    la config (slots, reglages, captions)
  slots/<id>/      les clips de chaque categorie
  music/           les musiques de fond (optionnel)
  output/          les videos generees
  thumbs/          les vignettes

Un SLOT = une categorie de clips (ex: "Hook", "Corps", "CTA"). Chaque
serie en definit autant qu'elle veut, dans l'ordre ou ils doivent
apparaitre dans la video finale.
"""

import json
import math
import os
import random
import re
import shutil
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import broll
import captions
import detourage
import transcription

VIDEO_EXTS = (".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm")
AUDIO_EXTS = (".mp3", ".m4a", ".wav", ".aac", ".flac", ".ogg", ".mp4")
# Banques d'images declenchees par un mot (voir broll.py).
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".heic", ".gif")


# Reglages par defaut d'une nouvelle serie. Groupes par impact reel
# sur l'empreinte perceptuelle (voir README).
DEFAULT_SETTINGS = {
    # Format de sortie
    "width": 1080,
    "height": 1920,
    # 60 par defaut: les iPhone filment en 60 im/s et sortir en 30 jetait
    # une image sur deux, ce qui se voit dans les mouvements.
    "fps": 60,
    # Qualite d'encodage. crf: plus bas = meilleur (14 = quasi sans perte,
    # 16 par defaut, 20 correct, 28 visiblement degrade). A 16 le debit
    # obtenu est proche de celui des sources iPhone (~14 contre ~16 Mb/s).
    "crf": 16,
    # `fast` mesure plus rapide que `medium` ET avec un debit superieur a
    # crf egal: pas de raison d'aller plus lent.
    "preset": "fast",
    # ------------------------------------------------------------------
    # PHILOSOPHIE DES REGLAGES PAR DEFAUT
    #
    # La variete vient du MONTAGE: clips differents, points de decoupe
    # differents. C'est gratuit en qualite et c'est le seul levier qui
    # deplace vraiment une empreinte perceptuelle (mesures dans le README).
    #
    # Toutes les retouches d'image et de son sont donc a ZERO par defaut.
    # Elles degradent l'image ou l'experience du spectateur pour un gain
    # nul ou marginal:
    #   couleurs      0 bit de difference mesure -> aucun interet
    #   recadrage     SSIM 0.99 -> 0.81, la perte la plus lourde
    #   vitesse >1.1  change le rythme et la voix, ca s'entend
    #   nettete       change le rendu pour un gain d'empreinte marginal
    # Tout reste reglable si tu veux les reactiver.
    # ------------------------------------------------------------------
    # MONTAGE - impact fort, cout nul
    # La duree se regle PAR CATEGORIE (dur_min / dur_max en secondes).
    # Si rien n'est defini pour une categorie, le clip est pris en entier.
    "shuffle_slots": False,    # melanger l'ordre des categories
    # Sortie brute: on tire un clip au sort et on le recopie TEL QUEL, sans
    # decoupe, sans retouche, sans texte. Sert a piocher dans une reserve de
    # clips sans les garder sur son telephone. Une seule categorie.
    "raw": 0,
    # SPLIT SCREEN: deux clips empiles, une bande noire entre eux ou passe
    # le texte. Ce n'est PAS une sequence de plans: les deux clips tournent
    # du debut a la fin, la video dure le plus court des deux.
    #
    # Mesures sur le reel de reference (1080x1920):
    #   noir en haut  216 px (11,2 %)
    #   clip du haut  615 px (32,0 %)
    #   bande          67 px ( 3,5 %)
    #   clip du bas   818 px (42,6 %)
    #   noir en bas   204 px (10,6 %)
    # Les deux noirs ne sont pas decoratifs: en haut passe l'interface de
    # TikTok/Reels, en bas la legende et les boutons. Y poser de l'image
    # revient a la jeter.
    "split": 0,
    "split_marge_haut": 0.112,
    "split_marge_bas": 0.106,
    "split_bande": 0.035,
    # Part du clip du HAUT dans l'espace restant une fois les deux marges
    # et la bande retirees. 0.43 = 615 / (615 + 818), le partage mesure.
    "split_part": 0.43,
    # AUDIO
    # Le son des clips sources est TOUJOURS retire, sans exception (`-an`
    # dans process_clip). `mute` decide seulement s'il reste une musique
    # par-dessus. A 0 par defaut: sans musique deposee la video sort muette
    # de toute facon, donc cette valeur ne rend rien bruyant toute seule --
    # elle evite juste qu'une musique deposee soit ignoree en silence.
    "mute": 0,
    # Serie parlee: le son des clips est GARDE et ce qui est dit s'affiche
    # mot a mot. Voir transcription.py et `assemble`.
    "parle": 0,
    # Incrustation (categorie « incrustation »): largeur de la personne
    # detouree, en fraction de la largeur de la video. 0.42 = elle occupe
    # un peu moins de la moitie de l'ecran en bas d'un coin.
    "incrust_largeur": 0.42,
    # 1 = toujours en bas a DROITE. 0 = cote tire au sort a chaque video
    # (le comportement d'origine). Demande le 12/11 sur Buzzy : on attend
    # sa tete au meme coin d'une video a l'autre, comme un facecam.
    "incrust_droite": 0,
    # Taille des sous-titres parles, plus petite que celle des textes fixes.
    # Mesuree sur un Reel de reference (capture 920 px, video recadree en
    # hauteur a 1810 px): un mot comme « c'est » y fait 132 px de large
    # ramene a 1080, ce que TikTok Sans Bold donne a 58.
    "subtitle_size": 58,
    # 1.0 = le volume du fichier tel quel. La musique n'est pas un fond
    # sous autre chose: c'est la seule piste audio de la video, elle doit
    # donc s'entendre a son niveau d'origine.
    "music_volume_min": 1.0,
    "music_volume_max": 1.0,
    # CADRE - tres leger. Le recadrage coute cher meme a faible dose (c'est
    # un rescale, pas juste un crop): a 14% le SSIM tombait a 0.81, a 3% deja
    # 0.885. On reste a 1.5%, negligeable a l'oeil.
    "zoom_min": 0.0,
    "zoom_max": 0.015,
    # PIXELS - retouches legeres. Avec one_effect=1 ci-dessous, un clip ne
    # recoit jamais plus d'UNE de ces retouches a la fois, donc les activer
    # toutes ne les cumule pas.
    "speed_min": 1.0,
    "speed_max": 1.04,         # imperceptible, mais change l'echantillonnage
    "brightness_amp": 0.02,
    "contrast_amp": 0.02,
    "saturation_amp": 0.03,
    "hue_amp": 2.0,
    # Nettete (unsharp). ATTENTION: la valeur neutre est 0, pas 1 -- 1 est
    # seulement le defaut de ffmpeg et applique deja une nettete bien
    # visible. Repere mesure sur les clips du projet: 0.3 imperceptible,
    # 0.8 visible et naturel, 1.5 marque, 2.5 tres marque (halos possibles
    # sur les contours contrastes). Plage 1-2 = look net facon CapCut.
    "sharpen_min": 1.0,
    "sharpen_max": 2.0,
    # Une seule retouche a la fois: si plusieurs sont activees, chaque clip
    # n'en recoit qu'UNE, tiree au sort. Empiler recadrage + couleurs +
    # nettete sur le meme clip cumule les degats sans rien
    # apporter de plus.
    "one_effect": 1,
    # Captions
    # 1.0 = un texte s'affiche des qu'une categorie en definit un.
    "caption_prob": 1.0,
    "caption_size": 70,        # taille du texte, relative a une video 1080 de large
    # Largeur de la colonne de texte, en fraction de la largeur de la video.
    # C'est elle qui decide OU le texte revient a la ligne. 0,92 est le
    # defaut de captions.py; il faut souvent plus en split screen, ou la
    # bande est faite pour UNE ligne: « Step 4. Let it chef up something
    # devious » mesure 1004 px a taille 55 dans le reel de reference, et la
    # colonne a 0,92 n'en offre que 974 — le texte passait sur deux lignes
    # et la bande doublait de hauteur.
    "caption_larg": 0.92,
    "caption_style": "contour",  # contour = blanc cerne de noir, sans fond
    # GRAISSE ET CONTOUR MESURES sur un texte TikTok de reference, a
    # hauteur de capitale egale (48 px), avec les memes metriques sur la
    # reference et sur nos rendus:
    #   graisse  le fut du « I » fait 0,163 x la capitale chez TikTok;
    #            Medium donne 0,170, SemiBold 0,195, Bold 0,231. Le Bold
    #            d'avant etait 40 % trop gras. Medium collait a la mesure
    #            mais se lisait un peu maigre a l'ecran: on prend Medium+
    #            (poids 560, fut 0,186), entre Medium et SemiBold.
    #   contour  ~3,0 px de noir autour de la lettre, mesure trait par
    #            trait avec le fond pris localement (la video derriere
    #            n'est pas uniforme) -> 10,5 % de la taille. A 16 on en
    #            mettait la moitie de plus.
    # L'interlettrage et l'interligne mesures en meme temps vivent dans le
    # style lui-meme (`captions.STYLES`), pour valoir partout.
    # Les 11 % qui « se delavaient sur fond clair » datent du trace en une
    # passe, qui rongeait la lettre: en deux passes et jointure arrondie,
    # 10,5 % reste noir franc sur un fond creme ou bleu ciel (verifie).
    "caption_font": "TikTok Sans Medium+",
    "caption_outline": 10.5,
}

TARGET_AR = 44100

# Qualite des morceaux temporaires, avant l'assemblage. Volontairement tres
# haute: ces fichiers sont ré-encodes juste apres, et toute perte introduite
# ici s'ajouterait a celle du rendu final. Ils sont supprimes ensuite.
INTERMEDIATE_CRF = 14
# Police pour le filtre drawtext de ffmpeg — le chemin d'un fichier, pas un
# nom. Celle livree avec le projet passe en premier: elle est la meme sur
# les trois systemes, donc un montage rendu sur Windows ressemble a un
# montage rendu sur Mac. Les suivantes ne servent que si elle a ete
# supprimee.
FONT_CANDIDATES = [
    str(Path(__file__).resolve().parent / "fonts" /
        "TikTokSans[opsz,slnt,wdth,wght].ttf"),
    "/System/Library/Fonts/Supplemental/Arial.ttf",      # macOS
    "/System/Library/Fonts/Helvetica.ttc",
    "/Library/Fonts/Arial.ttf",
    "C:/Windows/Fonts/arialbd.ttf",                      # Windows
    "C:/Windows/Fonts/arial.ttf",
    "C:/Windows/Fonts/segoeuib.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",   # Linux
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
]

# Cache des mesures ffprobe. Il vivait uniquement en memoire: chaque
# redemarrage du serveur relançait un ffprobe par clip, soit ~7 s pour ouvrir
# une serie de 80 clips. Il est maintenant recopie sur disque, donc le
# cout n'est paye qu'une fois par fichier, pour de bon.
_probe_cache = {}
_probe_dirty = False
from chemins import DONNEES as _DONNEES
_PROBE_FILE = _DONNEES / ".probe-cache.json"
_probe_lock = threading.Lock()
_drawtext_cache = None


def _load_probe_cache():
    """Relit le cache disque. Les cles sont "chemin|mtime|taille": si un
    fichier change, sa cle change, donc une entree perimee est simplement
    ignoree — pas besoin d'invalidation."""
    try:
        with open(_PROBE_FILE, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return {}
    out = {}
    for k, v in (d.items() if isinstance(d, dict) else []):
        try:
            out[k] = (float(v[0]), bool(v[1]))
        except (TypeError, ValueError, IndexError):
            pass
    return out


def save_probe_cache():
    """Ecrit le cache sur disque s'il a bouge. Echec silencieux: perdre le
    cache coute du temps, jamais de l'exactitude."""
    global _probe_dirty
    with _probe_lock:
        if not _probe_dirty:
            return
        snapshot, _probe_dirty = dict(_probe_cache), False
    # Les fichiers supprimes laissent leur entree derriere eux. Au-dela de
    # quelques milliers, on fait le menage: c'est rare, et ca evite que le
    # fichier gonfle indefiniment.
    if len(snapshot) > 4000:
        snapshot = {k: v for k, v in snapshot.items()
                    if os.path.exists(k.rsplit("|", 2)[0])}
        with _probe_lock:
            _probe_cache.clear()
            _probe_cache.update(snapshot)
    try:
        tmp = _PROBE_FILE.with_suffix(".json.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({k: list(v) for k, v in snapshot.items()}, f)
        os.replace(str(tmp), str(_PROBE_FILE))
    except OSError:
        pass


_probe_cache = _load_probe_cache()


# ------------------------------------------------------------------
# Utilitaires ffmpeg
# ------------------------------------------------------------------

def tools_available():
    """(ffmpeg_ok, texte_ok, message)

    Le texte ne depend plus de ffmpeg: il est dessine par macOS et incruste
    en PNG, donc il marche meme sans le filtre drawtext."""
    missing = [t for t in ("ffmpeg", "ffprobe") if shutil.which(t) is None]
    if missing:
        return False, False, f"{' et '.join(missing)} introuvable(s). Installe ffmpeg."
    return True, captions.available(), ""


def has_drawtext():
    """Le filtre drawtext n'existe que si ffmpeg est compile avec libfreetype."""
    global _drawtext_cache
    if _drawtext_cache is None:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-h", "filter=drawtext"],
                           capture_output=True, text=True)
        _drawtext_cache = "Unknown filter" not in (r.stdout + r.stderr)
    return _drawtext_cache


def font_file():
    for f in FONT_CANDIDATES:
        if Path(f).exists():
            return f
    return None


def audio_rate(path):
    """Frequence d'echantillonnage de la piste audio, ou None."""
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a:0",
         "-show_entries", "stream=sample_rate", "-of", "csv=p=0", path],
        capture_output=True, text=True)
    try:
        return int(r.stdout.strip())
    except ValueError:
        return None


def probe(path):
    """(duree_secondes, a_de_l_audio). Mis en cache par chemin+mtime+taille.

    Un seul appel ffprobe sort les deux informations: la version precedente
    en lançait deux par fichier, ce qui doublait pour rien le nombre de
    processus a demarrer — c'est le demarrage du processus qui coute, pas
    la lecture."""
    global _probe_dirty
    try:
        st = os.stat(path)
        key = f"{path}|{st.st_mtime}|{st.st_size}"
    except OSError:
        return 0.0, False
    hit = _probe_cache.get(key)
    if hit is not None:
        return hit

    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "format=duration:stream=codec_type", "-of", "json", path],
        capture_output=True, text=True)
    duration, has_audio = 0.0, False
    try:
        info = json.loads(r.stdout or "{}")
        duration = float(info.get("format", {}).get("duration") or 0.0)
        has_audio = any(st_.get("codec_type") == "audio"
                        for st_ in info.get("streams", []))
    except (ValueError, TypeError):
        pass

    with _probe_lock:
        _probe_cache[key] = (duration, has_audio)
        _probe_dirty = True
    return duration, has_audio


def probe_many(paths, workers=8):
    """Mesure une liste de fichiers en parallele.

    ffprobe passe l'essentiel de son temps a demarrer et a lire le disque,
    pas a calculer: les lancer a plusieurs divise l'attente d'autant. Sert a
    l'ouverture d'une serie, ou il y a des dizaines de clips a mesurer."""
    paths = list(paths)
    todo = [p for p in paths if not _cached(p)]
    if len(todo) > 1:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            list(pool.map(probe, todo))
        save_probe_cache()
    return {p: probe(p) for p in paths}


def _cached(path):
    try:
        st = os.stat(path)
    except OSError:
        return True                      # illisible: inutile de paralleliser
    return f"{path}|{st.st_mtime}|{st.st_size}" in _probe_cache


# ------------------------------------------------------------------
# Niveau sonore des clips (series parlees)
# ------------------------------------------------------------------
# Sonie integree EBU R128, en LUFS: le "dB" que percoit l'oreille, et celui
# que TikTok/Instagram mesurent. Un pic de crete ne dit rien du volume
# ressenti: une voix lointaine avec un claquement de porte a un pic haut et
# une sonie basse.
#
# Meme principe que le cache ffprobe: cle chemin|mtime|taille, sur disque.
# La mesure decode tout le son du clip (~0,3 s par clip), payee une fois.
_SONIE_FILE = _DONNEES / ".sonie-cache.json"
_sonie_lock = threading.Lock()
_sonie_cache = None

# On ne BAISSE jamais un clip: les plus faibles sont remontes au niveau du
# plus fort de la serie. Deux bornes quand meme:
# - la cible ne depasse pas -14 LUFS, le niveau auquel TikTok et Instagram
#   ramenent de toute facon les videos. Un clip plus fort que ca garde son
#   niveau, il n'est pas baisse, mais il ne tire pas tous les autres au-dela.
# - +20 dB de gain au plus: au-dela, on remonte surtout le souffle d'un
#   clip ou personne ne parle vraiment.
SONIE_CIBLE_MAX = -14.0
SONIE_GAIN_MAX = 20.0


def sonie(path):
    """Sonie integree du clip en LUFS, ou None (pas de son, silence)."""
    global _sonie_cache
    try:
        st = os.stat(path)
    except OSError:
        return None
    key = f"{path}|{st.st_mtime}|{st.st_size}"
    with _sonie_lock:
        if _sonie_cache is None:
            try:
                _sonie_cache = json.loads(_SONIE_FILE.read_text("utf-8"))
            except (OSError, ValueError):
                _sonie_cache = {}
            if not isinstance(_sonie_cache, dict):
                _sonie_cache = {}
        if key in _sonie_cache:
            return _sonie_cache[key]
    val = None
    if probe(path)[1]:
        r = subprocess.run(["ffmpeg", "-nostats", "-i", str(path), "-vn",
                            "-af", "ebur128", "-f", "null", "-"],
                           capture_output=True, text=True)
        # Le resume final: "Integrated loudness:\n    I:  -23.4 LUFS".
        m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
        if m and float(m[-1]) > -69:          # -70 = porte EBU: silence
            val = float(m[-1])
    with _sonie_lock:
        _sonie_cache[key] = val
    return val


def sonie_many(paths, workers=8):
    paths = list(paths)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        res = dict(zip(paths, pool.map(sonie, paths)))
    with _sonie_lock:
        if not paths or _sonie_cache is None:
            return res
        try:
            tmp = _SONIE_FILE.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(_sonie_cache), "utf-8")
            os.replace(str(tmp), str(_SONIE_FILE))
        except OSError:
            pass
    return res


def sonie_cible(niveaux):
    """Niveau commun: celui du clip le plus fort, plafonne. None si aucun."""
    n = [x for x in niveaux if x is not None]
    return min(max(n), SONIE_CIBLE_MAX) if n else None


def sonie_gain(niveau, cible):
    """dB a ajouter pour atteindre la cible. Jamais negatif."""
    if niveau is None or cible is None:
        return 0.0
    return round(max(0.0, min(cible - niveau, SONIE_GAIN_MAX)), 2)


def frame_luma(video_path, t):
    """Luminance moyenne (0-255) de l'image a l'instant t, ou None.

    On reduit l'image a un seul pixel: c'est ffmpeg qui fait la moyenne,
    donc rien a decoder cote Python."""
    r = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", str(t), "-i", video_path,
         "-frames:v", "1", "-vf", "scale=1:1,format=gray", "-f", "rawvideo", "-"],
        capture_output=True)
    return r.stdout[0] if r.stdout else None


def make_thumbnail(video_path, thumb_path, width=360):
    """Vignette JPEG pour l'interface. Echec silencieux: c'est cosmetique.

    On ne prend plus l'image a 1 s aveuglement: certains clips commencent
    par un plan sombre (un ecran filme dans une piece noire, par exemple)
    et la vignette sortait toute noire, ce qui donnait l'impression d'une
    video ratee. On echantillonne donc quelques instants et on garde le
    plus lumineux — a condition qu'il le soit assez pour qu'on distingue
    quelque chose."""
    duration, _ = probe(video_path)
    if not duration:
        candidats = [0]
    else:
        # Reparti sur toute la video, en evitant la toute premiere et la
        # toute derniere image (souvent un fondu ou une transition).
        candidats = [round(duration * f, 2) for f in (.12, .3, .5, .7, .88)]

    best, best_l = candidats[0], -1
    for t in candidats:
        l = frame_luma(video_path, t)
        if l is None:
            continue
        if l > best_l:
            best, best_l = t, l
        if l >= 90:            # assez lumineuse, inutile de chercher mieux
            break

    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", str(best), "-i", video_path,
         "-frames:v", "1", "-vf", f"scale={width}:-2", "-q:v", "4", thumb_path],
        capture_output=True)
    return Path(thumb_path).exists()


# ------------------------------------------------------------------
# Construction des filtres
# ------------------------------------------------------------------

def escape_drawtext(text):
    """drawtext: backslash, apostrophe, deux-points et % sont speciaux."""
    for ch in ("\\", "'", ":", "%"):
        text = text.replace(ch, "\\" + ch)
    return text


def slot_captions(slot, serie_captions):
    """Textes utilisables pour un clip de cette categorie.

    Les textes propres a la categorie ont la priorite; ceux de la serie
    servent de repli pour les categories qui n'en definissent pas."""
    own = [c for c in (slot or {}).get("captions", []) if c and c.strip()]
    return own or [c for c in (serie_captions or []) if c and c.strip()]


def slot_speed(slot, s):
    """Plage de vitesse a appliquer: celle de la categorie si elle en
    definit une, sinon celle de la serie. Jamais en dessous de 1x --
    un ralenti etirerait le clip, ce qui se voit tout de suite."""
    lo = float((slot or {}).get("speed_min") or 0)
    hi = float((slot or {}).get("speed_max") or 0)
    if hi <= 0:
        lo, hi = float(s["speed_min"]), float(s["speed_max"])
    if lo <= 0:
        lo = hi
    lo, hi = max(1.0, lo), max(1.0, hi)
    return (lo, hi) if lo <= hi else (hi, lo)


def roll_variation(s, texts, texts_ok, slot=None, bags=None):
    """Tire au sort les parametres de variation d'un clip."""
    # Le recadrage rogne puis re-agrandit: si la source fait deja la taille
    # de sortie, c'est une perte de nettete seche. On peut donc le couper
    # categorie par categorie, typiquement sur le clip d'accroche.
    can_zoom = (slot or {}).get("allow_zoom", True)

    # Vitesse: une categorie peut imposer la sienne (certains clips sont
    # toujours acceleres). Sinon on prend celle de la serie.
    sp_min, sp_max = slot_speed(slot, s)

    # Les textes sont tires comme les clips: sans remise, pour que chaque
    # phrase passe une fois avant qu'aucune ne repasse.
    pool = slot_captions(slot, texts)
    caption = None
    if pool and texts_ok and random.random() < s["caption_prob"]:
        if bags is not None:
            key = "texte|" + (slot or {}).get("id", "serie")
            drawn = draw_from_bag(bags, key, pool, 1)
            caption = drawn[0] if drawn else None
        else:
            caption = random.choice(pool)
    v = {
        # La vitesse n'est pas une "retouche": a 1.00-1.04 c'est
        # imperceptible et ca fait partie du montage. Elle reste toujours
        # active et n'entre pas dans le tirage ci-dessous.
        "speed": round(random.uniform(sp_min, sp_max), 3),
        # Miroir horizontal, decide CATEGORIE par categorie: une serie
        # melange des plans face camera (ou le miroir passe tres bien) et
        # des captures d'ecran (ou il rend le texte illisible). Un reglage
        # global aurait force a choisir entre les deux.
        #
        # Une fois active, il tombe une fois sur DEUX: c'est ce qui fait
        # varier. Systematique, il donnerait juste une categorie
        # entierement inversee, sans variete supplementaire.
        #
        # Il n'entre PAS dans `one_effect`: contrairement au recadrage ou a
        # la nettete, `hflip` ne coute aucune qualite, il n'a donc pas a
        # concurrencer les autres retouches.
        "flip": bool((slot or {}).get("flip")) and random.random() < 0.5,
        "zoom": (round(random.uniform(s["zoom_min"], s["zoom_max"]), 3)
                 if can_zoom else 0.0),
        "crop_x": round(random.uniform(0, 1), 3),
        "crop_y": round(random.uniform(0, 1), 3),
        "brightness": round(random.uniform(-s["brightness_amp"], s["brightness_amp"]), 3),
        "contrast": round(random.uniform(1 - s["contrast_amp"], 1 + s["contrast_amp"]), 3),
        "saturation": round(random.uniform(1 - s["saturation_amp"], 1 + s["saturation_amp"]), 3),
        "hue": round(random.uniform(-s["hue_amp"], s["hue_amp"]), 2),
        "sharpen": round(random.uniform(s.get("sharpen_min", 0),
                                        s.get("sharpen_max", 0)), 3),
        # Petit decalage aleatoire a l'interieur du tiers choisi: il
        # evite que le texte tombe toujours au pixel pres au meme endroit
        # d'une video a l'autre.
        #
        # AMPLITUDE REGLABLE, et mise a zero par les templates. Un
        # template refait un montage existant: quand le meme texte tient
        # sur trois plans d'affilee, ce tirage lui donnait trois positions
        # differentes — a +-1,5 % de la hauteur, soit +-29 px — et le
        # texte sautait a chaque coupe. C'est exactement ce qu'on ne veut
        # pas reproduire.
        "caption_jitter": round(random.uniform(
            -s.get("caption_jitter_amp", 0.015),
            s.get("caption_jitter_amp", 0.015)), 4),
        "caption": caption,
    }
    return keep_one_effect(v) if s.get("one_effect") else v


# Retouches mutuellement exclusives, avec de quoi les neutraliser.
_EFFECTS = {
    "recadrage": {"zoom": 0.0},
    "nettete":   {"sharpen": 0.0},
    "couleurs":  {"brightness": 0.0, "contrast": 1.0, "saturation": 1.0, "hue": 0.0},
}


def keep_one_effect(v):
    """Ne garde qu'UNE retouche parmi celles qui se sont declenchees.

    Empiler recadrage + couleurs + nettete sur le meme clip
    cumule les degradations sans rien apporter de plus: une seule suffit
    a changer l'empreinte, et le spectateur ne voit presque rien."""
    actives = [name for name, off in _EFFECTS.items()
               if any(v[k] != neutral for k, neutral in off.items())]
    if len(actives) <= 1:
        return v
    garde = random.choice(actives)
    for name, off in _EFFECTS.items():
        if name != garde:
            v.update(off)
    return v


# Tous les morceaux sortent avec EXACTEMENT les memes proprietes de couleur.
#
# Bug mesure (Face clipit, 2e clip absent): les .MP4 iPhone et quelques
# HEVC sont en plage "pleine" (yuvj420p/pc), les autres en plage TV. Un
# morceau yuvj420p suivi d'un yuv420p faisait reconstruire les filtres de
# l'assemblage au raccord; `setpts=PTS-STARTPTS` repartait de zero, et la
# cadence constante jetait les images jusqu'a rattraper l'horloge: 2,75 s
# perdues — tout le 2e clip et le debut du 3e. Meme une plage "unknown"
# face a "tv" suffit a declencher la reconstruction.
COULEURS_TV = "setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709"
OPTS_COULEURS = ["-color_range", "tv", "-colorspace", "bt709",
                 "-color_primaries", "bt709", "-color_trc", "bt709"]


def build_video_filter(v, s, box=None):
    """Chaine de filtres d'un clip. `box` = (largeur, hauteur, mode) pour
    le loger ailleurs que dans le cadre plein:
      « tenir »   l'image entiere tient dans la boite, le reste est noir
      « remplir » l'image remplit la boite, ce qui depasse est coupe
    Le split screen remplit: une video verticale posee TELLE QUELLE dans un
    panneau de 1080x615 n'en occuperait qu'un timbre-poste au milieu."""
    f = []
    # Miroir en TETE de chaine, avant le recadrage: le rognage decentre
    # garde ainsi le meme sens de lecture que ce qu'on voit a l'ecran.
    # Et comme le texte est incruste APRES ce filtre (`overlay` dans
    # process_clip), il n'est jamais inverse, lui.
    if v.get("flip"):
        f.append("hflip")
    # Crop DECENTRE: change la composition, pas seulement l'echelle.
    # A zoom nul on saute le filtre: aucun rognage, aucune remise a
    # l'echelle, l'image source passe telle quelle.
    if v["zoom"] > 0.001:
        p = round(1 - v["zoom"], 3)
        f.append(f"crop=iw*{p}:ih*{p}:(iw-ow)*{v['crop_x']}:(ih-oh)*{v['crop_y']}")
    # PTS-STARTPTS remet l'horloge du clip a zero. Sans ca, un clip decoupe
    # (ou filme en frequence d'images variable, comme les .MOV iPhone) garde
    # l'horodatage d'origine: le lecteur affiche la premiere image figee
    # pendant tout le decalage avant que la video demarre.
    f.append(f"setpts={1/v['speed']}*(PTS-STARTPTS)")
    f.append(f"eq=brightness={v['brightness']}:contrast={v['contrast']}"
             f":saturation={v['saturation']}")
    f.append(f"hue=h={v['hue']}")
    # Normalisation: sans ca, concatener des sources de resolutions ou de
    # framerates differents produit une video cassee.
    f.append(f"fps={s['fps']}")
    # out_range=tv: certaines sources (iPhone en .MP4, quelques HEVC) sont
    # en plage de couleurs "pleine" (yuvj420p). Voir COULEURS_TV.
    bw, bh, mode = box or (s["width"], s["height"], "tenir")
    cd = v.get("cadre") if mode != "remplir" else None
    if mode == "remplir":
        f.append(f"scale={bw}:{bh}:force_original_aspect_ratio=increase"
                 ":out_range=tv")
        f.append(f"crop={bw}:{bh}")
    elif cd:
        # Le recadrage de l'editeur: l'image tient dans le cadre, puis
        # grandit de z autour du centre et glisse de (x, y) fractions de
        # l'ecran — exactement le `transform` de l'apercu. On l'agrandit,
        # on l'entoure de noir sur un ecran de chaque cote (pad), et on
        # decoupe l'ecran a sa place: aucun cas particulier quand l'image
        # deborde d'un cote et pas de l'autre.
        z = max(1.0, float(cd.get("z") or 1.0))
        dx, dy = float(cd.get("x") or 0.0), float(cd.get("y") or 0.0)
        f.append(f"scale={int(bw * z)}:{int(bh * z)}:force_original_aspect_ratio=decrease"
                 ":force_divisible_by=2:out_range=tv")
        f.append(f"pad=iw+{2 * bw}:ih+{2 * bh}:{bw}:{bh}")
        f.append(f"crop={bw}:{bh}:'max(0,min(iw-{bw},(iw-{bw})/2-({dx})*{bw}))'"
                 f":'max(0,min(ih-{bh},(ih-{bh})/2-({dy})*{bh}))'")
    else:
        f.append(f"scale={bw}:{bh}:force_original_aspect_ratio=decrease"
                 ":out_range=tv")
        f.append(f"pad={bw}:{bh}:(ow-iw)/2:(oh-ih)/2")
    f.append("setsar=1")

    # Nettete, apres le redimensionnement (c'est la qu'elle est la plus utile:
    # elle rattrape le flou introduit par le scale). Negatif = flou.
    if abs(v.get("sharpen", 0)) > 0.01:
        f.append(f"unsharp=5:5:{v['sharpen']}:5:5:0")
    return ",".join(f)


def clip_regl(slot, src):
    """Les reglages notes sur CE clip-la de la categorie (editeur), ou {}.

    Ranges sous le NOM du fichier, comme les reperes de sync (`repere`):
    on redepose souvent le meme clip ailleurs, le chemin bougerait.
      debut, fin  la partie UTILE du clip, en secondes de la source: ce qui
                  est avant ou apres est rate, rien n'y est jamais pris
      vitesse     fixe, a la place du tirage de la serie (0,25 a 4)
      son         True/False: l'emporte sur le son de la categorie
      volume      multiplicateur de la voix du clip
      miroir      toujours inverse
      cadre       {z, x, y}: agrandi de z autour du centre, decale de x, y
                  (fractions de l'ecran) — le recadrage de CapCut
    """
    d = ((slot or {}).get("par_clip") or {}).get(os.path.basename(str(src)))
    return d if isinstance(d, dict) else {}


def atempo(v):
    """`atempo` en une chaine: un seul filtre ne descend pas sous 0,5."""
    v = float(v or 1.0)
    out = []
    while v < 0.5:
        out.append("atempo=0.5")
        v /= 0.5
    out.append(f"atempo={round(v, 4)}")
    return ",".join(out)


def plage_utile(path, slot):
    """(debut, fin) de la partie utilisable du clip, en secondes source."""
    r = clip_regl(slot, path)
    duree = probe(path)[0] or 0.0
    a = max(0.0, float(r.get("debut") or 0.0))
    b = float(r.get("fin") or 0.0) or duree
    if duree > 0:
        b = min(b, duree)
    if b <= a + 0.05:
        a, b = 0.0, duree
    return a, b, duree


def pick_trim(path, s, slot=None, speed=1.0):
    """Fenetre aleatoire dans le clip -> (start, duree) ou (None, None).

    Si la categorie fixe une duree (slot.dur_min / dur_max en secondes), on
    decoupe une fenetre au hasard qui donnera exactement cette duree en
    sortie. Comme la variation de vitesse change la duree, on prend
    `cible * vitesse` dans la source pour compenser.

    Sans duree fixee: (None, None) = le clip est pris en entier.

    Le decoupage est la variation la plus efficace du lot: des points
    d'entree/sortie differents changent la sequence de frames elle-meme.
    """
    # La partie UTILE du clip (editeur): rien n'est jamais pris avant son
    # debut ni apres sa fin. Sans reglage, c'est le clip entier.
    a, b, duration = plage_utile(path, slot)
    entier = (None, None) if (a <= 0.0 and b >= duration - 0.01) \
        else (round(a, 3), round(b - a, 3))
    dmax = float((slot or {}).get("dur_max") or 0)
    # « Garder au complet »: chaque clip passe en entier, quelle que soit
    # la duree reglee — ils sont de longueurs differentes, et c'est voulu.
    if dmax <= 0 or (slot or {}).get("complet"):
        return entier                  # clip complet

    if duration <= 0:
        return None, None

    dmin = float((slot or {}).get("dur_min") or 0)
    if dmin <= 0 or dmin > dmax:
        dmin = dmax

    target = random.uniform(dmin, dmax)
    need = target * speed              # compense l'acceleration
    if need >= b - a:
        # Clip plus court que la cible: on le prend EN ENTIER, tel quel.
        # Jamais de ralenti pour l'etirer, jamais de noir pour combler --
        # la video sera simplement un peu plus courte que prevu.
        return entier
    # OU commencer dans le clip. Au hasard pour une serie: des points
    # d'entree differents sont la variation la plus efficace du lot.
    # Mais un clip filme POUR un plan de template commence au bon
    # endroit, et un depart tire au sort rendrait deux montages
    # differents a partir des memes clips. D'ou le choix, par plan.
    if (slot or {}).get("depart") == "debut":
        return round(a, 3), round(need, 3)
    return round(random.uniform(a, b - need), 3), round(need, 3)


# ------------------------------------------------------------------
# COUPER LES SILENCES (22/11)
# ------------------------------------------------------------------
# « Supprime tous les silences de mon talking head » : le montage qu'on
# fait a la main sur une face cam — chaque clip commence au premier mot
# et finit au dernier, quelle que soit sa longueur, et (mode « tous ») les
# pauses au milieu sautent en jump cut. Les mots viennent de whisper
# (`transcription.mots`, en cache), dates sur la piste son EXTRAITE : on
# les ramene au temps de l'IMAGE (`depart_audio`), comme les sous-titres.
#
# Le morceau reste UN morceau par categorie : les passages gardes sont
# recolles DANS le morceau (trim + concat, exact meme sur les sources a
# cadence variable de l'iPhone), et la voix est recoupee aux MEMES
# instants a l'assemblage (`voix_coupes`). Tout ce qui compte les
# morceaux — editeur, musique « des ici », incrustation — ne change pas.
SILENCE_AVANT = 0.12     # garde avant le premier mot : l'attaque d'un mot
SILENCE_APRES = 0.22     # whisper date la fin d'un mot un peu tot
PAUSE_MAX = 0.45         # mode « tous » : une pause plus longue saute
MOT_INCERTAIN = 0.5      # duree donnee a un mot que whisper date a zero
SILENCES = ("bords", "tous")


def jete_du_clip(slot, src):
    """Les passages RATES de ce clip — reprises, faux departs, « attends je
    recommence » — en secondes de l'image source : [(debut, fin)] tries.

    Notes sous le NOM du fichier (`par_clip[nom]["jete"]`), comme tout ce
    qui tient a un clip. C'est la « prise du jour » qui les ecrit
    (`server.prise_nettoyer`) : une prise filmee d'une traite contient
    presque toujours une phrase dite deux fois, et couper les silences ne
    l'enleve pas — elle est PARLEE."""
    out = []
    for x in clip_regl(slot, src).get("jete") or []:
        try:
            a, b = float(x[0]), float(x[1])
        except (TypeError, ValueError, IndexError):
            continue
        if b > a:
            out.append((a, b))
    return sorted(out)


def coupes_parole(src, slot):
    """[(debut, fin)] des passages GARDES du clip, en secondes de l'image
    source, ou None (rien a couper, pas de voix, rien de lisible)."""
    mode = (slot or {}).get("silences") or ""
    jete = jete_du_clip(slot, src)
    if mode not in SILENCES and not jete:
        return None
    a0, b0, _duree = plage_utile(src, slot)
    if mode not in SILENCES:
        # Des reprises a retirer, mais les silences restent : on garde tout
        # ce qui est ENTRE les passages rates, sans rien lire des mots.
        out, t = [], a0
        for ja, jb in jete:
            if ja - t > 0.15:
                out.append((round(t, 3), round(min(ja, b0), 3)))
            t = max(t, jb)
        if b0 - t > 0.15:
            out.append((round(t, 3), round(b0, 3)))
        return out or None
    dec = depart_audio(src)
    try:
        mots = [(w, x + dec, y + dec) for w, x, y in transcription.mots(src)]
    except Exception:                                           # noqa: BLE001
        return None
    # Un mot que whisper n'a pas su dater a une duree NULLE (« results » a
    # 5,07-5,07 s sur IMG_8975, alors qu'il est dit a 5,42-5,62 s) : le
    # jeter coupait le DERNIER mot de la phrase. On lui donne une demi-
    # seconde — un silence garde de trop vaut mieux qu'un mot mange.
    mots = [(w, x, y if y - x >= 0.08 else x + MOT_INCERTAIN) for w, x, y in mots]
    mots = [m for m in mots if m[1] >= a0 - 0.05 and m[1] <= b0 + 0.05]
    # Un mot dit dans un passage rate n'existe plus. `rang` = combien de
    # passages rates sont AVANT lui : deux mots de rangs differents ne
    # peuvent pas partager un morceau, meme sans pause entre eux.
    if jete:
        dans = lambda t: any(ja <= t < jb for ja, jb in jete)
        mots = [m for m in mots if not dans(m[1] + min(0.05, (m[2] - m[1]) / 2))]
    rang = lambda t: sum(1 for ja, _jb in jete if ja <= t)
    if not mots:
        return None
    groupes = []                                   # [debut, fin, rang]
    for _w, x, y in mots:
        r = rang(x)
        if groupes and groupes[-1][2] == r and (mode == "bords" or x - groupes[-1][1] <= PAUSE_MAX):
            groupes[-1][1] = max(groupes[-1][1], y)
        else:
            groupes.append([x, y, r])
    out = []
    for x, y, _r in groupes:
        a, b = max(a0, x - SILENCE_AVANT), min(b0, y + SILENCE_APRES)
        # Les marges ne mordent jamais sur un passage rate : sans ca, les
        # 0,22 s gardees apres le dernier mot rendaient le debut de la
        # phrase qu'on venait de retirer.
        for ja, jb in jete:
            if jb <= x + 0.02:
                a = max(a, jb)
            elif ja >= x:
                b = min(b, ja)
        if out and a <= out[-1][1] + 0.05 and not any(out[-1][1] - 0.02 <= ja and jb <= a + 0.02 for ja, jb in jete):
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    out = [(round(a, 3), round(b, 3)) for a, b in out if b - a > 0.15]
    return out or None


def temps_coupe(t, coupes):
    """Un instant de la source -> son instant dans le morceau recolle
    (avant la vitesse), ou None s'il tombe dans un silence coupe."""
    c = 0.0
    for a, b in coupes:
        if t < a - 0.05:
            return None
        if t <= b + 0.05:
            return c + min(max(t - a, 0.0), b - a)
        c += b - a
    return None


def filtre_coupes(entree, coupes, sortie, audio=False):
    """Le graphe qui garde les passages et les recolle: split, trim, concat.
    `coupes` en secondes depuis le debut de l'entree."""
    k = len(coupes)
    sp, tr, ps = ("asplit", "atrim", "asetpts") if audio else ("split", "trim", "setpts")
    noms = "".join(f"[{sortie}i{n}]" for n in range(k))
    g = f"{entree}{sp}={k}{noms}"
    for n, (a, b) in enumerate(coupes):
        g += f";[{sortie}i{n}]{tr}=start={a:.3f}:end={b:.3f},{ps}=PTS-STARTPTS[{sortie}c{n}]"
    g += ";" + "".join(f"[{sortie}c{n}]" for n in range(k))
    g += f"concat=n={k}:v={0 if audio else 1}:a={1 if audio else 0}[{sortie}]"
    return g


# ------------------------------------------------------------------
# Rendu
# ------------------------------------------------------------------

class RenderError(Exception):
    pass


def caption_y(video_h, cap_h, position, jitter=0.0):
    """Position verticale du bloc de texte, selon le tiers demande.

    Un petit decalage aleatoire evite que le texte tombe toujours au pixel
    pres au meme endroit. Le resultat est borne pour ne jamais deborder."""
    if position == "milieu":
        y = (video_h - cap_h) / 2.0
    elif position == "bas":
        y = video_h * (0.76 + jitter) - cap_h / 2.0
    else:                                   # haut (defaut)
        # 0.155 et non 0.13: le texte collait un peu trop au bord haut, ou
        # il passe sous l'interface de TikTok/Reels. Descendu juste assez
        # pour respirer, sans quitter le tiers du haut.
        y = video_h * (0.155 + jitter)
    return int(max(video_h * 0.03, min(y, video_h * 0.95 - cap_h)))


# ------------------------------------------------------------------
# ZOOM ANIME ET TRANSITIONS (23/11)
# ------------------------------------------------------------------
# Le moteur ne savait que la coupe seche et un rognage fixe. Le monteur lit
# maintenant les zooms et les transitions de la video exemple (`ia.py`) ;
# il faut donc savoir les REFAIRE. Deux reglages de CATEGORIE :
#
#   zoom_anim  {"de": 1.0, "a": 1.15}  l'echelle au debut et a la fin du
#              morceau : de < a = zoom avant, de > a = zoom arriere,
#              de = a > 1 = plan resserre (le « punch-in » d'un jump cut) ;
#   transition "fondu" | "noir" | "flash" | "glisse", et `transition_dur`
#              (secondes) : comment la categorie ENTRE, depuis le plan
#              d'avant.
#
# RIEN NE CHANGE DE DUREE. Un vrai fondu enchaine superpose deux plans et
# raccourcit la video d'autant — or tout ce qui compte les morceaux (la
# frise de l'editeur, la musique « des ici », l'incrustation, la voix
# recoupee) suppose qu'ils se suivent bout a bout. La transition se joue
# donc DANS le morceau qui entre, sur ses premieres images, contre la
# DERNIERE IMAGE du morceau d'avant (figee) : a 0,2–0,4 s, on ne voit pas
# qu'elle est figee. Le fondu par le noir et le flash se partagent entre
# la fin du morceau qui sort et le debut de celui qui entre.
ZOOM_MAX = 1.6
TRANSITIONS = ("fondu", "noir", "flash", "glisse")
TRANSITION_DEFAUT = 0.3


def zoom_du_slot(slot):
    """(de, a) borne dans [1, ZOOM_MAX], ou None s'il n'y a pas de zoom."""
    z = (slot or {}).get("zoom_anim")
    if not isinstance(z, dict):
        return None
    try:
        de = min(ZOOM_MAX, max(1.0, float(z.get("de") or 1.0)))
        a = min(ZOOM_MAX, max(1.0, float(z.get("a") or 1.0)))
    except (TypeError, ValueError):
        return None
    return (round(de, 3), round(a, 3)) if (de > 1.004 or a > 1.004) else None


def filtre_zoom(slot, s, duree):
    """Le zoom de la categorie, a poser sur une image DEJA a la taille de
    sortie. L'image grandit autour de son centre et le cadre la recoupe.
    `scale` reevalue a chaque image (`eval=frame`) ; des tailles paires,
    sinon l'image tremble d'un pixel d'une image a l'autre."""
    z = zoom_du_slot(slot)
    if not z:
        return ""
    de, a = z
    W, H = s["width"], s["height"]
    if abs(a - de) < 0.005:
        return f"scale={2 * int(W * de / 2)}:{2 * int(H * de / 2)},crop={W}:{H}"
    e = f"({de}+({a - de:.4f})*min(t/{max(0.1, duree):.3f},1))"
    return (f"scale=w='2*trunc({W}*{e}/2)':h='2*trunc({H}*{e}/2)':eval=frame,"
            f"crop={W}:{H}")


def transition_du_slot(slot):
    """(type, duree) ou None."""
    t = str((slot or {}).get("transition") or "")
    if t not in TRANSITIONS:
        return None
    try:
        d = float((slot or {}).get("transition_dur") or TRANSITION_DEFAUT)
    except (TypeError, ValueError):
        d = TRANSITION_DEFAUT
    return t, round(min(1.0, max(0.1, d)), 3)


def derniere_image(piece, dst):
    """La derniere image d'un morceau, en PNG. -> chemin ou None."""
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-sseof", "-0.25", "-i", str(piece),
                        "-update", "1", "-frames:v", "30", str(dst)], capture_output=True)
    return str(dst) if r.returncode == 0 and os.path.exists(str(dst)) else None


def transitions_pour(slot, entre, suivant, parts, tmp_dir):
    """Ce que `process_clip` doit jouer sur ce morceau.
    `entre` : ce morceau est le premier de sa categorie (c'est la qu'on
    entre) ; `suivant` : la categorie du morceau d'apres, si elle differe.
    -> {"entree": (type, d, image | None), "sortie": (type, d)} ou None."""
    out = {}
    t = transition_du_slot(slot) if entre else None
    if t:
        img = None
        if t[0] in ("fondu", "glisse"):
            # Rien avant le premier plan : pas de fondu ni de glisse.
            img = derniere_image(parts[-1], Path(tmp_dir) / f"t_{uuid.uuid4().hex}.png") \
                if parts else None
            if not img:
                t = None
        if t:
            out["entree"] = (t[0], t[1], img)
    ts = transition_du_slot(suivant) if suivant else None
    if ts and ts[0] in ("noir", "flash"):
        out["sortie"] = ts
    return out or None


def process_clip(src, dst, s, texts, texts_ok, slot=None, cache_dir=None, bags=None,
                 regles=None, trans=None):
    v = roll_variation(s, texts, texts_ok, slot, bags)
    # Ce qui est regle sur CE clip dans l'editeur l'emporte sur le tirage:
    # une vitesse choisie n'est pas une variation, un cadrage choisi non
    # plus — un rognage tire au sort par-dessus le decalerait.
    regl = clip_regl(slot, src)
    if regl.get("vitesse"):
        v["speed"] = float(regl["vitesse"])
    if regl.get("miroir"):
        v["flip"] = True
    if regl.get("cadre"):
        v["cadre"] = regl["cadre"]
        v["zoom"] = 0.0
    # La vitesse est tiree avant le decoupage: la duree cible en depend.
    start, keep = pick_trim(src, s, slot, v["speed"])
    # Silences coupes: c'est la PAROLE qui decide de la fenetre, plus la
    # duree de la categorie (« meme si c'est pas le meme temps »).
    coupes = coupes_parole(src, slot)
    if coupes:
        start = coupes[0][0]
        keep = round(coupes[-1][1] - start, 3)
        coupes = [(round(a - start, 3), round(b - start, 3)) for a, b in coupes]

    # Clip pris EN ENTIER (trop court pour la fenetre demandee): la vitesse
    # s'applique quand meme et le raccourcit encore. Une categorie reglee
    # sur 2 s minimum pouvait donc sortir un plan bien plus court que 2 s,
    # alors que c'est precisement ce que le reglage promet.
    # On ralentit le tirage juste ce qu'il faut pour tenir le minimum,
    # jamais en dessous de 1.0 (pas de ralenti). Si le clip source est lui
    # meme plus court que le minimum, il n'y a rien a faire: il passe tel
    # quel, ce que l'interface annonce deja sous la categorie.
    dmin = float((slot or {}).get("dur_min") or 0)
    if start is None and dmin > 0 and v["speed"] > 1.0 and not regl.get("vitesse") \
            and not (slot or {}).get("complet"):
        source, _ = probe(src)
        if source > 0 and source / v["speed"] < dmin:
            v["speed"] = max(1.0, round(source / dmin, 3))

    cmd = ["ffmpeg", "-y", "-v", "error"]
    if start is not None:
        cmd += ["-ss", str(start), "-t", str(keep)]
    cmd += ["-i", src]
    idx = 1

    # Les morceaux sont VIDEO SEULE. Le silence est ajoute a l'assemblage.
    #
    # Avant, chaque morceau embarquait une piste `anullsrc` (infinie) coupee
    # par `-shortest`. Or `-shortest` deborde par intermittence: mesure sur
    # 7 tirages, un morceau est sorti avec 1,367 s de video et 4,179 s
    # d'audio. La duree du CONTENEUR suit la plus longue piste, et le
    # demuxeur concat decale le morceau suivant de cette duree-la — d'ou
    # 2,8 secondes de trou dans la video finale, sur lesquelles le lecteur
    # fige la derniere image. C'est l'origine des videos gelees.
    #
    # Sans piste audio, la duree du conteneur EST celle de la video. Les
    # morceaux restent homogenes entre eux, ce que le demuxeur exige.

    # Le texte est une image PNG transparente dessinee par captions.py,
    # incrustee avec `overlay`. ffmpeg de Homebrew n'a pas `drawtext`.
    cap_idx, cap_y = None, 0
    if v["caption"] and texts_ok:
        rendered = captions.cached(
            v["caption"], s["width"], s["height"],
            cache_dir or Path(dst).parent,
            # Une CATEGORIE peut imposer sa taille. Sert aux templates:
            # on y mesure la taille reelle du texte dans le reel de
            # reference, plan par plan, et une taille unique pour toute
            # la video ne la respecterait pas.
            size=int((slot or {}).get("caption_size") or s.get("caption_size", 56)),
            style=s.get("caption_style", "contour"),
            font_ps=captions.FONT_CHOICES.get(s.get("caption_font", "")),
            outline=s.get("caption_outline"),
            # L'interligne du reel d'origine, mesure plan par plan. Sert
            # aux templates: la taille des lettres ne fait pas tout, un
            # bloc trop aere parait plus gros qu'il n'est.
            lead=(slot or {}).get("caption_lead") or None,
            # Largeur de la colonne de texte: c'est elle qui decide du
            # nombre de lignes. Reglee a la main dans l'apercu du template,
            # sinon celle de la serie.
            larg=((slot or {}).get("caption_larg")
                  or s.get("caption_larg") or None))
        if rendered:
            png, cap_h = rendered
            cmd += ["-i", png]
            cap_idx = idx
            idx += 1
            # `text_y` (fraction de la hauteur) l'emporte sur le tiers:
            # un template sait OU le texte etait, au pixel pres, pendant
            # que « haut / milieu / bas » n'en donne qu'une approximation.
            ty = (slot or {}).get("text_y")
            if ty is not None:
                cap_y = int(max(0, min(float(ty) * s["height"],
                                       s["height"] - cap_h)))
            else:
                cap_y = caption_y(s["height"], cap_h,
                                  (slot or {}).get("text_pos", "haut"),
                                  v["caption_jitter"])

    # Serie parlee: la voix des clips est gardee (a l'assemblage, voir
    # `voix` plus bas) et ce qui est dit s'affiche en sous-titres, mot a mot.
    #
    # La transcription porte sur le clip SOURCE entier; on garde les mots
    # qui tombent dans la fenetre decoupee, ramenes au temps de sortie:
    # (t - debut) / vitesse, puisque `setpts` accelere l'image AVANT
    # l'incrustation.
    sous_titres = []
    # Son garde: soit toute la serie est « parlee », soit cette categorie
    # seule coche « garder le son » — dans une video react, c'est la video
    # de fond qu'on entend, pas l'incrustation.
    garde_son = bool(s.get("parle") or (slot or {}).get("son"))
    # Un clip peut couper ou garder SON son a part de sa categorie.
    if regl.get("son") is not None:
        garde_son = bool(regl["son"])
    if regl.get("volume") is not None and float(regl["volume"]) <= 0.001:
        garde_son = False
    # `sans_st`: categorie dont le son n'est pas une voix (la musique des
    # clips « buzzy gs », 13/11) — whisper y inventait du portugais.
    parle = bool(s.get("parle")) and not (slot or {}).get("sans_st")
    if parle and garde_son and texts_ok:
        t0 = start or 0.0
        t1 = t0 + keep if keep is not None else float("inf")
        # Les mots sont dates sur la piste son EXTRAITE, qui commence a son
        # premier echantillon. Si elle demarre apres l'image (voir
        # `depart_audio`), tous les temps doivent glisser d'autant pour
        # revenir dans le temps de l'IMAGE — sinon les sous-titres
        # repassent en avance de la meme quantite qu'on vient de corriger
        # sur la voix.
        dec = depart_audio(src)
        if coupes:
            # Les mots ramenes dans le morceau RECOLLE ; ceux d'un silence
            # coupe n'existent plus (il n'y en a pas, c'est un silence).
            dans = []
            for w, a, b in transcription.mots(src):
                ta = temps_coupe(a + dec - t0, coupes)
                tb = temps_coupe(b + dec - t0, coupes)
                if ta is not None and tb is not None:
                    dans.append((w, ta / v["speed"], tb / v["speed"]))
        else:
            dans = [(w, (a + dec - t0) / v["speed"], (b + dec - t0) / v["speed"])
                    for w, a, b in transcription.mots(src)
                    if a + dec >= t0 - 0.05 and b + dec <= t1 + 0.05]
        for texte, a, b in transcription.morceaux(dans):
            rendu = captions.cached(
                texte, s["width"], s["height"], cache_dir or Path(dst).parent,
                size=int(s.get("subtitle_size", 58)),
                style=s.get("caption_style", "contour"),
                font_ps=captions.FONT_CHOICES.get(s.get("caption_font", "")),
                outline=s.get("caption_outline"))
            if rendu:
                cmd += ["-i", rendu[0]]
                sous_titres.append((idx, rendu[1], max(0.0, a), b))
                idx += 1

    # Images declenchees par ce qui est dit (banque par declencheur, tirage
    # sans remise). Posees AU-DESSUS de la tete: `detourage.tete` donne le
    # point le plus haut atteint par la personne pendant le passage, l'image
    # s'arrete juste avant.
    images = []
    if regles and garde_son and probe(src)[1]:
        t0 = start or 0.0
        t1 = t0 + keep if keep is not None else (probe(src)[0] or 0)
        # Meme glissement que pour les sous-titres: les declencheurs sont
        # reperes sur la piste extraite, ils doivent revenir au temps image.
        dec = depart_audio(src)
        mots = [(w, x + dec, y + dec) for w, x, y in transcription.mots(src)]
        for a, b, i in broll.segments(mots, regles, duree=probe(src)[0]):
            if b <= t0 or a >= t1:
                continue                   # hors de la fenetre decoupee
            a, b = max(a, t0), min(b, t1)
            dossier = (regles[i] or {}).get("dossier")
            pool = list_media(dossier, IMAGE_EXTS) if dossier else []
            if not pool:
                continue
            tire = (draw_from_bag(bags, "image|" + str(regles[i].get("mot")), pool, 1)
                    if bags is not None else [random.choice(pool)])
            if not tire:
                continue
            pos = detourage.tete(src, a, b) or (0.35, 0.5)
            haut, cx = pos
            if v.get("flip"):
                cx = 1.0 - cx             # l'image suit la tete miroir
            if coupes:
                ia_, ib_ = temps_coupe(a - t0, coupes), temps_coupe(b - t0, coupes)
                if ia_ is None:
                    continue
                ta_, tb_ = ia_ / v["speed"], (ib_ if ib_ is not None else ia_ + (b - a)) / v["speed"]
            else:
                ta_, tb_ = max(0.0, (a - t0) / v["speed"]), (b - t0) / v["speed"]
            cmd += ["-i", tire[0]]
            images.append((idx, haut, cx, ta_, tb_))
            idx += 1

    # La duree REELLE du morceau, pour le zoom (il va du debut a la fin)
    # et le fondu de sortie (il finit avec lui).
    if coupes:
        d_src = sum(b - a for a, b in coupes)
    elif keep is not None:
        d_src = keep
    else:
        d_src = probe(src)[0] or 0.0
    d_piece = max(0.1, d_src / v["speed"])
    # Le zoom porte sur l'IMAGE, avant le texte : un texte qui grossirait
    # avec le plan n'est pas ce que fait un zoom de montage.
    fv = build_video_filter(v, s)
    fz = filtre_zoom(slot, s, d_piece)
    if fz:
        fv += "," + fz
    if coupes and len(coupes) > 1:
        fc = filtre_coupes("[0:v]", coupes, "vcut") + f";[vcut]{fv}[vb]"
    else:
        fc = f"[0:v]{fv}[vb]"
    vout = "[vb]"
    if cap_idx is not None:
        fc += f";[vb][{cap_idx}:v]overlay=(W-w)/2:{cap_y}[vo]"
        vout = "[vo]"
    # Sous-titres a 75 % de la hauteur. D'abord 67 % (mesure sur le Reel de
    # reference), descendus a la demande: plus bas encore, ils passeraient
    # sous la legende de TikTok/Reels, qui commence vers 80 %. Toujours
    # sous le visage, au-dessus
    # de la zone que couvrent la legende et les boutons de TikTok/Reels, et
    # loin du texte fixe de la categorie, place en haut par defaut.
    for n, (i, h, a, b) in enumerate(sous_titres):
        y = int(s["height"] * 0.75 - h / 2)
        fc += (f";{vout}[{i}:v]overlay=(W-w)/2:{y}"
               f":enable='between(t,{a:.3f},{b:.3f})'[st{n}]")
        vout = f"[st{n}]"

    # Les images declenchees passent APRES le texte fixe mais AVANT les
    # sous-titres: elles occupent le haut de l'ecran, les sous-titres le bas.
    # Bande libre: sous le texte fixe (s'il y en a un) et au-dessus de la
    # tete. Sans cette borne haute, l'image recouvrait le texte de la
    # categorie, qui vit dans le meme tiers de l'ecran.
    sous_texte = (cap_y + (rendered[1] if cap_idx is not None else 0) + 12
                  if cap_idx is not None else int(s["height"] * 0.03))
    for n, (i, haut, cx, a, b) in enumerate(images):
        bas = int(s["height"] * haut) - 12
        dispo = bas - sous_texte
        # Bande trop mince (texte fixe sur deux lignes ET tete haute): on
        # repart du haut de l'ecran. L'image passe alors devant le texte —
        # mieux qu'un timbre-poste illisible.
        if dispo < s["height"] * 0.12:
            dispo = max(60, bas - int(s["height"] * 0.03))
        larg = int(s["width"] * 0.72)
        fc += (f";[{i}:v]scale={larg}:{dispo}:force_original_aspect_ratio=decrease[img{n}]"
               f";{vout}[img{n}]overlay="
               f"'min(max({round(cx, 4)}*W-w/2,10),W-w-10)':{bas}-h"
               f":enable='between(t,{a:.3f},{b:.3f})'[bi{n}]")
        vout = f"[bi{n}]"

    # LES TRANSITIONS, apres le texte : un fondu emporte tout ce qui est a
    # l'ecran. Voir le bloc « ZOOM ANIME ET TRANSITIONS » plus haut.
    ent = (trans or {}).get("entree")
    sor = (trans or {}).get("sortie")
    if ent:
        typ, dt, img = ent
        dt = min(dt, d_piece * 0.6)
        if typ in ("noir", "flash"):
            fc += (f";{vout}fade=t=in:st=0:d={dt / 2:.3f}"
                   f":c={'white' if typ == 'flash' else 'black'}[te]")
            vout = "[te]"
        elif img:
            # L'image figee du plan d'avant, a la cadence de la sortie.
            cmd += ["-loop", "1", "-framerate", str(s["fps"]), "-t", f"{dt + 0.3:.3f}", "-i", img]
            if typ == "fondu":
                fc += (f";[{idx}:v]format=rgba,fade=t=out:st=0:d={dt:.3f}:alpha=1[tp]"
                       f";{vout}[tp]overlay=0:0:eof_action=pass"
                       f":enable='lt(t,{dt:.3f})'[te]")
            else:
                # « glisse » : le plan d'avant part a gauche, pousse par
                # celui-ci. Les deux cote a cote, et le cadre glisse dessus
                # (depart et arrivee adoucis, 3p²−2p³).
                W = s["width"]
                pp = f"min(t/{dt:.3f},1)"
                fc += (f";[{idx}:v]scale={W}:{s['height']},format=yuv420p,setsar=1[tp]"
                       f";{vout}format=yuv420p,setsar=1[tq]"
                       f";[tp][tq]hstack=inputs=2[th]"
                       f";[th]crop={W}:{s['height']}"
                       f":x='{W}*(3*pow({pp},2)-2*pow({pp},3))':y=0[te]")
            vout = "[te]"
            idx += 1
    if sor:
        typ, dt = sor
        dt = min(dt, d_piece * 0.6)
        # 0,02 s d'avance : la duree calculee et celle du fichier different
        # d'une image, et un fondu qui finirait apres la fin ne serait pas
        # complet a la coupe.
        fc += (f";{vout}fade=t=out:st={max(0.0, d_piece - dt / 2 - 0.02):.3f}:d={dt / 2:.3f}"
               f":c={'white' if typ == 'flash' else 'black'}[ts]")
        vout = "[ts]"

    # Normalisation des couleurs en toute fin de chaine, APRES le texte:
    # `overlay` choisit lui-meme son format de sortie.
    fc += f";{vout}format=yuv420p,{COULEURS_TV}[vn]"
    vout = "[vn]"

    cmd += ["-filter_complex", fc, "-map", vout, "-an"]

    cmd += [# fps_mode cfr force une cadence constante: les sources iPhone
            # sont en frequence variable et produisent sinon des saccades.
            "-fps_mode", "cfr", "-r", str(s["fps"]),
            # Morceau intermediaire: quasi-sans-perte et rapide. Il sera
            # re-encode a l'assemblage, donc toute compression appliquee ici
            # serait une degradation pure ajoutee a celle du rendu final.
            "-c:v", "libx264", "-preset", "veryfast",
            "-crf", str(INTERMEDIATE_CRF), "-pix_fmt", "yuv420p", *OPTS_COULEURS,
            # negative_cts_offsets laisse la premiere image a l'instant 0.
            # (`-avoid_negative_ts make_zero` decalait tout de 2 images, ce
            # que le MP4 final encode en "edition vide" = ecran noir avant
            # le debut de la video.)
            "-movflags", "+negative_cts_offsets", dst]

    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RenderError(f"{Path(src).name}: {r.stderr[-500:]}")
    # De quoi retrouver la voix a l'assemblage: les morceaux restent video
    # seule (voir plus haut pourquoi), le son est reconstruit a part.
    v["voix"] = ((str(src), start, keep, v["speed"])
                 if garde_son and probe(src)[1] else None)
    # Les memes passages, pour recouper la voix a l'assemblage.
    v["voix_coupes"] = coupes if coupes and len(coupes) > 1 else None
    # Le volume du clip, en dB, ajoute au gain de sonie a l'assemblage.
    vol = float(regl.get("volume") or 1.0)
    v["voix_db"] = round(20 * math.log10(vol), 2) if vol > 0.001 else 0.0
    return v, start


def split_geom(s, cap_h=0):
    """Geometrie du split screen, en pixels PAIRS (yuv420p l'exige).

    La bande s'elargit si le texte ne tient pas dedans: un texte qui mord
    sur les deux clips est bien pire qu'un partage decale de quelques
    pixels. Elle ne retrecit jamais en dessous du reglage.
    """
    def pair(n):
        return max(2, int(n) // 2 * 2)

    H = int(s["height"])
    mh = pair(H * float(s.get("split_marge_haut", 0.112)))
    mb = pair(H * float(s.get("split_marge_bas", 0.106)))
    # `cap_h` est la hauteur du PNG, pas celle de l'encre: captions.py y
    # laisse deja ~12 px de transparent au-dessus et en dessous des lettres
    # (contour et jambages). Ajouter une marge par-dessus la comptait deux
    # fois et gonflait la bande de 20 px, qu'il fallait prendre aux clips.
    bande = pair(max(H * float(s.get("split_bande", 0.035)), cap_h))
    libre = H - mh - mb - bande
    # Reglages absurdes (marges enormes, texte gigantesque): on rend la
    # bande a sa taille reglee et on laisse le texte deborder plutot que de
    # sortir une geometrie negative que ffmpeg refuserait.
    if libre < 8:
        bande = pair(H * float(s.get("split_bande", 0.035)))
        libre = max(8, H - mh - mb - bande)
    part = min(max(float(s.get("split_part", 0.43)), 0.05), 0.95)
    h_haut = pair(libre * part)
    h_bas = pair(libre - h_haut)
    return {"h_haut": h_haut, "y_haut": mh,
            "bande": bande, "y_bande": mh + h_haut,
            "h_bas": h_bas, "y_bas": mh + h_haut + bande}


# Duree d'une etape quand sa categorie n'en fixe pas. Mesure sur le reel de
# reference: 2,1 / 2,5 / 2,0 / 2,8 / 5,7 / 2,55 s. Elles ne sont PAS egales,
# d'ou un reglage par etape plutot qu'un partage automatique.
SPLIT_ETAPE_DEFAUT = 2.5


def variation_neutre(s):
    """Aucune retouche: le clip passe tel quel, a sa vitesse, sans rognage
    ni couleurs ni nettete.

    Les deux clips d'un split screen sont deja MONTES quand on les depose
    (coupes faites, cadrage voulu). Les leur retoucher au tirage, ne
    serait-ce qu'un rognage de 1,5 %, c'est abimer un montage fini pour
    une variete qui ne sert a rien: la variete d'une serie split vient des
    etapes et du couple de clips, pas des pixels.
    """
    return {"speed": 1.0, "flip": False, "zoom": 0.0,
            "crop_x": 0.5, "crop_y": 0.5,
            "brightness": 0.0, "contrast": 1.0, "saturation": 1.0,
            "hue": 0.0, "sharpen": 0.0,
            "caption_jitter": 0.0, "caption": None}


def etapes_tirees(etapes, s, texts, texts_ok, bags):
    """(slot, texte, duree) de chaque etape du split, dans l'ordre.

    Le texte est tire SANS REMISE dans la categorie de l'etape, comme un
    clip: une etape peut donc avoir plusieurs formulations, et elles
    passent toutes avant qu'aucune ne repasse.
    """
    out = []
    for sl in etapes:
        pool = slot_captions(sl, texts)
        texte = None
        if pool and texts_ok:
            tire = draw_from_bag(bags, "texte|" + sl["id"], pool, 1)
            texte = tire[0] if tire else None
        lo = float(sl.get("dur_min") or 0)
        hi = float(sl.get("dur_max") or 0)
        if hi <= 0:
            hi = lo or SPLIT_ETAPE_DEFAUT
        if lo <= 0 or lo > hi:
            lo = hi
        out.append((sl, texte, round(random.uniform(lo, hi), 3)))
    return out


def repere(slot, src, cle):
    """Le repere `cle` note sur CE clip-la de la categorie, ou None.

    Les reperes vivent par CLIP, jamais par categorie. Dans une serie
    split, l'instant du score n'est pas au meme endroit d'un match a
    l'autre (3,15 s sur Chiefs-Seahawks, 2,85 s sur Cowboys-Eagles) et le
    depart d'une reaction pas au meme endroit d'une prise a l'autre. Un
    seul chiffre pose sur la categorie calerait le premier couple et
    decalerait tous les autres -- et un calage faux de deux images se voit
    plus qu'une absence de calage.

    Ils sont ranges sous le NOM DU FICHIER et pas sous son chemin: on
    redepose souvent le meme clip ailleurs, et le chemin bougerait.
    """
    d = (slot.get("sync") or {}).get(os.path.basename(str(src)))
    if not isinstance(d, dict):
        return None
    v = d.get(cle)
    if isinstance(v, (list, tuple)):
        out = []
        for x in v:
            try:
                out.append(float(x))
            except (TypeError, ValueError):
                pass
        return out
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


BADGE_EXT = (".png", ".webp")
# Largeur de la pastille, en fraction de l'ecran, et sa marge au coin.
BADGE_LARG = 0.46
BADGE_MARGE = 0.022


def badges_dispo(serie):
    """Les pastilles deposees pour cette serie, triees par nom.

    Relu a CHAQUE generation, jamais mis en cache: le dossier est fait pour
    qu'on y glisse un fichier depuis le Finder entre deux videos, comme les
    fonds de la vue d'ensemble."""
    d = serie.get("badges_dir")
    if not d or not os.path.isdir(d):
        return []
    return sorted(os.path.join(d, f) for f in os.listdir(d)
                  if f.lower().endswith(BADGE_EXT) and not f.startswith("."))


def relais_du_slot(slot):
    """Combien de secondes un rail du HAUT tient avant de passer la main au
    suivant (`relais`, lu dans l'exemple). 0 = jusqu'au bout de son clip."""
    try:
        d = float((slot or {}).get("relais") or 0)
    except (TypeError, ValueError):
        return 0.0
    return round(d, 3) if d >= 0.3 else 0.0


def bas_slots(serie):
    """Toutes les categories « bas » d'un split, dans l'ordre. Une seule :
    le clip du bas de toujours. Plusieurs : elles s'ENCHAINENT dans la
    moitie basse (voir `bas_enchaine`)."""
    return [s for s in serie.get("slots", [])
            if not s.get("off") and not s.get("incrust") and s.get("split_role") == "bas"]


def bas_enchaine(tires, s, dst):
    """PLUSIEURS CLIPS EN BAS, L'UN APRES L'AUTRE (23/11). « Le clip du
    bas, c'est du foot, puis la demo de l'app » : chez nous c'etait UN
    fichier deja monte (NFL Win) ; un etudiant a deux fichiers, un extrait
    de match et un enregistrement d'ecran, et le moteur ne prenait que le
    premier. `tires` = [(categorie, clip)] : on fabrique UN clip du bas, les
    clips bout a bout, CHACUN EN ENTIER, et tout le reste du split le
    traite comme le clip du bas de toujours.

    Rend (categorie, chemin) : une categorie fabriquee pour ce tirage, qui
    porte les reperes du clip assemble —
      `coupes`  la jonction de deux clips (le haut change au meme instant),
                plus les coupes notees a l'interieur d'un clip ;
      `ancre`   celle du PREMIER clip (l'instant du jeu reussi) ;
      `etapes`  celles du DERNIER clip qui en a (l'ecran filme), decalees.
    Les clips n'ont pas la meme forme (un match en large, un ecran en
    haut) : chacun REMPLIT la boite du bas, ce que le split fait de toute
    facon ensuite. Le son : celui des categories qui le gardent, le silence
    pour les autres."""
    W = int(s["width"])
    hb = split_geom(s, 80)["h_bas"]
    cmd, fc, t, rep = ["ffmpeg", "-y", "-v", "error"], [], 0.0, {}
    jonctions, coupes, son = [], [], False
    n = 0
    for k, (sl, src) in enumerate(tires):
        d = round(probe(src)[0] or 0.0, 3)
        if d < 0.2:
            raise RenderError(f"Split screen : {Path(src).name} ne dure presque rien.")
        cmd += ["-i", str(src)]
        fc.append(f"[{n}:v]scale={W}:{hb}:force_original_aspect_ratio=increase,"
                  f"crop={W}:{hb},fps={s['fps']},setsar=1,format=yuv420p,"
                  f"trim=0:{d:.3f},setpts=PTS-STARTPTS[v{k}]")
        iv = n
        n += 1
        if sl.get("son") and probe(src)[1]:
            son = True
            fc.append(f"[{iv}:a]asetpts=PTS-STARTPTS,aresample={TARGET_AR},"
                      f"aformat=sample_fmts=fltp:channel_layouts=stereo,"
                      f"apad,atrim=0:{d:.4f}[a{k}]")
        else:
            cmd += ["-f", "lavfi", "-t", f"{d:.3f}", "-i", f"anullsrc=r={TARGET_AR}:cl=stereo"]
            fc.append(f"[{n}:a]atrim=0:{d:.4f}[a{k}]")
            n += 1
        if k == 0 and repere(sl, src, "ancre") is not None:
            rep["ancre"] = round(float(repere(sl, src, "ancre")), 3)
        ci = repere(sl, src, "coupes")
        for c in (ci if isinstance(ci, list) else [ci] if ci is not None else []):
            if 0.0 < float(c) < d:
                coupes.append(round(t + float(c), 3))
        et = repere(sl, src, "etapes")
        if isinstance(et, list) and et:
            rep["etapes"] = [round(t + float(x), 3) for x in et]
        t = round(t + d, 3)
        if k < len(tires) - 1:
            jonctions.append(t)
    rep["coupes"] = sorted(set(coupes + jonctions))
    fc.append("".join(f"[v{k}][a{k}]" for k in range(len(tires)))
              + f"concat=n={len(tires)}:v=1:a=1[v][a]")
    cmd += ["-filter_complex", ";".join(fc), "-map", "[v]", "-map", "[a]",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "14",
            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(dst)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(dst):
        raise RenderError("Clips du bas : " + " + ".join(Path(x[1]).name for x in tires)
                          + f" — {(r.stderr or '')[-400:]}")
    syn = dict(tires[0][0])
    syn["sync"] = {os.path.basename(str(dst)): rep}
    if son:
        syn["son"] = 1
    else:
        syn.pop("son", None)
    return syn, str(dst)


def bas_du_tirage(serie_dir, serie, s, bags, tmp_dir, hasard=None):
    """(categorie du bas, clip du bas) pour UNE video : le clip tire quand
    il n'y a qu'une categorie « bas », le clip assemble quand il y en a
    plusieurs. `hasard` : un tirage simple (apercu), sans les reserves."""
    slots = bas_slots(serie)
    tires = []
    for sl in slots:
        pool = slot_clips(serie_dir, sl)
        if not pool:
            raise RenderError(f"Aucun clip dans « {sl['name']} ».")
        tires.append((sl, hasard(pool) if hasard else draw_from_bag(bags, sl["id"], pool, 1)[0]))
    if len(tires) == 1:
        return tires[0][0], tires[0][1]
    return bas_enchaine(tires, s, str(Path(tmp_dir) / f"bas_{uuid.uuid4().hex}.mp4"))


def split_fenetres(hauts, src_bas, slot_bas, duree):
    """Ou chaque rail du haut commence et s'arrete, et ou l'on entre dans
    son clip. Rend [(slot, src, debut, fin, seek)] dans l'ordre.

    Deux reperes sur le clip du BAS commandent tout:
      `coupes`  les instants ou le bas change de sujet (la game qui passe
                a la demo). Le haut change au meme instant: c'est ce qui
                fait croire a un seul montage.
      `ancre`   l'instant du rendez-vous (le touchdown). Le PREMIER rail
                du haut est glisse pour que son `depart` tombe dessus.

    Et un sur le clip du HAUT:
      `depart`  l'instant, dans ce clip-la, qui doit tomber sur l'ancre
                (le debut de la reaction).

    Rend (rails, tete, ancre_t). `tete` est ce qu'il faut rogner AU DEBUT du clip
    du bas: quand le premier rail du haut n'a pas assez d'avance avant sa
    reaction pour remonter jusqu'a l'ancre, on avance le bas au lieu de
    laisser la moitie haute noire. Un trou noir d'une seconde en tete de
    hook se lit comme une panne, alors que les premieres secondes d'un
    clip de game ne sont que la mise en place -- et la fin du bas, elle,
    n'est jamais touchee: c'est elle que les etapes decrivent.

    Sans aucun repere on retombe exactement sur l'ancien comportement:
    un seul rail, colle a 0, de la meme longueur que le bas.
    """
    coupes = repere(slot_bas, src_bas, "coupes")
    if coupes is None:
        coupes = []
    elif not isinstance(coupes, list):
        coupes = [coupes]
    coupes = sorted(c for c in coupes if 0.0 < c < duree)
    if len(hauts) > len(coupes) + 1:
        # LE RELAIS PAR LA DUREE (23/11). Avant, plusieurs rails du haut
        # sans coupe notee a la main sur le clip du bas = generation
        # refusee, et l'IA ne gardait donc qu'UN rail du haut : une video
        # « reaction 4 s en haut, puis un autre clip en haut, le meme clip
        # en bas tout le long » — la forme la plus courante chez les
        # etudiants — sortait fausse. Les coupes qui manquent se deduisent
        # maintenant : chaque rail tient `relais` secondes (la duree lue
        # dans l'exemple), ou sinon la longueur de SON clip, puis passe la
        # main. Une coupe notee a la main l'emporte toujours.
        t = coupes[-1] if coupes else 0.0
        for k in range(len(coupes), len(hauts) - 1):
            sl, src = hauts[k]
            d = relais_du_slot(sl)
            if not d:
                ua, ub, _d = plage_utile(src, sl)
                dep = repere(sl, src, "depart")
                d = ub - (ua if dep is None else dep)
            t = round(t + max(0.3, d), 3)
            if t >= duree - 0.3:
                break               # le bas s'arrete avant : pas de relais
            coupes.append(t)
        # Les rails qui n'ont plus de place ne sont pas montes.
        hauts = hauts[:len(coupes) + 1]
    ancre = repere(slot_bas, src_bas, "ancre")

    out = []
    for k, (sl, src) in enumerate(hauts):
        bord = coupes[k - 1] if k >= 1 else 0.0
        # Le DERNIER rail va jusqu'au bout meme s'il reste des coupes (plus
        # de clips en bas que de rails en haut) : sinon la moitie haute
        # passait au noir a la jonction suivante.
        fin = coupes[k] if k < len(coupes) and k < len(hauts) - 1 else duree
        # Sans calage note a la main, le rail part du DEBUT DE SA PARTIE
        # UTILE (`par_clip`, choisie par le monteur) : pas des secondes ou
        # la personne installe sa camera.
        depart = repere(sl, src, "depart")
        if depart is None:
            depart = plage_utile(src, sl)[0]
        if k == 0 and ancre is not None:
            # On glisse le clip pour que sa reaction tombe sur l'ancre.
            # Debut negatif: on entre dans le clip en cours de route.
            # Debut positif: sa moitie d'ecran reste noire avant -- jamais
            # une image figee pour combler, c'est le bug deja paye.
            t0 = round(float(ancre) - depart, 3)
            seek = 0.0
            if t0 < 0.0:
                seek, t0 = round(-t0, 3), 0.0
        else:
            t0, seek = bord, depart
        out.append([sl, src, t0, round(fin, 3), seek])

    # Le premier rail commence apres 0: plutot que de laisser la moitie
    # haute noire jusque-la, on avance tout le monde, clip du bas compris.
    tete = round(out[0][2], 3) if out and out[0][2] > 0.0 else 0.0
    if tete:
        for r in out:
            r[2] = round(max(0.0, r[2] - tete), 3)
            r[3] = round(r[3] - tete, 3)
    # L'ancre ramenee sur la ligne de temps du montage: c'est l'instant du
    # score, donc celui ou la pastille apparait.
    ancre_t = None if ancre is None else round(float(ancre) - tete, 3)
    return [tuple(r) for r in out if r[3] - r[2] > 0.04], tete, ancre_t


def process_split(hauts, src_bas, slot_bas, etapes, dst, s,
                  texts, texts_ok, cache_dir=None, bags=None, badges=None):
    """La partie split d'une video: les clips du haut qui se relaient dans
    la moitie haute, UN clip entier en bas, et les etapes qui defilent
    dans la bande entre les deux. `hauts` = [(slot, chemin)] dans l'ordre.

    Les clips sont pris sans aucune retouche (voir `variation_neutre`):
    ils arrivent deja montes.

    C'est le clip du BAS qui donne la longueur, et il passe EN ENTIER: les
    etapes decrivent ce qui s'y passe a l'ecran, en couper la fin couperait
    le parcours au milieu. Chaque rail du haut est arrete a sa fenetre
    (voir `split_fenetres`). Quand plus rien ne couvre la moitie haute --
    un clip trop court, ou un premier rail glisse vers la droite -- elle
    passe au NOIR (`eof_action=pass`), jamais une image figee.

    `etapes` = [(slot, texte, duree)] dans l'ordre. Elles defilent a partir
    de la PREMIERE COUPE du clip du bas, pas du debut: avant la coupe le
    bas montre encore l'accroche (le touchdown), et une etape posee dessus
    decrirait un ecran qui n'est pas la. Pendant ce temps la bande tient le
    texte du premier rail du haut. La derniere etape TIENT jusqu'a la fin
    de l'image meme si sa duree est ecoulee: une bande vide en fin de video
    se lit comme un bug. Celles qui commencent apres la fin ne s'affichent
    pas.

    `badges`: les pastilles deposees pour la serie. Une seule est tiree, et
    elle apparait A L'ANCRE -- l'instant du score -- pour tenir jusqu'a la
    fin du premier rail. Elle annonce le gain au moment ou la reaction
    part; la poser plus tot vendrait la meche, plus tard elle commenterait
    une reaction deja finie. Elle s'en va avec la reaction: passe la coupe,
    le haut parle de l'app et plus du match.
    """
    brut = round(probe(src_bas)[0] or 0.0, 3)
    if brut < 0.2:
        raise RenderError(
            f"Split screen : {Path(src_bas).name} ne dure presque rien.")
    rails, tete, ancre_t = split_fenetres(hauts, src_bas, slot_bas, brut)
    duree = round(brut - tete, 3)
    if not rails:
        raise RenderError(
            f"Split screen : aucune catégorie du haut n'a de place sur "
            f"{Path(src_bas).name}.")

    def dessine(texte, slot):
        if not texte or not texts_ok:
            return None, 0
        r = captions.cached(
            texte, s["width"], s["height"], cache_dir or Path(dst).parent,
            size=int((slot or {}).get("caption_size")
                     or s.get("caption_size", 56)),
            style=s.get("caption_style", "contour"),
            font_ps=captions.FONT_CHOICES.get(s.get("caption_font", "")),
            outline=s.get("caption_outline"),
            lead=(slot or {}).get("caption_lead") or None,
            larg=((slot or {}).get("caption_larg")
                  or s.get("caption_larg") or None))
        return r if r else (None, 0)

    def tire_texte(slot):
        pool = slot_captions(slot, texts)
        if not pool or not texts_ok or bags is None:
            return None
        tire = draw_from_bag(bags, "texte|" + slot["id"], pool, 1)
        return tire[0] if tire else None

    # Les etapes commencent a la premiere coupe: avant, le bas est encore
    # sur l'accroche. C'est aussi la que le deuxieme rail du haut prend la
    # main -- le meme instant, sinon le texte annonce un ecran pas encore
    # affiche.
    t_etapes = rails[1][2] if len(rails) > 1 else 0.0

    # (png, hauteur, debut, fin) de chaque texte a poser dans la bande.
    poses = []
    if t_etapes > 0.0:
        # Pendant l'accroche, la bande tient le texte du premier rail.
        png, h = dessine(tire_texte(rails[0][0]), rails[0][0])
        if png:
            poses.append((png, h, 0.0, t_etapes))
    # LES ETAPES CALEES SUR L'ECRAN (23/11). Une duree fixe par etape ne
    # vaut que si tous les clips du bas sont montes pareil. Avec des
    # enregistrements d'ecran differents, chaque clip note OU chaque etape
    # commence (`etapes`, en secondes du clip — voir server.ia_calage) :
    # l'etape n part a SON instant, la premiere toujours a la coupe. Sans
    # repere, ou au-dela de la liste, les durees fixes de toujours.
    cales = repere(slot_bas, src_bas, "etapes")
    cales = [round(float(x) - tete, 3) for x in cales] if isinstance(cales, list) else []
    debuts, t = [], float(t_etapes)
    for n, (sl, texte, d) in enumerate(etapes):
        # Une etape cale a moins de 0,8 s de la precedente la ferait
        # clignoter : c'est un repere faux, on garde la duree fixe.
        if n and n < len(cales) and cales[n] > debuts[-1] + 0.8:
            t = cales[n]
        debuts.append(round(t, 3))
        t += d
    for n, (sl, texte, d) in enumerate(etapes):
        t = debuts[n]
        if t >= duree:
            break                       # l'image s'arrete avant cette etape
        png, h = dessine(texte, sl)
        fin = duree if n == len(etapes) - 1 else min(debuts[n + 1], duree)
        if png and fin - t > 0.04:
            poses.append((png, h, t, fin))
    if not etapes and t_etapes <= 0.0:
        # Aucune etape et aucune coupe: un seul texte, celui du premier
        # rail du haut, tenu d'un bout a l'autre.
        png, h = dessine(tire_texte(rails[0][0]), rails[0][0])
        if png:
            poses.append((png, h, 0.0, duree))

    # C'est le PLUS HAUT des textes qui decide de la bande. Une bande qui
    # change de taille d'une etape a l'autre ferait sauter la coupure entre
    # les deux clips a chaque changement de texte -- sur le reel de
    # reference elle ne bouge pas d'un pixel du debut a la fin.
    g = split_geom(s, max([h for _, h, _, _ in poses] or [0]))
    W, H = int(s["width"]), int(s["height"])

    # Chaque rail n'est decode que sur sa fenetre (`-ss` / `-t`): sur un
    # clip du haut de 30 s dont on ne garde que 13, c'est la moitie du
    # travail d'encodage en moins.
    #
    # Deux images de plus que la fenetre: coupe a `fin` pile, le rail n'a
    # plus d'image A l'instant de la coupe, et le suivant n'y a pas encore
    # la sienne (un `-ss` tombe rarement juste sur une image). L'image de
    # la coupe sortait NOIRE -- un flash sur chaque video de « NFL Win ».
    # Le `enable` ci-dessous borne toujours le rail, et le suivant passe
    # par-dessus des qu'il a une image.
    cmd = ["ffmpeg", "-y", "-v", "error"]
    for _, src, t0, fin, seek in rails:
        if seek > 0.0:
            cmd += ["-ss", f"{seek:.3f}"]
        cmd += ["-t", f"{fin - t0 + 2.0 / float(s['fps']):.3f}", "-i", str(src)]
    i_bas = len(rails)
    if tete:
        cmd += ["-ss", f"{tete:.3f}"]
    cmd += ["-i", str(src_bas)]
    for png, _, _, _ in poses:
        cmd += ["-i", png]
    # La pastille du gain, tiree sans remise comme un clip.
    badge = None
    if badges and ancre_t is not None and ancre_t < rails[0][3]:
        tire = (draw_from_bag(bags, "badge", list(badges), 1)
                if bags is not None else [random.choice(list(badges))])
        if tire:
            badge = (tire[0], max(0.0, ancre_t), rails[0][3])
            cmd += ["-i", badge[0]]

    # Fond noir explicite, a la duree exacte: les panneaux ne couvrent pas
    # tout l'ecran (c'est le principe) et `pad` ne sait pas empiler.
    fc = f"color=c=black:s={W}x{H}:r={s['fps']}:d={duree}[bg]"
    vout = "[bg]"
    for k, (_, _, t0, fin, _) in enumerate(rails):
        v = variation_neutre(s)
        # `setpts` glisse le rail a sa place sur la ligne de temps; le
        # `enable` l'y enferme pour que deux rails ne se marchent pas
        # dessus a la coupe.
        fc += (f";[{k}:v]{build_video_filter(v, s, (W, g['h_haut'], 'remplir'))}"
               f",setpts=PTS-STARTPTS+{t0:.3f}/TB[vh{k}]")
        fc += (f";{vout}[vh{k}]overlay=0:{g['y_haut']}"
               f":eof_action=pass:repeatlast=0"
               f":enable='between(t,{t0:.3f},{fin:.3f})'[h{k}]")
        vout = f"[h{k}]"
    fc += (f";[{i_bas}:v]"
           f"{build_video_filter(variation_neutre(s), s, (W, g['h_bas'], 'remplir'))}[vb]"
           f";{vout}[vb]overlay=0:{g['y_bas']}[b]")
    vout = "[b]"
    for n, (png, h, a, b) in enumerate(poses):
        # Chaque texte est CENTRE dans la bande, jamais cale en haut: deux
        # textes de hauteurs differentes se succederaient sinon en sautant.
        y = g["y_bande"] + (g["bande"] - h) // 2
        fc += (f";{vout}[{i_bas + 1 + n}:v]overlay=(W-w)/2:{y}"
               f":enable='between(t,{a:.3f},{b:.3f})'[e{n}]")
        vout = f"[e{n}]"
    if badge:
        # Posee en bas a DROITE de la moitie haute: dans les trois prises,
        # la tete et les mains occupent le centre et la gauche. `-2` garde
        # une hauteur paire (yuv420p l'exige) en respectant le rapport.
        m = int(W * BADGE_MARGE)
        bas_haut = g["y_haut"] + g["h_haut"]
        i_b = i_bas + 1 + len(poses)
        fc += (f";[{i_b}:v]scale={int(W * BADGE_LARG) // 2 * 2}:-2[bdg]"
               f";{vout}[bdg]overlay=W-w-{m}:{bas_haut}-h-{m}"
               f":enable='between(t,{badge[1]:.3f},{badge[2]:.3f})'[bd]")
        vout = "[bd]"
    fc += f";{vout}format=yuv420p,{COULEURS_TV}[vn]"

    cmd += ["-filter_complex", fc, "-map", "[vn]", "-an",
            "-t", str(duree),
            "-fps_mode", "cfr", "-r", str(s["fps"]),
            "-c:v", "libx264", "-preset", "veryfast",
            "-crf", str(INTERMEDIATE_CRF), "-pix_fmt", "yuv420p",
            *OPTS_COULEURS,
            "-movflags", "+negative_cts_offsets", dst]

    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        noms = " + ".join(Path(x[1]).name for x in rails)
        raise RenderError(f"{noms} + {Path(src_bas).name}: {r.stderr[-500:]}")

    # Le son: celui de la categorie qui coche « garder le son », le haut
    # d'abord. Seul un rail qui commence a 0 peut la donner: `assemble`
    # pose la voix au debut du morceau, celle d'un rail qui commence plus
    # loin tomberait trop tot -- une voix decalee d'une seconde est pire
    # que pas de voix. Un rail dont on saute la TETE (`seek`, le premier
    # rail recale sur l'ancre) la donne bien: on la coupe au meme `seek`.
    # Avant, il la perdait, et la reaction de « NFL Win » (un clip de 20 s,
    # entre a 7,5 s) sortait muette. La voix s'arrete avec son rail: le
    # rail suivant parle d'autre chose.
    # Pas de sous-titres mot a mot ici: la bande est deja la place du texte.
    out = variation_neutre(s)
    out["voix"] = None
    # PLUSIEURS RAILS QUI PARLENT (23/11) : « la reaction en haut, puis un
    # autre clip en haut ou la personne explique ». Le second rail commence
    # apres 0, donc la regle ci-dessus lui retirait sa voix — et c'est
    # justement lui qui parle. Quand un rail APRES le premier garde son
    # son, on fabrique UNE piste pour tout le morceau (`voix_rails`) :
    # chaque rail dans sa fenetre, le bas (ou le silence) ailleurs. Posee
    # au debut du morceau, elle est donc juste par construction.
    if any(k >= 1 and (r[0].get("son") or s.get("parle")) and probe(r[1])[1]
           for k, r in enumerate(rails)):
        wav = str(Path(dst).with_suffix(".rails.wav"))
        if voix_rails(rails, src_bas, slot_bas, tete, duree, wav, bool(s.get("parle"))):
            out["voix"] = (wav, None, None, 1.0)
            return out, duree
    for sl, src, t0, fin, seek in rails:
        if (sl.get("son") or s.get("parle")) and t0 <= 0.0 and probe(src)[1]:
            out["voix"] = (str(src), seek, round(fin - t0, 3), 1.0)
            # Le bas garde aussi son son: il PREND LE RELAIS a la fin du
            # rail. Sans ca, une fois la reaction finie, les 19 s de demo
            # de « NFL Win » sortaient muettes -- les clics de l'app
            # compris. Une seule piste pour le morceau (`assemble` n'en
            # prend qu'une), fabriquee ici en audio seul: les morceaux
            # d'image restent sans son, c'est la regle.
            if slot_bas.get("son") and probe(src_bas)[1] and fin < duree - 0.04:
                wav = str(Path(dst).with_suffix(".relais.wav"))
                if voix_relais(str(src), seek, fin - t0, str(src_bas), tete,
                               duree, wav):
                    out["voix"] = (wav, None, None, 1.0)
            break
    if not out["voix"] and slot_bas.get("son") and probe(src_bas)[1]:
        out["voix"] = (str(src_bas), tete or None, duree if tete else None, 1.0)
    return out, duree


def voix_rails(rails, src_bas, slot_bas, tete, duree, dst, parle=False):
    """Une piste pour tout le split quand plusieurs rails du haut parlent :
    chaque rail qui garde son son dans SA fenetre (a partir de son `seek`),
    et entre deux — ou sous un rail muet — le son du bas s'il garde le
    sien, sinon le silence. -> True si elle est ecrite."""
    bas_ok = bool(slot_bas.get("son")) and probe(src_bas)[1]

    def bas(a, b):
        return (str(src_bas) if bas_ok else None, tete + a, round(b - a, 3))
    segs, t = [], 0.0
    for sl, src, t0, fin, seek in rails:
        if t0 > t + 0.04:
            segs.append(bas(t, t0))
        if (sl.get("son") or parle) and probe(src)[1]:
            segs.append((str(src), seek, round(fin - t0, 3)))
        else:
            segs.append(bas(t0, fin))
        t = fin
    if t < duree - 0.04:
        segs.append(bas(t, duree))
    segs = [x for x in segs if x[2] > 0.02]
    if not any(x[0] for x in segs):
        return False
    cmd, fc = ["ffmpeg", "-y", "-v", "error"], []
    for k, (src, debut, d) in enumerate(segs):
        if src:
            cmd += ["-ss", f"{debut:.3f}", "-t", f"{d + 0.5:.3f}", "-i", src]
            retard = max(0.0, depart_audio(src) - debut)
        else:
            cmd += ["-f", "lavfi", "-t", f"{d + 0.5:.3f}",
                    "-i", f"anullsrc=r={TARGET_AR}:cl=stereo"]
            retard = 0.0
        cal = f"adelay={int(round(retard * 1000))}:all=1," if retard > 0.005 else ""
        fc.append(f"[{k}:a]asetpts=PTS-STARTPTS,{cal}aresample={TARGET_AR},"
                  f"aformat=sample_fmts=fltp:channel_layouts=stereo,"
                  f"apad,atrim=0:{d:.4f}[a{k}]")
    fc.append("".join(f"[a{k}]" for k in range(len(segs)))
              + f"concat=n={len(segs)}:v=0:a=1[o]")
    cmd += ["-filter_complex", ";".join(fc), "-map", "[o]", "-c:a", "pcm_s16le", dst]
    return subprocess.run(cmd, capture_output=True).returncode == 0


def voix_relais(src_h, seek, d_h, src_b, tete, duree, dst):
    """Une piste: le son du haut de `seek` pendant `d_h`, puis celui du
    bas, a l'endroit ou en est son image (`tete + d_h`), jusqu'a `duree`.
    -> True si elle est ecrite. Meme recalage que `assemble` pour l'audio
    d'un .mov d'iPhone qui demarre apres son image (`depart_audio`)."""
    d_b = round(duree - d_h, 3)
    def bout(k, src, debut, d):
        retard = max(0.0, depart_audio(src) - debut)
        cal = f"adelay={int(round(retard * 1000))}:all=1," if retard > 0.005 else ""
        return (f"[{k}:a]asetpts=PTS-STARTPTS,{cal}aresample={TARGET_AR},"
                f"aformat=sample_fmts=fltp:channel_layouts=stereo,"
                f"apad,atrim=0:{d:.4f}[a{k}]")
    cmd = ["ffmpeg", "-y", "-v", "error",
           "-ss", f"{seek:.3f}", "-t", f"{d_h + 0.5:.3f}", "-i", src_h,
           "-ss", f"{tete + d_h:.3f}", "-t", f"{d_b + 0.5:.3f}", "-i", src_b,
           "-filter_complex",
           bout(0, src_h, seek, d_h) + ";" + bout(1, src_b, tete + d_h, d_b)
           + ";[a0][a1]concat=n=2:v=0:a=1[o]",
           "-map", "[o]", "-c:a", "pcm_s16le", dst]
    return subprocess.run(cmd, capture_output=True).returncode == 0


def remux(src, dst):
    """Recopie un clip dans un .mp4 SANS le re-encoder.

    `-c copy` recopie les flux tels quels: aucune perte, et c'est quasi
    instantane. La mise en garde du README sur `-c copy` vise le demuxeur
    concat, qui produit des horodatages non monotones en enchainant
    plusieurs fichiers; sur un fichier unique il n'y a rien a enchainer.

    On passe quand meme par le .mp4 plutot que de copier le .mov tel quel:
    toute l'app liste ses sorties en *.mp4, et un .mov n'y apparaitrait
    nulle part."""
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(src),
                        "-c", "copy", "-movflags", "+faststart", str(dst)],
                       capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(dst):
        raise RenderError(
            f"Copie brute impossible pour {os.path.basename(str(src))} : "
            f"{(r.stderr or '').strip()[-300:]}")


_DEPART_AUDIO = {}


def depart_audio(src):
    """Instant ou la piste son commence, par rapport a l'image (secondes).

    Un .mov d'iPhone demarre souvent son audio APRES sa video. Mesure sur
    les clips parles de « blud collar »: 222 a 243 ms sur six clips sur
    sept.

    Tant que l'image et le son sont coupes par la MEME commande ffmpeg, il
    s'en occupe tout seul. Mais ici le son est reconstruit a part (les
    morceaux restent video seule, voir process_clip): extrait seul, il
    commence a son premier echantillon, et recolle a zero il AVANCE la voix
    de ce decalage. C'est exactement le defaut de synchro labiale qu'on
    entend — un quart de seconde, impossible a rater sur un visage qui
    parle."""
    try:
        st = os.stat(src)
        cle = f"{src}|{st.st_mtime}|{st.st_size}"
    except OSError:
        return 0.0
    if cle in _DEPART_AUDIO:
        return _DEPART_AUDIO[cle]
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "stream=codec_type,start_time", "-of", "json", str(src)],
                       capture_output=True, text=True)
    debuts = {}
    try:
        for f in json.loads(r.stdout).get("streams", []):
            debuts.setdefault(f.get("codec_type"), float(f.get("start_time") or 0.0))
    except (ValueError, TypeError):
        pass
    ecart = debuts.get("audio", 0.0) - debuts.get("video", 0.0)
    # Un ecart negatif (son AVANT image) ne se rattrape pas en retardant;
    # il est rarissime et ffmpeg l'a deja absorbe au decodage.
    _DEPART_AUDIO[cle] = max(0.0, ecart)
    return _DEPART_AUDIO[cle]


# ------------------------------------------------------------------
# MODE EDITEUR : les textes vivent sur leur propre rail
# ------------------------------------------------------------------
# Dans le mode normal un texte est incruste DANS son morceau: il dure
# exactement ce que dure son clip, ni plus ni moins, et ne peut ni
# commencer au milieu d'un clip ni deborder sur le suivant. L'editeur
# pose les textes sur la video ASSEMBLEE, a des instants absolus — le
# meme mecanisme que les etapes du split, qui tourne depuis les series
# NFL. Rien de neuf dans ffmpeg, un `overlay` avec `enable`.
#
# UN BLOC NE RETIENT PAS DES SECONDES. La longueur d'une video change a
# chaque tirage: mesure sur « lovable faced », 20,4 s au plus court et
# 30,1 s au plus long, 48 % d'ecart — trois categories prennent leur clip
# en entier et les autres tirent leur duree entre dur_min et dur_max. Un
# bloc pose a « 10,0 s » tomberait sur une categorie differente d'une
# video a l'autre. Il retient donc une CATEGORIE et un decalage, et ses
# secondes se recalculent a chaque video.


def editor_blocs(serie):
    """Les blocs de texte de l'editeur, ou None si le mode est eteint.

    None et liste vide ne veulent pas dire la meme chose: eteint, les
    categories gardent leurs propres legendes (mode live); allume mais
    sans bloc, la video sort sans texte, et c'est un choix."""
    ed = serie.get("editor") or {}
    if not ed.get("actif"):
        return None
    blocs = [b for b in (ed.get("blocs") or []) if (b.get("texte") or "").strip()]
    # EN SPLIT, L'ACCROCHE DU PREMIER RAIL EST DEJA DANS LA BANDE. Une serie
    # montee par l'IA recevait en plus un bloc de frise avec le MEME texte,
    # accroche au rail du haut : la video sortait avec le texte ecrit deux
    # fois, l'un sur l'autre (vu le 23/11). Un bloc pose sur un rail du
    # haut qui repete mot pour mot le texte de ce rail est ce doublon ; un
    # autre texte pose la a la main dans l'editeur est garde.
    if (serie.get("settings") or {}).get("split"):
        serre = lambda t: "".join(str(t or "").lower().split())
        dits = {sl.get("id"): {serre(x) for x in (sl.get("captions") or [])}
                for sl in serie.get("slots", []) if sl.get("split_role") == "haut"}
        blocs = [b for b in blocs
                 if serre(b.get("texte")) not in dits.get((b.get("debut") or {}).get("slot"), ())]
    return blocs


def editor_bornes(sequence, durees):
    """({id de categorie: (debut, fin)}, duree totale) dans l'assemblage.

    Une categorie peut fournir PLUSIEURS clips (min/max): ils se suivent
    dans la sequence (`pick_sequence` ne melange qu'a l'interieur d'une
    categorie), et la borne va du debut du premier a la fin du dernier.
    Garder seulement le premier ancrait le bloc sur un clip sur deux."""
    bornes, t = {}, 0.0
    for (slot, _src), d in zip(sequence, durees):
        a, b = bornes.get(slot["id"], (t, t))
        bornes[slot["id"]] = (min(a, t), max(b, t + d))
        t += d
    return bornes, t


def editor_fenetre(bloc, bornes, total):
    """(debut, fin) absolus d'un bloc, ou None s'il ne tombe nulle part.

    Une categorie eteinte ou videe de ses clips disparait de la sequence:
    le bloc qui s'y accrochait est alors ramene aux bornes de la video
    plutot que jete — un texte qui disparait sans rien dire se lit comme
    un bug, et l'editeur affiche l'avertissement avant la generation."""
    def point(ref, defaut):
        r = bloc.get(ref) or {}
        b = bornes.get(r.get("slot"))
        if not b:
            return defaut
        return b[0] + float(r.get("off") or 0.0)
    t0 = max(0.0, point("debut", 0.0))
    t1 = min(total, point("fin", total))
    return (round(t0, 3), round(t1, 3)) if t1 - t0 > 0.04 else None


def editor_rendu(blocs, bornes, total, s, dossier):
    """Les blocs prets pour `assemble`: [(png, debut, fin, y, x)].

    Chaque bloc est dessine par `captions.cached`, la MEME fonction que
    le mode live et que l'apercu — un apercu qui redessinerait le texte a
    sa facon mentirait le jour ou les deux divergeraient."""
    out = []
    for b in blocs or []:
        f = editor_fenetre(b, bornes, total)
        if not f:
            continue
        r = captions.cached(
            b["texte"], s["width"], s["height"], dossier,
            size=int(b.get("caption_size") or s.get("caption_size", 56)),
            style=b.get("style") or s.get("caption_style", "contour"),
            font_ps=captions.FONT_CHOICES.get(s.get("caption_font", "")),
            outline=s.get("caption_outline"),
            lead=b.get("caption_lead") or None,
            larg=b.get("caption_larg") or s.get("caption_larg") or None)
        if not r:
            continue
        png, cap_h = r
        ty = b.get("text_y")
        y = (int(max(0, min(float(ty) * s["height"], s["height"] - cap_h)))
             if ty is not None else caption_y(s["height"], cap_h, "haut", 0.0))
        # `text_x` decale le CENTRE du texte, en fraction de la largeur
        # (0 = centre). Le PNG fait toute la largeur avec le texte au
        # milieu: le decaler entier suffit, et overlay accepte un x
        # negatif — un texte pousse a gauche sort simplement du cadre,
        # comme dans CapCut.
        x = int(round(float(b.get("text_x") or 0.0) * s["width"]))
        out.append((png, f[0], f[1], y, x))
    return out


def editor_point(ref, bornes, defaut):
    """L'instant absolu d'une ancre {slot, off}, ou `defaut` si sa
    categorie n'est pas dans cette video."""
    r = ref or {}
    b = bornes.get(r.get("slot"))
    if not b:
        return defaut
    return b[0] + float(r.get("off") or 0.0)


VOIX_SOUS_DOSSIER = "voix"


def editor_sons(serie, serie_dir, bornes, total):
    """Les voix off de l'editeur: [(chemin, debut, volume)].

    Une voix off ne change PAS d'une video a l'autre — c'est un fichier,
    pas une categorie. Elle s'accroche pourtant a une categorie, comme un
    bloc de texte: c'est la seule facon qu'elle commence sur le meme plan
    quand la longueur des plans precedents varie d'un tirage a l'autre.
    Elle joue jusqu'a sa fin ou jusqu'a celle de la video.

    `entree`/`sortie`: le morceau du FICHIER qu'on garde, en secondes —
    rogner une voix off comme un clip, sans retoucher le fichier. Ils
    voyagent en 4e et 5e place du tuple (sortie None = jusqu'au bout)."""
    ed = serie.get("editor") or {}
    if not ed.get("actif"):
        return []
    out = []
    for a in ed.get("audios") or []:
        f = Path(serie_dir) / VOIX_SOUS_DOSSIER / str(a.get("fichier") or "")
        if not a.get("fichier") or not f.is_file():
            continue
        t0 = max(0.0, editor_point(a.get("debut"), bornes, 0.0))
        if t0 >= total - 0.05:
            continue
        e = max(0.0, float(a.get("entree") or 0.0))
        so = float(a.get("sortie") or 0.0) or None
        if so is not None and so <= e + 0.05:
            e, so = 0.0, None
        out.append((str(f), round(t0, 3), float(a.get("volume", 1.0) or 0.0), e, so))
    return out


def editor_mots(serie, s, pistes, sons):
    """Ce qui s'ENTEND dans cette video, mot par mot, au temps de sortie:
    [(mot, debut, fin, cle)].

    Deux sources, celles qu'on entend vraiment a l'export: la voix des
    clips dont la categorie garde le son (`voix`, construit pour
    `assemble`), et les voix off. Un clip muet ne parle pas, ses mots ne
    s'affichent donc pas — sinon on sous-titrerait un son coupe.

    Les captions se fabriquent ICI, a chaque video, et pas une fois dans
    l'editeur: les clips changent d'un tirage a l'autre, leurs paroles
    aussi. Seule la voix off est la meme partout.

    `cle` (source|instant dans la source) identifie un mot quelle que soit
    la video ou il tombe: c'est elle qui porte les corrections faites a la
    main dans l'editeur.

    `pistes` = [(debut dans la video, duree, voix ou None)]: les morceaux
    bout a bout a l'export, et les rails superposes d'un split dans
    l'apercu de l'editeur — d'ou une position par piste plutot qu'un
    cumul."""
    cc = (serie.get("editor") or {}).get("captions") or {}
    mots = []
    if cc.get("clips", True):
        for pos, d, vx in pistes:
            if vx:
                src, debut, garde, vitesse = vx[:4]
                t0 = debut or 0.0
                t1 = t0 + garde if garde else float("inf")
                # Meme calcul que les sous-titres de `process_clip`: les
                # mots sont dates sur la piste EXTRAITE, qui peut demarrer
                # apres l'image.
                dec = depart_audio(src)
                nom = Path(src).name
                coupes = vx[5] if len(vx) > 5 else None
                for w, a, b in transcription.mots(src):
                    if coupes:
                        ca = temps_coupe(a + dec - t0, coupes)
                        cb = temps_coupe(b + dec - t0, coupes)
                        if ca is None or cb is None:
                            continue
                        ta = pos + ca / (vitesse or 1.0)
                        tb = pos + cb / (vitesse or 1.0)
                    else:
                        if a + dec < t0 - 0.05 or b + dec > t1 + 0.05:
                            continue
                        ta = pos + (a + dec - t0) / (vitesse or 1.0)
                        tb = pos + (b + dec - t0) / (vitesse or 1.0)
                    if ta < pos + d:
                        mots.append((w, max(pos, ta), min(tb, pos + d), f"{nom}|{a:.2f}"))
    if cc.get("voix", True):
        for chemin, t0, _vol, *coupe in sons or []:
            nom = Path(chemin).name
            e = coupe[0] if coupe else 0.0
            so = coupe[1] if len(coupe) > 1 and coupe[1] else float("inf")
            for w, a, b in transcription.mots(chemin):
                # Un mot coupe par le rognage de la voix off ne s'entend
                # pas: il ne s'ecrit pas non plus.
                if a < e - 0.05 or b > so + 0.05:
                    continue
                mots.append((w, t0 + a - e, t0 + b - e, f"{nom}|{a:.2f}"))
    mots.sort(key=lambda m: m[1])
    return mots


def editor_captions_morceaux(serie, mots):
    """Les mots groupes en captions, corrections appliquees:
    [(texte, debut, fin, cle)]. Partage par l'export et l'apercu de
    l'editeur — deux decoupages differents montreraient deux videos."""
    cc = (serie.get("editor") or {}).get("captions") or {}
    n = max(1, min(int(cc.get("mots") or 1), 6))
    cles = {}
    for w, a, b, k in mots:
        cles.setdefault(round(a, 3), k)
    corr = cc.get("corr") or {}
    out = []
    for texte, a, b in transcription.morceaux([(w, a, b) for w, a, b, _k in mots],
                                              max_mots=n, max_car=16 if n == 1 else 28):
        k = cles.get(round(a, 3), "")
        t = corr.get(k, texte)
        if t.strip():
            out.append((t, a, b, k))
    return out


def editor_captions_rendu(serie, s, morceaux, total, dossier):
    """Les captions prets pour `assemble`, au meme format que les blocs."""
    cc = (serie.get("editor") or {}).get("captions") or {}
    size = int(cc.get("caption_size") or s.get("subtitle_size", 58))
    out = []
    for texte, a, b, _k in morceaux:
        if a >= total:
            continue
        r = captions.cached(
            texte, s["width"], s["height"], dossier, size=size,
            style=s.get("caption_style", "contour"),
            font_ps=captions.FONT_CHOICES.get(s.get("caption_font", "")),
            outline=s.get("caption_outline"),
            larg=cc.get("caption_larg") or s.get("caption_larg") or None)
        if not r:
            continue
        png, h = r
        # 75 % de la hauteur par defaut: la place des sous-titres des
        # series parlees (voir process_clip), sous le visage et au-dessus
        # de la legende de TikTok/Reels.
        ty = cc.get("text_y")
        y = (int(max(0, min(float(ty) * s["height"], s["height"] - h)))
             if ty is not None else int(s["height"] * 0.75 - h / 2))
        out.append((png, round(a, 3), round(min(b, total), 3), y, 0))
    return out


def editor_audio(serie, serie_dir, s, parts, voix, bornes, total, dossier):
    """(sons, captions) d'une video en mode editeur. Les captions ne
    sortent que si elles sont allumees ET que les textes sont dessinables."""
    sons = editor_sons(serie, serie_dir, bornes, total)
    cc = (serie.get("editor") or {}).get("captions") or {}
    if not cc.get("actif"):
        return sons, []
    pistes, pos = [], 0.0
    for p, vx in zip(parts, voix or [None] * len(parts)):
        d = probe(p)[0]
        pistes.append((pos, d, vx))
        pos += d
    mots = editor_mots(serie, s, pistes, sons)
    return sons, editor_captions_rendu(
        serie, s, editor_captions_morceaux(serie, mots), total, dossier)


def assemble(parts, dst, tmp_dir, music_files, s, voix=None, incrust=None,
             fondu=True, blocs=None, sons=None, musique_t0=0.0):
    """Concatene les morceaux, mixe une musique si dispo.

    La musique est appliquee sur la video assemblee (pas clip par clip),
    sinon elle repartirait de zero a chaque raccord.

    `voix`: pour chaque morceau, None ou (source, debut, duree, vitesse) si
    sa categorie garde la parole (voir process_clip).

    `incrust`: (clip, masque, cote[, fenetres]) — la personne detouree,
    en bas a gauche ou a droite (voir detourage.py). `fenetres`: liste de
    (debut, fin) en secondes du montage ou elle se montre — le clip demarre
    a la premiere et joue d'un trait, cache entre deux. Sans, toute la video.

    `musique_t0`: instant du montage ou la musique ENTRE (la categorie
    cochee « musique des ici »). Avant, silence musical; le fichier part de
    son debut a cet instant, pas au milieu.

    `fondu`: fondu d'entree de 80 ms sur la musique. Vrai par defaut, car
    un son tire au sort demarre en plein milieu d'une onde et claque.
    Faux pour la bande-son d'un reel qu'on refait: elle commence ou son
    auteur l'a voulu.
    """
    list_file = os.path.join(tmp_dir, f"concat_{uuid.uuid4().hex}.txt")
    with open(list_file, "w", encoding="utf-8") as f:
        for p in parts:
            f.write(f"file '{os.path.abspath(p)}'\n")

    # Duree exacte du montage: la somme des morceaux, qui sont video seule
    # et dont le conteneur ne peut donc plus mentir. Elle sert de `-t` sur
    # la sortie: rien ne peut deborder, ni le silence ni la musique.
    total = round(sum(probe(p)[0] for p in parts), 3)

    # -reinit_filter 0: voir COULEURS_TV. Si un morceau differe malgre tout
    # (format, plage de couleurs), ffmpeg ne reconstruit pas les filtres au
    # raccord — la reconstruction remettait `setpts=PTS-STARTPTS` a zero et
    # la cadence constante jetait ensuite tout ce qui semblait "en retard".
    cmd = ["ffmpeg", "-y", "-v", "error", "-reinit_filter", "0",
           "-f", "concat", "-safe", "0", "-i", list_file]
    # Le clip incruste n'est PAS mis en boucle: quand il se termine, la
    # personne disparait et le montage continue seul. L'inverse est vrai
    # aussi — un montage plus court coupe l'incrustation (`-t`).
    if incrust:
        cmd += ["-i", incrust[0], "-i", incrust[1]]
    track = None

    if s.get("mute"):
        music_files = []          # pas de musique sur une video muette

    # Numeros d'entree: 0 = le concat, puis l'incrustation (clip + masque),
    # puis la musique, puis les voix. L'ordre compte, `k` en depend.
    dec_incrust = 1 if incrust else 0

    # setpts/asetpts remettent les DEUX pistes a zero. Sans ca la piste
    # video demarrait quelques dizaines de millisecondes apres l'audio, ce
    # que le conteneur MP4 encode comme une "edition vide" -- et que les
    # lecteurs affichent en noir avant la premiere image.
    vchain = "[0:v]setpts=PTS-STARTPTS[vout]"
    if incrust:
        # alphamerge veut deux images de MEME taille: `scale2ref` met le
        # masque a la taille du clip (Vision le rend en 384x512 quelle que
        # soit la source). L'incrustation est ensuite reduite a la largeur
        # voulue et collee DANS le coin, sans marge: une personne detouree
        # a deja du vide autour d'elle, une marge en plus la faisait
        # flotter au milieu du bas de l'image.
        larg = max(0.1, min(float(s.get("incrust_largeur", 0.42)), 1.0))
        px = int(s["width"] * larg) // 2 * 2
        x = "W-w" if incrust[2] == "droite" else "0"
        fen = incrust[3] if len(incrust) > 3 else None
        dec, quand = "", ""
        if fen:
            # Le clip part a la premiere fenetre, pas a 0: sinon sa
            # reaction serait deja passee quand la tete apparait.
            dec = f"+{fen[0][0]}/TB"
            quand = ":enable='" + "+".join(
                f"between(t,{a},{b})" for a, b in fen) + "'"
        vchain = (f"[0:v]setpts=PTS-STARTPTS[bg];"
                  f"[1:v]setpts=PTS-STARTPTS{dec},scale={px}:-2,setsar=1[iv];"
                  f"[2:v]setpts=PTS-STARTPTS{dec},format=gray[im];"
                  f"[im][iv]scale2ref=w=iw:h=ih[mk][iv2];"
                  f"[iv2][mk]alphamerge[pers];"
                  # eof_action=pass: quand l'incrustation se termine, le
                  # fond continue seul au lieu de s'arreter avec elle.
                  f"[bg][pers]overlay={x}:H-h:"
                  f"format=auto:shortest=0:eof_action=pass{quand}[vout]")

    if music_files:
        # La musique EST la bande-son, elle n'est pas un fond.
        #
        # Les clips arrivent deja sans audio (`-an` dans process_clip), donc
        # il n'y a rien a mixer avec: la piste du fichier depose devient
        # telle quelle celle de la video. Avant, on la mixait quand meme
        # avec le silence via `amix`, qui divise par le nombre d'entrees
        # (normalize=1 par defaut): la musique repartait a moitie volume
        # PAR-DESSUS le reglage de volume, deja a 12-28 %. Resultat mesure:
        # -34,9 dB, une musique qu'on devine a peine.
        #
        # `apad` remplace le role de bouche-trou que tenait le silence: une
        # musique plus courte que le montage etait coupee net a sa fin,
        # maintenant elle est prolongee par du silence jusqu'a `-t`.
        track = random.choice(music_files)
        vol = round(random.uniform(s["music_volume_min"], s["music_volume_max"]), 3)
        # Lecture depuis le DEBUT du fichier, toujours: pas de `-ss`, et le
        # tirage au sort ne choisit QUE le morceau, jamais un point dedans.
        # On partait avant a un instant aleatoire, ce qui coupait l'accroche
        # d'un son tendance enregistre exactement pour elle.
        #
        # Le fondu d'entree est a 0,08 s et pas plus: assez pour tuer le
        # claquement d'un fichier qui demarre en plein milieu d'une onde,
        # trop court pour qu'on entende l'attaque s'adoucir. A 0,4 s, le
        # premier temps d'un son qui commence sur un coup etait mange.
        #
        # La fin n'a pas de fondu: `-t` coupe net quand la video s'arrete,
        # c'est ce qu'on veut — la musique s'arrete avec l'image.
        cmd += ["-i", track]
    else:
        track = None
    idx_musique = 1 + 2 * dec_incrust

    durees = [probe(p)[0] for p in parts]
    voix = list(voix or [None] * len(parts))
    fc = [vchain]

    # La parole: une piste reconstruite morceau par morceau, chaque bout
    # coupe a la duree EXACTE de son morceau d'image. Un clip sans voix
    # donne un silence de la meme duree. `atempo` suit la vitesse tiree
    # pour l'image sans changer la hauteur de la voix.
    #
    # Pas d'audio dans les morceaux eux-memes: c'etait l'origine des videos
    # figees (voir process_clip). Ici chaque bout est borne par `atrim`, il
    # ne peut pas deborder sur le suivant.
    parle = []                        # (debut, fin) de chaque passage parle
    if any(voix):
        pos, bouts, gains = 0.0, [], []
        for n, (d, vx) in enumerate(zip(durees, voix)):
            if vx:
                src, debut, garde, vitesse = vx[:4]
                gain = vx[4] if len(vx) > 4 else 0.0
                gains.append(gain)
                k = 1 + 2 * dec_incrust + (1 if track else 0) + len(parle)
                if debut is not None:
                    cmd += ["-ss", str(debut), "-t", str(garde)]
                cmd += ["-i", src]
                # Remettre la piste son a sa place (voir depart_audio). Le
                # silence est ajoute AVANT atempo: la vitesse doit le
                # comprimer comme le reste, sinon le rattrapage serait faux
                # des qu'un clip est accelere.
                retard = max(0.0, depart_audio(src) - (debut or 0.0))
                cal = f"adelay={int(round(retard * 1000))}:all=1," if retard > 0.005 else ""
                coupes = vx[5] if len(vx) > 5 else None
                if coupes:
                    # Silences coupes: la voix recollee aux MEMES instants
                    # que l'image du morceau (`process_clip`).
                    fc.append(f"[{k}:a]asetpts=PTS-STARTPTS,{cal}anull[vx{n}]")
                    fc.append(filtre_coupes(f"[vx{n}]", coupes, f"vc{n}", audio=True))
                    tete = f"[vc{n}]"
                else:
                    tete = f"[{k}:a]asetpts=PTS-STARTPTS,{cal}"
                fc.append(f"{tete}volume={gain}dB,{atempo(vitesse)},"
                          f"aresample={TARGET_AR},aformat=sample_fmts=fltp:channel_layouts=stereo,"
                          f"apad,atrim=0:{d:.4f}[p{n}]")
                parle.append((pos, pos + d))
            else:
                fc.append(f"anullsrc=r={TARGET_AR}:cl=stereo,atrim=0:{d:.4f}[p{n}]")
            bouts.append(f"[p{n}]")
            pos += d
        # Un clip remonte de plusieurs dB peut depasser 0 dB sur ses pics et
        # saturer (craquement). Le limiteur rabote les pics a -1 dB et ne
        # touche pas au reste. level=0: sinon alimiter renormalise tout le
        # signal de lui-meme. latency=1: compense son delai d'anticipation,
        # sans quoi la voix arriverait 5 ms apres les levres.
        lim = (",alimiter=limit=0.891:level=0:latency=1:attack=5:release=50"
               if any(g > 0 for g in gains) else "")
        fc.append(f"{''.join(bouts)}concat=n={len(bouts)}:v=0:a=1{lim}[voix]")

    if track:
        # Volume CONSTANT sur toute la video, celui du reglage (10 % par
        # defaut pour une serie parlee). Une version baissait la musique
        # seulement pendant la parole: refuse, on veut un niveau fixe et
        # previsible, ajuste a la main.
        # `fondu=False` quand la piste EST la bande-son d'origine d'un reel
        # qu'on refait a l'identique (voir template.py): son attaque est
        # voulue, pas un artefact de depart en plein milieu d'une onde.
        # Les 80 ms de fondu mangeaient le premier temps.
        f_in = "afade=t=in:d=0.08," if fondu else ""
        retard = ""
        if musique_t0 and musique_t0 > 0.01:
            # Entree en cours de video: un fondu de 0,3 s, sinon la musique
            # tombe d'un coup sur la coupe et se lit comme un raté.
            f_in = "afade=t=in:d=0.3,"
            retard = f"adelay={int(round(musique_t0 * 1000))}:all=1,"
        fc.append(f"[{idx_musique}:a]volume={vol},{f_in}aresample={TARGET_AR},"
                  f"aformat=sample_fmts=fltp:channel_layouts=stereo,"
                  f"{retard}apad,asetpts=PTS-STARTPTS[mus]")
        if parle:
            # normalize=0: amix diviserait sinon chaque piste par deux.
            fc.append("[voix][mus]amix=inputs=2:duration=first:normalize=0[aout]")
        else:
            fc[-1] = fc[-1].replace("[mus]", "[aout]")
    elif parle:
        fc.append("[voix]anull[aout]")
    else:
        # Aucune musique ni parole: une piste muette, fabriquee ICI et non
        # dans chaque morceau. Bornee par `-t`, elle ne peut plus faire
        # deborder la duree du conteneur (bug de l'image figee).
        fc.append(f"anullsrc=r={TARGET_AR}:cl=stereo[aout]")

    # LES VOIX OFF DE L'EDITEUR, mixees par-dessus tout le reste du son.
    # La piste deja construite ([aout], quelle que soit la branche qui l'a
    # faite) est renommee, puis melangee aux voix decalees a leur instant.
    # normalize=0: amix diviserait sinon chaque piste par le nombre
    # d'entrees, et la voix off sortirait a moitie volume.
    if sons:
        j = max(n for n, f in enumerate(fc) if f.endswith("[aout]"))
        fc[j] = fc[j][:-len("[aout]")] + "[abase]"
        entrees = ["[abase]"]
        for n, (chemin, t0, vol, *coupe) in enumerate(sons):
            k = cmd.count("-i")
            cmd += ["-i", chemin]
            # Le morceau garde du fichier (voix off rognee dans l'editeur).
            e = coupe[0] if coupe else 0.0
            so = coupe[1] if len(coupe) > 1 else None
            rog = (f"atrim=start={e:.3f}" + (f":end={so:.3f}" if so else "") + ","
                   if e > 0.001 or so else "")
            fc.append(f"[{k}:a]{rog}asetpts=PTS-STARTPTS,volume={vol},aresample={TARGET_AR},"
                      f"aformat=sample_fmts=fltp:channel_layouts=stereo,"
                      f"adelay={int(round(t0 * 1000))}:all=1,apad[vo{n}]")
            entrees.append(f"[vo{n}]")
        fc.append(f"{''.join(entrees)}amix=inputs={len(entrees)}"
                  f":duration=first:normalize=0[aout]")

    # LES BLOCS DE L'EDITEUR, poses par-dessus la video assemblee.
    #
    # Leurs entrees sont ajoutees EN DERNIER et leur numero est compte sur
    # `cmd` lui-meme (`cmd.count("-i")`) plutot que recalcule: l'ordre des
    # entrees — concat, incrustation, musique, voix — est deja une suite
    # d'arithmetiques (`dec_incrust`, `idx_musique`, `k`), en ajouter une
    # de plus qui doit rester d'accord avec les autres, c'est le genre de
    # chose qui casse au prochain ajout.
    if blocs:
        n_in = cmd.count("-i")
        fc[0] = fc[0].rsplit("[vout]", 1)[0] + "[vb0]"
        for i, (png, t0, t1, y, *x) in enumerate(blocs):
            cmd += ["-i", png]
            sortie = "[vout]" if i == len(blocs) - 1 else f"[vb{i+1}]"
            fc.append(f"[vb{i}][{n_in + i}:v]overlay={x[0] if x else 0}:{y}"
                      f":enable='between(t,{t0:.3f},{t1:.3f})'{sortie}")

    cmd += ["-filter_complex", ";".join(fc), "-map", "[vout]", "-map", "[aout]"]

    # Cadence constante sur la sortie aussi: l'encodage final ne la forcait
    # pas et laissait donc passer tel quel tout trou d'horodatage venu du
    # demuxeur. Avec `-t`, la duree est bornee des deux cotes.
    cmd += ["-fps_mode", "cfr", "-r", str(s["fps"]), "-t", str(total)]

    # Ne PAS recopier les flux ici (-c copy): le demuxeur concat produit
    # alors des horodatages non monotones et des images figees de plusieurs
    # secondes. On re-encode donc, mais les morceaux d'entree ont ete faits
    # en quasi-sans-perte (INTERMEDIATE_CRF), si bien que cet encodage-ci
    # est le seul qui degrade vraiment l'image.
    cmd += ["-c:v", "libx264", "-preset", s.get("preset", "medium"),
            "-crf", str(s.get("crf", 20)), "-pix_fmt", "yuv420p", *OPTS_COULEURS,
            "-c:a", "aac", "-b:a", "192k", "-ar", str(TARGET_AR), "-ac", "2",
            # Meme raison que pour les morceaux: pas d'edition vide en tete,
            # la video demarre a l'instant 0.
            "-muxdelay", "0", "-muxpreload", "0",
            "-movflags", "+faststart+negative_cts_offsets", dst]

    r = subprocess.run(cmd, capture_output=True, text=True)
    try:
        os.remove(list_file)
    except OSError:
        pass
    if r.returncode != 0:
        raise RenderError(f"assemblage: {r.stderr[-500:]}")

    # Controle de la PISTE VIDEO, pas du conteneur: la duree du conteneur
    # suit la piste la plus longue — l'audio, borne par `-t` — et restait
    # donc exacte meme quand 2,75 s d'images avaient disparu. C'est ce qui
    # a laisse passer le bug du 2e clip manquant.
    vid = _duree_piste_video(dst)
    if vid is not None and vid < total - 2.5 / float(s["fps"]):
        try:
            os.remove(dst)
        except OSError:
            pass
        raise RenderError(f"assemblage: piste video de {vid:.2f} s au lieu de {total:.2f} s")
    return track


def _duree_piste_video(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0",
                        "-show_entries", "stream=duration", "-of", "csv=p=0", path],
                       capture_output=True, text=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        return None


def draw_from_bag(bags, key, pool, n):
    """Tire n clips SANS REMISE dans un sac melange.

    Un tirage aleatoire independant repete naturellement: sur 7 clips, le
    meme sort 3 fois d'affilee environ une fois sur 50. Ici on melange le
    lot entier et on le vide avant d'en refaire un: chaque clip passe donc
    une fois avant qu'aucun ne repasse. C'est la variete maximale possible.
    """
    pool = list(pool)
    if not pool or n <= 0:
        return []

    bag = [b for b in bags.get(key, []) if b in pool]   # oublie les fichiers disparus
    last = bags.get(key + "|last")
    out = []

    while len(out) < min(n, len(pool)):
        if not bag:
            bag = list(pool)
            random.shuffle(bag)
            # Evite que le nouveau sac redonne aussitot le dernier clip joue.
            if len(bag) > 1 and bag[0] == last:
                bag.append(bag.pop(0))
        pick = bag.pop(0)
        if pick in out:                 # deja pris pour cette meme video
            continue
        out.append(pick)
        last = pick

    bags[key] = bag
    bags[key + "|last"] = last
    return out


def split_slots(serie):
    """Les quatre roles d'une serie en split screen, dans l'ordre du
    montage: (plans d'intro, categorie du haut, categorie du bas, etapes).

    Chaque categorie porte `split_role`:
      ""       un plan normal, plein cadre, AVANT le split (l'accroche)
      "haut"   un clip de la moitie haute. Il peut y en avoir PLUSIEURS:
               ils se relaient aux coupes notees sur le clip du bas.
      "bas"    le clip qui tient toute la moitie basse
      "etape"  pas de clip du tout: un texte et une duree dans la bande

    Mesure sur le reel de reference: 2,8 s de plan plein cadre, puis
    17,6 s de split traversees par six etapes. Les deux phases ne sont pas
    un choix d'interface, c'est la forme de la video.
    """
    actifs = [s for s in serie.get("slots", [])
              if not s.get("off") and not s.get("incrust")]
    role = lambda s: s.get("split_role") or ""
    plans = [s for s in actifs if role(s) == ""]
    etapes = [s for s in actifs if role(s) == "etape"]
    hauts = [s for s in actifs if role(s) == "haut"]
    bas = next((s for s in actifs if role(s) == "bas"), None)
    return plans, hauts, bas, etapes


def pick_sequence(serie_dir, serie, bags=None):
    """Choisit les clips d'une video: pour chaque slot, min..max clips."""
    if bags is None:
        bags = {}
    slots = list(serie["slots"])
    if serie["settings"].get("shuffle_slots"):
        random.shuffle(slots)

    sequence = []
    for slot in slots:
        if (slot.get("off") or slot.get("incrust")
                or slot.get("split_role")):
            # `off`: categorie mise de cote. `incrust`: elle n'est pas un
            # plan du montage, elle se pose PAR-DESSUS (voir generate).
            # `split_role`: moitie haute, moitie basse ou etape d'un split
            # screen — aucune des trois n'est un plan de la sequence.
            continue
        pool = slot_clips(serie_dir, slot)
        if not pool:
            continue
        n = random.randint(int(slot.get("min", 1)), int(slot.get("max", 1)))
        picked = draw_from_bag(bags, slot["id"], pool, n)
        random.shuffle(picked)
        sequence += [(slot, p) for p in picked]
    return sequence


def combination_count(serie_dir, serie, pools=None):
    """Nombre de structures distinctes possibles (indicatif).

    `pools` evite de relister les dossiers quand l'appelant vient de le
    faire — la file d'attente calcule les deux pour chaque serie, et deux
    parcours de disque par categorie au lieu d'un se sentent des qu'il y a
    une quinzaine de series."""
    # Split screen: une video = une PAIRE de clips, pas une sequence. Le
    # nombre de montages distincts est donc le produit des deux reserves.
    if serie.get("settings", {}).get("split"):
        plans, hauts, bas, _ = split_slots(serie)
        if not hauts or not bas:
            return 0
        pb = (pools.get(bas["id"]) if pools is not None
              else slot_clips(serie_dir, bas))
        total = len(pb or [])
        # Chaque rail du haut est un tirage independant: deux rails de
        # trois clips sur trois clips du bas font vingt-sept montages.
        for sl in hauts:
            ph = (pools.get(sl["id"]) if pools is not None
                  else slot_clips(serie_dir, sl))
            total *= len(ph or [])
        # Les plans d'intro sont une vraie sequence, eux: ils multiplient.
        for sl in plans:
            pool = (pools.get(sl["id"]) if pools is not None
                    else slot_clips(serie_dir, sl))
            if pool:
                total *= len(pool)
        return total

    total = 1
    for slot in serie["slots"]:
        if (slot.get("off") or slot.get("incrust")
                or slot.get("split_role")):
            continue
        pool = pools.get(slot["id"]) if pools is not None else slot_clips(serie_dir, slot)
        if not pool:
            continue
        lo, hi = int(slot.get("min", 1)), int(slot.get("max", 1))
        ways = 0
        for n in range(lo, hi + 1):
            if n <= len(pool):
                c = 1
                for k in range(n):
                    c = c * (len(pool) - k) // (k + 1)
                ways += c
        total *= max(1, ways)
    return total


def dernier_ajout(paths):
    """Quand un clip est-il arrive dans la serie pour la derniere fois ?
    Horodatage Unix, 0 s'il n'y a aucun clip.

    On retient le plus recent entre la date de creation du fichier ICI
    (`st_birthtime` sur macOS: la date de la copie) et sa date de
    modification. Un clip glisse depuis le Finder ou Drive garde souvent la
    date de TOURNAGE dans `mtime`: s'y fier ferait passer une serie montee
    ce matin pour abandonnee depuis des mois."""
    dernier = 0.0
    for p in paths:
        try:
            st = os.stat(p)
        except OSError:
            continue                    # clip disparu: il ne date rien
        dernier = max(dernier, getattr(st, "st_birthtime", 0) or 0, st.st_mtime)
    return round(dernier, 3) if dernier else 0


# ------------------------------------------------------------------
# Structure de serie sur disque
# ------------------------------------------------------------------

def slot_dir(serie_dir, slot_id):
    return Path(serie_dir) / "slots" / slot_id


def list_media(folder, exts):
    """Liste les fichiers d'un dossier. Ignore les fichiers caches et les
    .part (uploads en cours) et les fichiers fantomes de synchro cloud."""
    try:
        d = Path(folder)
        if not d.is_dir():
            return []
        return sorted(str(f) for f in d.iterdir()
                      if f.is_file()
                      and not f.name.startswith(".")
                      and f.suffix.lower() in exts)
    except OSError:
        return []


def slot_clips_all(serie_dir, slot):
    """TOUS les clips d'une categorie, masques compris.

    Si le slot a un `path`, les clips sont lus EN DIRECT depuis ce dossier
    (Google Drive synchronise, dossier local, disque externe...). Rien n'y
    est jamais ecrit ni supprime. Sinon on utilise le stockage interne de
    la serie, alimente par glisser-deposer.

    C'est la liste d'AFFICHAGE: un clip masque doit rester visible dans la
    grille, previsualisable et demasquable. Pour le tirage, c'est
    `slot_clips` qu'il faut.
    """
    if isinstance(slot, str):                    # compat: ancien appel par id
        slot = {"id": slot}
    if slot.get("path"):
        return list_media(slot["path"], VIDEO_EXTS)
    return list_media(slot_dir(serie_dir, slot["id"]), VIDEO_EXTS)


def slot_hidden(slot):
    """Noms des clips ecartes du tirage dans cette categorie."""
    if isinstance(slot, str):
        return set()
    return set(slot.get("hidden") or [])


def slot_clips(serie_dir, slot):
    """Clips REELLEMENT tirables d'une categorie: tout sauf les masques.

    Masquer ecarte un clip du tirage sans toucher au fichier. C'est la
    seule facon d'exclure un clip d'un dossier lie, ou l'app ne supprime et
    ne deplace jamais rien — et c'est reversible, contrairement au X.

    `hidden` ne contient que des NOMS de fichiers, jamais des chemins: un
    dossier lie peut etre deplace ou renomme sans que les masques sautent,
    et le nom suffit puisqu'une categorie pointe un seul dossier.
    """
    clips = slot_clips_all(serie_dir, slot)
    hidden = slot_hidden(slot)
    if not hidden:
        return clips
    return [p for p in clips if Path(p).name not in hidden]


def load_bags(serie_dir):
    """Etat des sacs de tirage. Persiste sur disque pour que relancer
    l'app ne redonne pas systematiquement le meme premier clip."""
    f = Path(serie_dir) / "bags.json"
    try:
        with open(f, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_bags(serie_dir, bags):
    f = Path(serie_dir) / "bags.json"
    try:
        tmp = f.with_suffix(".json.tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(bags, fh)
        os.replace(str(tmp), str(f))
    except OSError:
        pass


def output_dir(serie_dir, serie=None):
    """Dossier de sortie de la serie.

    Par defaut output/<Serie>/ a la racine du projet, pour que toutes
    les videos generees soient regroupees au meme endroit. Les anciennes
    series qui n'ont pas de `output_dir` gardent leur dossier interne."""
    if serie and serie.get("output_dir"):
        return Path(serie["output_dir"])
    return Path(serie_dir) / "output"


def music_files(serie_dir, serie=None):
    """Musiques utilisables par cette serie: DEUX sources qui s'additionnent.

    Le pot commun de la campagne d'abord, puis ce qui appartient en propre
    a la serie. On additionne au lieu de choisir: une campagne peut avoir
    ses musiques generiques et une serie en ajouter une qui ne vaut que
    pour cet angle-la. Le tirage se fait ensuite sur l'ensemble.

    `music_camp_dir` est INJECTE par `load_serie` (server.py) et n'est
    jamais ecrit dans serie.json: le dossier porte le NOM de la campagne,
    qui peut changer, donc on le resout a chaque lecture plutot que d'en
    garder une copie qui perimerait au premier renommage. Le moteur ne lit
    pas la base — c'est le serveur qui fait la traduction.

    `music_dir` (dossier lie) remplace toujours le dossier interne de la
    serie — c'est son role — mais ne fait pas disparaitre la campagne."""
    out = []
    camp = (serie or {}).get("music_camp_dir")
    if camp:
        out += list_media(camp, AUDIO_EXTS)
    if serie and serie.get("music_dir"):
        out += list_media(serie["music_dir"], AUDIO_EXTS)
    else:
        out += list_media(Path(serie_dir) / "music", AUDIO_EXTS)
    return out


def scan_subfolders(root):
    """Sous-dossiers d'un dossier, avec le nombre de videos dans chacun.
    Sert a proposer automatiquement une categorie par sous-dossier."""
    out = []
    try:
        for d in sorted(Path(root).iterdir()):
            if d.is_dir() and not d.name.startswith("."):
                out.append({"name": d.name, "path": str(d),
                            "clips": len(list_media(d, VIDEO_EXTS)),
                            "audio": len(list_media(d, AUDIO_EXTS))})
    except OSError:
        pass
    return out


def generate(serie_dir, serie, count, progress=None, stop_flag=None):
    """Genere `count` videos. `progress(done, total, message)` est appele
    apres chaque etape. Retourne la liste des fichiers produits."""
    serie_dir = Path(serie_dir)
    out_dir = output_dir(serie_dir, serie)
    # Le temporaire reste dans la serie: on ne veut pas de dossier
    # technique au milieu des videos finies.
    #
    # UN DOSSIER PAR EXECUTION. Avant, toutes les generations d'une meme
    # serie partageaient `_tmp`, et chacune faisait un rmtree du dossier
    # entier en terminant: lancer une generation pendant qu'une autre
    # tournait (par exemple depuis la file d'attente et depuis la serie)
    # effacait les morceaux intermediaires de l'autre en plein montage.
    # Le concat lisait alors des fichiers tronques, dont la duree annoncee
    # ne correspondait plus aux images -> image figee de plusieurs secondes
    # au milieu de la video.
    tmp_dir = serie_dir / "_tmp" / f"run-{uuid.uuid4().hex[:10]}"
    out_dir.mkdir(parents=True, exist_ok=True)
    tmp_dir.mkdir(parents=True, exist_ok=True)

    s = dict(DEFAULT_SETTINGS)
    s.update(serie.get("settings", {}))
    texts = [c for c in serie.get("captions", []) if c.strip()]
    texts_ok = captions.available()
    music = music_files(serie_dir, serie)
    # Les PNG de texte sont mis en cache: le meme texte n'est dessine
    # qu'une fois pour tout le lot.
    cache_dir = serie_dir / "thumbs" / "_captions"
    bags = load_bags(serie_dir)

    # Serie parlee: tous les clips remontes au niveau du plus fort (voir
    # SONIE_CIBLE_MAX). La cible se calcule sur TOUTE la serie, pas sur la
    # video: sinon le meme clip sortirait plus ou moins fort selon ce qu'il
    # a tire a cote de lui.
    #
    # SEULS les clips ou l'on parle sont concernes. Beaucoup de clips n'ont
    # que du bruit de fond (voiture, piece, ecran filme): les aligner sur
    # une voix remontait ce bruit jusqu'a +20 dB. Un clip sans parole garde
    # donc son son d'origine, et il n'entre pas dans le calcul de la cible.
    # « Parole » = whisper y trouve des mots; la transcription est de toute
    # facon necessaire pour les sous-titres et reste en cache.
    niveaux, cible = {}, None
    if s.get("parle") and not s.get("raw"):
        # Une categorie sans sous-titres n'a pas de voix: sa musique ne
        # compte pas comme parole et n'est pas remontee a la cible.
        tous = [p for sl in serie.get("slots", [])
                if not sl.get("off") and not sl.get("sans_st")
                for p in slot_clips(serie_dir, sl)]
        parlants = []
        for n, p in enumerate(tous, 1):
            # L'ecoute d'une grosse serie prend des minutes: le bouton Stop
            # doit agir ici aussi, pas seulement entre deux videos.
            if stop_flag and stop_flag():
                shutil.rmtree(str(tmp_dir), ignore_errors=True)
                return []
            if progress and not transcription.en_cache(p):
                progress(0, count, f"Écoute des clips {n}/{len(tous)}")
            if transcription.mots(p):
                parlants.append(p)
        niveaux = sonie_many(parlants)
        cible = sonie_cible(niveaux.values())

    made = []
    try:
        for i in range(1, count + 1):
            if stop_flag and stop_flag():
                break

            # SPLIT SCREEN. La video a deux phases: les plans pleins
            # cadre (l'accroche), puis le split — un clip entier en haut,
            # un clip entier en bas, et les etapes qui defilent entre eux.
            if s.get("split") and not s.get("raw"):
                plans, slots_h, slot_b, etapes = split_slots(serie)
                if not slots_h or not slot_b:
                    manque = "du haut" if not slots_h else "du bas"
                    raise RenderError(
                        f"Split screen : aucune catégorie n'est marquée "
                        f"« moitié {manque} ».")
                pools_h = []
                for sl in slots_h:
                    pool = slot_clips(serie_dir, sl)
                    if not pool:
                        raise RenderError(f"Aucun clip dans « {sl['name']} ».")
                    pools_h.append(pool)
                pool_b = slot_clips(serie_dir, slot_b)
                if not pool_b:
                    raise RenderError(f"Aucun clip dans « {slot_b['name']} ».")

                parts, voix = [], []
                # Editeur allume: les plans d'accroche laissent leur texte
                # aux blocs, comme en plein cadre. La BANDE, elle, garde
                # ses etapes et son accroche — c'est la forme du split, et
                # l'editeur les montre sur leur propre piste.
                blocs_ed = editor_blocs(serie)
                txt_ok_plan = texts_ok and blocs_ed is None
                seq_plans = []           # (categorie, morceau) de la phase 1
                # Phase 1: les plans d'accroche, montes normalement. C'est
                # la seule partie de la video ou les variations jouent.
                for j, sl in enumerate(plans):
                    pool = slot_clips(serie_dir, sl)
                    if not pool:
                        continue
                    for src_p in draw_from_bag(bags, sl["id"], pool,
                                               random.randint(int(sl.get("min", 1)),
                                                              int(sl.get("max", 1)))):
                        if progress:
                            progress(i - 1, count,
                                     f"Vidéo {i}/{count} — {sl['name']}")
                        dp = str(tmp_dir / f"p_{uuid.uuid4().hex}.mp4")
                        # Phase 1 d'un split : le plan suivant n'est pas
                        # encore tire, la sortie se lit sur la categorie.
                        tr = transitions_pour(
                            sl, not seq_plans or seq_plans[-1][0]["id"] != sl["id"],
                            plans[j + 1] if j + 1 < len(plans) else None, parts, tmp_dir)
                        var, _ = process_clip(src_p, dp, s, texts, txt_ok_plan,
                                              sl, cache_dir, bags,
                                              serie.get("images_regles"), trans=tr)
                        parts.append(dp)
                        seq_plans.append((sl, src_p))
                        vx = var.get("voix")
                        if vx:
                            vx = vx + (sonie_gain(niveaux.get(str(src_p)), cible) + var.get("voix_db", 0.0),
                                       var.get("voix_coupes"))
                        voix.append(vx)

                # Phase 2: le split.
                if progress:
                    progress(i - 1, count, f"Vidéo {i}/{count} — split screen")
                # Un tirage par rail du haut: chacun a sa propre reserve,
                # et c'est ce qui fait la variete d'une serie split.
                tires_h = [(sl, draw_from_bag(bags, sl["id"], pool, 1)[0])
                           for sl, pool in zip(slots_h, pools_h)]
                # Le clip du bas : tire, ou ASSEMBLE s'il y a plusieurs
                # categories « bas » (le foot, puis la demo).
                slot_b, src_b = bas_du_tirage(serie_dir, serie, s, bags, tmp_dir)
                tire_b = [src_b]
                ets = etapes_tirees(etapes, s, texts, texts_ok, bags)
                dsp = str(tmp_dir / f"p_{uuid.uuid4().hex}.mp4")
                var, _ = process_split(tires_h, tire_b[0], slot_b,
                                       ets, dsp, s, texts, texts_ok,
                                       cache_dir, bags, badges_dispo(serie))
                parts.append(dsp)
                vx = var.get("voix")
                if vx:
                    # Le gain se mesure sur la source RETENUE, qui n'est pas
                    # forcement le haut: un rail glisse n'a pas sa voix.
                    vx = vx + (sonie_gain(niveaux.get(str(vx[0])), cible),)
                voix.append(vx)

                if progress:
                    progress(i - 1, count, f"Vidéo {i}/{count} — assemblage")
                stamp = time.strftime("%Y%m%d-%H%M%S")
                name = f"{stamp}-{uuid.uuid4().hex[:4]}.mp4"
                brouillon = str(tmp_dir / f"final_{uuid.uuid4().hex[:8]}.mp4")
                # Les blocs de l'editeur s'accrochent aux plans d'accroche
                # ET aux rails du haut: ensemble ils couvrent la video de
                # bout en bout, sans trou. Les rails sont recalcules avec
                # `split_fenetres` sur les memes entrees que process_split —
                # la fonction est deterministe, elle rend les memes fenetres.
                rendus, sons = None, None
                if blocs_ed is not None:
                    durees = [probe(pp)[0] for pp in parts]
                    bornes, t_split = editor_bornes(seq_plans, durees[:-1])
                    rails_ed, _tete, _a = split_fenetres(
                        tires_h, tire_b[0], slot_b, probe(tire_b[0])[0])
                    for (sl_r, _src, deb, fin, _seek) in rails_ed:
                        bornes.setdefault(sl_r["id"], (t_split + deb, t_split + fin))
                    sons, caps = editor_audio(serie, serie_dir, s, parts, voix, bornes,
                                              sum(durees), cache_dir or tmp_dir)
                    if texts_ok:
                        rendus = editor_rendu(blocs_ed, bornes, sum(durees), s,
                                              cache_dir or tmp_dir) + caps
                assemble(parts, brouillon, str(tmp_dir), music, s, voix,
                         blocs=rendus, sons=sons)
                os.replace(brouillon, str(out_dir / name))
                make_thumbnail(str(out_dir / name),
                               str(serie_dir / "thumbs" / (name + ".jpg")))
                for pp in parts:
                    try:
                        os.remove(pp)
                    except OSError:
                        pass
                made.append(name)
                save_bags(serie_dir, bags)
                if progress:
                    progress(i, count, f"Vidéo {i}/{count} terminée")
                continue

            sequence = pick_sequence(serie_dir, serie, bags)
            if not sequence:
                raise RenderError("Aucun clip disponible. Ajoute des clips dans tes catégories.")

            # Sortie brute: pas de montage du tout. On recopie le clip tire
            # au sort. Le tirage reste sans remise, donc on fait le tour de
            # la reserve avant qu'un clip repasse.
            if s.get("raw"):
                if len(sequence) > 1:
                    raise RenderError(
                        "La sortie brute ne marche qu'avec UNE seule catégorie "
                        f"(celle-ci en a {len(sequence)}). Décoche « Sortie brute » "
                        "dans les réglages, ou ne garde qu'une catégorie.")
                src = sequence[0][1]
                if progress:
                    progress(i - 1, count, f"Vidéo {i}/{count} — copie de "
                                           f"{os.path.basename(str(src))}")
                stamp = time.strftime("%Y%m%d-%H%M%S")
                name = f"{stamp}-{uuid.uuid4().hex[:4]}.mp4"
                brouillon = str(tmp_dir / f"raw_{uuid.uuid4().hex[:8]}.mp4")
                remux(src, brouillon)
                os.replace(brouillon, str(out_dir / name))
                make_thumbnail(str(out_dir / name),
                               str(serie_dir / "thumbs" / (name + ".jpg")))
                made.append(name)
                save_bags(serie_dir, bags)
                if progress:
                    progress(i, count, f"Vidéo {i}/{count} copiée")
                continue

            # Incrustation: un clip tire dans la categorie source (`incrust`,
            # « tête à incruster »), detoure par macOS (voir detourage.py),
            # pose sur les categories cochees « incrustation ». Le cote change d'une video a l'autre, une fois sur deux
            # a gauche, une fois sur deux a droite.
            incrust = None
            for slot in serie.get("slots", []):
                if not slot.get("incrust") or slot.get("off"):
                    continue
                pool = slot_clips(serie_dir, slot)
                if not pool:
                    continue
                tire = draw_from_bag(bags, "incrust|" + slot["id"], pool, 1)
                if not tire:
                    continue
                if progress:
                    progress(i - 1, count, f"Vidéo {i}/{count} — détourage")
                mq = detourage.masque(tire[0])
                if mq:
                    cote = ("droite" if s.get("incrust_droite")
                            else random.choice(("gauche", "droite")))
                    incrust = (tire[0], mq, cote)
                break
            # La tete n'est posee QUE sur les categories cochees
            # « incrustation » (`incrust_sur`). Avant, elle couvrait toute la
            # video: sur Buzzy (12/11) elle s'ajoutait par-dessus l'accroche,
            # ou on est deja plein cadre — deux fois la meme personne.
            # Aucune categorie cochee = pas d'incrustation du tout.
            if incrust and not any(sl.get("incrust_sur") for sl, _ in sequence):
                incrust = None

            # MODE EDITEUR: les textes ne sont plus incrustes dans les
            # morceaux, ils sont poses sur l'assemblage. On coupe donc les
            # legendes de categorie (`texts_ok=False`) pour ne pas ecrire
            # deux fois par-dessus la meme image. Eteint (`None`), rien de
            # tout ca ne s'execute et le mode live est identique.
            blocs_ed = editor_blocs(serie)
            txt_ok_clip = texts_ok and blocs_ed is None

            parts, voix = [], []
            for j, (slot, src) in enumerate(sequence):
                if progress:
                    progress(i - 1, count,
                             f"Vidéo {i}/{count} — {slot['name']} ({j+1}/{len(sequence)})")
                dst = str(tmp_dir / f"p_{uuid.uuid4().hex}.mp4")
                apres = sequence[j + 1][0] if j + 1 < len(sequence) else None
                tr = transitions_pour(
                    slot, j == 0 or sequence[j - 1][0]["id"] != slot["id"],
                    apres if apres and apres["id"] != slot["id"] else None, parts, tmp_dir)
                var, _ = process_clip(src, dst, s, texts, txt_ok_clip, slot, cache_dir,
                                      bags, serie.get("images_regles"), trans=tr)
                parts.append(dst)
                vx = var.get("voix")
                if vx:
                    vx = vx + (sonie_gain(niveaux.get(str(src)), cible) + var.get("voix_db", 0.0),
                               var.get("voix_coupes"))
                voix.append(vx)

            if progress:
                progress(i - 1, count, f"Vidéo {i}/{count} — assemblage")

            stamp = time.strftime("%Y%m%d-%H%M%S")
            name = f"{stamp}-{uuid.uuid4().hex[:4]}.mp4"
            final = str(out_dir / name)

            # On assemble dans le dossier temporaire, PUIS on deplace.
            #
            # Ecrire directement a la destination exposait un fichier a
            # moitie ecrit: `sync_all_outputs()` (appele par /api/state, que
            # l'interface interroge en boucle) en faisait un lien physique
            # dans « toutes les videos », et il apparaissait dans la liste.
            # Avec `+faststart`, ffmpeg ecrit le fichier puis remonte l'index
            # en tete dans une seconde passe: pendant cette passe le fichier
            # a un index COMPLET mais des donnees PARTIELLES. Un lecteur
            # l'ouvre, joue ce qui existe, et fige sur la derniere image
            # jusqu'a la fin annoncee. C'est l'origine des videos « gelees a
            # la 3e seconde ».
            #
            # os.replace est atomique: le fichier apparait d'un coup, entier.
            # Les deux dossiers sont sous la racine du projet, donc sur le
            # meme systeme de fichiers.
            brouillon = str(tmp_dir / f"final_{uuid.uuid4().hex[:8]}.mp4")
            # Les bornes se calculent sur les morceaux REELS, pas sur les
            # durees reglees: une categorie qui prend son clip en entier
            # ne connait sa duree qu'une fois le morceau fabrique.
            rendus, sons = None, None
            if blocs_ed is not None:
                if progress:
                    progress(i - 1, count, f"Vidéo {i}/{count} — son et captions")
                bornes, total_ed = editor_bornes(sequence, [probe(p)[0] for p in parts])
                sons, caps = editor_audio(serie, serie_dir, s, parts, voix, bornes,
                                          total_ed, cache_dir or tmp_dir)
                if texts_ok:
                    rendus = editor_rendu(blocs_ed, bornes, total_ed, s,
                                          cache_dir or tmp_dir) + caps
            if incrust:
                # Fenetres des categories cochees, sur les morceaux REELS
                # (meme raison que les bornes de l'editeur). Deux voisines
                # cochees ne font qu'une fenetre: la tete ne clignote pas
                # au raccord.
                fen, t0 = [], 0.0
                for (sl, _), p in zip(sequence, parts):
                    d = probe(p)[0]
                    if sl.get("incrust_sur"):
                        if fen and abs(fen[-1][1] - t0) < 0.01:
                            fen[-1][1] = t0 + d
                        else:
                            fen.append([t0, t0 + d])
                    t0 += d
                incrust = incrust + ([(round(a, 3), round(b, 3)) for a, b in fen],)
            # « Musique des ici »: la premiere categorie cochee de la
            # sequence, mesuree sur les morceaux REELS (meme raison que les
            # fenetres de l'incrustation).
            m_t0, t0 = 0.0, 0.0
            for (sl, _), p in zip(sequence, parts):
                if sl.get("musique_ici"):
                    m_t0 = t0
                    break
                t0 += probe(p)[0]
            assemble(parts, brouillon, str(tmp_dir), music, s, voix, incrust,
                     blocs=rendus, sons=sons, musique_t0=m_t0)
            os.replace(brouillon, final)

            make_thumbnail(final, str(serie_dir / "thumbs" / (name + ".jpg")))

            for p in parts:
                try:
                    os.remove(p)
                except OSError:
                    pass

            made.append(name)
            save_bags(serie_dir, bags)
            if progress:
                progress(i, count, f"Vidéo {i}/{count} terminée")
    finally:
        save_bags(serie_dir, bags)
        # On ne supprime QUE le dossier de cette execution.
        shutil.rmtree(str(tmp_dir), ignore_errors=True)
        try:
            # Le parent `_tmp` ne part que s'il est vide, donc jamais tant
            # qu'une autre generation y travaille.
            (serie_dir / "_tmp").rmdir()
        except OSError:
            pass

    return made
