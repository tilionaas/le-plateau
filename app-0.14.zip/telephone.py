"""LE PLATEAU SUR LE TELEPHONE (23/11).

On filme avec son telephone : c'est de la que partent les clips et la
prise du jour, et c'est la qu'on veut recuperer la video montee pour la
poster. Le telephone ouvre donc une PETITE page servie par l'ordinateur,
sur le meme wifi.

Ce module ne connait ni les series ni le serveur : il tient QUI a le droit
d'entrer. Les routes sont dans `server.HandlerTel`.

Trois choix, a ne pas defaire :

- ETEINT PAR DEFAUT. Ouvrir un port sur le reseau de la maison est une
  decision de la personne, pas de l'app.
- UN CODE, TAPE UNE FOIS PAR TELEPHONE. Six chiffres ; le telephone recoit
  en echange un jeton long, garde dans un cookie. On ne range ici que
  l'EMPREINTE du jeton : lire `telephone.json` ne donne pas l'entree.
  Cinq essais rates ferment la porte dix minutes — un million de codes a
  cinq essais par dix minutes, ca fait 0,07 % de chances par jour.
- LE TELEPHONE NE PARLE JAMAIS AU SERVEUR PRINCIPAL. Celui-la reste sur
  127.0.0.1 (voir `Handler.porte`) et connait les mots de passe des
  comptes ; le telephone a son propre port et une liste fermee de routes.

La connexion n'est PAS chiffree (http sur le wifi) : quelqu'un qui ecoute
le meme wifi peut voir passer une video. C'est pour ca que rien de ce que
le telephone peut lire ne contient un mot de passe ou une cle.
"""
import hashlib
import hmac
import ipaddress
import json
import os
import secrets
import socket
import subprocess
import threading
import time

from chemins import DONNEES

FICHIER = DONNEES / "telephone.json"
VERROU = threading.Lock()
ESSAIS_MAX = 5
BLOCAGE_S = 600
TELEPHONES_MAX = 10          # au-dela, le plus ancien sort
COOKIE = "plateau_tel"

_etat = None                 # {"actif": bool, "code": str, "jetons": {empreinte: {...}}}
_rates = []                  # instants des essais rates (memoire seule)


def _charger():
    global _etat
    if _etat is None:
        try:
            d = json.loads(FICHIER.read_text())
        except (OSError, ValueError):
            d = {}
        _etat = {"actif": bool(d.get("actif")), "code": str(d.get("code") or ""),
                 "jetons": d.get("jetons") if isinstance(d.get("jetons"), dict) else {}}
    return _etat


def _ecrire():
    tmp = FICHIER.with_suffix(".part")
    tmp.write_text(json.dumps(_etat, indent=1, ensure_ascii=False))
    os.chmod(str(tmp), 0o600)          # le code d'entree est dedans
    os.replace(str(tmp), str(FICHIER))


def _code_neuf():
    return f"{secrets.randbelow(1000000):06d}"


def _empreinte(jeton):
    return hashlib.sha256(str(jeton).encode("utf-8")).hexdigest()


def etat():
    with VERROU:
        e = _charger()
        return {"actif": e["actif"], "code": e["code"], "telephones": len(e["jetons"])}


def regler(actif=None, debrancher=False):
    """Allume, eteint, ou met tous les telephones dehors (nouveau code)."""
    with VERROU:
        e = _charger()
        # Un reglage vient de l'ORDINATEUR : il leve aussi le blocage des
        # essais rates — sinon cinq mauvais codes tapes par un autre
        # fermeraient la porte dix minutes a la personne elle-meme.
        _rates.clear()
        if debrancher:
            e["jetons"] = {}
            e["code"] = _code_neuf()
        if actif is not None:
            e["actif"] = bool(actif)
        if e["actif"] and not e["code"]:
            e["code"] = _code_neuf()
        _ecrire()
    return etat()


def entrer(code, nom=""):
    """-> (jeton, "") si le code est bon, ("", raison) sinon."""
    with VERROU:
        e = _charger()
        t = time.time()
        _rates[:] = [x for x in _rates if t - x < BLOCAGE_S]
        if len(_rates) >= ESSAIS_MAX:
            return "", f"Trop d'essais — réessaie dans {int((BLOCAGE_S - (t - _rates[0])) // 60) + 1} min"
        saisi = "".join(ch for ch in str(code or "") if ch.isdigit())
        if not e["actif"] or not e["code"] or not hmac.compare_digest(saisi, e["code"]):
            _rates.append(t)
            return "", "Code refusé"
        jeton = secrets.token_urlsafe(32)
        e["jetons"][_empreinte(jeton)] = {"nom": str(nom or "")[:60], "le": int(t)}
        while len(e["jetons"]) > TELEPHONES_MAX:
            del e["jetons"][min(e["jetons"], key=lambda k: e["jetons"][k].get("le", 0))]
        _ecrire()
        return jeton, ""


def connu(jeton):
    if not jeton:
        return False
    with VERROU:
        e = _charger()
        return bool(e["actif"]) and _empreinte(jeton) in e["jetons"]


def sortir(jeton):
    with VERROU:
        e = _charger()
        if e["jetons"].pop(_empreinte(jeton), None) is not None:
            _ecrire()


def du_reseau_local(ip):
    """Le telephone est-il sur le meme reseau ? Une adresse publique n'a
    rien a faire ici : le port ne doit servir que la maison."""
    try:
        a = ipaddress.ip_address(str(ip).split("%")[0])
    except ValueError:
        return False
    if getattr(a, "ipv4_mapped", None):
        a = a.ipv4_mapped
    return a.is_private or a.is_loopback or a.is_link_local


def adresse_ip():
    """L'adresse de l'ordinateur sur le wifi. Une socket UDP « connectee »
    n'envoie RIEN : elle fait seulement choisir au systeme la carte reseau
    qui sortirait, et on lit son adresse."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()
    return ip if du_reseau_local(ip) and not ip.startswith("127.") else ""


def nom_local():
    """« Mon-Mac.local » : le nom que le Mac annonce sur le reseau. Il ne
    change pas quand la box redonne une autre adresse — l'icone posee sur
    l'ecran d'accueil du telephone continue de marcher."""
    try:
        if os.uname().sysname != "Darwin":
            return ""
        n = subprocess.run(["scutil", "--get", "LocalHostName"], capture_output=True,
                           text=True, timeout=3).stdout.strip()
    except (OSError, AttributeError, subprocess.SubprocessError):
        return ""
    return (n + ".local").lower() if n and all(c.isalnum() or c == "-" for c in n) else ""


# ------------------------------------------------------------------
# LE QR, DESSINE ICI (23/11)
# ------------------------------------------------------------------
# D'abord dessine par CoreImage — donc Mac seulement, et sur Windows
# l'adresse se tapait a la main (« pourquoi pas de QR pour les Windows »).
# Un QR n'a rien de mysterieux et le plateau n'a pas de dependance : il
# est dessine ici, pareil partout. Ce qui est verifie sur le Mac (relu par
# le lecteur de QR de macOS) est donc exactement ce que Windows affiche.
#
# Juste ce qu'il faut pour une adresse : mode octets, correction « L »,
# versions 1 a 5 (jusqu'a 106 caracteres) — a ces tailles les donnees
# tiennent en UN seul bloc, ce qui evite tout l'entrelacement des grands QR.
_QR_BLOCS = {1: (19, 7), 2: (34, 10), 3: (55, 15), 4: (80, 20), 5: (108, 26)}   # (donnees, correction)
_QR_EXP, _QR_LOG = [0] * 512, [0] * 256
_x = 1
for _i in range(255):
    _QR_EXP[_i], _QR_LOG[_x] = _x, _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _QR_EXP[_i] = _QR_EXP[_i - 255]


def _qr_correction(donnees, n):
    """Les `n` octets de correction (Reed-Solomon) d'un bloc."""
    gen = [1]
    for i in range(n):
        suiv = [0] * (len(gen) + 1)
        for j, g in enumerate(gen):
            suiv[j] ^= g
            suiv[j + 1] ^= _QR_EXP[_QR_LOG[g] + i] if g else 0
        gen = suiv
    reste = [0] * n
    for d in donnees:
        f = d ^ reste[0]
        reste = reste[1:] + [0]
        if f:
            for j in range(n):
                if gen[j + 1]:
                    reste[j] ^= _QR_EXP[_QR_LOG[gen[j + 1]] + _QR_LOG[f]]
    return reste


def _qr_penalite(m, t):
    """La note d'un masque (plus bas = plus lisible) : les quatre regles de
    la norme. Tout masque se decode ; celui-la se decode le mieux."""
    p = 0
    lignes = m + [[m[y][x] for y in range(t)] for x in range(t)]
    for l in lignes:
        suite = 1
        for i in range(1, t):
            if l[i] == l[i - 1]:
                suite += 1
            else:
                if suite >= 5:
                    p += suite - 2
                suite = 1
        if suite >= 5:
            p += suite - 2
        ch = "".join("1" if v else "0" for v in l)
        p += 40 * (ch.count("10111010000") + ch.count("00001011101"))
    for y in range(t - 1):
        for x in range(t - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                p += 3
    noirs = sum(sum(1 for v in l if v) for l in m)
    p += 10 * (abs(noirs * 20 - t * t * 10) // (t * t))
    return p


def qr_matrice(texte):
    """Le QR de `texte` : une grille de True (noir) / False, ou None si le
    texte est trop long pour les tailles qu'on sait dessiner."""
    octets = str(texte).encode("utf-8")
    v = next((k for k in sorted(_QR_BLOCS) if len(octets) <= _QR_BLOCS[k][0] - 2), None)
    if v is None:
        return None
    nd, nc = _QR_BLOCS[v]
    # Les donnees : le mode (octets), la longueur, le texte, la fin, puis
    # le remplissage convenu jusqu'a la capacite.
    bits = [0, 1, 0, 0] + [(len(octets) >> i) & 1 for i in range(7, -1, -1)]
    for o in octets:
        bits += [(o >> i) & 1 for i in range(7, -1, -1)]
    bits += [0] * min(4, nd * 8 - len(bits))
    bits += [0] * (-len(bits) % 8)
    mots = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    for i in range(nd - len(mots)):
        mots.append(0xEC if i % 2 == 0 else 0x11)
    mots += _qr_correction(mots, nc)
    flux = [(o >> i) & 1 for o in mots for i in range(7, -1, -1)]

    t = 17 + 4 * v
    m = [[False] * t for _ in range(t)]
    fixe = [[False] * t for _ in range(t)]          # ce que les donnees ne touchent pas

    def pose(x, y, noir):
        if 0 <= x < t and 0 <= y < t:
            m[y][x], fixe[y][x] = noir, True

    # Les trois reperes de coin, avec leur marge blanche.
    for ox, oy in ((0, 0), (t - 7, 0), (0, t - 7)):
        for dy in range(-1, 8):
            for dx in range(-1, 8):
                dans = 0 <= dx <= 6 and 0 <= dy <= 6
                noir = dans and (dx in (0, 6) or dy in (0, 6) or (2 <= dx <= 4 and 2 <= dy <= 4))
                pose(ox + dx, oy + dy, noir)
    # Le petit repere d'alignement (a partir de la version 2).
    if v >= 2:
        c = t - 7
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                pose(c + dx, c + dy, max(abs(dx), abs(dy)) != 1)
    # Les deux lignes en pointilles.
    for i in range(8, t - 8):
        pose(i, 6, i % 2 == 0)
        pose(6, i, i % 2 == 0)
    # Le module toujours noir, et la place du format (remplie plus bas).
    pose(8, 4 * v + 9, True)
    for i in range(9):
        if not fixe[8][i]:
            pose(i, 8, False)
        if not fixe[i][8]:
            pose(8, i, False)
    for i in range(8):
        pose(t - 1 - i, 8, False)
        pose(8, t - 1 - i, False)

    # Les donnees, en zigzag depuis le coin en bas a droite, par colonnes
    # de deux, en sautant la colonne des pointilles.
    k, x, monte = 0, t - 1, True
    cases = []
    while x > 0:
        if x == 6:
            x -= 1
        for y in (range(t - 1, -1, -1) if monte else range(t)):
            for xx in (x, x - 1):
                if not fixe[y][xx]:
                    m[y][xx] = bool(flux[k]) if k < len(flux) else False
                    cases.append((xx, y))
                    k += 1
        x -= 2
        monte = not monte

    masques = (lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0,
               lambda x, y: x % 3 == 0, lambda x, y: (x + y) % 3 == 0,
               lambda x, y: (y // 2 + x // 3) % 2 == 0,
               lambda x, y: (x * y) % 2 + (x * y) % 3 == 0,
               lambda x, y: ((x * y) % 2 + (x * y) % 3) % 2 == 0,
               lambda x, y: ((x + y) % 2 + (x * y) % 3) % 2 == 0)
    mieux = None
    for n, f in enumerate(masques):
        g = [l[:] for l in m]
        for xx, y in cases:
            if f(xx, y):
                g[y][xx] = not g[y][xx]
        # Le format : niveau de correction « L » (01) et numero du masque,
        # proteges par leur propre code, ecrits deux fois.
        d = (0b01 << 3) | n
        r = d << 10
        for i in range(14, 9, -1):
            if r >> i & 1:
                r ^= 0x537 << (i - 10)
        fmt = ((d << 10) | r) ^ 0x5412
        b = [(fmt >> i) & 1 == 1 for i in range(15)]         # b[0] = bit de poids faible
        for i in range(6):
            g[i][8] = b[i]
        g[7][8], g[8][8], g[8][7] = b[6], b[7], b[8]
        for i in range(9, 15):
            g[8][14 - i] = b[i]
        for i in range(8):
            g[8][t - 1 - i] = b[i]
        for i in range(8, 15):
            g[t - 15 + i][8] = b[i]
        note = _qr_penalite(g, t)
        if mieux is None or note < mieux[0]:
            mieux = (note, g)
    return mieux[1]


def qr_png(texte, module=8, marge=4):
    """Le QR de `texte` en PNG (noir sur blanc, avec sa marge), ou None."""
    import struct                                       # noqa: PLC0415
    import zlib                                         # noqa: PLC0415
    g = qr_matrice(texte)
    if not g:
        return None
    t = len(g)
    cote = (t + 2 * marge) * module
    blanc = b"\xff" * cote
    lignes = bytearray()
    for _ in range(marge * module):
        lignes += b"\x00" + blanc
    for l in g:
        ligne = b"\x00" + b"\xff" * (marge * module) \
            + b"".join((b"\x00" if noir else b"\xff") * module for noir in l) \
            + b"\xff" * (marge * module)
        lignes += ligne * module
    for _ in range(marge * module):
        lignes += b"\x00" + blanc

    def bloc(typ, d):
        return struct.pack(">I", len(d)) + typ + d + struct.pack(">I", zlib.crc32(typ + d) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + bloc(b"IHDR", struct.pack(">IIBBBBB", cote, cote, 8, 0, 0, 0, 0))
            + bloc(b"IDAT", zlib.compress(bytes(lignes), 9)) + bloc(b"IEND", b""))
