#!/usr/bin/env python3
"""
Sous-titres automatiques des clips parles.
------------------------------------------
La transcription est faite par whisper.cpp (`whisper-cli`, Homebrew:
`brew install whisper-cpp`), un programme externe comme ffmpeg — pas une
bibliotheque Python, la regle du zero dependance tient.

Un clip est transcrit UNE fois, en entier, puis mis en cache sur disque
(cle chemin|mtime|taille, comme le cache ffprobe). Un meme clip revient
dans des dizaines de variantes avec des decoupes differentes: on pioche
dans la transcription complete les mots qui tombent dans la fenetre.

Mesure (M2, modele large-v3): 8,9 s pour 7 s de voix, chargement du
modele compris. Payable une fois par clip, pas une fois par video.
"""

import audioop
import glob
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import threading
import wave
from pathlib import Path

from chemins import CODE, DONNEES as ROOT
CACHE_DIR = ROOT / ".transcriptions"
# Version du RECALAGE, pas de la transcription. Le cache garde les deux
# listes: `brut`, ce que whisper a dit, et `mots`, le resultat du recalage.
# Les deux, parce que le recalage est DESTRUCTIF — il coupe des fins et
# avance des debuts. Sans le brut, changer une regle de recalage ne pouvait
# que l'appliquer par-dessus le travail de la version precedente, et une
# passe trop agressive devenait irrattrapable sans tout retranscrire.
# Changer ce numero refait le recalage depuis `brut`, sans relancer whisper.
CACHE_V = 6

# Un modele depose dans `modeles/` passe devant ceux trouves ailleurs.
# Du plus precis au plus leger: on prend le premier present.
_MODELES = ("large-v3-turbo", "large-v3", "large-v2", "medium", "small", "base", "tiny")
_DOSSIERS = (ROOT / "modeles", CODE / "modeles",
             Path.home() / ".cache" / "whisper",
             Path.home() / ".cache" / "hyperframes" / "whisper" / "models",
             Path("/opt/homebrew/share/whisper-cpp"),
             Path("/usr/local/share/whisper-cpp"))

# Deux generations en parallele sur le meme clip ne le transcrivent qu'une
# fois: la seconde attend la premiere et lit le cache.
_verrou = threading.Lock()


def binaire():
    return shutil.which("whisper-cli")


def modele():
    trouves = []
    for d in _DOSSIERS:
        trouves += glob.glob(str(d / "ggml-*.bin"))
    for nom in _MODELES:
        for f in trouves:
            base = Path(f).stem[len("ggml-"):]
            # "large-v3" ne doit pas attraper "large-v3-turbo", ni une
            # variante anglais seul (".en") qui ne comprend pas le francais.
            if base == nom or base.startswith(nom + "-q"):
                return f
    return None


def disponible():
    return bool(binaire() and modele())


# LE MODELE TELECHARGEABLE, pour l'app installee : il ne voyage pas dans
# l'app (celui de la copie de travail, large-v3, pese 3 Go). On prend
# large-v3-turbo quantifie (q5_0) : ~570 Mo, et `modele()` le reconnait
# deja (« large-v3-turbo-q… »). Il va dans les DONNEES (`modeles/`), pas
# dans le code : une mise a jour ne doit pas le faire retelecharger.
MODELE_NOM = "ggml-large-v3-turbo-q5_0.bin"
MODELE_URL = ("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"
              + MODELE_NOM)


def telecharger_modele(progres=None):
    """-> chemin du modele. Ecrit dans un `.part` puis renomme : un
    telechargement coupe ne laisse jamais un faux modele que `modele()`
    prendrait pour un vrai."""
    import urllib.request
    adresse = os.environ.get("PLATEAU_MODELE_URL") or MODELE_URL
    nom = Path(adresse.split("?")[0]).name or MODELE_NOM
    d = ROOT / "modeles"
    d.mkdir(parents=True, exist_ok=True)
    dest, part = d / nom, d / (nom + ".part")
    req = urllib.request.Request(adresse, headers={"User-Agent": "Le-plateau"})
    with urllib.request.urlopen(req, timeout=60) as r, open(part, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        lu = 0
        while True:
            bloc = r.read(1 << 20)
            if not bloc:
                break
            f.write(bloc)
            lu += len(bloc)
            if progres and total:
                progres(lu / total)
    if total and lu != total:
        part.unlink()
        raise IOError("Téléchargement interrompu — réessaie")
    os.replace(part, dest)
    return str(dest)


def _cle(path):
    st = os.stat(path)
    return hashlib.sha1(f"{path}|{st.st_mtime}|{st.st_size}".encode()).hexdigest()[:20]


def mots(path):
    """Mots prononces dans le clip: [(texte, debut_s, fin_s), ...].

    Liste vide si le clip n'a pas de voix, si whisper manque, ou si la
    transcription echoue: un clip sans sous-titres vaut mieux qu'une
    generation plantee."""
    try:
        cache = CACHE_DIR / (_cle(path) + ".json")
    except OSError:
        return []
    with _verrou:
        if cache.exists():
            try:
                d = json.loads(cache.read_text("utf-8"))
            except (ValueError, OSError):
                d = None
            # `isinstance` et non la verite du contenu: un clip muet donne
            # une liste VIDE, et la tester comme un booleen le faisait
            # retranscrire a chaque generation.
            if isinstance(d, dict) and d.get("v") == CACHE_V \
                    and isinstance(d.get("mots"), list):
                return corriger(tuple(m) for m in d["mots"])
            brut = d.get("brut") if isinstance(d, dict) else None
            if isinstance(brut, list):
                # Regle de recalage changee: on refait le travail DEPUIS LE
                # BRUT, sans relancer whisper — ca ne coute qu'un decodage
                # audio (2,7 s pour 59 clips, mesure).
                res = caler(path, [tuple(m) for m in brut])
                _ecrire(cache, brut, res)
                return corriger(res)
            # Cache d'avant cette separation: le brut est perdu, il faut
            # vraiment retranscrire.
        if not disponible():
            return []
        res = _transcrire(path)
        if res is None:
            return []
        brut, cales = res
        CACHE_DIR.mkdir(exist_ok=True)
        _ecrire(cache, brut, cales)
        return corriger(cales)


# Noms de marque que whisper ecorche. Corriges a la LECTURE, pas dans le
# cache: une regle ajoutee ici s'applique tout de suite a tous les clips
# deja transcrits, sans rien retranscrire.
#
# Entendu sur Replit colouring books: « repli.com », « replid.com »,
# « Ripley is so easy to connect with Shopify ». On vise les deformations
# proches (r + e/i/y + p + l + voyelle + d/t/k/c eventuel) mais PAS les vrais
# mots anglais voisins — « reply », « replay », « replied », « ripple » —
# sauf s'ils sont colles a « .com », ou le doute n'est plus permis.
_REPLIT = re.compile(r"^(r[eiy]p{1,2}l[iy]e?[dtkc]?|r[eiy]p{1,2}let|replit|ripley|ripli)$", re.I)
_REPLIT_COM = re.compile(r"^(r[eiy]p{1,2}l[a-z]{0,4})$", re.I)
_PAS_REPLIT = {"reply", "replay", "replied", "ripple", "replica", "replies"}


def _corriger_mot(w):
    m = re.match(r"^(\W*)(.*?)(\W*)$", w)
    avant, coeur, apres = m.groups()
    # « .com » colle au mot: la ponctuation de fin est apres lui.
    dom = re.match(r"^(.*?)\.com$", coeur, re.I)
    if dom and _REPLIT_COM.match(dom.group(1)):
        return f"{avant}replit.com{apres}"
    if coeur.lower() not in _PAS_REPLIT and _REPLIT.match(coeur):
        return f"{avant}Replit{apres}"
    return w


def corriger(liste):
    # Un « mot » sans lettre ni chiffre (« - » en tete de phrase chez
    # whisper) s'afficherait seul a l'ecran comme un sous-titre vide.
    return [(_corriger_mot(w), a, b) for w, a, b in liste if re.search(r"\w", w)]


def _ecrire(cache, brut, mots):
    cache.write_text(json.dumps({"v": CACHE_V, "brut": brut, "mots": mots},
                                ensure_ascii=False), "utf-8")


def en_cache(path):
    """Mots deja transcrits pour ce clip, ou None s'il ne l'a jamais ete.

    Ne lance RIEN: sert a l'affichage, qui ne doit pas bloquer l'ouverture
    d'une serie sur des minutes de transcription."""
    try:
        cache = CACHE_DIR / (_cle(path) + ".json")
        d = json.loads(cache.read_text("utf-8"))
        liste = d["mots"] if isinstance(d, dict) else d
        return corriger(tuple(m) for m in liste)
    except (OSError, ValueError, KeyError, TypeError):
        return None


def _transcrire(path):
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "voix.wav")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(path), "-vn",
                            "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", wav],
                           capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(wav):
            return [], []                # pas de piste audio: rien a dire
        # Dans une serie parlee TOUS les clips passent ici, y compris les
        # plans muets ou d'ambiance. Sur du quasi-silence whisper invente
        # du texte ("Sous-titres realises par la communaute d'Amara.org",
        # "Thank you."): on ne le lance meme pas.
        vol = subprocess.run(["ffmpeg", "-i", wav, "-af", "volumedetect", "-f", "null", "-"],
                             capture_output=True, text=True).stderr
        crete = re.search(r"max_volume: (-?[\d.]+) dB", vol)
        if crete and float(crete.group(1)) < -35:
            return [], []
        base = os.path.join(tmp, "t")
        # -l auto: la langue est detectee clip par clip (francais ou anglais).
        r = subprocess.run([binaire(), "-m", modele(), "-f", wav, "-l", "auto",
                            "-ojf", "-of", base, "-np"],
                           capture_output=True, text=True)
        try:
            data = json.loads(Path(base + ".json").read_text("utf-8"))
        except (OSError, ValueError):
            return None                  # echec: pas de cache, on retentera
        # Le wav est encore la: on recale sans le redecoder. On renvoie
        # les DEUX listes, le brut sert a refaire le recalage plus tard.
        brut = _assembler_mots(data)
        return brut, caler(path, brut, wav=wav)


# ------------------------------------------------------------------
# LA DICTEE (23/11) : parler au monteur au lieu de lui ecrire
# ------------------------------------------------------------------
# Le micro du navigateur enregistre, whisper — deja la pour les
# sous-titres — transcrit SUR LA MACHINE. Pas la reconnaissance vocale du
# navigateur : celle de Chrome envoie la voix chez Google, Firefox n'en a
# pas, et on a deja l'outil. Le francais est IMPOSE (`-l fr`) : en
# detection automatique, une phrase quebecoise pleine de « hook », « clip »
# et « split screen » partait une fois sur deux en anglais. L'amorce donne
# a whisper les mots du metier, qu'il ecrit sinon de travers.
DICTEE_AMORCE = ("Montage vidéo : le hook, l'accroche, le clip, le split screen, les "
                 "sous-titres, un zoom, une transition, la musique, l'étape, la réaction, "
                 "le texte à l'écran, la vidéo exemple.")


def dicter(path):
    """Ce qui a ete DIT dans cet enregistrement -> texte ("" si rien
    d'audible). None si whisper a echoue."""
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "voix.wav")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(path), "-vn",
                            "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", wav],
                           capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(wav):
            return None
        vol = subprocess.run(["ffmpeg", "-i", wav, "-af", "volumedetect", "-f", "null", "-"],
                             capture_output=True, text=True).stderr
        crete = re.search(r"max_volume: (-?[\d.]+) dB", vol)
        if crete and float(crete.group(1)) < -45:
            return ""                    # micro coupe ou personne n'a parle
        base = os.path.join(tmp, "t")
        subprocess.run([binaire(), "-m", modele(), "-f", wav, "-l", "fr", "-nt", "-np",
                        "-otxt", "-of", base, "--prompt", DICTEE_AMORCE],
                       capture_output=True, text=True)
        try:
            texte = Path(base + ".txt").read_text("utf-8")
        except OSError:
            return None
    lignes = [x.strip() for x in texte.splitlines() if x.strip()]
    lignes = [x for x in lignes if not _BRUIT.match(x)
              and not any(h in x.lower() for h in _HALLUCINATIONS)]
    return re.sub(r"\s+", " ", " ".join(lignes)).strip()


# Ce que whisper invente sur du silence ou de la musique.
_BRUIT = re.compile(r"^[\[\(\*♪].*|^(\.\.\.)$")
_HALLUCINATIONS = ("amara.org", "sous-titr", "thank you for watching",
                   "merci d'avoir regard", "abonnez-vous")


def _assembler_mots(data):
    """Tokens whisper -> mots entiers.

    Whisper decoupe en sous-mots: " repl" + "it", " minutes" + ".". Un
    token sans espace initial se colle au mot precedent."""
    out = []
    for seg in data.get("transcription", []):
        texte = seg.get("text", "").lower()
        if any(h in texte for h in _HALLUCINATIONS):
            continue
        # Un segment dont whisper lui-meme doute (probabilite moyenne des
        # tokens sous 0,4) est presque toujours du bruit ou de la musique.
        ps = [t.get("p", 1) for t in seg.get("tokens", []) if not t.get("text", "").startswith("[_")]
        if ps and sum(ps) / len(ps) < 0.4:
            continue
        for t in seg.get("tokens", []):
            txt = t.get("text", "")
            if txt.startswith("[_") or not txt.strip():
                continue                 # marqueurs internes ([_BEG_], [_TT_...])
            a = t["offsets"]["from"] / 1000.0
            b = t["offsets"]["to"] / 1000.0
            if out and not txt.startswith(" "):
                w = out[-1]
                out[-1] = [w[0] + txt, w[1], max(w[2], b)]
            else:
                out.append([txt.strip(), a, b])
    return [(w, round(a, 3), round(b, 3)) for w, a, b in out
            if w and not _BRUIT.match(w)]


# Fenetre d'affichage d'un sous-titre. Mesure sur un clip reel (« Bro, I
# genuinely can't... »): l'ancienne regle — tenir chaque bloc jusqu'au
# DEBUT du suivant, plus une demi-seconde sur le dernier — laissait le mot
# a l'ecran 0,10 a 0,15 s apres qu'il soit dit, et une demi-seconde apres
# la derniere syllabe. Pire, le rattrapage des mots de duree nulle
# DECALAIT le mot suivant: « genuinely » s'affichait 0,12 s en retard,
# et le retard se voit tout de suite.
#
# La regle est maintenant: on tient le mot, rien de plus.
TENUE = 0.15     # trou comble entre deux mots: en dessous, un blanc clignote
QUEUE = 0.08     # de quoi ne pas couper la derniere image du mot
MINI = 0.08      # en dessous, whisper n'a pas su dater le mot: on ne l'affiche pas


# ------------------------------------------------------------------
# Recaler les mots sur le son reellement present
# ------------------------------------------------------------------
# Un mot date APRES un silence commence souvent au debut du SILENCE et non
# a la premiere syllabe: whisper pose le premier mot d'un segment au debut
# de ce segment, et un segment demarre la ou le precedent s'est arrete. Le
# sous-titre restait donc affiche pendant tout le silence — et quand deux
# mots tombaient dedans, il changeait au milieu du silence.
#
# On ne corrige QUE ce cas: un mot dont le debut tombe dans un vrai blanc.
# Deplacer tous les mots sur l'energie ferait pire — une consonne douce
# (« f », « s ») demarre sous le seuil et le mot partirait en retard.
PAS = 0.02            # trame d'analyse, 20 ms
# DEUX seuils, et c'est le coeur de l'affaire. Un seul, place assez haut
# pour reconnaitre une attaque de voix, voyait du silence entre deux
# syllabes: tous les mots se faisaient couper a 0,16 s et les sous-titres
# clignotaient. Un seul, place assez bas pour ne pas confondre, ne trouvait
# plus le debut d'un mot. Donc:
#   PAROLE   haut  — « ca, c'est une attaque » : sert a POSER un debut
#   SILENCE  bas   — « la, il n'y a vraiment rien » : sert a COUPER
# Les deux seuils sont pris en DECIBELS et sur des PERCENTILES, jamais sur
# le pic. Premiere version: une fraction de (pic - plancher), en lineaire.
# Un seul cri dans le clip faisait exploser le pic, le seuil montait avec,
# et les creux normaux de la voix passaient pour du silence: tous les mots
# se faisaient couper a 0,16 s et les sous-titres clignotaient.
# En dB et entre p10 et p90, la dynamique d'un clip tient dans 20 a 25 dB
# quel que soit son niveau, et un cri isole ne deplace plus rien.
#
#   SILENCE  bas  — « la, il n'y a vraiment rien » : sert a COUPER
#   PAROLE   haut — « ca, c'est une attaque »      : sert a POSER un debut
PAS = 0.02            # trame d'analyse, 20 ms
PART_SILENCE = 0.20   # de p10 vers p90, en dB
PART_PAROLE = 0.50
BLANC_DEBUT = 0.25    # blanc avant un mot au-dela duquel sa date est fausse
BLANC_FIN = 0.35      # blanc dans un mot au-dela duquel on coupe


def _enveloppe(wav_path):
    """(energie en dB par trame, seuil de silence, seuil de parole)."""
    try:
        w = wave.open(str(wav_path))
    except (OSError, wave.Error):
        return None, 0, 0
    try:
        largeur, canaux = w.getsampwidth(), w.getnchannels()
        n = int(w.getframerate() * PAS)
        rms = []
        while True:
            bloc = w.readframes(n)
            if len(bloc) < n * largeur * canaux:
                break
            rms.append(20 * math.log10(audioop.rms(bloc, largeur) + 1))
    except (wave.Error, audioop.error):
        return None, 0, 0
    finally:
        w.close()
    if len(rms) < 10:
        return None, 0, 0
    tri = sorted(rms)
    bas, haut = tri[int(len(tri) * 0.10)], tri[int(len(tri) * 0.90)]
    # Un clip sans dynamique (bruit constant, musique de fond forte) ne
    # donne aucun repere fiable: on prefere ne rien deplacer du tout.
    if haut - bas < 8:
        return None, 0, 0
    ecart = haut - bas
    return rms, bas + ecart * PART_SILENCE, bas + ecart * PART_PAROLE


def caler(path, mots, wav=None):
    """Recale les mots sur le son reellement present.

    Deux corrections, et seulement celles-la:
      - un mot dont le debut tombe dans un vrai blanc est AVANCE jusqu'a la
        premiere attaque (jamais recule, jamais reordonne);
      - un mot dont la fenetre contient un vrai blanc s'arrete a ce blanc.
    Tout le reste est laisse tel quel: sur de la voix continue whisper date
    juste, c'est mesure (ecart median nul contre l'enveloppe du son)."""
    mots = [tuple(m) for m in mots]
    if not mots:
        return mots
    tmp = None
    try:
        if wav is None:
            tmp = tempfile.mkdtemp()
            wav = os.path.join(tmp, "v.wav")
            r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(path), "-vn",
                                "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", wav],
                               capture_output=True)
            if r.returncode != 0 or not os.path.exists(wav):
                return mots
        rms, s_silence, s_parole = _enveloppe(wav)
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
    if not rms:
        return mots

    def muet(i):
        return 0 <= i < len(rms) and rms[i] < s_silence

    def attaque(i):
        return 0 <= i < len(rms) and rms[i] >= s_parole

    out = []
    for n, (w, a, b) in enumerate(mots):
        i = int(a / PAS)
        if muet(i):
            # Depuis quand est-ce vraiment muet ? Un creux entre deux
            # syllabes ne compte pas.
            j = i
            while j > 0 and muet(j - 1):
                j -= 1
            if (i - j) * PAS >= BLANC_DEBUT or j == 0:
                # Premiere attaque, sans depasser la fin du mot ni le debut
                # du suivant: on ne reordonne jamais les mots.
                limite = int(min(b, mots[n + 1][1] if n + 1 < len(mots) else b) / PAS)
                k = i
                while k < limite and not attaque(k):
                    k += 1
                if attaque(k):
                    a = round(k * PAS, 3)
        # Whisper etire parfois un mot jusqu'au bord de son segment. Mesure
        # sur un clip reel: « My » occupait 0,00 -> 7,14 s, sept secondes de
        # sous-titre pour un mot d'une syllabe. On coupe au premier vrai
        # blanc apres le debut: ca traite d'un coup la queue muette et le
        # silence avale au milieu. Pas de duree minimale ici — un mot reduit
        # a rien est un mot que whisper a invente, `morceaux` l'ecartera.
        # Si la coupe ne laisse rien, ce n'est pas la fin qui est fausse,
        # c'est le DEBUT: whisper a date le mot avant qu'il soit dit, mais
        # dans une zone pas tout a fait silencieuse (le test d'avant ne l'a
        # donc pas vu). On cherche l'attaque suivante et on recommence —
        # trois essais, apres quoi le mot est vraiment introuvable.
        for _ in range(3):
            creux, suite = None, 0
            for k in range(int(a / PAS), int(b / PAS)):
                if not muet(k):
                    suite = 0
                else:
                    suite += 1
                    if suite * PAS >= BLANC_FIN:
                        creux = k - suite + 1
                        break
            if creux is None:
                break
            if creux * PAS - a >= MINI:
                b = round(creux * PAS, 3)
                break
            k = creux
            limite = int(b / PAS)
            while k < limite and not attaque(k):
                k += 1
            if not attaque(k):
                b = round(creux * PAS, 3)
                break
            a = round(k * PAS, 3)
        out.append((w, a, max(b, a)))
    return out


def morceaux(liste, max_mots=1, max_car=16, pause=0.4):
    """Groupe les mots en sous-titres, facon TikTok.

    UN mot a la fois par defaut: c'est le rendu demande (reference: un
    Reel ou chaque mot s'affiche seul, centre). Avec max_mots > 1, coupe
    aussi a la ponctuation, aux pauses et quand le bloc depasse une ligne.

    `liste` = [(texte, debut, fin)] deja ramene au temps de SORTIE du clip.
    Renvoie [(texte, debut, fin)].

    AUCUN mot n'est jamais decale: son debut est celui que donne la
    transcription, point. Un mot que whisper date sur une duree plus
    courte qu'une image n'est pas affiche — le voler au mot suivant
    mettait toute la suite en retard, et un mot manquant de temps en temps
    coute moins cher qu'un sous-titre qui traine."""
    blocs, cur = [], []
    for m in liste:
        if cur:
            txt = " ".join(x[0] for x in cur + [m])
            if (len(cur) >= max_mots or len(txt) > max_car
                    or m[1] - cur[-1][2] > pause
                    or cur[-1][0][-1:] in ".!?,;:"):
                blocs.append(cur)
                cur = []
        cur.append(m)
    if cur:
        blocs.append(cur)

    out = []
    for i, b in enumerate(blocs):
        debut, fin = b[0][1], b[-1][2]
        suivant = blocs[i + 1][0][1] if i + 1 < len(blocs) else None
        if suivant is not None and suivant - fin <= TENUE:
            # Trou trop court pour qu'un blanc se voie autrement que comme
            # un clignotement: on tient jusqu'au mot suivant.
            fin = suivant
        else:
            # Vraie pause: le sous-titre s'efface avec la voix.
            fin += QUEUE
            if suivant is not None:
                fin = min(fin, suivant)
        texte = " ".join(x[0] for x in b).rstrip(".,;:")
        if texte and fin - debut >= MINI:
            out.append((texte, round(debut, 3), round(fin, 3)))
    return out
