# -*- coding: utf-8 -*-
"""Instagram EN DIRECT : les stats des comptes, sans Buffer ni aucun outil
entre les deux (25/11, « 100 % en dehors de Buffer »).

L'API officielle de Meta, « Instagram API with Instagram Login ». Une app
Meta qui ne sert que des comptes qu'on possede ou qu'on gere n'a PAS besoin
de revue (« Standard Access ») : on ajoute le compte a l'app, le tableau de
bord de Meta fabrique une cle de 60 jours, et cette cle se renouvelle par un
simple appel. Le compte doit etre professionnel (createur ou entreprise) et
public ; pas besoin de page Facebook.

Ce module ne fait que LIRE : le profil (abonnes), la liste des publications
et leurs chiffres (vues, portee, likes, partages, enregistrements, temps
regarde). Il couvre tout ce que le compte a publie, a la main comme par le
plateau. Meta peut avoir jusqu'a 48 h de retard sur ses propres chiffres.

Zero dependance : `urllib`. La cle vit dans `instagram.json` (600, dans les
donnees) et ne sort JAMAIS de ce module — ni dans une reponse du serveur, ni
vers le telephone, ni vers Claude. Les chiffres, eux, sont dans
`.instagram-stats.json`, relus a volonte sans rien redemander a Meta.
"""
import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

from chemins import DONNEES

API = "https://graph.instagram.com"
CLES = DONNEES / "instagram.json"
STATS = DONNEES / ".instagram-stats.json"

RELEVE_S = 20 * 3600        # un releve par jour suffit : Meta ne va pas plus vite
RENOUVELER_S = 7 * 86400    # la cle dure 60 jours ; on la renouvelle chaque semaine
MEDIAS_MAX = 150            # publications gardees par compte
FRAIS_J = 30                # en dessous, les chiffres bougent encore : relus a chaque releve
INSIGHTS_MAX = 120          # appels de chiffres par compte et par releve, au plus
HISTO_J = 180               # jours d'historique des abonnes

# Ce qu'on demande pour un reel, puis pour le reste. Une metrique refusee
# fait echouer TOUT l'appel : on retombe alors sur la liste courte.
M_REEL = ("views,reach,saved,shares,likes,comments,total_interactions,"
          "ig_reels_avg_watch_time,ig_reels_video_view_total_time")
M_COURT = "views,reach,saved,shares,likes,comments"
M_MINI = "reach,saved"

_verrou = threading.RLock()
_ETAT = {"en_cours": False, "msg": "", "erreur": "", "t": 0.0}


class IGError(Exception):
    """Une erreur a dire telle quelle a la personne."""

    def __init__(self, message, code=0):
        super().__init__(message)
        self.code = code


# ------------------------------------------------------------------
# Fichiers
# ------------------------------------------------------------------

def _lire(chemin):
    try:
        with open(chemin, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _ecrire(chemin, d, prive=False):
    tmp = str(chemin) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    if prive:
        os.chmod(tmp, 0o600)
    os.replace(tmp, chemin)


def pseudo(h):
    """« @Mon.Compte » ou une adresse de profil -> « mon.compte »."""
    h = str(h or "").strip().lower()
    h = h.split("instagram.com/")[-1].split("?")[0].strip("/ ")
    return h.lstrip("@")


# ------------------------------------------------------------------
# L'API
# ------------------------------------------------------------------

def _appel(chemin, cle, **params):
    """GET sur l'API. La cle part en parametre (c'est la forme que Meta
    documente) : l'adresse complete n'est donc JAMAIS ecrite nulle part, ni
    dans un journal ni dans un message d'erreur."""
    params["access_token"] = cle
    url = f"{API}/{chemin.lstrip('/')}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Macintosh)"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        try:
            err = (json.loads(e.read().decode("utf-8") or "{}").get("error")) or {}
        except (ValueError, OSError):
            err = {}
        code = int(err.get("code") or 0)
        msg = str(err.get("message") or f"Instagram a répondu {e.code}")
        if code == 190:
            msg = "La clé de ce compte n'est plus valable : refais-en une sur Meta et recolle-la."
        elif code in (4, 17, 32, 613):
            msg = "Instagram limite les demandes pour l'instant : réessaie dans une heure."
        raise IGError(msg[:300], code)
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise IGError(f"Instagram injoignable ({type(e).__name__})")


def _profil(cle):
    d = _appel("me", cle, fields="user_id,username,account_type,followers_count,media_count")
    if not d.get("username"):
        raise IGError("Cette clé ne mène à aucun compte Instagram.")
    return d


# ------------------------------------------------------------------
# Les comptes
# ------------------------------------------------------------------

def ajouter(cle):
    """Branche un compte par sa cle (collee depuis le tableau de bord de
    Meta). Le compte se reconnait tout seul : c'est la cle qui dit a qui
    elle appartient. -> la fiche publique du compte."""
    cle = "".join(str(cle or "").split())
    if len(cle) < 40:
        raise IGError("Ce n'est pas une clé Instagram : elle fait plus de cent caractères.")
    p = _profil(cle)
    nom = pseudo(p["username"])
    with _verrou:
        d = _lire(CLES)
        cs = d.setdefault("comptes", {})
        maintenant = time.time()
        cs[nom] = {"cle": cle, "id": str(p.get("user_id") or p.get("id") or ""),
                   "type": p.get("account_type") or "", "ajoute": maintenant,
                   "renouvele": maintenant,
                   # Une cle du tableau de bord dure 60 jours ; on ne sait pas
                   # quand elle a ete fabriquee, donc on la renouvelle des
                   # qu'elle a un jour (`renouveler`).
                   "expire": maintenant + 59 * 86400}
        _ecrire(CLES, d, prive=True)
    return compte(nom)


def retirer(nom):
    nom = pseudo(nom)
    with _verrou:
        d = _lire(CLES)
        if (d.get("comptes") or {}).pop(nom, None) is None:
            return False
        _ecrire(CLES, d, prive=True)
        s = _lire(STATS)
        if s.pop(nom, None) is not None:
            _ecrire(STATS, s)
    return True


def branches():
    """Les pseudos des comptes branches."""
    return sorted((_lire(CLES).get("comptes") or {}).keys())


def compte(nom):
    """La fiche PUBLIQUE d'un compte : tout sauf sa cle."""
    nom = pseudo(nom)
    c = (_lire(CLES).get("comptes") or {}).get(nom)
    if not c:
        return None
    s = _lire(STATS).get(nom) or {}
    return {"compte": nom, "type": c.get("type") or "",
            "expire_j": max(0, int((float(c.get("expire") or 0) - time.time()) // 86400)),
            "releve": s.get("t") or 0, "abonnes": s.get("abonnes"),
            "erreur": c.get("erreur") or ""}


def comptes():
    return [compte(n) for n in branches()]


def renouveler():
    """Prolonge de 60 jours les cles qui ont plus d'une semaine. Une cle de
    moins de 24 h ne se renouvelle pas (Meta refuse) ; une cle laissee 60
    jours sans renouvellement est morte, il faut en refaire une."""
    n = 0
    with _verrou:
        d = _lire(CLES)
        for nom, c in (d.get("comptes") or {}).items():
            age = time.time() - float(c.get("renouvele") or 0)
            if age < max(86400, RENOUVELER_S if c.get("prolongee") else 86400):
                continue
            try:
                r = _appel("refresh_access_token", c["cle"], grant_type="ig_refresh_token")
            except IGError as e:
                c["erreur"] = str(e)
                continue
            if r.get("access_token"):
                c["cle"] = r["access_token"]
                c["renouvele"] = time.time()
                c["expire"] = time.time() + float(r.get("expires_in") or 59 * 86400)
                c["prolongee"] = 1
                c.pop("erreur", None)
                n += 1
        _ecrire(CLES, d, prive=True)
    return n


# ------------------------------------------------------------------
# Le releve
# ------------------------------------------------------------------

def _epoch(iso):
    """« 2026-11-24T19:30:12+0000 » -> secondes."""
    s = str(iso or "").strip()
    if not s:
        return 0.0
    if s.endswith("Z"):
        s = s[:-1] + "+0000"
    for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S.%f%z"):
        try:
            return datetime.strptime(s, fmt).timestamp()
        except ValueError:
            continue
    try:
        return datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
    except ValueError:
        return 0.0


def _chiffres(mid, cle, reel):
    """Les chiffres d'une publication -> dict, {} si Meta n'en a pas."""
    for metriques in ((M_REEL, M_COURT, M_MINI) if reel else (M_COURT, M_MINI)):
        try:
            d = _appel(f"{mid}/insights", cle, metric=metriques)
        except IGError as e:
            if e.code in (190, 4, 17, 32, 613) or not e.code:
                raise
            continue                      # une metrique refusee : liste plus courte
        out = {}
        for x in d.get("data") or []:
            v = (x.get("values") or [{}])[0].get("value")
            if v is None:
                v = (x.get("total_value") or {}).get("value")
            if isinstance(v, (int, float)):
                out[x.get("name")] = v
        return out
    return {}


def relever(nom, progres=None):
    """Relit le profil et les publications d'un compte, et range les
    chiffres. Les publications de moins de `FRAIS_J` jours sont relues a
    chaque fois (leurs chiffres montent encore) ; les autres une seule
    fois. -> la fiche des stats du compte."""
    nom = pseudo(nom)
    c = (_lire(CLES).get("comptes") or {}).get(nom)
    if not c:
        raise IGError(f"@{nom} n'est pas branché.")
    cle = c["cle"]
    p = _profil(cle)
    medias, suite, pages = [], None, 0
    while len(medias) < MEDIAS_MAX and pages < 4:
        params = {"fields": "id,caption,media_type,media_product_type,permalink,timestamp,"
                            "like_count,comments_count", "limit": 50}
        if suite:
            params["after"] = suite
        d = _appel("me/media", cle, **params)
        medias += d.get("data") or []
        suite = (((d.get("paging") or {}).get("cursors")) or {}).get("after")
        pages += 1
        if not suite or not (d.get("paging") or {}).get("next"):
            break
    ancien = {m["id"]: m for m in ((_lire(STATS).get(nom) or {}).get("medias") or [])}
    maintenant, appels, out = time.time(), 0, []
    for k, m in enumerate(medias[:MEDIAS_MAX]):
        t = _epoch(m.get("timestamp"))
        reel = (m.get("media_product_type") or "") == "REELS"
        f = {"id": m["id"], "t": t, "lien": m.get("permalink") or "",
             "legende": (m.get("caption") or "")[:200], "reel": reel,
             "likes": m.get("like_count"), "com": m.get("comments_count")}
        vieux = ancien.get(m["id"]) or {}
        frais = maintenant - t < FRAIS_J * 86400
        if (frais or "vu" not in vieux) and appels < INSIGHTS_MAX:
            if progres:
                progres(f"@{nom} : {k + 1}/{min(len(medias), MEDIAS_MAX)}")
            appels += 1
            ch = _chiffres(m["id"], cle, reel)
            if ch:
                f.update({"vues": ch.get("views"), "portee": ch.get("reach"),
                          "enreg": ch.get("saved"), "partages": ch.get("shares"),
                          "interactions": ch.get("total_interactions"),
                          # Meta compte en millisecondes.
                          "regarde": round(ch["ig_reels_avg_watch_time"] / 1000.0, 2)
                          if ch.get("ig_reels_avg_watch_time") else None,
                          })
                if ch.get("likes") is not None:
                    f["likes"] = ch["likes"]
                if ch.get("comments") is not None:
                    f["com"] = ch["comments"]
            # `vu` meme sans chiffres : une photo n'en aura jamais, inutile
            # de la redemander a chaque releve une fois qu'elle a vieilli.
            f["vu"] = maintenant
        if "vu" not in f:
            for cle_ in ("vues", "portee", "enreg", "partages", "interactions", "regarde", "vu"):
                if vieux.get(cle_) is not None:
                    f[cle_] = vieux[cle_]
        out.append(f)
    with _verrou:
        s = _lire(STATS)
        fiche = s.get(nom) or {}
        histo = dict(fiche.get("histo") or {})
        histo[time.strftime("%Y-%m-%d")] = p.get("followers_count")
        for j in sorted(histo)[:-HISTO_J]:
            histo.pop(j, None)
        s[nom] = {"t": maintenant, "abonnes": p.get("followers_count"),
                  "publications": p.get("media_count"), "type": p.get("account_type") or "",
                  "medias": out, "histo": histo, "appels": appels + pages + 1}
        _ecrire(STATS, s)
        d = _lire(CLES)
        if nom in (d.get("comptes") or {}):
            d["comptes"][nom].pop("erreur", None)
            _ecrire(CLES, d, prive=True)
    return s[nom]


def stats(nom):
    """Les chiffres ranges d'un compte (aucun appel a Meta), ou None."""
    return _lire(STATS).get(pseudo(nom))


def etat():
    return dict(_ETAT)


def tout_relever(force=False):
    """Un passage : les cles a renouveler, puis chaque compte dont le releve
    a plus de `RELEVE_S`. Ne leve jamais (la boucle de fond l'appelle) ;
    l'erreur d'un compte est notee sur sa fiche et n'arrete pas les autres.
    -> le nombre de comptes releves."""
    with _verrou:
        if _ETAT["en_cours"]:
            return 0
        _ETAT.update(en_cours=True, msg="", erreur="")
    n = 0
    try:
        noms = branches()
        if not noms:
            return 0
        s = _lire(STATS)
        dus = [x for x in noms
               if force or time.time() - float((s.get(x) or {}).get("t") or 0) > RELEVE_S]
        if not dus:
            return 0
        renouveler()
        for nom in dus:
            try:
                relever(nom, progres=lambda m: _ETAT.update(msg=m))
                n += 1
            except IGError as e:
                _ETAT["erreur"] = f"@{nom} : {e}"
                with _verrou:
                    d = _lire(CLES)
                    if nom in (d.get("comptes") or {}):
                        d["comptes"][nom]["erreur"] = str(e)
                        _ecrire(CLES, d, prive=True)
            except Exception as e:                              # noqa: BLE001
                _ETAT["erreur"] = f"@{nom} : {type(e).__name__}"
    finally:
        _ETAT.update(en_cours=False, t=time.time())
    return n
