"""Le CALQUE de la video exemple : ce que son monteur a pose PAR-DESSUS la
personne — une capture de l'app, un autocollant, un logo, un code — repris
et repose au meme moment sur NOTRE video.

Pourquoi (25/11) : en « montage on the spot », l'exemple ne servait qu'a
regler la taille des sous-titres. « Rien du montage de la video d'exemple a
ete garde… il y a telle image qui apparait, il faut que je reprenne cette
image-la et que je la mette sur le montage. » Trois temps :

1. CLAUDE SITUE (`ia.elements_exemple`) : il regarde l'exemple deux images
   par seconde et dit quels elements sont poses, ou et quand, a une
   demi-seconde et quelques pour cent pres.
2. LA MESURE PRECISE (`mesurer`) : la camera d'un talking head ne bouge
   pas. On fabrique donc une PLAQUE PROPRE (la mediane d'images prises
   quand rien n'est pose) et tout ce qui s'en ecarte durablement dans la
   zone designee EST l'element : ses bords au pixel, son entree et sa
   sortie au dixieme de seconde. La personne qui bouge fait aussi un
   ecart, mais ailleurs et pas longtemps : on ne garde que les taches qui
   tiennent dans la boite de Claude.
3. LA DECOUPE (`extraire`) : chaque element devient un petit film a fond
   TRANSPARENT (ProRes 4444), l'ecart a la plaque servant de masque. Son
   animation d'entree est dedans — on ne la refait pas, on la reprend.

A chaque video, `poser` replace les elements : au meme ENDROIT (fractions
de l'image, remonte si notre tete est plus haute) et au meme MOMENT, non
pas en secondes mais sur les MOTS — l'element qui arrive quand l'exemple
dit « free » arrive quand NOUS disons « free » (`carte_temps`).

Zero dependance : ffmpeg pour les images, Python pour le reste.
"""
import difflib
import os
import re
import subprocess
from pathlib import Path

A_LARG, A_FPS = 240, 10        # l'analyse se fait a mi-taille, 10 images/s
ECART = 26                     # niveaux de gris : au-dela, le pixel a change
MARGE_ZONE = 0.07              # on cherche un peu plus large que la boite de Claude
FICHIER = "calque-{}.mov"
VIGNETTE = "calque-{}.png"
MASQUE = "calque-{}-zone.pgm"


def _dims(video):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "stream=width,height:format=duration", "-of", "csv=p=0:s=,", str(video)],
                       capture_output=True, text=True)
    try:
        v = [x for x in r.stdout.replace("\n", ",").split(",") if x.strip()]
        return int(v[0]), int(v[1]), float(v[2])
    except (ValueError, IndexError):
        return 0, 0, 0.0


def _images(video, w, h):
    """Toute la video en petites images RVB. En COULEUR : un logo vert sur
    un mur gris a la meme luminosite que lui, en gris il est invisible."""
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(video), "-an",
                        "-vf", f"fps={A_FPS},scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                       capture_output=True)
    return r.stdout


def _personne(video, t0, t1, W, H):
    """Ou est la PERSONNE pendant que l'element est a l'ecran : un octet par
    pixel d'analyse, 1 = elle y est plus d'une image sur deux. Vision
    (macOS) ; ailleurs None, et une meche de cheveux peut rester.

    Sans ca, la tete de la personne de l'exemple — qui a bouge depuis la
    plaque — venait avec l'element : on aurait pose SES cheveux sur NOTRE
    video. Vision ne voit que ce qui est visible : un autocollant pose
    devant son front n'est pas « la personne », il est donc garde."""
    try:
        import detourage
        if not detourage.disponible():
            return None
        pas = max(0.25, (t1 - t0) / 8.0)
        w = 384
        h = int(round(H * w / float(W) / 2)) * 2
        r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t0:.2f}", "-t", f"{max(0.3, t1 - t0):.2f}",
                            "-i", str(video), "-an", "-vf", f"fps=1/{pas:.3f},scale={w}:{h}",
                            "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True)
        taille = w * h * 3
        votes, n = [0] * (W * H), 0
        for i in range(len(r.stdout) // taille):
            data, mw, mh = detourage._masque_image(r.stdout[i * taille:(i + 1) * taille], w, h)
            if data is None:
                continue
            n += 1
            for y in range(H):
                o, om = y * W, (y * mh // H) * mw
                for x in range(W):
                    if data[om + x * mw // W] >= 128:
                        votes[o + x] += 1
        if not n:
            return None
        return bytes(1 if v * 2 > n else 0 for v in votes)
    except Exception:                                           # noqa: BLE001
        return None


def _instants_propres(elements, duree):
    """Des instants ou AUCUN element n'est a l'ecran, pour la plaque."""
    occ = sorted((float(e["debut"]), float(e["fin"])) for e in elements)
    trous, t = [], 0.0
    for a, b in occ:
        if a - t >= 0.9:
            trous.append((t, a))
        t = max(t, b)
    if duree - t >= 0.9:
        trous.append((t, duree))
    inst = []
    for a, b in trous:
        # Loin des bords du trou : Claude date a une demi-seconde pres.
        inst += [a + 1.0, (a + b) / 2, b - 1.0] if b - a >= 3.0 else [(a + b) / 2]
    return [round(x, 2) for x in inst][:15]


def mesurer(video, elements):
    """Precise chaque element : `t0`, `t1` (secondes) et `px` = [x, y, l, h]
    en pixels de la video, plus `zone` (les taches gardees, pour le masque).
    -> (elements mesures, instants de la plaque). Un element introuvable
    dans l'image est retire : Claude l'a peut-etre invente."""
    vw, vh, duree = _dims(video)
    if not vw or not elements:
        return [], []
    W = A_LARG
    H = int(round(vh * W / float(vw) / 2)) * 2
    raw = _images(video, W, H)
    T = W * H * 3
    N = len(raw) // T
    if N < 5:
        return [], []
    fr = lambda k: raw[k * T:(k + 1) * T]

    def change(F, i):
        """Le pixel `i` de l'image F s'ecarte-t-il de la plaque ?"""
        i *= 3
        return (abs(F[i] - P[i]) > ECART or abs(F[i + 1] - P[i + 1]) > ECART
                or abs(F[i + 2] - P[i + 2]) > ECART)
    inst = _instants_propres(elements, duree)
    if not inst:
        return [], []
    pl = [fr(min(N - 1, int(x * A_FPS))) for x in inst]
    P = bytes(sorted(v)[len(v) // 2] for v in zip(*pl))
    out = []
    for e in elements:
        ex, ey, el_, eh = (max(0.0, min(1.0, float(e[k]))) for k in ("x", "y", "l", "h"))
        cx0, cx1 = int(ex * W), min(W, int((ex + el_) * W) + 1)
        cy0, cy1 = int(ey * H), min(H, int((ey + eh) * H) + 1)
        if cx1 - cx0 < 3 or cy1 - cy0 < 3:
            continue
        # La fenetre de temps : une demi-seconde de chaque cote, sans
        # deborder sur l'element d'avant ni sur celui d'apres.
        autres = [o for o in elements if o is not e]
        lo = max([float(o["fin"]) for o in autres if float(o["fin"]) <= float(e["debut"]) + 0.01]
                 + [float(e["debut"]) - 0.6, 0.0])
        hi = min([float(o["debut"]) for o in autres if float(o["debut"]) >= float(e["fin"]) - 0.01]
                 + [float(e["fin"]) + 0.6, duree])
        ka, kb = int(lo * A_FPS), min(N, int(hi * A_FPS) + 1)
        pres = []
        for k in range(ka, kb):
            F, c = fr(k), 0
            for y in range(cy0, cy1):
                o = y * W
                c += sum(1 for x in range(cx0, cx1) if change(F, o + x))
            pres.append(c / float((cx1 - cx0) * (cy1 - cy0)))
        if not pres or max(pres) < 0.02:
            continue
        seuil = max(0.015, 0.3 * max(pres))
        best, cur = [], []
        for i, v in enumerate(pres):
            if v >= seuil:
                cur.append(ka + i)
                if len(cur) > len(best):
                    best = list(cur)
            else:
                cur = []
        if len(best) < 2:
            continue
        x0, x1 = max(0, int((ex - MARGE_ZONE) * W)), min(W, int((ex + el_ + MARGE_ZONE) * W) + 1)
        y0, y1 = max(0, int((ey - MARGE_ZONE) * H)), min(H, int((ey + eh + MARGE_ZONE) * H) + 1)
        zw, zh = x1 - x0, y1 - y0
        acc = [0] * (zw * zh)
        for k in best:
            F = fr(k)
            for y in range(y0, y1):
                o, oz = y * W, (y - y0) * zw - x0
                for x in range(x0, x1):
                    if change(F, o + x):
                        acc[oz + x] += 1
        rect = e.get("forme") == "rectangle"
        # Un rectangle plein est la presque tout le temps ; un element
        # decoupe peut s'animer, arriver piece par piece : on est large.
        need = max(2, (0.6 if rect else 0.12) * len(best))
        M = [1 if v >= need else 0 for v in acc]
        if not rect:
            qui = _personne(video, best[0] / float(A_FPS), (best[-1] + 1) / float(A_FPS), W, H)
            if qui:
                # Le masque de Vision colle a la personne ; ce qui a change
                # deborde d'un lisere (elle a bouge). On l'elargit de 5
                # pixels, en deux passes (lignes puis colonnes).
                R = 5
                z = [qui[(y0 + i // zw) * W + x0 + i % zw] for i in range(zw * zh)]
                h1 = [1 if any(z[y * zw + max(0, x - R):y * zw + min(zw, x + R + 1)]) else 0
                      for y in range(zh) for x in range(zw)]
                for x in range(zw):
                    col = [h1[y * zw + x] for y in range(zh)]
                    for y in range(zh):
                        if M[y * zw + x] and any(col[max(0, y - R):min(zh, y + R + 1)]):
                            M[y * zw + x] = 0
        lab, garde = [0] * (zw * zh), []
        for i0 in range(zw * zh):
            if not M[i0] or lab[i0]:
                continue
            pile, pts = [i0], []
            lab[i0] = 1
            while pile:
                i = pile.pop()
                pts.append(i)
                yy, xx = divmod(i, zw)
                for ny in (yy - 1, yy, yy + 1):
                    if 0 <= ny < zh:
                        for nx in (xx - 1, xx, xx + 1):
                            if 0 <= nx < zw:
                                j = ny * zw + nx
                                if M[j] and not lab[j]:
                                    lab[j] = 1
                                    pile.append(j)
            if len(pts) < 5:
                continue
            # Un trait fin et long (le contour d'une epaule, l'arete d'une
            # porte) n'est pas un element : il ne remplit pas sa boite.
            lx = max(i % zw for i in pts) - min(i % zw for i in pts) + 1
            ly = max(i // zw for i in pts) - min(i // zw for i in pts) + 1
            if len(pts) < 0.12 * lx * ly and max(lx, ly) >= 12 and len(pts) < 300:
                continue
            # La tache est-elle DANS la boite de Claude ? La tete de la
            # personne, qui a bouge, fait une tache qui en sort par le bas.
            ok = lambda i, m=0: (cx0 - m <= x0 + i % zw < cx1 + m and cy0 - m <= y0 + i // zw < cy1 + m)
            dedans = sum(1 for i in pts if ok(i))
            if dedans >= 0.6 * len(pts):
                garde += pts
            elif dedans >= 0.25 * len(pts):
                # A cheval : deux elements qui se touchent (un logo pose
                # sur son slogan) ne font qu'une tache. On garde la part
                # qui est chez nous, a 3 pixels pres.
                garde += [i for i in pts if ok(i, 3)]
        if not garde:
            continue
        gs = set(garde)
        bx0, bx1 = min(i % zw for i in garde), max(i % zw for i in garde) + 1
        by0, by1 = min(i // zw for i in garde), max(i // zw for i in garde) + 1
        if rect:
            # Les bords d'un rectangle : on rogne tant qu'une ligne ou une
            # colonne du bord n'est pas pleine aux deux tiers.
            plein_l = lambda y: sum(1 for x in range(bx0, bx1) if (y * zw + x) in gs) / float(max(1, bx1 - bx0))
            plein_c = lambda x: sum(1 for y in range(by0, by1) if (y * zw + x) in gs) / float(max(1, by1 - by0))
            for _ in range(3):
                while by1 - by0 > 4 and plein_l(by0) < 0.66:
                    by0 += 1
                while by1 - by0 > 4 and plein_l(by1 - 1) < 0.66:
                    by1 -= 1
                while bx1 - bx0 > 4 and plein_c(bx0) < 0.66:
                    bx0 += 1
                while bx1 - bx0 > 4 and plein_c(bx1 - 1) < 0.66:
                    bx1 -= 1
        k = vw / float(W)
        m = 0 if rect else 3          # un peu d'air autour d'une forme decoupee
        px = [max(0, int((x0 + bx0 - m) * k)), max(0, int((y0 + by0 - m) * k))]
        px += [min(vw - px[0], int((bx1 - bx0 + 2 * m) * k)), min(vh - px[1], int((by1 - by0 + 2 * m) * k))]
        px = [v // 2 * 2 for v in px]
        if px[2] < 16 or px[3] < 16:
            continue
        f = dict(e)
        f["t0"], f["t1"] = round(best[0] / float(A_FPS), 2), round((best[-1] + 1) / float(A_FPS), 2)
        f["px"] = px
        if not rect:
            # Le masque de zone, a la taille d'analyse : les taches gardees,
            # grossies de 3 pixels. Tout ce qui est hors d'elles (une meche
            # de cheveux, un reflet sur la porte) sera transparent.
            z = bytearray(W * H)
            for i in garde:
                yy, xx = y0 + i // zw, x0 + i % zw
                for ny in range(max(0, yy - 3), min(H, yy + 4)):
                    o = ny * W
                    for nx in range(max(0, xx - 3), min(W, xx + 4)):
                        z[o + nx] = 255
            f["_zone"] = (W, H, bytes(z))
        out.append(f)
    return out, inst


def extraire(video, elements, dossier, instants):
    """Decoupe chaque element mesure dans `dossier` : un film a fond
    transparent et une vignette. Pose `fichier` et `vignette` (des NOMS).
    -> les elements reellement ecrits."""
    dossier = Path(dossier)
    dossier.mkdir(parents=True, exist_ok=True)
    for vieux in list(dossier.glob("calque-*")):
        try:
            vieux.unlink()
        except OSError:
            pass
    vw, vh, _d = _dims(video)
    plaque = dossier / "calque-plaque.png"
    inst = list(instants)
    while 0 < len(inst) < 3:
        inst.append(inst[-1])
    cmd = ["ffmpeg", "-v", "error", "-y"]
    for x in inst:
        cmd += ["-ss", f"{x:.2f}", "-i", str(video)]
    cmd += ["-filter_complex", "".join(f"[{i}:v]" for i in range(len(inst))) + f"xmedian=inputs={len(inst)}",
            "-frames:v", "1", str(plaque)]
    subprocess.run(cmd, capture_output=True)
    out = []
    for n, e in enumerate(elements, 1):
        x, y, w, h = e["px"]
        d = max(0.2, e["t1"] - e["t0"])
        dst = dossier / FICHIER.format(n)
        zone = e.pop("_zone", None)
        if e.get("forme") != "rectangle" and plaque.is_file() and zone:
            zp = dossier / MASQUE.format(n)
            zp.write_bytes(b"P5\n%d %d\n255\n" % (zone[0], zone[1]) + zone[2])
            fc = (f"[0:v]crop={w}:{h}:{x}:{y},split[e][e2];[1:v]crop={w}:{h}:{x}:{y}[p];"
                  f"[e2][p]blend=all_mode=difference:shortest=1,format=gbrp,extractplanes=r+g+b[r][g][b];"
                  f"[r][g]blend=all_mode=lighten[rg];[rg][b]blend=all_mode=lighten,"
                  # 16 = le grain de la compression ; au-dela de 38 c'est plein.
                  f"lut=y='clip((val-16)*255/22\\,0\\,255)',"
                  # Ouvrir (un trait d'un pixel disparait) puis fermer (un
                  # trou dans l'element se rebouche).
                  f"erosion,dilation,dilation,dilation,erosion,erosion[m0];"
                  f"[2:v]scale={vw}:{vh}:flags=bilinear,crop={w}:{h}:{x}:{y},format=gray[z];"
                  f"[m0][z]blend=all_mode=darken:shortest=1,gblur=sigma=0.7[m];"
                  f"[e][m]alphamerge,format=yuva444p10le[o]")
            cmd = ["ffmpeg", "-v", "error", "-y", "-ss", f"{e['t0']:.2f}", "-t", f"{d:.2f}", "-i", str(video),
                   "-loop", "1", "-i", str(plaque), "-loop", "1", "-i", str(zp),
                   "-filter_complex", fc, "-map", "[o]"]
        else:
            cmd = ["ffmpeg", "-v", "error", "-y", "-ss", f"{e['t0']:.2f}", "-t", f"{d:.2f}", "-i", str(video),
                   "-vf", f"crop={w}:{h}:{x}:{y},format=yuva444p10le"]
        r = subprocess.run(cmd + ["-an", "-c:v", "prores_ks", "-profile:v", "4444", str(dst)],
                           capture_output=True)
        if r.returncode != 0 or not dst.is_file() or dst.stat().st_size < 500:
            continue
        vg = dossier / VIGNETTE.format(n)
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{d * 0.6:.2f}", "-i", str(dst),
                        "-frames:v", "1", str(vg)], capture_output=True)
        f = {k: v for k, v in e.items() if not k.startswith("_")}
        f["fichier"], f["vignette"] = dst.name, (vg.name if vg.is_file() else "")
        f["id"] = n
        out.append(f)
    for tmp in list(dossier.glob("calque-*-zone.pgm")):
        try:
            tmp.unlink()
        except OSError:
            pass
    return out


# ------------------------------------------------------------------
# Le MEME MOMENT : sur les mots, pas sur les secondes
# ------------------------------------------------------------------
_norme = lambda w: re.sub(r"[^a-z0-9àâçéèêëîïôûùüÿœ]", "", str(w).lower())


def carte_temps(mots_ex, mots_nous, duree_ex, duree_nous):
    """Une fonction instant de l'exemple -> instant de notre video.

    Les deux videos disent (a peu pres) le meme texte : chaque mot commun
    est un point d'ancrage, dans l'ordre. Entre deux ancrages on avance au
    prorata. Sans assez de mots communs (un autre script, une autre
    langue), il ne reste que les deux bouts : tout se place au prorata."""
    a = [_norme(m[0]) for m in mots_ex]
    b = [_norme(m[0]) for m in mots_nous]
    pts = [(0.0, 0.0)]
    if a and b:
        sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
        for blk in sm.get_matching_blocks():
            # Un mot seul de trois lettres (« the », « you ») s'apparie
            # n'importe ou : il faut une suite, ou un mot qui pese.
            if blk.size >= 2 or (blk.size == 1 and len(a[blk.a]) >= 6):
                for k in range(blk.size):
                    te, tn = float(mots_ex[blk.a + k][1]), float(mots_nous[blk.b + k][1])
                    if te > pts[-1][0] + 0.01 and tn >= pts[-1][1]:
                        pts.append((te, tn))
    de, dn = max(duree_ex, pts[-1][0] + 0.01), max(duree_nous, pts[-1][1])
    pts.append((de, dn))

    def f(t):
        t = max(0.0, min(float(t), de))
        for (e0, n0), (e1, n1) in zip(pts, pts[1:]):
            if t <= e1:
                return n0 + (n1 - n0) * (t - e0) / max(1e-6, e1 - e0)
        return dn
    f.ancrages = len(pts) - 2
    return f


def poser(calque, mots_nous, total, larg, haut, tete=None):
    """Ou et quand poser chaque element dans NOTRE video de `total` secondes.
    -> [{element, t0, t1, x, y, l, h}] en secondes et en pixels de sortie.

    `tete(t0, t1)` : la fraction de la hauteur ou arrive le haut de NOTRE
    tete entre ces deux instants de la video (ou None). Un element qui
    descendrait sur le visage est remonte, et rapetisse s'il n'y a pas la
    place — on ne cadre jamais comme la personne de l'exemple. Les
    elements arrives ENSEMBLE (un logo et son slogan) bougent ensemble,
    sinon ils se retrouvent l'un sur l'autre."""
    els = [e for e in (calque or {}).get("elements") or [] if not e.get("off")]
    if not els or total <= 0:
        return []
    f = carte_temps(calque.get("mots") or [], mots_nous, float(calque.get("duree") or 0.0), total)
    vw, vh = float(calque.get("larg") or 1), float(calque.get("haut") or 1)
    HAUT_SUR = 0.075                 # au-dessus, l'interface de TikTok/Reels
    out = []
    for e in sorted(els, key=lambda z: z["t0"]):
        d = float(e["t1"]) - float(e["t0"])
        t0 = f(e["t0"])
        # Un film garde SA vitesse (son animation est dedans) : plus court
        # que sa place, sa derniere image tient ; plus long, il est coupe.
        t1 = max(t0 + min(d, 0.6), min(f(e["t1"]), t0 + d + 1.5))
        t0, t1 = max(0.0, t0), min(total, t1)
        if t1 - t0 < 0.25:
            continue
        out.append({"element": e, "t0": round(t0, 3), "t1": round(t1, 3),
                    "b": [e["px"][0] / vw, e["px"][1] / vh, e["px"][2] / vw, e["px"][3] / vh]})
    # Les groupes : arrives a moins de 0,4 s l'un de l'autre dans l'exemple.
    groupes = []
    for p in out:
        if groupes and abs(float(p["element"]["t0"]) - float(groupes[-1][0]["element"]["t0"])) <= 0.4:
            groupes[-1].append(p)
        else:
            groupes.append([p])
    for g in groupes:
        gy0 = min(p["b"][1] for p in g)
        gy1 = max(p["b"][1] + p["b"][3] for p in g)
        gx0 = min(p["b"][0] for p in g)
        gx1 = max(p["b"][0] + p["b"][2] for p in g)
        k, dy = 1.0, 0.0
        th = None
        if tete is not None:
            try:
                th = tete(min(p["t0"] for p in g), max(p["t1"] for p in g)) if callable(tete) else float(tete)
            except Exception:                                   # noqa: BLE001
                th = None
        if th is not None:
            # Jusqu'a 2 % sous le sommet du crane : des cheveux, pas le visage.
            bas = max(HAUT_SUR + 0.08, th + 0.02)
            if gy1 > bas:
                dispo = bas - HAUT_SUR
                if gy1 - gy0 > dispo:                      # pas la place : on rapetisse
                    k = dispo / (gy1 - gy0)
                dy = bas - (gy0 + (gy1 - gy0) * k)
        cx = (gx0 + gx1) / 2
        for p in g:
            x, y, l, h = p.pop("b")
            # L'echelle se fait autour du centre du groupe, en haut.
            x, y = cx + (x - cx) * k, gy0 + (y - gy0) * k + dy
            l, h = l * k, h * k
            p.update(x=int(round(x * larg)), y=int(round(y * haut)),
                     l=int(round(l * larg)) // 2 * 2, h=int(round(h * haut)) // 2 * 2)
    out = [p for p in out if p["l"] >= 8 and p["h"] >= 8]
    # Deux elements au meme endroit ne se recouvrent pas : le premier
    # s'efface quand le suivant arrive.
    for i, p in enumerate(out):
        for q in out[i + 1:]:
            croise = not (q["x"] >= p["x"] + p["l"] or p["x"] >= q["x"] + q["l"]
                          or q["y"] >= p["y"] + p["h"] or p["y"] >= q["y"] + q["h"])
            # (Arrives ENSEMBLE — un logo et son slogan — ils vont ensemble.)
            if croise and p["t0"] + 0.3 < q["t0"] < p["t1"]:
                p["t1"] = max(p["t0"] + 0.2, q["t0"])
    return out
