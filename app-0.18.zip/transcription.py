#!/usr/bin/env python3
"""
Sous-titres automatiques des clips parles.
------------------------------------------
La transcription est faite par whisper.cpp (`whisper-cli`, Homebrew:
`brew install whisper-cpp`), un programme externe comme ffmpeg — pas une
bibliotheque Python, la regle du zero dependance tient.

Un clip est transcrit UNE fois, en entier, puis mis en cache sur disque
(cle chemin|mtime|taille, comme le cache ffprobe). Un meme clip revient
dans des dizaines de variantes avec des decoupes differentes: on pioche
dans la transcription complete les mots qui tombent dans la fenetre.

Mesure (M2, modele large-v3): 8,9 s pour 7 s de voix, chargement du
modele compris. Payable une fois par clip, pas une fois par video.
"""

import audioop
import glob
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import threading
import wave
from pathlib import Path

from chemins import CODE, DONNEES as ROOT
CACHE_DIR = ROOT / ".transcriptions"
# Version du RECALAGE, pas de la transcription. Le cache garde les deux
# listes: `brut`, ce que whisper a dit, et `mots`, le resultat du recalage.
# Les deux, parce que le recalage est DESTRUCTIF — il coupe des fins et
# avance des debuts. Sans le brut, changer une regle de recalage ne pouvait
# que l'appliquer par-dessus le travail de la version precedente, et une
# passe trop agressive devenait irrattrapable sans tout retranscrire.
# Changer ce numero refait le recalage depuis `brut`, sans relancer whisper.
CACHE_V = 6

# Un modele depose dans `modeles/` passe devant ceux trouves ailleurs.
# Du plus precis au plus leger: on prend le premier present.
_MODELES = ("large-v3-turbo", "large-v3", "large-v2", "medium", "small", "base", "tiny")
_DOSSIERS = (ROOT / "modeles", CODE / "modeles",
             Path.home() / ".cache" / "whisper",
             Path.home() / ".cache" / "hyperframes" / "whisper" / "models",
             Path("/opt/homebrew/share/whisper-cpp"),
             Path("/usr/local/share/whisper-cpp"))

# Deux generations en parallele sur le meme clip ne le transcrivent qu'une
# fois: la seconde attend la premiere et lit le cache.
_verrou = threading.Lock()


def binaire():
    return shutil.which("whisper-cli")


def modele():
    trouves = []
    for d in _DOSSIERS:
        trouves += glob.glob(str(d / "ggml-*.bin"))
    for nom in _MODELES:
        for f in trouves:
            base = Path(f).stem[len("ggml-"):]
            # "large-v3" ne doit pas attraper "large-v3-turbo", ni une
            # variante anglais seul (".en") qui ne comprend pas le francais.
            if base == nom or base.startswith(nom + "-q"):
                return f
    return None


def disponible():
    return bool(binaire() and modele())


# LE MODELE TELECHARGEABLE, pour l'app installee : il ne voyage pas dans
# l'app (celui de la copie de travail, large-v3, pese 3 Go). On prend
# large-v3-turbo quantifie (q5_0) : ~570 Mo, et `modele()` le reconnait
# deja (« large-v3-turbo-q… »). Il va dans les DONNEES (`modeles/`), pas
# dans le code : une mise a jour ne doit pas le faire retelecharger.
MODELE_NOM = "ggml-large-v3-turbo-q5_0.bin"
MODELE_URL = ("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"
              + MODELE_NOM)


def telecharger_modele(progres=None):
    """-> chemin du modele. Ecrit dans un `.part` puis renomme : un
    telechargement coupe ne laisse jamais un faux modele que `modele()`
    prendrait pour un vrai."""
    import urllib.request
    adresse = os.environ.get("PLATEAU_MODELE_URL") or MODELE_URL
    nom = Path(adresse.split("?")[0]).name or MODELE_NOM
    d = ROOT / "modeles"
    d.mkdir(parents=True, exist_ok=True)
    dest, part = d / nom, d / (nom + ".part")
    req = urllib.request.Request(adresse, headers={"User-Agent": "Le-plateau"})
    with urllib.request.urlopen(req, timeout=60) as r, open(part, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        lu = 0
        while True:
            bloc = r.read(1 << 20)
            if not bloc:
                break
            f.write(bloc)
            lu += len(bloc)
            if progres and total:
                progres(lu / total)
    if total and lu != total:
        part.unlink()
        raise IOError("Téléchargement interrompu — réessaie")
    os.replace(part, dest)
    return str(dest)


def _cle(path):
    st = os.stat(path)
    return hashlib.sha1(f"{path}|{st.st_mtime}|{st.st_size}".encode()).hexdigest()[:20]


def en_boucle(liste):
    """Whisper a-t-il tourne en boucle ? Vrai si une meme suite de quatre
    mots ou plus revient au moins QUATRE fois d'affilee, mot pour mot. Une
    personne qui recommence sa phrase ne la redit jamais quatre fois a
    l'identique et sans rien d'autre entre ; la boucle, si (onze fois)."""
    w = [re.sub(r"[^\w']+", "", str(m[0]).lower()) for m in liste]
    w = [x for x in w if x]
    n = len(w)
    for L in range(4, 21):
        i = 0
        while i + 2 * L <= n:
            k = 1
            while i + (k + 1) * L <= n and w[i + k * L:i + (k + 1) * L] == w[i:i + L]:
                k += 1
            if k >= 4:
                return True
            i += 1
    return False


def mots(path, precis=False):
    """Mots prononces dans le clip: [(texte, debut_s, fin_s), ...].

    Liste vide si le clip n'a pas de voix, si whisper manque, ou si la
    transcription echoue: un clip sans sous-titres vaut mieux qu'une
    generation plantee.

    `precis` : on veut les mots dates PAR ELAN DE PAROLE (voir « LA PRISE
    D'UNE TRAITE » plus bas). Une transcription gardee d'avant, qui ne l'est
    pas, est alors refaite une fois ; ensuite tout le monde lit la meme."""
    try:
        cache = CACHE_DIR / (_cle(path) + ".json")
    except OSError:
        return []
    with _verrou:
        if cache.exists():
            try:
                d = json.loads(cache.read_text("utf-8"))
            except (ValueError, OSError):
                d = None
            # `isinstance` et non la verite du contenu: un clip muet donne
            # une liste VIDE, et la tester comme un booleen le faisait
            # retranscrire a chaque generation.
            # Une transcription EN BOUCLE gardee d'avant le correctif est
            # refaite, pas resservie (voir `en_boucle`).
            boucle = isinstance(d, dict) and en_boucle(d.get("mots") or d.get("brut") or [])
            vieux = precis and isinstance(d, dict) and not d.get("dtw") \
                and not _DTW_KO and disponible()
            if isinstance(d, dict) and d.get("v") == CACHE_V \
                    and isinstance(d.get("mots"), list) and not boucle and not vieux:
                return corriger(tuple(m) for m in d["mots"])
            brut = d.get("brut") if isinstance(d, dict) and not boucle and not vieux else None
            if isinstance(brut, list):
                # Regle de recalage changee: on refait le travail DEPUIS LE
                # BRUT, sans relancer whisper — ca ne coute qu'un decodage
                # audio (2,7 s pour 59 clips, mesure).
                if d.get("dtw") and d.get("elans"):
                    res = caler_elans([tuple(m) for m in brut], d["elans"])
                else:
                    res = caler(path, [tuple(m) for m in brut])
                _ecrire(cache, brut, res, bool(d.get("dtw")), d.get("elans"))
                return corriger(res)
            # Cache d'avant cette separation: le brut est perdu, il faut
            # vraiment retranscrire.
        if not disponible():
            return []
        res = _transcrire(path)
        if res is None:
            return []
        brut, cales, dtw, el = res
        CACHE_DIR.mkdir(exist_ok=True)
        _ecrire(cache, brut, cales, dtw, el)
        return corriger(cales)


def elans(path):
    """Les ELANS DE PAROLE du clip, mesures dans le son : [(debut, fin)] en
    secondes de la piste son. Gardes avec la transcription ; None si le clip
    n'a jamais ete transcrit « precis » ou n'a pas de dynamique lisible."""
    try:
        d = json.loads((CACHE_DIR / (_cle(path) + ".json")).read_text("utf-8"))
        el = d.get("elans") if isinstance(d, dict) and d.get("dtw") else None
        return [(float(a), float(b)) for a, b in el] if el else None
    except (OSError, ValueError, TypeError):
        return None


# Noms de marque que whisper ecorche. Corriges a la LECTURE, pas dans le
# cache: une regle ajoutee ici s'applique tout de suite a tous les clips
# deja transcrits, sans rien retranscrire.
#
# Entendu sur Replit colouring books: « repli.com », « replid.com »,
# « Ripley is so easy to connect with Shopify ». On vise les deformations
# proches (r + e/i/y + p + l + voyelle + d/t/k/c eventuel) mais PAS les vrais
# mots anglais voisins — « reply », « replay », « replied », « ripple » —
# sauf s'ils sont colles a « .com », ou le doute n'est plus permis.
_REPLIT = re.compile(r"^(r[eiy]p{1,2}l[iy]e?[dtkc]?|r[eiy]p{1,2}let|replit|ripley|ripli)$", re.I)
_REPLIT_COM = re.compile(r"^(r[eiy]p{1,2}l[a-z]{0,4})$", re.I)
_PAS_REPLIT = {"reply", "replay", "replied", "ripple", "replica", "replies"}


def _corriger_mot(w):
    m = re.match(r"^(\W*)(.*?)(\W*)$", w)
    avant, coeur, apres = m.groups()
    # « .com » colle au mot: la ponctuation de fin est apres lui.
    dom = re.match(r"^(.*?)\.com$", coeur, re.I)
    if dom and _REPLIT_COM.match(dom.group(1)):
        return f"{avant}replit.com{apres}"
    if coeur.lower() not in _PAS_REPLIT and _REPLIT.match(coeur):
        return f"{avant}Replit{apres}"
    return w


def corriger(liste):
    # Un « mot » sans lettre ni chiffre (« - » en tete de phrase chez
    # whisper) s'afficherait seul a l'ecran comme un sous-titre vide.
    return [(_corriger_mot(w), a, b) for w, a, b in liste if re.search(r"\w", w)]


def _ecrire(cache, brut, mots, dtw=False, elans=None):
    d = {"v": CACHE_V, "brut": brut, "mots": mots}
    if dtw:
        d["dtw"], d["elans"] = True, elans or []
    cache.write_text(json.dumps(d, ensure_ascii=False), "utf-8")


def en_cache(path):
    """Mots deja transcrits pour ce clip, ou None s'il ne l'a jamais ete.

    Ne lance RIEN: sert a l'affichage, qui ne doit pas bloquer l'ouverture
    d'une serie sur des minutes de transcription."""
    try:
        cache = CACHE_DIR / (_cle(path) + ".json")
        d = json.loads(cache.read_text("utf-8"))
        liste = d["mots"] if isinstance(d, dict) else d
        return corriger(tuple(m) for m in liste)
    except (OSError, ValueError, KeyError, TypeError):
        return None


def _transcrire(path):
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "voix.wav")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(path), "-vn",
                            "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", wav],
                           capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(wav):
            return [], []                # pas de piste audio: rien a dire
        # Dans une serie parlee TOUS les clips passent ici, y compris les
        # plans muets ou d'ambiance. Sur du quasi-silence whisper invente
        # du texte ("Sous-titres realises par la communaute d'Amara.org",
        # "Thank you."): on ne le lance meme pas.
        vol = subprocess.run(["ffmpeg", "-i", wav, "-af", "volumedetect", "-f", "null", "-"],
                             capture_output=True, text=True).stderr
        crete = re.search(r"max_volume: (-?[\d.]+) dB", vol)
        if crete and float(crete.group(1)) < -35:
            return [], []
        base = os.path.join(tmp, "t")
        # -l auto: la langue est detectee clip par clip (francais ou anglais).
        # `-mc 0` : SANS MEMOIRE DU TEXTE D'AVANT (25/11). Avec elle, whisper
        # peut tourner EN BOUCLE des qu'une phrase est redite : sur une prise
        # de 104 s ou la meme phrase etait recommencee quatre fois, il a ecrit
        # onze fois la suivante et n'a jamais entendu la fin — et tout le
        # nettoyage (reprises, silences) coupait sur un texte faux. Or une
        # prise « on the spot » est faite de phrases recommencees. `-sns` :
        # pas de jetons de bruit. Mesure sur cette prise : texte juste d'un
        # bout a l'autre, 22 s.
        cmd = [binaire(), "-m", modele(), "-f", wav, "-l", "auto",
               "-mc", "0", "-sns", "-ojf", "-of", base, "-np"]
        # D'abord avec l'ALIGNEMENT (`-dtw`, voir « LA PRISE D'UNE TRAITE »).
        # Un whisper qui ne connait pas l'option, ou un modele sans preset,
        # echoue : on le retient et on repart comme avant.
        global _DTW_KO
        data, dtw = None, False
        preset = None if _DTW_KO else _preset_dtw(modele())
        if preset:
            subprocess.run(cmd + ["-dtw", preset, "-nfa"], capture_output=True, text=True)
            try:
                data = json.loads(Path(base + ".json").read_text("utf-8"))
                dtw = any(t.get("t_dtw", -1) > 0 for sg in data.get("transcription", [])
                          for t in sg.get("tokens", []))
            except (OSError, ValueError):
                data = None
            if not dtw:
                _DTW_KO = True
        if data is None:
            subprocess.run(cmd, capture_output=True, text=True)
            try:
                data = json.loads(Path(base + ".json").read_text("utf-8"))
            except (OSError, ValueError):
                return None              # echec: pas de cache, on retentera
        # Le wav est encore la: on recale sans le redecoder. On renvoie
        # les DEUX listes, le brut sert a refaire le recalage plus tard.
        brut = _assembler_mots(data, dtw)
        if dtw:
            el = _elans_wav(wav)
            if el:
                return brut, caler_elans(brut, el), True, el
        return brut, caler(path, brut, wav=wav), False, None


# ------------------------------------------------------------------
# LA PRISE D'UNE TRAITE (25/11) : des mots dates par ELAN DE PAROLE
# ------------------------------------------------------------------
# Les dates que whisper donne a ses jetons sont fausses des qu'une phrase
# suit un blanc : sur une vraie prise de 104 s, huit mots de suite etaient
# dates au MEME instant (69,84 s) alors que la phrase dure six secondes.
# Couper les silences d'apres ces dates gardait un bout muet et mangeait
# des mots. Deux choses, reprises de la methode qui marche dans les
# montages faits a la main (decoupe sur les « elans », jamais sur l'ASR) :
#   - `-dtw` : whisper aligne chaque jeton sur le son (attention croisee).
#     C'est juste a 0,2-0,4 s pres — assez pour savoir DANS QUEL elan
#     tombe un mot, pas pour couper au ras d'une syllabe ;
#   - les ELANS : les passages ou il y a vraiment de la voix, mesures dans
#     le son (seuil pris sur les percentiles du clip). Ce sont EUX qui
#     donnent les bords : le premier mot d'un elan commence avec lui, le
#     dernier finit avec lui, ceux du milieu gardent l'ordre et l'ecart de
#     l'alignement.
# Mesure sur cette prise : « And you can use those stats to rip » retrouve
# 70,2-71,8 s (la voix y est), « collectible card packs… » 72,6-76,4 s.
_DTW_KO = False
_PRESETS_DTW = (("large-v3-turbo", "large.v3.turbo"), ("large-v3", "large.v3"),
                ("large-v2", "large.v2"), ("large-v1", "large.v1"),
                ("medium", "medium"), ("small", "small"), ("base", "base"), ("tiny", "tiny"))


def _preset_dtw(chemin):
    nom = Path(str(chemin)).name.lower()
    for cle, preset in _PRESETS_DTW:
        if cle in nom:
            return preset + (".en" if ".en" in nom and not preset.startswith("large") else "")
    return None


ELAN_PAS = 0.01       # trame de 10 ms
ELAN_TROU = 0.12      # un creux plus court ne separe pas deux elans
ELAN_MINI = 0.35      # un elan plus court se colle au suivant


def _elans_wav(wav_path):
    """[(debut, fin)] des passages de voix du wav, ou [] (pas de dynamique)."""
    try:
        w = wave.open(str(wav_path))
    except (OSError, wave.Error):
        return []
    try:
        largeur, canaux = w.getsampwidth(), w.getnchannels()
        n = int(w.getframerate() * ELAN_PAS)
        db = []
        while True:
            bloc = w.readframes(n)
            if len(bloc) < n * largeur * canaux:
                break
            db.append(20 * math.log10(audioop.rms(bloc, largeur) + 1))
    except (wave.Error, audioop.error):
        return []
    finally:
        w.close()
    if len(db) < 30:
        return []
    tri = sorted(db)
    p15, p90 = tri[int(len(tri) * 0.15)], tri[int(len(tri) * 0.90)]
    if p90 - p15 < 8:
        return []
    # Le seuil des montages faits a la main : 8 dB au-dessus du plancher,
    # sans jamais descendre a plus de 26 dB sous la voix.
    seuil = max(p15 + 8, p90 - 26)
    bruts, i = [], 0
    while i < len(db):
        if db[i] > seuil:
            j = i
            while j < len(db) and db[j] > seuil:
                j += 1
            bruts.append([i * ELAN_PAS, j * ELAN_PAS])
            i = j
        else:
            i += 1
    out = []
    for r in bruts:
        if out and (r[0] - out[-1][1] < ELAN_TROU
                    or (out[-1][1] - out[-1][0] < ELAN_MINI and r[0] - out[-1][1] < 0.3)):
            out[-1][1] = r[1]
        else:
            out.append(r)
    # Un clic isole (moins de 60 ms) n'est pas de la voix.
    return [(round(a, 2), round(b, 2)) for a, b in out if b - a >= 0.06]


def elan_de(t, el):
    """L'indice de l'elan ou tombe l'instant `t` (le plus proche sinon)."""
    best, d = 0, None
    for k, (a, b) in enumerate(el):
        if a - 0.02 <= t <= b + 0.02:
            return k
        # Un mot date dans un blanc : l'alignement est en avance plus
        # souvent qu'en retard, on penche vers l'elan qui SUIT.
        e = (a - t) * 0.6 if t < a else (t - b)
        if d is None or e < d:
            best, d = k, e
    return best


def caler_elans(mots, el):
    """Recale des mots alignes (`-dtw`) sur les elans de parole."""
    mots = [tuple(m) for m in mots]
    if not mots or not el:
        return mots
    idx, k = [], 0
    for _w, a, _b in mots:
        k = max(k, elan_de(a, el))          # jamais en arriere
        idx.append(k)
    out = list(mots)
    i = 0
    while i < len(mots):
        j = i
        while j + 1 < len(mots) and idx[j + 1] == idx[i]:
            j += 1
        ea, eb = el[idx[i]]
        s = [mots[n][1] for n in range(i, j + 1)]
        q = min(0.5, 0.06 * len(mots[j][0]) + 0.12)        # place du dernier mot
        A = ea if s[0] - ea <= 0.7 else min(s[0], eb - 0.1)
        if j == i:
            t = [max(ea, min(A, eb - 0.05))]
        elif s[-1] - s[0] < 0.05:
            # Tous dates au meme instant : on les etale selon leur longueur.
            poids = [len(mots[n][0]) + 1 for n in range(i, j + 1)]
            tot, acc, t = float(sum(poids)), 0.0, []
            for pds in poids:
                t.append(A + (eb - A) * acc / tot)
                acc += pds
        else:
            T = max(A + 0.08 * (j - i), min(max(s[-1], A), eb - q))
            T = min(T, max(A, eb - 0.05))
            t = [A + (x - s[0]) * (T - A) / (s[-1] - s[0]) for x in s]
        for m, n in enumerate(range(i, j + 1)):
            fin = t[m + 1] if m + 1 < len(t) else eb
            out[n] = (mots[n][0], round(t[m], 3), round(max(fin, t[m] + 0.04), 3))
        i = j + 1
    return out


# ------------------------------------------------------------------
# LA DICTEE (23/11) : parler au monteur au lieu de lui ecrire
# ------------------------------------------------------------------
# Le micro du navigateur enregistre, whisper — deja la pour les
# sous-titres — transcrit SUR LA MACHINE. Pas la reconnaissance vocale du
# navigateur : celle de Chrome envoie la voix chez Google, Firefox n'en a
# pas, et on a deja l'outil. Le francais est IMPOSE (`-l fr`) : en
# detection automatique, une phrase quebecoise pleine de « hook », « clip »
# et « split screen » partait une fois sur deux en anglais. L'amorce donne
# a whisper les mots du metier, qu'il ecrit sinon de travers.
DICTEE_AMORCE = ("Montage vidéo : le hook, l'accroche, le clip, le split screen, les "
                 "sous-titres, un zoom, une transition, la musique, l'étape, la réaction, "
                 "le texte à l'écran, la vidéo exemple.")


def dicter(path):
    """Ce qui a ete DIT dans cet enregistrement -> texte ("" si rien
    d'audible). None si whisper a echoue."""
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "voix.wav")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(path), "-vn",
                            "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", wav],
                           capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(wav):
            return None
        vol = subprocess.run(["ffmpeg", "-i", wav, "-af", "volumedetect", "-f", "null", "-"],
                             capture_output=True, text=True).stderr
        crete = re.search(r"max_volume: (-?[\d.]+) dB", vol)
        if crete and float(crete.group(1)) < -45:
            return ""                    # micro coupe ou personne n'a parle
        base = os.path.join(tmp, "t")
        subprocess.run([binaire(), "-m", modele(), "-f", wav, "-l", "fr", "-nt", "-np",
                        "-otxt", "-of", base, "--prompt", DICTEE_AMORCE],
                       capture_output=True, text=True)
        try:
            texte = Path(base + ".txt").read_text("utf-8")
        except OSError:
            return None
    lignes = [x.strip() for x in texte.splitlines() if x.strip()]
    lignes = [x for x in lignes if not _BRUIT.match(x)
              and not any(h in x.lower() for h in _HALLUCINATIONS)]
    return re.sub(r"\s+", " ", " ".join(lignes)).strip()


# Ce que whisper invente sur du silence ou de la musique.
_BRUIT = re.compile(r"^[\[\(\*♪].*|^(\.\.\.)$")
_HALLUCINATIONS = ("amara.org", "sous-titr", "thank you for watching",
                   "merci d'avoir regard", "abonnez-vous",
                   # Sur une video de musique seule (25/11, un exemple de 14 s) :
                   # « Субтитры сделал DimaTorzok », la signature d'un sous-
                   # titreur russe que whisper a apprise. Ses cousines aussi.
                   "субтитр", "dimatorzok", "продолжение следует",
                   "subtítulos", "untertitel", "字幕")


def _assembler_mots(data, dtw=False):
    """Tokens whisper -> mots entiers.

    Whisper decoupe en sous-mots: " repl" + "it", " minutes" + ".". Un
    token sans espace initial se colle au mot precedent."""
    out = []
    for seg in data.get("transcription", []):
        texte = seg.get("text", "").lower()
        if any(h in texte for h in _HALLUCINATIONS):
            continue
        # Un segment dont whisper lui-meme doute (probabilite moyenne des
        # tokens sous 0,4) est presque toujours du bruit ou de la musique.
        ps = [t.get("p", 1) for t in seg.get("tokens", []) if not t.get("text", "").startswith("[_")]
        if ps and sum(ps) / len(ps) < 0.4:
            continue
        for t in seg.get("tokens", []):
            txt = t.get("text", "")
            if txt.startswith("[_") or not txt.strip():
                continue                 # marqueurs internes ([_BEG_], [_TT_...])
            a = t["offsets"]["from"] / 1000.0
            b = t["offsets"]["to"] / 1000.0
            if dtw and t.get("t_dtw", -1) >= 0:
                # L'instant ALIGNE du jeton, et jamais avant le mot d'avant.
                a = max(t["t_dtw"] / 100.0, out[-1][1] if out else 0.0)
                b = a
            if out and not txt.startswith(" "):
                w = out[-1]
                out[-1] = [w[0] + txt, w[1], max(w[2], b)]
            else:
                out.append([txt.strip(), a, b])
    return [(w, round(a, 3), round(b, 3)) for w, a, b in out
            if w and not _BRUIT.match(w)]


# Fenetre d'affichage d'un sous-titre. Mesure sur un clip reel (« Bro, I
# genuinely can't... »): l'ancienne regle — tenir chaque bloc jusqu'au
# DEBUT du suivant, plus une demi-seconde sur le dernier — laissait le mot
# a l'ecran 0,10 a 0,15 s apres qu'il soit dit, et une demi-seconde apres
# la derniere syllabe. Pire, le rattrapage des mots de duree nulle
# DECALAIT le mot suivant: « genuinely » s'affichait 0,12 s en retard,
# et le retard se voit tout de suite.
#
# La regle est maintenant: on tient le mot, rien de plus.
TENUE = 0.15     # trou comble entre deux mots: en dessous, un blanc clignote
QUEUE = 0.08     # de quoi ne pas couper la derniere image du mot
MINI = 0.08      # en dessous, whisper n'a pas su dater le mot: on ne l'affiche pas


# ------------------------------------------------------------------
# Recaler les mots sur le son reellement present
# ------------------------------------------------------------------
# Un mot date APRES un silence commence souvent au debut du SILENCE et non
# a la premiere syllabe: whisper pose le premier mot d'un segment au debut
# de ce segment, et un segment demarre la ou le precedent s'est arrete. Le
# sous-titre restait donc affiche pendant tout le silence — et quand deux
# mots tombaient dedans, il changeait au milieu du silence.
#
# On ne corrige QUE ce cas: un mot dont le debut tombe dans un vrai blanc.
# Deplacer tous les mots sur l'energie ferait pire — une consonne douce
# (« f », « s ») demarre sous le seuil et le mot partirait en retard.
PAS = 0.02            # trame d'analyse, 20 ms
# DEUX seuils, et c'est le coeur de l'affaire. Un seul, place assez haut
# pour reconnaitre une attaque de voix, voyait du silence entre deux
# syllabes: tous les mots se faisaient couper a 0,16 s et les sous-titres
# clignotaient. Un seul, place assez bas pour ne pas confondre, ne trouvait
# plus le debut d'un mot. Donc:
#   PAROLE   haut  — « ca, c'est une attaque » : sert a POSER un debut
#   SILENCE  bas   — « la, il n'y a vraiment rien » : sert a COUPER
# Les deux seuils sont pris en DECIBELS et sur des PERCENTILES, jamais sur
# le pic. Premiere version: une fraction de (pic - plancher), en lineaire.
# Un seul cri dans le clip faisait exploser le pic, le seuil montait avec,
# et les creux normaux de la voix passaient pour du silence: tous les mots
# se faisaient couper a 0,16 s et les sous-titres clignotaient.
# En dB et entre p10 et p90, la dynamique d'un clip tient dans 20 a 25 dB
# quel que soit son niveau, et un cri isole ne deplace plus rien.
#
#   SILENCE  bas  — « la, il n'y a vraiment rien » : sert a COUPER
#   PAROLE   haut — « ca, c'est une attaque »      : sert a POSER un debut
PAS = 0.02            # trame d'analyse, 20 ms
PART_SILENCE = 0.20   # de p10 vers p90, en dB
PART_PAROLE = 0.50
BLANC_DEBUT = 0.25    # blanc avant un mot au-dela duquel sa date est fausse
BLANC_FIN = 0.35      # blanc dans un mot au-dela duquel on coupe


def _enveloppe(wav_path):
    """(energie en dB par trame, seuil de silence, seuil de parole)."""
    try:
        w = wave.open(str(wav_path))
    except (OSError, wave.Error):
        return None, 0, 0
    try:
        largeur, canaux = w.getsampwidth(), w.getnchannels()
        n = int(w.getframerate() * PAS)
        rms = []
        while True:
            bloc = w.readframes(n)
            if len(bloc) < n * largeur * canaux:
                break
            rms.append(20 * math.log10(audioop.rms(bloc, largeur) + 1))
    except (wave.Error, audioop.error):
        return None, 0, 0
    finally:
        w.close()
    if len(rms) < 10:
        return None, 0, 0
    tri = sorted(rms)
    bas, haut = tri[int(len(tri) * 0.10)], tri[int(len(tri) * 0.90)]
    # Un clip sans dynamique (bruit constant, musique de fond forte) ne
    # donne aucun repere fiable: on prefere ne rien deplacer du tout.
    if haut - bas < 8:
        return None, 0, 0
    ecart = haut - bas
    return rms, bas + ecart * PART_SILENCE, bas + ecart * PART_PAROLE


def caler(path, mots, wav=None):
    """Recale les mots sur le son reellement present.

    Deux corrections, et seulement celles-la:
      - un mot dont le debut tombe dans un vrai blanc est AVANCE jusqu'a la
        premiere attaque (jamais recule, jamais reordonne);
      - un mot dont la fenetre contient un vrai blanc s'arrete a ce blanc.
    Tout le reste est laisse tel quel: sur de la voix continue whisper date
    juste, c'est mesure (ecart median nul contre l'enveloppe du son)."""
    mots = [tuple(m) for m in mots]
    if not mots:
        return mots
    tmp = None
    try:
        if wav is None:
            tmp = tempfile.mkdtemp()
            wav = os.path.join(tmp, "v.wav")
            r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(path), "-vn",
                                "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", wav],
                               capture_output=True)
            if r.returncode != 0 or not os.path.exists(wav):
                return mots
        rms, s_silence, s_parole = _enveloppe(wav)
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
    if not rms:
        return mots

    def muet(i):
        return 0 <= i < len(rms) and rms[i] < s_silence

    def attaque(i):
        return 0 <= i < len(rms) and rms[i] >= s_parole

    out = []
    for n, (w, a, b) in enumerate(mots):
        i = int(a / PAS)
        if muet(i):
            # Depuis quand est-ce vraiment muet ? Un creux entre deux
            # syllabes ne compte pas.
            j = i
            while j > 0 and muet(j - 1):
                j -= 1
            if (i - j) * PAS >= BLANC_DEBUT or j == 0:
                # Premiere attaque, sans depasser la fin du mot ni le debut
                # du suivant: on ne reordonne jamais les mots.
                limite = int(min(b, mots[n + 1][1] if n + 1 < len(mots) else b) / PAS)
                k = i
                while k < limite and not attaque(k):
                    k += 1
                if attaque(k):
                    a = round(k * PAS, 3)
        # Whisper etire parfois un mot jusqu'au bord de son segment. Mesure
        # sur un clip reel: « My » occupait 0,00 -> 7,14 s, sept secondes de
        # sous-titre pour un mot d'une syllabe. On coupe au premier vrai
        # blanc apres le debut: ca traite d'un coup la queue muette et le
        # silence avale au milieu. Pas de duree minimale ici — un mot reduit
        # a rien est un mot que whisper a invente, `morceaux` l'ecartera.
        # Si la coupe ne laisse rien, ce n'est pas la fin qui est fausse,
        # c'est le DEBUT: whisper a date le mot avant qu'il soit dit, mais
        # dans une zone pas tout a fait silencieuse (le test d'avant ne l'a
        # donc pas vu). On cherche l'attaque suivante et on recommence —
        # trois essais, apres quoi le mot est vraiment introuvable.
        for _ in range(3):
            creux, suite = None, 0
            for k in range(int(a / PAS), int(b / PAS)):
                if not muet(k):
                    suite = 0
                else:
                    suite += 1
                    if suite * PAS >= BLANC_FIN:
                        creux = k - suite + 1
                        break
            if creux is None:
                break
            if creux * PAS - a >= MINI:
                b = round(creux * PAS, 3)
                break
            k = creux
            limite = int(b / PAS)
            while k < limite and not attaque(k):
                k += 1
            if not attaque(k):
                b = round(creux * PAS, 3)
                break
            a = round(k * PAS, 3)
        out.append((w, a, max(b, a)))
    return out


def morceaux(liste, max_mots=1, max_car=16, pause=0.4):
    """Groupe les mots en sous-titres, facon TikTok.

    UN mot a la fois par defaut: c'est le rendu demande (reference: un
    Reel ou chaque mot s'affiche seul, centre). Avec max_mots > 1, coupe
    aussi a la ponctuation, aux pauses et quand le bloc depasse une ligne.

    `liste` = [(texte, debut, fin)] deja ramene au temps de SORTIE du clip.
    Renvoie [(texte, debut, fin)].

    AUCUN mot n'est jamais decale: son debut est celui que donne la
    transcription, point. Un mot que whisper date sur une duree plus
    courte qu'une image n'est pas affiche — le voler au mot suivant
    mettait toute la suite en retard, et un mot manquant de temps en temps
    coute moins cher qu'un sous-titre qui traine."""
    blocs, cur = [], []
    for m in liste:
        if cur:
            txt = " ".join(x[0] for x in cur + [m])
            if (len(cur) >= max_mots or len(txt) > max_car
                    or m[1] - cur[-1][2] > pause
                    or cur[-1][0][-1:] in ".!?,;:"):
                blocs.append(cur)
                cur = []
        cur.append(m)
    if cur:
        blocs.append(cur)

    out = []
    for i, b in enumerate(blocs):
        debut, fin = b[0][1], b[-1][2]
        suivant = blocs[i + 1][0][1] if i + 1 < len(blocs) else None
        if suivant is not None and suivant - fin <= TENUE:
            # Trou trop court pour qu'un blanc se voie autrement que comme
            # un clignotement: on tient jusqu'au mot suivant.
            fin = suivant
        else:
            # Vraie pause: le sous-titre s'efface avec la voix.
            fin += QUEUE
            if suivant is not None:
                fin = min(fin, suivant)
        texte = " ".join(x[0] for x in b).rstrip(".,;:")
        if texte and fin - debut >= MINI:
            out.append((texte, round(debut, 3), round(fin, 3)))
    return out
