"""L'IA du plateau — Claude Code, celui qui est DEJA sur la machine.

Pas de cle d'API ni de SDK: on appelle le programme `claude` comme on
appelle `ffmpeg` ou `whisper-cli`. Il passe par le compte Claude de la
personne (son abonnement), et la regle « zero dependance » tient: rien a
installer cote Python.

Mesure le 09/11 sur le Mac de Tilio: une image + une question, 3,9 s de
bout en bout, reponse JSON validee par un schema. Ce qui coute ce temps,
c'est le DEMARRAGE de Claude Code, pas la reponse: on regroupe donc les
questions (un appel pour trier six clips, pas six appels).

Trois choix qui comptent, tous dans `demander`:
  --system-prompt   remplace le prompt de Claude Code (~20 000 jetons) par
                    le notre (~300). Sans ca, chaque question puisait dans
                    les limites de l'abonnement pour rien.
  --tools ""        aucun outil: Claude ne lit pas le disque, ne lance
                    rien. Il regarde ce qu'on lui donne et repond.
  --setting-sources "" et un dossier de travail neutre: le CLAUDE.md du
                    projet et celui de l'utilisateur ne sont pas charges —
                    ils parlent a un developpeur, pas a l'assistant.
Les images partent DANS le message (`--input-format stream-json`), en
base64: pas besoin d'ouvrir l'outil de lecture de fichiers, et pas de
tour de boucle par image.
"""
import base64
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path


class IAError(Exception):
    pass


# Ou chercher `claude` quand le PATH du serveur ne le voit pas: lance
# depuis le Finder (un .command), le PATH est celui de launchd, sans
# ~/.local/bin.
CANDIDATS = ("~/.local/bin/claude", "~/.local/bin/claude.exe",
             "~/AppData/Roaming/npm/claude.cmd", "/opt/homebrew/bin/claude",
             "/usr/local/bin/claude", "~/.claude/local/claude")

# Deux modeles, choisis par tache. Haiku pour le tri et les questions:
# rapide, et ca menage les limites de l'abonnement. Sonnet pour monter une
# campagne: un seul appel, et c'est lui qui decide de toute la recette.
RAPIDE = "haiku"
SOIGNE = "sonnet"

SYSTEME = (
    "Tu es l'assistant du plateau, une app locale de création de vidéos UGC "
    "(TikTok, Reels). Tu parles français québécois simple, direct, sans "
    "jargon technique: l'utilisateur n'est pas développeur. Tu ne promets "
    "jamais une fonction qui n'existe pas dans le plateau.")

# Taille des images envoyees. 360 px de large suffisent pour reconnaitre
# un plan et lire un texte a l'ecran, et une image de 360 x 640 coute
# ~300 jetons: trente plans tiennent dans un seul message.
LARGEUR = 360


def binaire():
    b = shutil.which("claude")
    if b:
        return b
    for c in CANDIDATS:
        p = Path(os.path.expanduser(c))
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    return None


def disponible():
    """(oui/non, raison). Ne lance rien: savoir si Claude Code est
    CONNECTE coute un appel, on l'apprend au premier vrai."""
    if not binaire():
        return False, ("Claude Code n'est pas installé sur cet ordinateur "
                       "(claude.com/claude-code)")
    return True, ""


def _neutre():
    d = Path(tempfile.gettempdir()) / "plateau-ia"
    d.mkdir(exist_ok=True)
    return str(d)


def demander(texte, images=(), schema=None, modele=RAPIDE, systeme=None,
             delai=300):
    """Une question a Claude. `images` = [(legende, octets jpeg)], posees
    AVANT le texte, chacune precedee de sa legende: « Plan 3 (2,4 s) »
    ne se devine pas sur l'image. Rend le JSON valide par `schema`, ou le
    texte de la reponse sans schema."""
    b = binaire()
    if not b:
        raise IAError(disponible()[1])
    contenu = []
    for legende, octets in images:
        if not octets:
            continue
        if legende:
            contenu.append({"type": "text", "text": legende})
        contenu.append({"type": "image", "source": {
            "type": "base64", "media_type": "image/jpeg",
            "data": base64.b64encode(octets).decode()}})
    contenu.append({"type": "text", "text": texte})
    msg = {"type": "user", "message": {"role": "user", "content": contenu}}
    cmd = [b, "-p", "--output-format", "stream-json", "--verbose",
           "--input-format", "stream-json", "--model", modele,
           "--system-prompt", systeme or SYSTEME,
           "--tools", "", "--setting-sources", "", "--strict-mcp-config",
           "--no-session-persistence"]
    if schema:
        cmd += ["--json-schema", json.dumps(schema)]
    try:
        p = subprocess.run(cmd, input=json.dumps(msg) + "\n", text=True,
                           capture_output=True, timeout=delai, cwd=_neutre())
    except subprocess.TimeoutExpired:
        raise IAError("Claude n'a pas répondu à temps — réessaie")
    fin = None
    for ligne in p.stdout.splitlines():
        try:
            d = json.loads(ligne)
        except ValueError:
            continue
        if d.get("type") == "result":
            fin = d
    if not fin:
        err = (p.stderr or p.stdout or "").strip()[-300:]
        raise IAError(_traduire(err) or "Claude Code n'a rien répondu")
    if fin.get("is_error"):
        raise IAError(_traduire(str(fin.get("result") or "")) or "Erreur de Claude Code")
    if schema:
        so = fin.get("structured_output")
        if so is None:
            try:
                so = json.loads(fin.get("result") or "")
            except ValueError:
                raise IAError("Réponse de Claude illisible — réessaie")
        return so
    return (fin.get("result") or "").strip()


def _traduire(err):
    """Les erreurs de Claude Code qu'on sait expliquer."""
    e = err.lower()
    if "login" in e or "api key" in e or "authenticat" in e or "oauth" in e:
        return ("Claude Code n'est pas connecté. Ouvre le Terminal, tape "
                "« claude », connecte-toi, puis réessaie.")
    if "usage limit" in e or "rate limit" in e or "limit reached" in e:
        return ("Limite de ton abonnement Claude atteinte pour l'instant — "
                "réessaie plus tard.")
    return err


# ------------------------------------------------------------------
# Images d'une video
# ------------------------------------------------------------------
def image(chemin, t, largeur=LARGEUR):
    """Une image du film a l'instant `t`, en JPEG."""
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t):.3f}", "-i", str(chemin),
         "-frames:v", "1", "-vf", f"scale={largeur}:-2",
         "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "5", "pipe:1"],
        capture_output=True)
    return p.stdout or None


def duree(chemin):
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "format=duration", "-of", "csv=p=0", str(chemin)],
                       capture_output=True, text=True)
    try:
        return float(p.stdout.strip())
    except ValueError:
        return 0.0


_SCD = re.compile(r"lavfi\.scd\.time:\s*([0-9.]+)")
# Memes reglages que l'atelier des templates (template.py, qui n'est pas
# dans la copie partagee — d'ou cette version a part): seuil 10 mesure sur
# des reels montes a la main, et un plan de moins de 0,25 s est un flash.
COUPE_SEUIL = 10.0
PLAN_MINI = 0.25
# Pour l'IA, le seuil est PLUS BAS que celui des templates. Un UGC filme
# souvent un ECRAN puis un autre ecran : la coupe change peu de pixels. Sur
# la reference TrueCurrent (« No way I've traded… »), deux des cinq coupes
# mesuraient 9,8 et 7,9 : a 10, la video sortait en 4 plans au lieu de 6.
# Une coupe en trop ne coute rien (Claude regroupe deux plans qui montrent
# la meme chose) ; une coupe manquee fond deux categories en une.
COUPE_SEUIL_IA = 5.0
# Au-dela, la video exemple est un tuto de dix minutes, pas un reel: on ne
# montre a Claude que les premiers plans.
PLANS_MAX = 30


def plans(chemin):
    """[(debut, fin)] de chaque plan de la video exemple."""
    fin = duree(chemin)
    if fin <= 0:
        raise IAError("La vidéo exemple est illisible")
    p = subprocess.run(["ffmpeg", "-v", "info", "-i", str(chemin), "-vf",
                        f"scdet=threshold={COUPE_SEUIL_IA}", "-f", "null", "-"],
                       capture_output=True, text=True)
    cs = sorted({round(float(t), 3) for t in _SCD.findall(p.stderr)})
    bornes = [0.0] + [t for t in cs if 0 < t < fin] + [fin]
    out = []
    for a, b in zip(bornes, bornes[1:]):
        if out and (b - a) < PLAN_MINI:
            out[-1] = (out[-1][0], b)
        else:
            out.append((a, b))
    if len(out) > 1 and out[0][1] - out[0][0] < PLAN_MINI:
        out[1] = (out[0][0], out[1][1])
        out.pop(0)
    return [(round(a, 3), round(b, 3)) for a, b in out][:PLANS_MAX]


# ------------------------------------------------------------------
# Monter une campagne depuis un brief et une video exemple
# ------------------------------------------------------------------
SCHEMA_CAMPAGNE = {
    "type": "object", "additionalProperties": False,
    "required": ["resume", "campagne", "serie", "tournage", "questions"],
    "properties": {
        "resume": {"type": "string"},
        "campagne": {
            "type": "object", "additionalProperties": False,
            "required": ["nom", "plateformes", "objectif_jour", "paie_par_video",
                         "cycle_paie", "base_pay", "cpm", "frequence", "notes"],
            "properties": {
                "nom": {"type": "string"},
                "plateformes": {"type": "array", "items": {
                    "type": "string", "enum": ["ig", "tt", "yt", "fb"]}},
                "objectif_jour": {"type": "integer"},
                "paie_par_video": {"type": "number"},
                "cycle_paie": {"type": "string", "enum": ["", "hebdo", "2sem", "mensuel"]},
                "base_pay": {"type": "string"},
                "cpm": {"type": "string"},
                "frequence": {"type": "string"},
                "notes": {"type": "string"}}},
        "serie": {
            "type": "object", "additionalProperties": False,
            "required": ["nom", "format", "parle", "categories"],
            "properties": {
                "nom": {"type": "string"},
                "format": {"type": "string", "enum": ["plein", "split"]},
                "parle": {"type": "boolean"},
                "categories": {"type": "array", "items": {
                    "type": "object", "additionalProperties": False,
                    "required": ["nom", "role", "plans", "duree", "delta",
                                 "texte", "position", "son", "complet", "consigne"],
                    "properties": {
                        "nom": {"type": "string"},
                        "role": {"type": "string", "enum": ["", "haut", "bas", "etape"]},
                        "plans": {"type": "array", "items": {"type": "integer"}},
                        "duree": {"type": "number"},
                        "delta": {"type": "number"},
                        "texte": {"type": "string"},
                        "position": {"type": "string", "enum": ["haut", "milieu", "bas"]},
                        "son": {"type": "boolean"},
                        "complet": {"type": "boolean"},
                        "consigne": {"type": "string"}}}}}},
        "tournage": {"type": "array", "items": {"type": "string"}},
        "questions": {"type": "array", "items": {"type": "string"}},
    }}

CONSIGNES_CAMPAGNE = """\
Monte une campagne du plateau à partir du BRIEF du client et de la VIDÉO EXEMPLE
(ses plans sont au-dessus, une image par plan, avec leur durée).

Comment le plateau fabrique les vidéos: une SÉRIE est une suite de CATÉGORIES.
Chaque catégorie est un dossier de clips interchangeables que l'utilisateur
filme; à chaque vidéo, le plateau tire UN clip par catégorie, le coupe à la
durée de la catégorie, et pose le texte de la catégorie par-dessus. Des dizaines
de variantes sortent ainsi des mêmes clips.

Règles:
- Une catégorie = un plan. Regroupe deux plans consécutifs (« plans » liste
  leurs numéros) SEULEMENT si c'est la même prise coupée en deux : même cadre,
  même écran. Deux écrans différents de l'app, même filmés pareil, sont deux
  catégories : on doit pouvoir filmer chacun à part. Garde l'ordre.
- « duree » = la durée du plan dans l'exemple (somme si plusieurs plans), en
  secondes. « delta » = la variation permise, 0,2 par défaut (0 si le plan doit
  durer exactement ça, par exemple calé sur la musique).
- « texte » = le texte à l'écran du plan, RÉÉCRIT pour le produit du brief si
  l'exemple parle d'autre chose, en gardant le ton et la longueur. Garde la
  LANGUE des textes de l'exemple (le public visé est le même), sauf si le
  brief en demande une autre. Saut de ligne: « | ». Vide s'il n'y a pas de
  texte.
- « position » = où est le texte (haut, milieu, bas).
- « son » = vrai seulement si on doit entendre le son du clip (quelqu'un qui
  parle, une réaction). Sinon la musique remplace le son.
- « complet » = vrai si le clip doit passer en entier (une démo d'app, un
  enregistrement d'écran), faux sinon.
- « consigne » = ce que l'utilisateur doit FILMER pour cette catégorie, en une
  ou deux phrases concrètes (cadrage, action, expression, durée à filmer — un
  peu plus long que « duree », pour laisser du choix). Pas de consigne vague.
- « parle » = vrai si la vidéo repose sur quelqu'un qui parle à la caméra
  (sous-titres automatiques).
- FORMAT « split »: seulement si l'exemple montre DEUX vidéos empilées (une en
  haut, une en bas) avec une bande de texte entre les deux. Alors: d'abord les
  plans plein cadre (role ""), puis une ou plusieurs catégories role « haut »,
  UNE catégorie role « bas », et les textes de la bande en catégories role
  « etape » (texte + durée, sans clip, consigne vide). Sinon format « plein »
  et role "" partout.
- Le nom des catégories est court (2-4 mots) et dit ce qu'on y voit.
- « plateformes » = où le deal exige de POSTER, d'après le brief et le
  contrat: ig = Instagram, tt = TikTok, yt = YouTube (Shorts), fb = Facebook.
  Seulement celles qui sont demandées (« Instagram only » → ["ig"]). Si rien
  n'est dit, liste vide et mets la question dans « questions ».
- Si un CONTRAT suit le brief, il fait foi sur la paie, le rythme et les
  plateformes quand les deux ne disent pas la même chose.
- CAMPAGNE: nom du client/produit; « objectif_jour » = vidéos par jour exigées
  par le brief (0 si rien n'est dit); la paie seulement si le brief la donne
  (0 / "" sinon). « notes » = les règles du client à ne pas oublier (interdits,
  mots à dire, hashtags, mentions), en lignes courtes.
- « tournage » = la liste de tournage, dans l'ordre: une ligne par chose à
  filmer, avec le nombre de prises conseillé (au moins 3 par catégorie pour que
  les vidéos varient).
- « questions » = ce que le brief ne dit pas et qu'il faudrait demander au
  client (vide si rien).
- « resume » = deux phrases: ce que montre la vidéo exemple et l'idée à garder.
"""


# Sans video exemple, la campagne se monte sur le brief seul: la forme
# d'un UGC qui marche est assez connue pour partir d'elle, et l'exemple
# arrive souvent apres le brief (« je t'envoie une ref demain »). Il
# remplacera ces categories quand il arrivera (`/api/series/<id>/exemple`).
SANS_EXEMPLE = """
PAS DE VIDÉO EXEMPLE pour l'instant. Monte la série d'après le BRIEF seul :
la forme d'un UGC court qui marche sur TikTok/Reels pour ce produit (en
général : une accroche de 1 à 2 s, le problème ou la situation, la démo du
produit, le résultat, un appel à l'action), 4 à 7 catégories, des durées
typiques de ce format, « plans » vide partout, format « plein » sauf si le
brief décrit un split screen. Les textes à l'écran en anglais sauf si le
brief dit une autre langue. « resume » = deux phrases sur l'idée de la vidéo
et le fait que la structure sera recalée sur l'exemple quand il arrivera.
"""


def proposer_campagne(brief, exemple=None, progres=None):
    """La campagne, la serie et la liste de tournage proposees par Claude.
    Rien n'est cree: c'est une proposition que l'utilisateur relit.
    `exemple` facultatif: sans lui, tout part du brief."""
    pl, images = [], []
    if exemple:
        if progres:
            progres("Lecture de la vidéo exemple…")
        pl = plans(exemple)
        for i, (a, b) in enumerate(pl, 1):
            images.append((f"Plan {i} — de {a:.2f} s à {b:.2f} s ({b - a:.2f} s)",
                           image(exemple, a + (b - a) * 0.6)))
        if progres:
            progres(f"{len(pl)} plans — Claude prépare la campagne…")
        fin = f"\n\nLa vidéo exemple dure {duree(exemple):.1f} s et a {len(pl)} plans."
    else:
        if progres:
            progres("Claude prépare la campagne à partir du brief…")
        fin = "\n" + SANS_EXEMPLE
    texte = (CONSIGNES_CAMPAGNE + "\n\nBRIEF DU CLIENT:\n" + (brief or "(aucun brief)") + fin)
    r = demander(texte, images, schema=SCHEMA_CAMPAGNE, modele=SOIGNE, delai=600)
    r["plans"] = [{"debut": a, "fin": b, "duree": round(b - a, 3)} for a, b in pl]
    return r


# ------------------------------------------------------------------
# Trier les clips deposes en vrac
# ------------------------------------------------------------------
SCHEMA_TRI = {
    "type": "object", "additionalProperties": False, "required": ["clips"],
    "properties": {"clips": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["clip", "categorie", "confiance", "remarque"],
        "properties": {
            "clip": {"type": "string"},
            "categorie": {"type": "string"},
            "confiance": {"type": "number"},
            "remarque": {"type": "string"}}}}}}

# Six clips par appel: deux images chacun plus les categories, ~5 000
# jetons — et un seul demarrage de Claude Code pour six.
TRI_LOT = 6


def trier(categories, clips, progres=None):
    """`categories` = [{"id", "nom", "consigne", "image": jpeg|None}],
    `clips` = [chemin]. Rend {nom du clip: {"categorie": id|"", "confiance",
    "remarque"}}."""
    refs = []
    for c in categories:
        if c.get("image"):
            refs.append((f"Exemple de la catégorie « {c['nom']} » (id {c['id']})", c["image"]))
    liste = "\n".join(f"- id {c['id']} — « {c['nom']} » : {c.get('consigne') or '(pas de consigne)'}"
                      for c in categories)
    out = {}
    for k in range(0, len(clips), TRI_LOT):
        lot = clips[k:k + TRI_LOT]
        if progres:
            progres(f"Tri des clips {k + 1} à {k + len(lot)} sur {len(clips)}…")
        images = list(refs)
        for ch in lot:
            d = duree(ch) or 1.0
            nom = os.path.basename(str(ch))
            images.append((f"Clip « {nom} » ({d:.1f} s) — début", image(ch, d * 0.25)))
            images.append((f"Clip « {nom} » — fin", image(ch, d * 0.75)))
        texte = (
            "Range chaque clip dans la catégorie de la série qui lui correspond.\n"
            "Catégories:\n" + liste + "\n\n"
            "Pour chaque clip: « categorie » = l'id de la catégorie la PLUS PROCHE. "
            "\"\" seulement si le clip n'a rien à voir avec aucune catégorie (autre "
            "sujet, autre produit). Un clip qui ne suit pas bien la consigne va quand "
            "même dans sa catégorie, et tu le dis dans la remarque. « confiance » entre "
            "0 et 1. « remarque » = 12 mots maximum, SEULEMENT s'il y a un problème "
            "que l'image montre (ne suit pas la consigne, mauvais cadrage, on ne voit "
            "pas le produit, contenu à risque pour le client), sinon \"\". Ne parle "
            "jamais de durée, de lumière ni de netteté: l'app les mesure déjà. "
            "Réponds pour chacun de ces clips: "
            + ", ".join(f"« {os.path.basename(str(c))} »" for c in lot))
        r = demander(texte, images, schema=SCHEMA_TRI, modele=RAPIDE)
        for x in r.get("clips") or []:
            out[str(x.get("clip") or "")] = {
                "categorie": str(x.get("categorie") or ""),
                "confiance": float(x.get("confiance") or 0),
                "remarque": str(x.get("remarque") or "")}
    return out


# ------------------------------------------------------------------
# Repondre a une question
# ------------------------------------------------------------------
def repondre(question, contexte, historique=()):
    """`contexte` = ce que le plateau sait de l'etat (texte), `historique`
    = [(qui, texte)] des derniers echanges."""
    passe = "\n".join(f"{'Utilisateur' if q == 'moi' else 'Toi'}: {t}"
                      for q, t in list(historique)[-8:])
    texte = (
        "ÉTAT ACTUEL DU PLATEAU (ce que l'app sait, à jour):\n" + contexte +
        ("\n\nCONVERSATION JUSQU'ICI:\n" + passe if passe else "") +
        "\n\nQUESTION: " + question +
        "\n\nRéponds en 1 à 5 phrases courtes, concrètes, en nommant les boutons "
        "et les écrans du plateau tels qu'ils sont décrits plus haut. Si la "
        "question demande quoi faire ensuite, donne UNE prochaine étape.")
    return demander(texte, modele=RAPIDE, systeme=SYSTEME + "\n\n" + GUIDE)


# ------------------------------------------------------------------
# Le monteur et le chef de campagne: une demande -> des changements
# ------------------------------------------------------------------
# Claude ne touche a rien lui-meme (aucun outil, `--tools ""`): il rend une
# LISTE D'ACTIONS, que le serveur traduit en requetes sur les routes
# existantes — celles de l'interface, avec leurs gardes — et que
# l'utilisateur applique d'un clic. Un objet plat plutot qu'une union par
# type: le schema reste lisible pour le modele, et le serveur ne lit que
# les champs qui ont un sens pour le type.
SCHEMA_PARLER = {
    "type": "object",
    "properties": {
        "reponse": {"type": "string"},
        "actions": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "type": {"type": "string", "enum": [
                    "categorie", "nouvelle_categorie", "ordre", "serie",
                    "campagne", "generer", "tache", "texte_video"]},
                "bloc": {"type": "string"},
                "de_categorie": {"type": "string"},
                "jusqua_categorie": {"type": "string"},
                "decalage_debut": {"type": "number"},
                "decalage_fin": {"type": "number"},
                "supprimer": {"type": "boolean"},
                "serie": {"type": "string"},
                "categorie": {"type": "string"},
                "nom": {"type": "string"},
                "dur_min": {"type": "number"},
                "dur_max": {"type": "number"},
                "textes": {"type": "array", "items": {"type": "string"}},
                "position_texte": {"type": "string", "enum": ["haut", "milieu", "bas"]},
                "son": {"type": "boolean"},
                "complet": {"type": "boolean"},
                "mise_de_cote": {"type": "boolean"},
                "consigne": {"type": "string"},
                "ordre": {"type": "array", "items": {"type": "string"}},
                "envoi_auto_jour": {"type": "integer"},
                "taille_texte": {"type": "integer"},
                "style_texte": {"type": "string", "enum": ["contour", "pastille", "nu"]},
                "melanger_ordre": {"type": "boolean"},
                "musique_volume": {"type": "number"},
                "sans_musique": {"type": "boolean"},
                "legendes_post": {"type": "array", "items": {"type": "string"}},
                "objectif_jour": {"type": "integer"},
                "paie_video": {"type": "number"},
                "cycle_paie": {"type": "string"},
                "date_paie": {"type": "string"},
                "notes": {"type": "string"},
                "pause": {"type": "boolean"},
                "nombre": {"type": "integer"},
                "texte": {"type": "string"},
            },
            "required": ["type"],
        }},
    },
    "required": ["reponse", "actions"],
}

CONSIGNES_PARLER = """Tu es à la fois le MONTEUR et le CHEF DE CAMPAGNE de l'utilisateur. Il te
parle comme à un collègue : « raccourcis l'accroche », « mets le texte plus
gros », « passe cette campagne à 5 vidéos par jour », « exporte-m'en une ».

Si sa demande se traduit en changements, mets-les dans `actions` : l'app
les APPLIQUE TOUT DE SUITE, sans lui demander (il peut annuler d'un clic),
sauf l'envoi auto et la pause d'une campagne, qu'il confirme. Dans
`reponse`, dis en 1 à 3 phrases ce que tu as changé (ou réponds à sa
question s'il n'y a rien à changer, et laisse `actions` vide). Il veut que
ce soit FAIT : traduis la demande en actions plutôt que de lui expliquer
où cliquer.

Les types d'action et leurs champs :
- categorie (serie, categorie = son nom EXACT dans l'état) : nom (renommer),
  dur_min/dur_max (secondes ; une durée fixe = les deux égaux), textes (la
  liste COMPLÈTE des textes à l'écran de la catégorie, tirés au sort — elle
  remplace l'ancienne : recopie ceux à garder), position_texte, son (garder
  le son du clip), complet (passer chaque clip en entier), mise_de_cote
  (true = ne sort plus au tirage, false = revient), consigne (ce qu'il faut
  filmer).
- nouvelle_categorie (serie, nom, + les mêmes champs que categorie).
- ordre (serie, ordre = les noms des catégories dans le nouvel ordre).
- serie (serie) : envoi_auto_jour (vidéos envoyées à Buffer par jour),
  taille_texte (taille des textes, 70 par défaut), style_texte,
  melanger_ordre, musique_volume (1 = normal), sans_musique, legendes_post
  (les légendes du post Instagram, liste complète).
- campagne : nom, objectif_jour, paie_video, cycle_paie (hebdo, 2sem,
  mensuel), date_paie (AAAA-MM-JJ, un jour de paiement connu), notes (le
  texte COMPLET des notes), pause (true = arrêter de publier).
- generer (serie, nombre) : exporter des vidéos pour voir le résultat. Ajoute
  une action generer d'1 vidéo après un changement de montage quand il veut
  voir le résultat.
- tache (texte) : une ligne dans sa todo.
- texte_video (serie) : un texte de la FRISE DE L'ÉDITEUR — seulement si
  l'état dit « FRISE DE L'ÉDITEUR : ACTIVE » ; c'est alors elle qui dessine
  les textes de la vidéo, pas les catégories (n'utilise PAS `textes` d'une
  catégorie dans ce cas, ça ne se verrait pas). bloc = l'id du bloc dans
  l'état (vide = nouveau texte) ; texte (le nouveau texte) ; de_categorie
  (où il commence, nom exact ; obligatoire pour un nouveau) ;
  jusqua_categorie (il s'arrête au DÉBUT de cette catégorie ; « fin » =
  jusqu'au bout) ; decalage_debut / decalage_fin (secondes, + = plus tard) ;
  position_texte ; taille_texte (70 par défaut) ; style_texte ;
  supprimer (true = retirer le bloc).

Règles :
- `serie` = le nom exact d'une série de l'état ; vide = la série ouverte.
- N'invente jamais une catégorie, une série ou une valeur que l'état ne
  donne pas. Si la demande est floue, pose UNE question dans `reponse` et
  ne propose rien.
- Une durée en dessous de 0,5 s ne se lit pas ; garde ±0,2 s d'écart entre
  dur_min et dur_max sauf s'il veut une durée exacte.
- Garde la langue des textes à l'écran telle qu'elle est (souvent l'anglais).
- Ne mets en pause une campagne ou ne coupe l'envoi auto que s'il le demande.
- Si des images de sa dernière vidéo sont jointes, sers-t'en pour comprendre
  de quoi il parle (« le texte du début », « le deuxième plan »).
"""


def parler(demande, contexte, historique=(), images=()):
    """-> {"reponse", "actions"}. Sonnet et pas Haiku: une action mal
    comprise touche une serie qui publie, et c'est un seul appel par
    message."""
    passe = "\n".join(f"{'Utilisateur' if q == 'moi' else 'Toi'}: {t}"
                      for q, t in list(historique)[-10:])
    texte = (
        "ÉTAT ACTUEL DU PLATEAU (à jour) :\n" + contexte +
        ("\n\nCONVERSATION JUSQU'ICI :\n" + passe if passe else "") +
        "\n\nDEMANDE : " + demande)
    r = demander(texte, images, schema=SCHEMA_PARLER, modele=SOIGNE,
                 systeme=SYSTEME + "\n\n" + GUIDE + "\n\n" + CONSIGNES_PARLER)
    if not isinstance(r, dict):
        raise IAError("Réponse de Claude illisible — réessaie")
    r.setdefault("actions", [])
    return r


# Ce que l'assistant sait de l'app. Court: c'est envoye a chaque question.
GUIDE = """\
Le plateau, en bref:
- Barre de gauche: Vue d'ensemble, Éditeur (les projets), File d'attente, Todo,
  Contenu, Prospection, Onboarding, puis la liste des CAMPAGNES et « Nouvelle
  campagne ».
- Une CAMPAGNE = un deal avec un client (comptes, paie, objectif par jour). Elle
  contient des SÉRIES. Une série = la recette de montage: des CATÉGORIES de clips.
- « Nouvelle campagne » → « Avec l'IA »: on colle le brief, on dépose la vidéo
  exemple, l'IA propose la campagne, la série et la liste de tournage.
- Dans une série, onglet « Clips »: chaque catégorie a sa case, avec ce qu'il
  faut y filmer. « Déposer tous les clips » envoie les clips d'un coup et l'IA
  les range dans la bonne catégorie, avec des avertissements (trop sombre, flou,
  horizontal, trop court, ne ressemble pas à la consigne).
- Onglet « Générer »: fabriquer des vidéos. Onglet « Vidéos »: les voir.
  Onglet « Publier »: Buffer, envoi automatique par jour.
- L'Éditeur: un projet = une série, montée comme dans CapCut (frise, textes,
  aperçu, Exporter).
- Le bouton « Tuto » en haut à droite explique chaque écran.
L'ordre normal: créer la campagne → filmer la liste de tournage → déposer les
clips → générer une vidéo pour vérifier → brancher Buffer → envoi automatique.
"""
