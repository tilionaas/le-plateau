#!/usr/bin/env python3
"""
Serveur web local du Video Remixer.
-----------------------------------
Aucune dependance: uniquement la bibliotheque standard de Python.

    python3 server.py

Puis ouvre http://127.0.0.1:8765 (le navigateur s'ouvre tout seul).

Le serveur n'ecoute que sur 127.0.0.1: rien n'est expose sur ton reseau
ni sur Internet. Les fichiers restent sur ta machine, dans series/.
"""

import hashlib
import json
import mimetypes
import os
import random
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import unicodedata
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

import brief
import carte
# L'ATELIER DES TEMPLATES EST OPTIONNEL. Il n'a rien a voir avec le UGC
# (voir CLAUDE.md): c'est l'atelier du compte personnel. La copie qu'on
# donne a d'autres est fabriquee SANS `template.py`, et l'app doit alors
# tourner comme si l'onglet n'avait jamais existe — plutot que de garder
# deux versions du code, qui finiraient par diverger.
try:
    import template as tpl
except ImportError:                                     # pas dans cette copie
    tpl = None
import classement
import reddit
import detourage
import ia
import maj
import qualite
import remixer
import transcription
import publisher
import plateau
import portable

from chemins import CODE, DONNEES as ROOT, INSTALLEE    # voir chemins.py
SERIES_DIR = ROOT / "series"
CLIPS_DIR = ROOT / "clips"          # ou tu deposes tes rushes, un dossier par serie
OUTPUT_DIR = ROOT / "output"        # videos generees, un dossier par serie
WEB_DIR = CODE / "web"          # livre avec l'app, pas une donnee
AVATARS_DIR = ROOT / "avatars"   # photos de profil des comptes
FONDS_DIR = ROOT / "fonds"       # images de fond de la vue d'ensemble
# Pot commun de musiques, un sous-dossier par campagne. Dans `clips/`, la
# ou tu deposes deja tes rushes: c'est le dossier que tu ouvres dans le
# Finder et que Drive synchronise, donc une musique s'y depose comme un
# clip, sans passer par le navigateur. Prefixe `_` pour qu'il se range en
# tete et ne passe pas pour une serie — meme convention que
# `output/_TOUTES LES VIDEOS`.
MUSIQUES_DIR = CLIPS_DIR / "_MUSIQUES"
# Banques d'images declenchees par un mot, une par declencheur. Dans
# `clips/` comme les musiques: on y depose depuis le Finder ou Drive.
IMAGES_DIR = CLIPS_DIR / "_IMAGES"
BADGES_DIR = CLIPS_DIR / "_BADGES"
FOND_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".avif", ".gif"}
MUSIQUE_MAX_BYTES = 200 * 1024 * 1024  # une capture d'ecran d'1 min pese ~30 Mo
AVATAR_MAX_BYTES = 25 * 1024 * 1024   # une photo brute d'iPhone fait 4-8 Mo
AVATAR_SIDE = 512                      # une pastille n'a pas besoin de plus
PORT = int(os.environ.get("REMIXER_PORT", "8765"))

JOBS = {}
JOBS_LOCK = threading.Lock()
QUEUE = []                       # file d'attente de generation multi-series
QUEUE_LOCK = threading.Lock()
QUEUE_STATE = {"running": False, "stop": False, "current": None}
# Series en cours de generation, quel que soit le declencheur (bouton d'une
# serie ou file d'attente). Deux generations simultanees sur la meme serie
# se marchaient dessus dans le dossier temporaire; le dossier est maintenant
# unique par execution, mais rien ne justifie de faire tourner deux rendus
# ffmpeg sur les memes clips en meme temps.
BUSY = set()
BUSY_LOCK = threading.Lock()


def claim_serie(cid):
    """Reserve une serie pour une generation. False si deja prise."""
    with BUSY_LOCK:
        if cid in BUSY:
            return False
        BUSY.add(cid)
        return True


def release_serie(cid):
    with BUSY_LOCK:
        BUSY.discard(cid)
ALL_OUTPUTS_DIRNAME = "_TOUTES LES VIDEOS"

SAFE_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


# ------------------------------------------------------------------
# Securite des chemins
# ------------------------------------------------------------------

def slugify(name, fallback="serie"):
    txt = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode()
    txt = re.sub(r"[^a-zA-Z0-9]+", "-", txt).strip("-").lower()
    return (txt or fallback)[:40]


def safe_filename(name):
    """Garde un nom de fichier lisible mais inoffensif (pas de traversee)."""
    name = os.path.basename(unquote(name or ""))
    name = name.replace("\x00", "")
    name = re.sub(INTERDITS_FS, "_", name)
    name = re.sub(r"^\.+", "_", name)
    name = name.rstrip(". ")            # Windows refuse un nom finissant par . ou espace
    if name.split(".")[0].upper() in RESERVES_WIN:
        name = f"_{name}"
    return name[:120] or f"fichier-{uuid.uuid4().hex[:6]}"


def serie_path(cid):
    """Chemin d'une serie, ou None si l'id est invalide/inexistant."""
    if not cid or not SAFE_ID.match(cid):
        return None
    p = SERIES_DIR / cid
    if not (p / "serie.json").exists():
        return None
    return p


def within(base, target):
    """True si target est bien a l'interieur de base (anti path-traversal)."""
    try:
        base = os.path.realpath(str(base))
        target = os.path.realpath(str(target))
        return target == base or target.startswith(base + os.sep)
    except OSError:
        return False


# ------------------------------------------------------------------
# Persistance des series
# ------------------------------------------------------------------

def load_serie(cid):
    p = serie_path(cid)
    if not p:
        return None
    with open(p / "serie.json", encoding="utf-8") as f:
        c = json.load(f)
    c["id"] = cid
    merged = dict(remixer.DEFAULT_SETTINGS)
    merged.update(c.get("settings", {}))
    c["settings"] = merged
    # Le pot commun de musiques de la campagne. Resolu ICI et pas dans le
    # moteur: le dossier porte le nom de la campagne, une donnee de la base
    # que remixer.py ne sait pas lire. `save_serie` le retire avant
    # d'ecrire — un chemin fige perimerait au premier renommage.
    if c.get("campaign_id"):
        d = musique_dir(c["campaign_id"])
        if d:
            c["music_camp_dir"] = str(d)
    # Meme raison pour les pastilles: le dossier porte le nom de la serie,
    # un chemin fige perimerait au premier renommage.
    b = badges_dir(c.get("name"))
    if b.is_dir():
        c["badges_dir"] = str(b)
    return c


def save_serie(c):
    p = SERIES_DIR / c["id"]
    p.mkdir(parents=True, exist_ok=True)
    Path(remixer.output_dir(p, c)).mkdir(parents=True, exist_ok=True)
    (p / "music").mkdir(exist_ok=True)
    (p / "thumbs").mkdir(exist_ok=True)
    (p / "slots").mkdir(exist_ok=True)
    for s in c["slots"]:
        (p / "slots" / s["id"]).mkdir(parents=True, exist_ok=True)
    # Champ calcule par `load_serie`, jamais une donnee de la serie: l'ecrire
    # figerait le nom d'une campagne qui peut etre renommee demain.
    c.pop("music_camp_dir", None)
    c.pop("badges_dir", None)
    tmp = p / "serie.json.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(c, f, ensure_ascii=False, indent=2)
    os.replace(str(tmp), str(p / "serie.json"))
    return c


def list_series():
    if not SERIES_DIR.exists():
        return []
    out = []
    for d in sorted(SERIES_DIR.iterdir()):
        if not (d / "serie.json").exists():
            continue
        c = load_serie(d.name)
        if not c:
            continue
        pools = {s["id"]: remixer.slot_clips(d, s) for s in c["slots"]}
        clips = sum(len(v) for v in pools.values())
        depuis_clip = remixer.dernier_ajout(
            [p for s in c["slots"] if not s.get("off") for p in pools[s["id"]]])
        od = Path(remixer.output_dir(d, c))
        vids = sorted(od.glob("*.mp4"), key=lambda f: f.stat().st_mtime) \
            if od.exists() else []
        # Fenetre glissante de 24 h (et non « depuis minuit ») : quand on
        # genere le soir, un compteur remis a zero a minuit afficherait 0
        # alors que le lot vient d'etre produit.
        #
        # Le compte vient du JOURNAL, pas des fichiers: supprimer les
        # videos ne doit pas effacer le fait qu'on les a produites. Ce qui
        # doit retomber a zero quand on vide, c'est « pretes a poster »,
        # et celui-la compte les lignes du pipeline.
        since = time.time() - 86400
        last24 = plateau.generated_since(since, d.name)
        out.append({"id": c["id"], "name": c["name"], "slots": len(c["slots"]),
                    # Campagne de rattachement: c'est ce qui range la serie
                    # sous son deal dans la barre laterale et dans le graphe.
                    "campaign_id": c.get("campaign_id") or None,
                    "clips": clips, "outputs": len(vids), "last24": last24,
                    # Le son coupe se lit au niveau campagne: c'est la
                    # qu'on depose les musiques, et c'est la qu'il faut
                    # pouvoir dire quelles series les ignoreront.
                    "mute": 1 if c.get("settings", {}).get("mute") else 0,
                    "paused": 1 if c.get("paused") else 0,
                    # Range hors de la page « Projets » de l'editeur, et
                    # seulement la: la serie continue de tourner partout.
                    "archive": 1 if c.get("archive") else 0,
                    # La page « Projets » de l'editeur: le format se voit
                    # sur la carte, comme dans CapCut, sans ouvrir le projet.
                    "split": 1 if c.get("settings", {}).get("split") else 0,
                    "editeur": 1 if (c.get("editor") or {}).get("actif") else 0,
                    # Couverture de secours de la carte « Projets »: le premier
                    # clip de la premiere categorie qui en a. Sans elle, un
                    # projet jamais exporte n'avait qu'un rectangle gris —
                    # et c'est justement le projet qu'on vient de commencer.
                    "apercu": next(({"slot": x["id"],
                                     "clip": os.path.basename(str(pools[x["id"]][0]))}
                                    for x in c["slots"]
                                    if not x.get("off") and pools.get(x["id"])), None),
                    "created": c.get("created") or "",
                    # Vignette de la derniere video: sert de couverture a la
                    # tuile dans la vue d'ensemble.
                    "cover": vids[-1].name if vids else "",
                    "last": vids[-1].stat().st_mtime if vids else 0,
                    # Usure de la recette, pour l'alerte de la file
                    # d'attente: une alerte qui ne vit que dans l'onglet
                    # d'une serie ne se voit qu'une fois qu'on y est entre,
                    # c'est-a-dire jamais quand on lance un lot.
                    # Envoi quotidien vers Buffer: le chiffre se decide en
                    # meme temps que les volumes du jour, donc il doit vivre
                    # dans la file et pas seulement au fond d'une serie.
                    "auto_jour": int(c.get("auto_jour") or 0),
                    "auto_demain": (int((c.get("auto_demain") or {}).get("n"))
                                    if isinstance(c.get("auto_demain"), dict)
                                    and (c.get("auto_demain") or {}).get("n") is not None
                                    else None),
                    "combinations": remixer.combination_count(d, c, pools),
                    # Depuis le dernier clip ajoute seulement: voir
                    # `serie_detail`. Deposer des clips remet le compteur a
                    # zero, c'est le geste qui rafraichit la serie.
                    "generated": (plateau.generated_since(depuis_clip, c["id"])
                                  if depuis_clip else plateau.generated_total(c["id"])),
                    # Le total de toujours voyage AUSSI dans la liste, pas
                    # seulement dans la fiche d'une serie. Sans lui, une
                    # serie dont le catalogue est deja bien entame avait
                    # l'air toute neuve dans la file des qu'on y deposait
                    # deux clips — et c'est justement la, au moment de
                    # choisir combien en lancer, qu'il faut le savoir.
                    "generated_total": plateau.generated_total(c["id"]),
                    "clips_at": depuis_clip,
                    "created": c.get("created", "")})
    out.sort(key=lambda x: x["created"], reverse=True)
    return out


def new_slot(name, path=None):
    s = {"id": f"s{uuid.uuid4().hex[:8]}", "name": name, "min": 1, "max": 1,
         "allow_zoom": True, "captions": []}
    if path:
        s["path"] = path
    return s


# Caracteres que Windows refuse dans un nom de fichier. On les retire
# partout, meme sur Mac: un dossier de clips cree ici doit pouvoir etre
# copie sur un PC, et une serie nommee « POV: ca marche? » faisait echouer
# la creation des dossiers cote Windows.
INTERDITS_FS = r'[/\\:\x00<>"|?*]+'

# Noms reserves par Windows, quelle que soit l'extension. Un dossier
# « CON » ou « AUX » est impossible a creer.
RESERVES_WIN = {"CON", "PRN", "AUX", "NUL",
                *(f"COM{i}" for i in range(1, 10)),
                *(f"LPT{i}" for i in range(1, 10))}


def folder_name(name, index=None):
    """Nom de dossier propre pour une categorie. Le prefixe numerique fixe
    l'ordre, car les categories sont lues par ordre alphabetique."""
    clean = re.sub(INTERDITS_FS, "-", str(name or "").strip()).strip(". ")
    clean = clean[:40] or "categorie"
    if clean.split(".")[0].upper() in RESERVES_WIN:
        clean = f"_{clean}"
    return f"{index}-{clean}" if index else clean


def make_output_folder(name):
    """Cree output/<Serie>/ et renvoie son chemin.

    Le dossier est NEUF, jamais repris: deux series au meme nom (une par
    campagne dupliquee) partageaient output/<Nom>/, et supprimer l'une
    effacait les videos de l'autre. Meme numerotation que les dossiers de
    clips (« Nom 2 », « Nom 3 »). Un dossier encore reclame par une serie
    compte comme pris meme s'il a disparu du disque: elle le recreerait a
    la prochaine generation."""
    OUTPUT_DIR.mkdir(exist_ok=True)
    pris = set()
    for d in sorted(SERIES_DIR.iterdir()) if SERIES_DIR.exists() else []:
        try:
            with open(d / "serie.json", encoding="utf-8") as f:
                od = json.load(f).get("output_dir")
        except (OSError, ValueError):
            continue
        if od:
            pris.add(os.path.realpath(od))
    base = OUTPUT_DIR / folder_name(name)
    d, i = base, 2
    while d.exists() or os.path.realpath(str(d)) in pris:
        d = OUTPUT_DIR / f"{base.name} {i}"
        i += 1
    d.mkdir(parents=True, exist_ok=True)
    return str(d)


def series_sharing_output(cid, od):
    """Les AUTRES series dont le dossier de sortie est `od`.

    Les series creees avant que make_output_folder ne numerote peuvent
    encore partager le leur: c'est la qu'un rmtree effacerait les videos
    d'une serie qu'on n'a pas touchee."""
    cible = os.path.realpath(str(od))
    return [c_id for c_id, _nom, d in serie_output_dirs()
            if c_id != cid and os.path.realpath(str(d)) == cible]


def own_outputs(cid, od):
    """Les .mp4 de `od` que la serie `cid` a produits, d'apres le pipeline.

    Un fichier qu'aucune ligne ne rattache a cette serie reste en place:
    dans un dossier partage, on ne sait pas a qui il est, et le garder
    ne coute qu'un peu de disque."""
    a_elle = set()
    try:
        a_elle = {os.path.realpath(p) for p in plateau.series_video_paths(cid)}
    except Exception:                                       # noqa: BLE001
        pass
    if not od.exists():
        return []
    return [f for f in od.glob("*.mp4") if os.path.realpath(str(f)) in a_elle]


def make_serie_folders(name, categories):
    """Cree clips/<serie>/<n-categorie>/ et renvoie (racine, sous-dossiers).

    C'est ce qui permet de creer une serie dans l'app et d'avoir tout de
    suite les dossiers ou glisser ses rushes."""
    CLIPS_DIR.mkdir(exist_ok=True)
    base = CLIPS_DIR / folder_name(name)
    if base.exists():
        i = 2
        while (CLIPS_DIR / f"{base.name} {i}").exists():
            i += 1
        base = CLIPS_DIR / f"{base.name} {i}"
    base.mkdir(parents=True)

    subs = []
    for i, cat in enumerate(categories, 1):
        d = base / folder_name(cat, i)
        d.mkdir(exist_ok=True)
        subs.append((d.name, str(d)))
    return str(base), subs


def real_dir(raw):
    """Normalise un chemin saisi par l'utilisateur. None si ce n'est pas
    un dossier lisible. Accepte ~, les chemins relatifs au home et les
    URL file:// que macOS met dans le presse-papier."""
    if not raw:
        return None
    raw = str(raw).strip().strip('"').strip("'")
    if raw.startswith("file://"):
        raw = unquote(raw[7:])
    p = Path(os.path.expanduser(raw))
    try:
        p = p.resolve()
    except OSError:
        return None
    return str(p) if p.is_dir() and os.access(str(p), os.R_OK) else None


def home_shortcuts():
    """Raccourcis proposes dans le sélecteur de dossier."""
    home = Path.home()
    cands = [("Bureau", home / "Desktop"), ("Documents", home / "Documents"),
             ("Téléchargements", home / "Downloads"), ("Films", home / "Movies"),
             ("Dossier personnel", home)]
    cloud = home / "Library" / "CloudStorage"
    if cloud.is_dir():
        for d in sorted(cloud.iterdir()):
            if d.is_dir():
                label = d.name.split("-")[0]
                cands.append((f"{label} — {d.name.split('-', 1)[-1]}", d))
    for legacy in (home / "Google Drive", home / "Dropbox"):
        if legacy.is_dir():
            cands.append((legacy.name, legacy))
    return [{"name": n, "path": str(p)} for n, p in cands if p.is_dir()]


def find_source_clip(cid, filename):
    """Retrouve le chemin reel d'un clip a partir de son nom, toutes
    categories confondues. Sert aux vignettes des dossiers lies."""
    c = load_serie(cid)
    if not c:
        return None
    d = SERIES_DIR / cid
    for s in c["slots"]:
        # `_all`: un clip masque garde sa vignette, sinon il disparaitrait
        # de la grille au lieu d'y apparaitre grise.
        for p in remixer.slot_clips_all(d, s):
            if Path(p).name == filename:
                return p
    return None


def serie_detail(cid):
    c = load_serie(cid)
    if not c:
        return None
    d = SERIES_DIR / cid
    # Toutes les mesures sont lancees d'un coup et en parallele: en serie,
    # une serie de 80 clips mettait ~7 s a s'ouvrir apres un redemarrage.
    per_slot = {s["id"]: remixer.slot_clips_all(d, s) for s in c["slots"]}
    outs_paths = []
    od0 = Path(remixer.output_dir(d, c))
    if od0.exists():
        outs_paths = [str(f) for f in od0.glob("*.mp4")]
    measured = remixer.probe_many(
        [p for ps in per_slot.values() for p in ps] + outs_paths)

    for s in c["slots"]:
        s["linked"] = bool(s.get("path"))
        s["missing"] = bool(s.get("path")) and not Path(s["path"]).is_dir()
        hidden = remixer.slot_hidden(s)
        s["clips"] = [{"name": Path(p).name,
                       "duration": round(measured[p][0], 1),
                       "audio": measured[p][1],
                       "hidden": Path(p).name in hidden}
                      for p in per_slot[s["id"]]]
        # Ce que le tirage verra vraiment. L'interface s'en sert pour
        # avertir qu'une categorie n'a plus rien a donner.
        s["usable"] = sum(1 for c2 in s["clips"] if not c2["hidden"])
    # Serie parlee: le niveau de chaque clip et ce qu'il recevra en plus.
    # Le gain n'est connu que pour un clip deja ecoute par whisper: la
    # transcription se fait a la generation, pas a l'ouverture de la serie.
    # `voix`: True = on y parle, False = bruit seul, None = pas encore ecoute.
    if c.get("settings", {}).get("parle"):
        tous = [p for ps in per_slot.values() for p in ps]
        niv = remixer.sonie_many(tous)
        ecoute = {p: transcription.en_cache(p) for p in tous}
        actifs = [niv[p] for s in c["slots"] if not s.get("off")
                  for p in per_slot[s["id"]]
                  if Path(p).name not in remixer.slot_hidden(s) and ecoute[p]]
        cible = remixer.sonie_cible(actifs)
        c["sonie_cible"] = cible
        for s in c["slots"]:
            for clip, p in zip(s["clips"], per_slot[s["id"]]):
                clip["lufs"] = None if niv[p] is None else round(niv[p], 1)
                clip["voix"] = None if ecoute[p] is None else bool(ecoute[p])
                # Ce qui sera affiche en sous-titres, pour le voir avant de generer.
                clip["texte"] = " ".join(m[0] for m in (ecoute[p] or []))
                clip["gain"] = remixer.sonie_gain(niv[p], cible) if ecoute[p] else 0.0
    for r in c.get("images_regles") or []:
        dossier = r.get("dossier") or str(images_dir(c.get("name"), r.get("mot")))
        r["dossier"] = dossier
        r["images"] = len(remixer.list_media(dossier, remixer.IMAGE_EXTS))
    c["music"] = [Path(p).name for p in remixer.music_files(d, c)]
    c["voix_ok"] = transcription.disponible()
    c["incrust_ok"] = detourage.disponible()
    c["music_linked"] = bool(c.get("music_dir"))
    od = Path(remixer.output_dir(d, c))
    outs = sorted(od.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True) \
        if od.exists() else []
    c["output_dir"] = str(od)
    c["outputs"] = [{"name": p.name, "size": p.stat().st_size,
                     "duration": round(measured.get(str(p), (0.0, False))[0], 1)}
                    for p in outs]
    c["combinations"] = remixer.combination_count(d, c)
    # Les clips deposes en vrac, pas encore ranges par le tri.
    vd = vrac_dir(cid)
    c["vrac"] = [Path(x).name for x in remixer.list_media(str(vd), remixer.VIDEO_EXTS)] \
        if vd.is_dir() else []
    # Usure de la recette: combien de videos sont deja sorties de ce meme
    # pot de clips, et depuis quand aucun clip n'y a ete ajoute. Sert a
    # avertir avant que les montages se repetent. On ne compte que les
    # clips que le tirage voit vraiment — un clip masque ou une categorie
    # mise de cote ne rafraichit rien.
    tires = [p2 for s2 in c["slots"] if not s2.get("off")
             for p2 in per_slot[s2["id"]]
             if Path(p2).name not in remixer.slot_hidden(s2)]
    c["clips_at"] = remixer.dernier_ajout(tires)
    # On ne compte QUE les videos faites depuis le dernier clip ajoute: une
    # video montee avant qu'un clip n'existe n'a pas pu consommer les
    # combinaisons qu'il apporte. Deposer des clips remet donc le
    # pourcentage a zero, ce qui est le geste exact qui rafraichit une
    # serie. `generated_total` reste pour le total de toujours.
    c["generated"] = (plateau.generated_since(c["clips_at"], cid)
                      if c["clips_at"] else plateau.generated_total(cid))
    c["generated_total"] = plateau.generated_total(cid)
    with JOBS_LOCK:
        c["job"] = next((dict(j) for j in JOBS.values()
                         if j["serie"] == cid and j["status"] == "running"), None)
    return c


# ------------------------------------------------------------------
# Jobs de generation
# ------------------------------------------------------------------

def register_made(cid, made):
    """Inscrit dans le pipeline les videos qui viennent d'etre generees.

    C'est le pont entre le moteur et le niveau campagne: sans ca, il
    faudrait ressaisir a la main chaque video dans le calendrier. Une
    erreur ici ne doit jamais faire echouer une generation reussie — les
    fichiers sont sur le disque quoi qu'il arrive."""
    if not made:
        return 0
    c = load_serie(cid)
    if not c:
        return 0
    # remixer.generate() renvoie des NOMS de fichiers, pas des chemins:
    # on les resout contre le dossier de sortie de la serie, sinon la
    # video serait inscrite avec un chemin inutilisable.
    od = Path(remixer.output_dir(SERIES_DIR / cid, c))
    cam = serie_campaign_id(cid)
    n = 0
    for name in made:
        try:
            plateau.log_generation(cid, name)
            if plateau.register_output(od / name, cid, c.get("name", cid), cam):
                n += 1
        except Exception:                                   # noqa: BLE001
            pass
    return n


def backfill_outputs():
    """Inscrit les videos deja sur le disque mais absentes de la base.

    Sert une fois, a la fusion: les videos generees avant que le pipeline
    n'existe doivent apparaitre dans le calendrier comme les nouvelles.
    Reste utile ensuite si une generation se termine pendant un plantage.
    `register_output` ignore les chemins deja connus, donc relancer est
    sans effet."""
    n = 0
    for d in sorted(SERIES_DIR.iterdir()) if SERIES_DIR.exists() else []:
        if not (d / "serie.json").exists():
            continue
        c = load_serie(d.name)
        if not c:
            continue
        od = Path(remixer.output_dir(d, c))
        if not od.exists():
            continue
        cam = serie_campaign_id(d.name)
        for f in sorted(od.glob("*.mp4"), key=lambda x: x.stat().st_mtime):
            try:
                # Date du fichier et non maintenant: sinon un redemarrage
                # ferait remonter d'anciennes videos dans les « 24 h ».
                plateau.log_generation(d.name, f.name, f.stat().st_mtime)
                if plateau.register_output(f, d.name, c.get("name", d.name), cam):
                    n += 1
            except Exception:                                   # noqa: BLE001
                pass
    return n


def start_job(cid, count):
    c = load_serie(cid)
    with JOBS_LOCK:
        for j in JOBS.values():
            if j["serie"] == cid and j["status"] == "running":
                return None, "Une génération est déjà en cours pour cette série."
        jid = uuid.uuid4().hex[:12]
        JOBS[jid] = {"id": jid, "serie": cid, "total": count, "done": 0,
                     "message": "Démarrage…", "status": "running",
                     "error": "", "made": [], "stop": False}

    def worker():
        def progress(done, total, msg):
            with JOBS_LOCK:
                JOBS[jid]["done"] = done
                JOBS[jid]["message"] = msg

        def stopped():
            with JOBS_LOCK:
                return JOBS[jid]["stop"]

        if not claim_serie(cid):
            with JOBS_LOCK:
                JOBS[jid]["status"] = "error"
                JOBS[jid]["error"] = ("Une génération tourne déjà sur cette série "
                                      "(file d'attente ?). Attends qu'elle finisse.")
                JOBS[jid]["message"] = "Occupée"
            return
        try:
            made = remixer.generate(SERIES_DIR / cid, c, count,
                                    progress=progress, stop_flag=stopped)
            register_made(cid, made)
            with JOBS_LOCK:
                JOBS[jid]["made"] = made
                JOBS[jid]["done"] = len(made)
                JOBS[jid]["status"] = "stopped" if JOBS[jid]["stop"] else "done"
                JOBS[jid]["message"] = (f"{len(made)} vidéo(s) générée(s)"
                                        if made else "Arrêté")
        except Exception as e:                                  # noqa: BLE001
            with JOBS_LOCK:
                JOBS[jid]["status"] = "error"
                JOBS[jid]["error"] = str(e)
                JOBS[jid]["message"] = "Erreur"
        finally:
            release_serie(cid)

    threading.Thread(target=worker, daemon=True).start()
    return jid, ""


# ------------------------------------------------------------------
# Dossier unique regroupant toutes les videos generees
# ------------------------------------------------------------------
# ------------------------------------------------------------------
# Publication (Buffer -> Instagram)
# ------------------------------------------------------------------

PUBLISHED_FILE = ROOT / "published.json"

def draw_description(cid):
    """Legende Instagram pour la prochaine video de cette serie.

    Meme principe que les textes incrustes: on pioche dans un sac melange
    plutot qu'au hasard, pour que les 25 videos du jour n'aient pas trois
    fois la meme legende d'affilee. Le sac est range dans le bags.json de
    la serie, sous une cle qui lui est propre."""
    c = load_serie(cid)
    pool = [d for d in (c or {}).get("descriptions", []) if d.strip()]
    if not pool:
        return ""
    d = serie_path(cid)
    bags = remixer.load_bags(d)
    got = remixer.draw_from_bag(bags, "descriptions", pool, 1)
    remixer.save_bags(d, bags)
    return got[0] if got else ""




def load_published():
    """Ce qui a deja ete envoye, indexe par nom de fichier video."""
    try:
        with open(PUBLISHED_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_published(d):
    tmp = PUBLISHED_FILE.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(str(tmp), str(PUBLISHED_FILE))


# ------------------------------------------------------------------
# Buffer : le bon compte pour chaque campagne
# ------------------------------------------------------------------
# Chaque campagne a SON compte Instagram (`ig_handle`). On le retrouve parmi
# les comptes connectes a Buffer par son nom d'utilisateur. Avant, tout
# partait vers un seul compte « par defaut », quelle que soit la campagne:
# une video MeDo serait sortie sur le compte Replit.
#
# La liste est gardee 30 minutes: la fiche campagne l'affiche et chaque
# publication en a besoin, inutile d'interroger Buffer a chaque fois.
# (Buffer limite le nombre d'appels a son API — avertissement recu le
# 24/09 — et cette liste ne bouge que lorsqu'on connecte un compte.)
_CANAUX = {"t": 0.0, "liste": None, "erreur": None}
_CANAUX_LOCK = threading.Lock()


def canaux_buffer(frais=False):
    with _CANAUX_LOCK:
        # 6 h et non 30 min: un compte Buffer ne se connecte pas deux fois
        # par jour, et 48 appels quotidiens pour s'en assurer pesaient la
        # moitie du budget d'une journee (100 appels). Le bouton
        # « Revérifier » passe `frais=True` quand on vient d'en brancher un.
        # Sauf si un compte est DECONNECTE: on attend alors qu'il soit
        # reconnecte dans Buffer, et 6 h de cache retarderaient d'autant la
        # reprise. Une heure, et seulement tant que ca dure (24 appels/jour
        # au pire, sur un budget de 200).
        ttl = 3600 if any(x.get("isDisconnected") for x in (_CANAUX["liste"] or [])) else 21600
        if not frais and _CANAUX["liste"] is not None and time.time() - _CANAUX["t"] < ttl:
            return _CANAUX["liste"]
    cfg = publisher.load_config()
    if not cfg.get("buffer_api_key"):
        return []
    try:
        liste = publisher.buffer_channels(cfg["buffer_api_key"])
        err = None
    except publisher.PublishError as e:
        liste, err = [], str(e)
    with _CANAUX_LOCK:
        _CANAUX.update(t=time.time(), liste=liste, erreur=err)
    return liste


def _pseudo(h):
    """« @Polo.MakesApps », « instagram.com/polo.makesapps/ » -> « polo.makesapps »."""
    h = str(h or "").strip().lower().rstrip("/")
    h = h.rsplit("/", 1)[-1]
    return h.lstrip("@")


def canal_campagne(cam_id):
    """Le compte Buffer de la campagne, ou None s'il n'y est pas connecte."""
    if not cam_id:
        return None
    c = plateau.campaign(int(cam_id))
    voulu = _pseudo((c or {}).get("ig_handle"))
    if not voulu:
        return None
    for ch in canaux_buffer():
        if voulu in (_pseudo(ch.get("name")), _pseudo(ch.get("displayName"))):
            return ch
    return None


def publier(cid, name, channel_id=None, caption=None, mode="addToQueue", due_at=None):
    """Envoie UNE video a Buffer. Retourne l'enregistrement, erreurs comprises
    (elles sont aussi inscrites dans published.json)."""
    path = find_output(cid, name)
    if not path:
        raise publisher.PublishError("Vidéo introuvable")
    cfg = publisher.load_config()
    cam = serie_campaign_id(cid)
    if not channel_id:
        ch = canal_campagne(cam)
        if ch:
            channel_id = ch["id"]
        elif cam:
            c = plateau.campaign(int(cam)) or {}
            h = c.get("ig_handle")
            raise publisher.PublishError(
                f"Le compte Instagram {'@' + _pseudo(h) if h else 'de la campagne'} "
                f"n'est pas connecté à Buffer." if h else
                "Aucun compte Instagram renseigné dans la campagne.")
        else:
            channel_id = cfg.get("default_channel_id")
    if not channel_id:
        raise publisher.PublishError("Aucun compte Instagram sélectionné")
    if caption is None:
        caption = draw_description(cid) or cfg.get("default_caption", "")
    try:
        rec = publisher.publish_video(cfg, str(path), channel_id, caption=caption,
                                      mode=mode, due_at=due_at,
                                      duration=remixer.probe(str(path))[0])
    except publisher.PublishError as e:
        mark_published(name, {"status": "error", "error": str(e), "serie": cid,
                              "at": time.strftime("%Y-%m-%dT%H:%M:%S")})
        raise
    rec["serie"] = cid
    rec["texte"] = caption
    mark_published(name, rec)
    # La video passe a « Posté ». En file d'attente, Buffer choisit le
    # creneau: on prend la date qu'il renvoie, a defaut celle du jour.
    try:
        when = jour_local(rec.get("due_at")) or time.strftime("%Y-%m-%d")
        plateau.mark_posted(path, when)
        # Une serie peut publier sur le compte d'une AUTRE campagne (light
        # mode sur les deux comptes Replit). La publication compte alors
        # pour la campagne du compte, pas pour celle de la serie: c'est
        # elle dont l'objectif du jour avance.
        cam = campagne_du_canal(channel_id)
        v = plateau.video_by_path(str(path))
        if cam and v and v.get("campaign_id") != cam:
            plateau.update_video(v["id"], {"campaign_id": cam})
    except Exception:                                   # noqa: BLE001
        pass
    effacer_local(path, cid)
    return rec


def jour_local(iso):
    """Date LOCALE d'un horodatage ISO de Buffer (toujours en UTC).

    Buffer renvoie « 2026-09-24T00:30:00Z » pour un post prevu a 20 h 30
    a Montreal: prendre les 10 premiers caracteres inscrivait la video au
    lendemain, et le compteur du jour en perdait deux tous les soirs."""
    from datetime import datetime
    try:
        return (datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
                .astimezone().strftime("%Y-%m-%d"))
    except (TypeError, ValueError):
        return ""


def effacer_local(path, cid):
    """Le .mp4 est chez Buffer: la copie locale ne sert plus.

    Sans ca, generer pour une autre serie obligeait a faire le tri dans des
    dizaines de videos deja parties. La ligne du pipeline, elle, reste: elle
    porte la date de publication et fait le compteur du jour."""
    try:
        p = Path(path)
        nom = p.name
        p.unlink(missing_ok=True)
        # Le lien physique dans « toutes les videos » et la miniature.
        (all_outputs_dir() / nom).unlink(missing_ok=True)
        base = serie_path(cid)
        if base:
            (Path(base) / "thumbs" / (nom + ".jpg")).unlink(missing_ok=True)
    except OSError:
        pass


def videos_non_envoyees(cid):
    """Videos de la serie encore sur le disque et jamais parties.

    Une coupure reseau laisse des .mp4 montes mais non publies: ils
    resservent au tour suivant au lieu d'etre regeneres pour rien (le
    fichier est efface des qu'il part chez Buffer)."""
    base = serie_path(cid)
    if not base:
        return []
    od = Path(remixer.output_dir(base, load_serie(cid)))
    if not od.exists():
        return []
    pub = load_published()
    return sorted(f.name for f in od.glob("*.mp4")
                  if (pub.get(f.name) or {}).get("status") in (None, "error"))


# `rattraper_echecs` et `menage_r2` tournent coup sur coup, dans le meme
# passage horaire, et interrogent Buffer sur LES MEMES comptes a quelques
# secondes d'intervalle. Trois appels par compte au lieu de deux.
#
# Dix minutes de cache partage suffisent a supprimer le doublon sans rien
# perimer: entre les deux taches il s'ecoule une seconde.
_ENTRETIEN = {}
ENTRETIEN_TTL = 600


def _buffer_entretien(key, chan, quoi):
    """`quoi` = "rates" | "file" | "publies". Un seul appel par passage."""
    e = _ENTRETIEN.get(chan)
    if not e or time.time() - e["t"] > ENTRETIEN_TTL:
        e = {"t": time.time()}
        _ENTRETIEN[chan] = e
    if quoi not in e:
        try:
            if quoi == "rates":
                e[quoi] = publisher.buffer_posts_rates(key, chan)
            elif quoi == "file":
                e[quoi] = publisher.buffer_etat_file(key, chan)
            else:
                e[quoi] = publisher.buffer_posts_publies(key, chan)
        except publisher.PublishError:
            e[quoi] = set() if quoi != "file" else (0, [])
    return e[quoi]


def rattraper_echecs():
    """Repropose a Buffer les videos qu'Instagram a refusees.

    Instagram rejette parfois un media sans raison lisible (« issue with
    the media attached ») alors que les autres videos du meme lot passent.
    Le fichier est encore sur R2 — on ne l'efface qu'une fois la video
    publiee — donc il suffit de recreer un post avec la meme URL, a une
    heure libre. Deux essais au plus: au troisieme echec, c'est la video
    qui a un probleme, pas Buffer."""
    pub = load_published()
    candidats = [(n, r) for n, r in pub.items()
                 if r.get("post_id") and r.get("r2_key") and not r.get("r2_efface")
                 and int(r.get("essais") or 0) < 2]
    if not candidats:
        return 0
    cfg = publisher.load_config()
    key = cfg.get("buffer_api_key")
    rates, n = {}, 0
    # Un compte deconnecte fait echouer TOUT renvoi: on garde les essais
    # pour quand il sera reconnecte, au lieu de les bruler en deux tours.
    coupes = {x.get("id") for x in canaux_buffer() if x.get("isDisconnected")}
    for nom, rec in candidats:
        chan = rec.get("channel_id")
        if chan in coupes:
            continue
        if chan not in rates:
            rates[chan] = _buffer_entretien(key, chan, "rates")
            rates[chan + "|h"] = _buffer_entretien(key, chan, "file")[1]
        if rec["post_id"] not in rates[chan]:
            continue
        quand = auto_horaires(1, rates.get(chan + "|h") or [])
        if not quand:
            continue                      # plus de creneau: on reessaiera demain
        try:
            post = publisher.buffer_create_video_post(
                key, chan, rec["video_url"], rec.get("texte", ""),
                mode="customScheduled", due_at=quand[0])
        except publisher.PublishError as e:
            rec["erreur_rattrapage"] = str(e)
            mark_published(nom, rec)
            continue
        rates[chan + "|h"] = list(rates.get(chan + "|h") or []) + [quand[0]]
        rec["post_id"] = post.get("id")
        rec["due_at"] = post.get("dueAt") or quand[0]
        rec["essais"] = int(rec.get("essais") or 0) + 1
        rec["erreur_rattrapage"] = ""
        mark_published(nom, rec)
        n += 1
    return n


def menage_r2():
    """Efface du stockage les videos que Buffer a deja publiees.

    Buffer telecharge la video au moment de publier: avant ca, le fichier
    doit rester en ligne. Apres, il ne sert plus a rien et il compte dans
    les 10 Go gratuits de Cloudflare — 26 Mo par video, une dizaine par
    jour."""
    pub = load_published()
    a_faire = [(n, r) for n, r in pub.items()
               if r.get("r2_key") and r.get("post_id") and not r.get("r2_efface")]
    if not a_faire:
        return 0
    cfg = publisher.load_config()
    key = cfg.get("buffer_api_key")
    publies, n = {}, 0
    for nom, rec in a_faire:
        chan = rec.get("channel_id")
        if chan not in publies:
            publies[chan] = _buffer_entretien(key, chan, "publies")
        if rec["post_id"] not in publies[chan]:
            continue                      # pas encore publiee: on garde
        try:
            publisher.r2_delete(cfg, rec["r2_key"])
        except publisher.PublishError:
            continue
        rec["r2_efface"] = True
        mark_published(nom, rec)
        n += 1
    return n


def campagne_du_canal(channel_id):
    """Campagne dont le compte Instagram est ce compte Buffer, ou None."""
    ch = next((x for x in canaux_buffer() if x.get("id") == channel_id), None)
    if not ch:
        return None
    noms = {_pseudo(ch.get("name")), _pseudo(ch.get("displayName"))} - {""}
    # DEUX CAMPAGNES PEUVENT PORTER LE MEME PSEUDO: un compte Instagram se
    # reutilise d'un deal au suivant (@hooknpolo etait a SomeSome, il est a
    # lovable). On rendait alors la premiere par ordre alphabetique, et si
    # c'etait l'ancienne — en pause — `auto_tour_serie` arretait tout avec
    # « Campagne en pause » pour une campagne qui ne publie plus depuis des
    # semaines. La campagne ACTIVE l'emporte; la pause ne compte que si
    # aucune active ne porte ce pseudo.
    repli = None
    for c in plateau.campaigns():
        if _pseudo(c.get("ig_handle")) in noms:
            if not c.get("paused"):
                return c["id"]
            if repli is None:
                repli = c["id"]
    return repli


# ------------------------------------------------------------------
# Envoi automatique quotidien vers Buffer
# ------------------------------------------------------------------
# Generer et publier sont INDEPENDANTS. « Generer » a la main n'envoie
# jamais rien. Une serie peut en plus fixer `auto_jour` = N: chaque jour,
# le plateau genere lui-meme N videos de cette serie et les met dans la
# file Buffer du compte de sa campagne. Buffer les etale selon son planning
# d'horaires.
#
# Tourne tant que le serveur est lance: un Mac eteint rattrape la journee
# au prochain demarrage (pas les jours manques — on ne publie pas 3 jours
# de retard d'un coup).
#
# Le compte « envoyees aujourd'hui » vit dans auto_buffer.json. Tant qu'il
# est sous N, chaque tour complete, dans la limite de la place libre dans
# la file Buffer (10 posts en attente sur le plan gratuit): une video qui ne
# pourrait pas y entrer n'est meme pas generee.
AUTO_FILE = ROOT / "auto_buffer.json"
AUTO_LOCK = threading.Lock()
# Posts qu'on accepte de laisser en attente chez Buffer.
#
# Le forfait GRATUIT n'en garde que 10 par compte, et c'est cette limite
# qui coutait le plus cher en appels d'API: la file restait pleine toute
# la journee, il fallait sans arret revenir voir si une place s'etait
# liberee. Sur un forfait payant la file est pratiquement illimitee
# (politique d'usage raisonnable, quelques milliers par compte), donc la
# journee entiere part en une fois et on ne redemande plus rien.
#
# SUIT DONC LE FORFAIT, ce n'est pas un reglage de confort: au-dela de la
# limite du compte Buffer refuse le post. 100 sur Essentials, 10 sur le
# gratuit — le compte est repasse au gratuit le 01/11, d'ou 10.
BUFFER_FILE_MAX = 10
# Mais on ne MONTE pas 100 videos d'affilee pour autant: `auto_tour_serie`
# garde le verrou de la serie pendant toute la fabrication, et une
# generation lancee a la main attendrait tout ce temps. Par lot, donc,
# comme avant — c'etait la file a 10 qui imposait cette taille, pas un
# choix: elle devient explicite.
AUTO_LOT_MAX = 10
AUTO_TOUR_S = 300          # un passage toutes les 5 minutes
# Fenetre de publication, heure locale du Mac. Les N videos du jour sont
# etalees regulierement entre ces deux heures. C'est le plateau qui fixe
# l'heure de chaque post (mode customScheduled), pas le planning de Buffer:
# ce planning ne se regle pas par l'API, et celui du compte n'avait que 2
# creneaux par jour pour un objectif de 10.
AUTO_DEBUT_H = 4
# 21 h et non plus minuit (demande du 06/11): un post de 23 h tombe quand
# le public dort. 25 posts tiennent encore a 41 min d'ecart en 17 h.
AUTO_FIN_H = 21            # 24 = minuit, donc dernier envoi possible a 23 h 59


def fin_auto(maintenant):
    """Dernier instant ou un post peut partir aujourd'hui."""
    if AUTO_FIN_H >= 24:
        return maintenant.replace(hour=23, minute=59, second=0, microsecond=0)
    return maintenant.replace(hour=AUTO_FIN_H, minute=0, second=0, microsecond=0)


def fin_auto_txt():
    return "minuit" if AUTO_FIN_H >= 24 else f"{AUTO_FIN_H} h"
AUTO_PAUSE_ERREUR_S = 3600  # apres un echec, on ne reessaie pas avant 1 h
# ...SAUF si c'est le reseau qui a flanche. Une cle refusee ou un post
# invalide ne se reparent pas en reessayant: attendre une heure est sense.
# Une coupure de wifi, si — et la meme penalite d'une heure a transforme,
# le 15/10, une panne de DNS de l'apres-midi en douze videos non publiees.
# On repasse donc au tour suivant, dans cinq minutes.
AUTO_PAUSE_RESEAU_S = 300
# Ecart minimum entre deux posts du meme compte. Vingt minutes pour le
# PLAN du matin, qui a toute la journee devant lui; huit seulement pour le
# RATTRAPAGE, qui n'a plus que ce qu'il reste. Un seul chiffre pour les
# deux et le rattrapage echoue: c'est exactement ce qui faisait disparaitre
# deux a trois videos par jour (mesure plus bas, dans `recaler_plan`).
ECART_MINI = 20
ECART_RATTRAPAGE = 8


def auto_etats():
    try:
        return json.loads(AUTO_FILE.read_text("utf-8"))
    except (OSError, ValueError):
        return {}


# Etat du jour PAR (serie, compte): cle "serie|compte". Une serie qui
# publie sur deux comptes a deux compteurs, et chaque compte recoit ses N
# videos (des videos differentes, generees pour lui).
def auto_maj(cle, **champs):
    with AUTO_LOCK:
        d = auto_etats()
        e = d.get(cle) or {}
        jour = time.strftime("%Y-%m-%d")
        if e.get("jour") != jour:              # nouveau jour: compteur a zero
            e = {"jour": jour, "envoyees": 0}
        e.update(champs)
        d[cle] = e
        tmp = AUTO_FILE.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), "utf-8")
        os.replace(str(tmp), str(AUTO_FILE))
        return e


def auto_etat(cle):
    e = auto_etats().get(cle) or {}
    if e.get("jour") != time.strftime("%Y-%m-%d"):
        return {"jour": time.strftime("%Y-%m-%d"), "envoyees": 0}
    return e


def auto_horaires(n, prises=(), mini=ECART_MINI, debut_h=None):
    """Heures de publication pour les `n` videos qui restent aujourd'hui.

    Entre maintenant (ou 4 h) et AUTO_FIN_H. Chaque video est posee au MILIEU
    du plus grand trou libre, en comptant les heures deja prises sur le
    compte (`prises`, posts programmes et deja publies).

    Un simple etalement regulier suffisait tant que le lot partait d'un
    coup. Mais quand la file Buffer est pleine, le reste part une ou deux
    heures plus tard et se re-etalait sur la journee entiere, sans voir les
    heures deja reservees: mesure le 24/09, deux posts a 11 h 00 et 11 h 10,
    deux autres a 19 h 32 et 19 h 35.

    Liste vide passe 23 h 29: on ne tasse pas les posts restants dans la
    derniere demi-heure, la journee est perdue.

    `mini` est l'ecart minimum accepte. Le plan du matin le veut large
    (ECART_MINI), un rattrapage de fin de journee s'en contente de peu
    (ECART_RATTRAPAGE): mieux vaut deux posts a huit minutes d'ecart
    qu'une video jamais partie."""
    from datetime import datetime, timedelta, timezone
    maintenant = datetime.now().astimezone()
    # `debut_h`: une serie peut commencer plus tard que AUTO_DEBUT_H
    # (`auto_debut_h`, Buzzy a 5 h). Jamais plus tot: la fin reste commune.
    h0 = AUTO_DEBUT_H if debut_h is None else max(0, min(int(debut_h), 23))
    debut = maintenant.replace(hour=h0, minute=0, second=0, microsecond=0)
    fin = fin_auto(maintenant)
    debut = max(debut, maintenant + timedelta(minutes=10))
    if n <= 0 or fin - debut < timedelta(minutes=mini + 10):
        return []

    # Bornes du jour + heures deja prises a l'interieur.
    points = [debut, fin]
    for p in prises:
        t = jour_local_dt(p)
        if t and debut < t < fin:
            points.append(t)
    points.sort()

    out = []
    for _ in range(n):
        i = max(range(len(points) - 1), key=lambda k: points[k + 1] - points[k])
        trou = points[i + 1] - points[i]
        # Au milieu du trou, a un quart d'ecart pres: deux journees de suite
        # ne tombent pas aux memes minutes.
        if trou < timedelta(minutes=mini):
            break              # plus de place: deux posts colles ne servent a rien
        t = points[i] + trou / 2 + trou * random.uniform(-0.15, 0.15)
        points.insert(i + 1, t)
        out.append(t.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"))
    out.sort()
    return out


def recaler_plan(plan, mini=ECART_RATTRAPAGE):
    """Le plan du jour, creneaux depasses REPOUSSES — jamais jetes.

    Un creneau dont l'heure est passee (file Buffer pleine pendant ce
    temps-la, ou dix minutes de montage) etait avant simplement supprime,
    la video comptant sur un creneau recalcule plus tard. Mais en fin de
    journee il n'y a plus de place a recalculer: la fenetre 4 h - minuit
    tient 26 posts a 46 minutes d'ecart, et `auto_horaires` refuse de
    descendre sous ECART_MINI. Chaque creneau rate le matin etait donc
    perdu pour de bon. Mesure le 06/10 a 13 h 43: 21 envoyees sur 26,
    3 creneaux au plan, 2 videos envolees avant meme la fin de l'apres-midi.

    On repousse donc: le creneau depasse part dans cinq minutes, le
    suivant `mini` minutes apres, et ainsi de suite. Les creneaux encore
    a venir ne bougent pas, sauf si la cascade les atteint. Un post de
    rattrapage peut tomber pres d'un post deja programme par Buffer: on
    l'accepte, une video qui part cinq minutes trop tot vaut mieux qu'une
    video qui ne part pas.

    Ce qui depasse AUTO_FIN_H est perdu — la, c'est vraiment la journee qui
    est finie."""
    from datetime import datetime, timedelta, timezone
    maintenant = datetime.now().astimezone()
    fin = fin_auto(maintenant)
    t_min = maintenant + timedelta(minutes=5)
    sortie = []
    for h in sorted(plan):
        t = jour_local_dt(h)
        if t is None:
            continue
        t = max(t, t_min)
        if t > fin:
            break
        sortie.append(t.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"))
        t_min = t + timedelta(minutes=mini)
    return sortie


def a_venir(heures):
    """Celles de ces heures qui sont encore dans le futur, triees."""
    out = [t for t in (jour_local_dt(h) for h in heures)
           if t and t.timestamp() > time.time()]
    return sorted(out)


def prochaine_place(prises):
    """Quand une place se liberera dans la file Buffer (horodatage unix).

    C'est l'heure du prochain post deja programme, plus une minute: des
    que Buffer l'a publie, il reste neuf en attente et on peut en pousser
    un. Sans post a venir (file pleine de posts passes, ce qui ne devrait
    pas arriver), on retente dans un quart d'heure plutot que de ne plus
    jamais revenir."""
    futurs = [t for t in (jour_local_dt(h) for h in prises)
              if t and t.timestamp() > time.time()]
    return (min(futurs).timestamp() + 60) if futurs else (time.time() + 900)


def datetime_now_plus(minutes):
    from datetime import datetime, timedelta
    return datetime.now().astimezone() + timedelta(minutes=minutes)


def jour_local_dt(iso):
    from datetime import datetime
    try:
        return datetime.fromisoformat(str(iso).replace("Z", "+00:00")).astimezone()
    except (TypeError, ValueError):
        return None


def comptes_serie(cid, c=None):
    """Comptes Buffer sur lesquels la serie publie.

    `buffer_comptes` (ids Buffer) si la serie en a choisi; sinon le compte
    de sa campagne. Un compte choisi puis deconnecte de Buffer est ignore."""
    c = c or load_serie(cid) or {}
    chans = {x["id"]: x for x in canaux_buffer()}
    choisis = [chans[i] for i in (c.get("buffer_comptes") or []) if i in chans]
    if c.get("buffer_comptes"):
        return choisis
    ch = canal_campagne(serie_campaign_id(cid))
    return [ch] if ch else []


def auto_bloquant(cid, c=None):
    """Ce qui empeche tout envoi auto de cette serie, ou None."""
    c = c or load_serie(cid)
    if not c:
        return "Série introuvable"
    if c.get("paused"):
        return "Série mise de côté"
    # Campagne en pause: le deal est suspendu, ses series n'envoient plus.
    cam = serie_campaign_id(cid)
    camp = plateau.campaign(int(cam)) if cam else None
    if camp and camp.get("paused"):
        return "Campagne en pause"
    if not [d for d in c.get("descriptions", []) if d.strip()]:
        return "Aucune légende Instagram"
    if not comptes_serie(cid, c):
        # Distinguer « rien de choisi » de « Buffer n'a pas repondu ».
        # Quand l'API est coupee, la liste des comptes revient VIDE et le
        # plateau accusait un reglage: le 13/10 il affichait « Aucun
        # compte Buffer choisi » alors que le quota d'API etait a zero,
        # ce qui envoie chercher le probleme a l'oppose de sa cause.
        return _CANAUX.get("erreur") or "Aucun compte Buffer choisi"
    return None


def auto_jour_effectif(cid, c=None):
    """Nombre de videos a envoyer AUJOURD'HUI.

    Changer le chiffre en cours de journee ne doit rien ajouter a la
    journee deja lancee: la nouvelle valeur est rangee dans `auto_demain`
    avec sa date, et prend le relais le lendemain. Tant que rien n'est
    parti dans la journee, le changement s'applique tout de suite — c'est
    le cas du reglage qu'on vient de poser."""
    c = c or load_serie(cid) or {}
    dem = c.get("auto_demain")
    if isinstance(dem, dict) and dem.get("depuis") and dem["depuis"] < time.strftime("%Y-%m-%d"):
        c["auto_jour"] = int(dem.get("n") or 0)
        c.pop("auto_demain", None)
        save_serie(c)
    monter_palier(c)
    return int(c.get("auto_jour") or 0), c


def monter_palier(c):
    """Monte l'objectif d'un cran par jour, jusqu'a son plafond.

    On ne passe pas de 0 a 27 videos par jour du jour au lendemain: un
    compte qui multiplie son rythme d'un coup se fait remarquer. Trois
    champs suffisent — `auto_pas` (le cran), `auto_plafond` (ou s'arreter)
    et `auto_palier_jour` (le dernier jour applique).

    LE RATTRAPAGE COMPTE LES JOURS, pas les passages. Si le Mac reste
    eteint trois jours, on monte de trois crans au reveil et pas d'un
    seul: le palier suit le calendrier, pas la disponibilite de la
    machine. Il s'arrete net au plafond.

    Appele depuis `auto_jour_effectif`, donc APRES la promotion de
    `auto_demain`: un chiffre pose a la main l'emporte sur le palier du
    jour, sinon regler la valeur ne servirait a rien."""
    pas = int(c.get("auto_pas") or 0)
    plafond = int(c.get("auto_plafond") or 0)
    if pas <= 0 or plafond <= 0:
        return
    aujourd = time.strftime("%Y-%m-%d")
    depuis = c.get("auto_palier_jour") or ""
    if depuis == aujourd:
        return
    if not depuis:                       # premier jour: on ne monte pas
        c["auto_palier_jour"] = aujourd
        save_serie(c)
        return
    jours = _jours_entre(depuis, aujourd)
    if jours <= 0:
        return
    n = min(plafond, int(c.get("auto_jour") or 0) + pas * jours)
    c["auto_jour"] = n
    c["auto_palier_jour"] = aujourd
    # Arrive au plafond, le palier n'a plus de raison d'etre: on le
    # retire pour que le chiffre cesse de bouger tout seul.
    if n >= plafond:
        c.pop("auto_pas", None)
        c.pop("auto_plafond", None)
        c.pop("auto_palier_jour", None)
    save_serie(c)


def _jours_entre(a, b):
    from datetime import date
    try:
        ya, ma, da = (int(x) for x in a.split("-"))
        yb, mb, db = (int(x) for x in b.split("-"))
        return (date(yb, mb, db) - date(ya, ma, da)).days
    except (ValueError, TypeError):
        return 0


def auto_envoyees_aujourdhui(cid, c=None):
    return sum(auto_etat(f"{cid}|{ch['id']}").get("envoyees") or 0
               for ch in comptes_serie(cid, c))


def auto_tour_serie(cid):
    n_jour, c = auto_jour_effectif(cid)
    if n_jour <= 0:
        return
    bloque = auto_bloquant(cid, c)
    if bloque:
        auto_maj(cid, erreur=bloque, erreur_t=time.time())
        return
    auto_maj(cid, erreur="")
    cfg = publisher.load_config()
    for ch in comptes_serie(cid, c):
        cle = f"{cid}|{ch['id']}"
        # Une campagne en pause ne publie plus sur SON compte, meme depuis
        # une serie d'une autre campagne.
        cam = campagne_du_canal(ch["id"])
        camp = plateau.campaign(int(cam)) if cam else None
        if camp and camp.get("paused"):
            auto_maj(cle, attente="Campagne en pause")
            continue
        # COMPTE DECONNECTE DE BUFFER: Buffer ACCEPTE encore les posts,
        # puis chacun echoue a l'heure dite (« Buffer has lost authorization
        # to post on your behalf »). Le 11/11, huit videos de Voyager sont
        # parties dans le vide, puis rattraper_echecs les a renvoyees et
        # chaque renvoi a echoue aussi. Seul un humain peut reconnecter le
        # compte (connexion Instagram) — on attend, on ne gaspille rien.
        if ch.get("isDisconnected"):
            auto_maj(cle, erreur=f"@{ch.get('name')} est déconnecté de Buffer — "
                                 "reconnecte le compte dans Buffer", erreur_t=time.time())
            continue
        # Reconnecte: on efface le message ET sa pause d'une heure, sinon
        # il restait affiche jusqu'au lendemain sur un compte qui marche.
        if "déconnecté de Buffer" in (auto_etat(cle).get("erreur") or ""):
            auto_maj(cle, erreur="", erreur_t=0)
        etat = auto_etat(cle)
        reste = n_jour - int(etat.get("envoyees") or 0)
        if reste <= 0:
            continue
        pause = (AUTO_PAUSE_RESEAU_S if etat.get("reseau")
                 else AUTO_PAUSE_ERREUR_S)
        if etat.get("erreur_t") and time.time() - etat["erreur_t"] < pause:
            continue
        # LA FILE NE SE VIDE PAS TOUTE SEULE ENTRE DEUX POSTS.
        #
        # Quand les 10 places de Buffer sont prises, la suivante ne se
        # libere qu'au moment ou Buffer publie — une heure plus tard en
        # moyenne. Redemander l'etat toutes les 5 minutes entre-temps
        # coutait 240 appels par jour pour 240 fois la meme reponse, sur
        # un quota de 3000 PAR 30 JOURS (100 par jour). C'est ce qui a
        # vide le seau le 12/10 et coupe huit jours de publication.
        #
        # On sait quand une place se libere: c'est l'heure du prochain
        # post deja programme. On attend jusque-la.
        if etat.get("prochain") and time.time() < etat["prochain"]:
            continue
        # L'ETAT DE LA FILE SE DEDUIT, IL NE SE REDEMANDE PAS.
        #
        # On connait chaque heure qu'on a programmee (`programmes`): ce qui
        # est encore a venir est exactement ce qui occupe la file Buffer.
        # Le redemander coutait DEUX appels par place liberee — un pour
        # constater la place, un pour reconstater au tour suivant que la
        # file est pleine. Sur le forfait gratuit (file de 10, donc quinze
        # places liberees une par une pour 25 videos) ca faisait une
        # trentaine d'appels par jour sur un budget de cent.
        #
        # On interroge Buffer UNE fois par jour et par compte, au premier
        # tour: des posts peuvent avoir ete programmes a la main ou rester
        # d'hier, et c'est la seule chose que le journal ne peut pas
        # savoir. Et on recale apres un echec, qui est justement le cas ou
        # le journal a pu deriver de la realite.
        journal = list(etat.get("programmes") or [])
        if etat.get("vu") and not etat.get("resync"):
            prises = journal
            en_attente = len(a_venir(journal))
        else:
            try:
                en_attente, prises = publisher.buffer_etat_file(cfg["buffer_api_key"], ch["id"])
            except publisher.PublishError as e:
                # L'etat de la file est un CONFORT: il sert a savoir s'il
                # reste de la place et a eviter deux posts colles. Quand il
                # est refuse pour economiser le budget, on ne doit surtout
                # pas arreter de publier pour autant — ce serait se tirer
                # dans le pied. On repart du plan deja calcule, qui contient
                # justement les heures a respecter.
                if "budget" not in str(e).lower() or not etat.get("plan"):
                    auto_maj(cle, erreur=str(e), erreur_t=time.time(),
                             reseau=isinstance(e, publisher.ReseauError))
                    continue
                en_attente, prises = len(a_venir(journal)), list(etat.get("plan") or [])
                auto_maj(cle, attente="Budget serré — file non vérifiée")
            else:
                # Le journal repart de ce que Buffer dit VRAIMENT. Ce qui
                # est encore a venir est ce qui attend; ce qui est passe
                # est deja publie et ne tient plus de place.
                journal = [t.isoformat() for t in a_venir(prises)]
                auto_maj(cle, vu=1, resync=0, programmes=journal)
        libre = BUFFER_FILE_MAX - en_attente
        # PLAN DE LA JOURNEE, calcule une seule fois.
        #
        # La file Buffer ne garde que 10 posts: les videos suivantes ne
        # partent qu'une fois de la place liberee, en fin de journee. En
        # recalculant « le plus grand trou libre » a ce moment-la, les
        # dernieres se tassaient toutes le soir — mesure le 29/09: six
        # posts entre 21 h 23 et 22 h 53. Le plan, lui, repartit les N
        # videos du jour d'un bout a l'autre et chaque envoi prend le
        # prochain creneau prevu, meme des heures plus tard.
        plan = [h for h in (etat.get("plan") or []) if jour_local(h) == time.strftime("%Y-%m-%d")]
        plan = recaler_plan(plan)
        if len(plan) < reste:
            # Plan vide = premier tour de la journee: on etale largement.
            # Plan deja entame = on complete ce qui manque, et la il faut
            # accepter de serrer, sinon la fin de journee ne rentre plus.
            plan += auto_horaires(reste - len(plan), list(prises) + plan,
                                  mini=ECART_RATTRAPAGE if plan else ECART_MINI,
                                  debut_h=c.get("auto_debut_h"))
            plan.sort()
        auto_maj(cle, plan=plan)
        n = min(reste, libre, len(plan), AUTO_LOT_MAX)
        if n <= 0 and libre > 0:
            auto_maj(cle, attente=f"Plus de créneau avant {fin_auto_txt()}")
            continue
        if n <= 0:
            # File pleine: pas une erreur, Buffer va publier et liberer de
            # la place. On revient quand ce sera fait, pas avant.
            auto_maj(cle, erreur="", attente="File Buffer pleine",
                     prochain=prochaine_place(prises))
            continue
        auto_maj(cle, prochain=0)          # il reste de la place: on suit
        if not claim_serie(cid):
            return                           # une generation manuelle tourne
        try:
            auto_maj(cle, en_cours=True, erreur="", attente="", reseau=False)
            # Des videos deja sur le disque et jamais parties (coupure
            # reseau au tour precedent): on les envoie AVANT d'en fabriquer
            # de nouvelles, sinon elles s'accumulent pour rien.
            restes = videos_non_envoyees(cid)[:n]
            made = restes + list(remixer.generate(SERIES_DIR / cid, c, n - len(restes)))
            register_made(cid, made)
            for name in made:
                # Fichier disparu entre-temps (« Tout supprimer » pendant
                # le lot): on le saute, sans arreter les autres ni mettre
                # la serie en pause pour une heure.
                if not find_output(cid, name):
                    continue
                # L'heure est calculee ICI, pas avant la generation: monter
                # dix videos prend plus de dix minutes, et le premier
                # creneau prevu etait deja passe quand on l'envoyait
                # (« Scheduled time must be in the future »).
                # Prochain creneau du plan, repousse s'il est deja passe
                # (le montage a pris plus longtemps que prevu).
                plan = recaler_plan(plan)
                if not plan:
                    auto_maj(cle, attente=f"Plus de créneau avant {fin_auto_txt()}")
                    break
                quand = [plan.pop(0)]
                auto_maj(cle, plan=plan)
                try:
                    publier(cid, name, channel_id=ch["id"],
                            mode="customScheduled", due_at=quand[0])
                    e = auto_etat(cle)
                    journal.append(quand[0])
                    auto_maj(cle, envoyees=int(e.get("envoyees") or 0) + 1,
                             dernier=time.strftime("%H:%M"),
                             programmes=journal)
                except publisher.PublishError as err:
                    # Un echec perime le journal: on ne sait plus ce que
                    # Buffer a vraiment pris. `resync` fait redemander
                    # l'etat reel au prochain tour — c'est la seule
                    # occasion ou ca vaut un appel.
                    auto_maj(cle, erreur=str(err), erreur_t=time.time(),
                             resync=1,
                             reseau=isinstance(err, publisher.ReseauError))
                    break
        except Exception as err:                            # noqa: BLE001
            auto_maj(cle, erreur=f"Génération : {err}", erreur_t=time.time())
        finally:
            # LA PLACE SUIVANTE SE CALCULE ICI, SANS RIEN REDEMANDER.
            # On vient de remplir la file: si elle est pleine, la place
            # suivante se libere a la premiere de nos heures a venir.
            # Avant il fallait un tour de plus, et un appel de plus, pour
            # le decouvrir — un appel par place liberee, quinze par jour
            # sur une file de dix.
            suite = a_venir(journal)
            if len(suite) >= BUFFER_FILE_MAX:
                auto_maj(cle, attente="File Buffer pleine",
                         prochain=suite[0].timestamp() + 60)
            auto_maj(cle, en_cours=False)
            release_serie(cid)


# ------------------------------------------------------------------
# Classement Discord
# ------------------------------------------------------------------
# Le suivi de l'argent reste MANUEL et le restera: les gens envoient une
# capture dans le groupe, on verifie, on renomme le membre « Marc 1240$ ».
# Ce renommage est la seule source — il n'y a pas de seconde liste a tenir
# a jour, donc rien a reconcilier le jour ou les deux divergent.
_CLASSEMENT = {"t": 0.0, "lignes": [], "sans": 0, "erreur": "", "jours": 0}

# Historique des montants, une photo par jour. Le pseudo ne porte que le
# total du moment: sans ces photos, « combien il a monte cette semaine »
# est impossible a repondre. Range a part de publish_config.json, qui
# contient des secrets et n'a pas a grossir d'un journal.
CLASSEMENT_HIST = ROOT / "classement_historique.json"
# Le branchement du bot se fait dans un FICHIER TEXTE, pas dans l'app: le
# classement se lit dans Discord, il n'a aucune raison d'occuper un ecran
# ici. Trois lignes a remplir une fois. Le programme, lui, n'ecrit que son
# etat (identifiant du message, date du dernier envoi) dans
# publish_config.json — jamais dans ce fichier-ci, qui reste a l'utilisateur.
CLASSEMENT_CONF = ROOT / "discord.txt"
MODELE_CONF = """# Classement Discord — remplis les trois lignes, garde le reste.
#
# jeton   : portail Discord > ton application > Bot > Reset Token
#           (coche aussi SERVER MEMBERS INTENT sur la meme page)
# serveur : clic droit sur le serveur > Copy Server ID
# salon   : clic droit sur le salon    > Copy Channel ID
#           (Discord > Settings > Advanced > Developer Mode pour les voir)
#
# titre et chaque_jour sont facultatifs.

jeton =
serveur =
salon =
titre = Classement
chaque_jour = oui
"""


def classement_conf():
    """Les reglages du bot, lus dans discord.txt a chaque fois.

    Relu a chaque appel et jamais mis en cache: corriger une faute de
    frappe dans le fichier doit prendre effet sans redemarrer le serveur."""
    if not CLASSEMENT_CONF.exists():
        try:
            CLASSEMENT_CONF.write_text(MODELE_CONF, "utf-8")
            os.chmod(str(CLASSEMENT_CONF), 0o600)   # il contiendra un jeton
        except OSError:
            pass
        return {}
    out = {}
    try:
        for ligne in CLASSEMENT_CONF.read_text("utf-8").splitlines():
            ligne = ligne.strip()
            if not ligne or ligne.startswith("#") or "=" not in ligne:
                continue
            cle, _, val = ligne.partition("=")
            out[cle.strip().lower()] = val.strip()
    except OSError:
        return {}
    return out
HIST_JOURS = 120


def hist_charger():
    try:
        d = json.loads(CLASSEMENT_HIST.read_text("utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def hist_noter(lignes):
    """Photo du jour. Ecrite sous l'IDENTIFIANT Discord, pas sous le nom:
    c'est la seule cle qui survit a un renommage — et renommer, c'est
    precisement ce qu'on fait pour mettre un montant a jour."""
    h = hist_charger()
    h[jour_courant()] = {l["id"]: l["montant"] for l in lignes if l.get("id")}
    for vieux in sorted(h)[:-HIST_JOURS]:
        h.pop(vieux, None)
    tmp = CLASSEMENT_HIST.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(h, ensure_ascii=False, indent=1), "utf-8")
    os.replace(str(tmp), str(CLASSEMENT_HIST))


def hist_base_semaine():
    """(montants d'avant, nombre de jours de recul). (None, 0) si on n'a
    rien a comparer.

    On vise sept jours: la photo la plus recente datant d'au moins une
    semaine — et non « celle du lundi », un classement ouvert un mercredi
    n'aurait rien a montrer pendant cinq jours.

    Tant que l'historique n'est pas assez profond, on se rabat sur la plus
    ANCIENNE photo disponible et on dit de combien de jours il s'agit.
    Attendre une semaine entiere avant d'afficher quoi que ce soit, c'est
    une semaine ou la colonne la plus motivante du tableau reste vide."""
    from datetime import date, timedelta
    h = hist_charger()
    if not h:
        return None, 0
    aujourdhui = date.today()
    limite = (aujourdhui - timedelta(days=7)).isoformat()
    passees = sorted(j for j in h if j <= limite)
    choisi = passees[-1] if passees else min(h)
    try:
        jours = (aujourdhui - date.fromisoformat(choisi)).days
    except ValueError:
        return None, 0
    if jours < 1:
        return None, 0                    # une seule photo, celle du jour
    return h[choisi], jours


def jour_courant():
    """Date locale, pour ne publier qu'une fois par jour."""
    return time.strftime("%Y-%m-%d")


def classement_lignes(frais=False):
    """(classement, nombre de membres sans montant). Garde 2 min.

    Lire les membres coute un appel par millier: inutile de le refaire a
    chaque ouverture de la vue, le pseudo d'un membre ne change pas dix
    fois par minute."""
    conf = classement_conf()
    tok = conf.get("jeton") or ""
    guild = conf.get("serveur") or ""
    if not (tok and guild):
        raise classement.ClassementError("Jeton du bot ou identifiant du serveur manquant")
    if not frais and time.time() - _CLASSEMENT["t"] < 120:
        if _CLASSEMENT["erreur"]:
            raise classement.ClassementError(_CLASSEMENT["erreur"])
        return _CLASSEMENT["lignes"], _CLASSEMENT["sans"]
    try:
        gens = classement.membres(tok, guild)
    except classement.ClassementError as e:
        _CLASSEMENT.update(t=time.time(), erreur=str(e))
        raise
    lignes = classement.classer(gens)
    hist_noter(lignes)
    base, jours = hist_base_semaine()
    _CLASSEMENT["jours"] = jours
    for l in lignes:
        avant = (base or {}).get(l["id"])
        # None = pas de photo d'il y a une semaine, ou personne absente a
        # l'epoque. Zero serait un mensonge: on ne sait pas, on ne dit rien.
        l["semaine"] = None if avant is None else round(l["montant"] - avant, 2)
    _CLASSEMENT.update(t=time.time(), lignes=lignes,
                       sans=len(gens) - len(lignes), erreur="")
    return lignes, len(gens) - len(lignes)


def publier_classement(frais=True):
    """Ecrit (ou modifie) le tableau dans le salon. Renvoie le nombre de
    lignes publiees."""
    conf = classement_conf()
    salon = conf.get("salon") or ""
    if not salon:
        raise classement.ClassementError(
            f"Salon non renseigné dans {CLASSEMENT_CONF.name}")
    lignes, sans = classement_lignes(frais=frais)
    cfg = publisher.load_config()
    titre = conf.get("titre") or "Classement"
    png = carte_classement(lignes, sans, titre, conf.get("serveur"), conf["jeton"],
                           _CLASSEMENT.get("jours") or 7)
    if png:
        mid = classement.publier_image(conf["jeton"], salon, png,
                                       cfg.get("discord_message"))
    else:
        # Sans AppKit (hors macOS), le tableau en texte fait le travail.
        mid = classement.publier(conf["jeton"], salon,
                                 classement.tableau(lignes, titre),
                                 cfg.get("discord_message"))
    # Relu APRES l'appel reseau: la configuration a pu changer entre-temps
    # (l'interface ecrit dans le meme fichier).
    cfg = publisher.load_config()
    cfg["discord_message"] = mid
    cfg["discord_jour"] = jour_courant()
    publisher.save_config(cfg)
    return len(lignes)


def carte_classement(lignes, sans, titre, guild, jeton, jours=7):
    """La carte en image, avec les vraies photos de profil.

    Les avatars sont telecharges a chaque fois: ils changent, et quinze
    petites images ne coutent rien a cote de la lecture des membres. Un
    avatar qui ne repond pas laisse une pastille a l'initiale, jamais un
    trou — et surtout n'empeche pas la carte de sortir."""
    if not carte.disponible():
        return None
    avatars = {}
    for l in lignes[:carte.MAX_LIGNES]:
        u = classement.url_avatar(l, guild)
        if u:
            octets = classement.telecharger(u)
            if octets:
                avatars[l["id"]] = octets
    from datetime import datetime
    # Pas de decompte des zeros ni des non-declares: c'est un classement,
    # il met en avant ceux qui vendent — pas un releve de qui ne vend pas.
    pied = datetime.now().strftime("Mis à jour le %d/%m à %H:%M")
    return carte.rendre(lignes, str(ROOT / ".classement.png"), titre,
                        "Montants déclarés · mis à jour chaque jour", pied,
                        avatars, jours=jours)


# ------------------------------------------------------------------
# Prospection Reddit
# ------------------------------------------------------------------
# Seuils demandes: 500 $/mois pour du non-parle, 800 $ des qu'il faut
# parler face camera. Au-dessous, l'annonce ne vaut pas le temps d'y
# repondre.
SEUIL_SIMPLE = 500
SEUIL_PARLE = 800
# Deux semaines: une annonce de dix jours peut encore etre ouverte, et
# mieux vaut en ecarter une a la main que de ne jamais la voir.
FENETRE_H = 336
REDDIT_TOUR_S = 10800         # un passage toutes les trois heures: trois
                              # appels a chaque fois, vingt-quatre par jour
_REDDIT = {"t": 0.0, "erreur": "", "dernier": 0.0}


def brouillon(p):
    """Le message propose, en anglais: les annonces le sont.

    Ecrit mais JAMAIS envoye. L'utilisateur le relit, le corrige, et c'est
    lui qui appuie — on ne poste rien a sa place sur un compte qui porte
    son nom."""
    quoi = "talking-head" if p.get("parle") else "short-form"
    return (f"Hey — saw your post about {quoi} UGC.\n\n"
            "I'm a UGC creator, I shoot and edit everything myself and can "
            "turn around a batch quickly. Happy to send samples that match "
            "what you're after.\n\n"
            "What's the volume you're looking for per month?")


def tour_reddit():
    """Un passage de prospection. Ne leve jamais: la boucle de fond ne doit
    pas s'arreter parce que Reddit a eu un hoquet."""
    if time.time() - _REDDIT["t"] < REDDIT_TOUR_S:
        return 0
    _REDDIT["t"] = time.time()
    try:
        trouves = reddit.scruter(heures=FENETRE_H, seuil_simple=SEUIL_SIMPLE,
                                 seuil_parle=SEUIL_PARLE)
    except Exception as e:                              # noqa: BLE001
        _REDDIT["erreur"] = str(e)
        return 0
    n = 0
    for t in trouves:
        try:
            if plateau.ajouter_prospect(t):
                n += 1
        except Exception:                               # noqa: BLE001
            pass
    _REDDIT.update(erreur="", dernier=time.time())
    return n


def tour_classement():
    """Une mise a jour par jour, si elle est demandee."""
    conf = classement_conf()
    if not (conf.get("jeton") and conf.get("serveur") and conf.get("salon")):
        return
    if (conf.get("chaque_jour") or "oui").lower() in ("non", "no", "0", "false"):
        return
    if publisher.load_config().get("discord_jour") == jour_courant():
        return
    publier_classement(frais=True)


def _brief_n(c):
    """Combien de lignes le brief contient, 0 s'il n'y en a pas."""
    try:
        return int((json.loads(c.get("brief_json") or "") or {}).get("n") or 0)
    except (TypeError, ValueError):
        return 0


# Le nombre de posts en attente, pour l'AFFICHAGE seulement.
#
# L'onglet « Publier » le demandait a Buffer a chaque ouverture: cinquante
# allers-retours dans l'interface faisaient cinquante appels d'API, pour
# un chiffre qui ne bouge qu'a chaque publication. Deux minutes de cache
# suffisent a le rendre gratuit sans qu'il paraisse perime.
#
# `auto_tour_serie` ne passe PAS par ici: lui doit savoir exactement
# combien de place il reste au moment ou il pousse un post.
_FILE_CACHE = {}
FILE_CACHE_S = 120


def file_en_attente(key, chan):
    e = _FILE_CACHE.get(chan)
    if e and time.time() - e[0] < FILE_CACHE_S:
        return e[1]
    try:
        n = publisher.buffer_etat_file(key, chan)[0]
    except publisher.PublishError:
        return e[1] if e else None
    _FILE_CACHE[chan] = (time.time(), n)
    return n


def brief_lu(c):
    """Le brief d'une campagne, relu depuis la base.

    Le `brut` ne sort PAS: il ne sert qu'a retrier sans redemander la
    page a Notion, et il double le poids de la reponse pour rien."""
    try:
        d = json.loads(c.get("brief_json") or "")
    except (TypeError, ValueError):
        d = None
    if not isinstance(d, dict):
        return {"vide": True, "url": c.get("brief_url") or "",
                "jeton": bool(brief.jeton())}
    d = dict(d)
    d.pop("brut", None)
    d["vide"] = False
    d["jeton"] = bool(brief.jeton())
    return d


def boucle_auto():
    time.sleep(20)                 # laisser le serveur finir de demarrer
    dernier_menage = dernier_leger = 0.0
    while True:
        for d in sorted(SERIES_DIR.glob("*/serie.json")):
            try:
                c = load_serie(d.parent.name)
                # `auto_demain` COMPTE AUSSI DANS LE FILTRE. En ne
                # regardant que `auto_jour`, une serie a zero aujourd'hui
                # mais reglee pour demain n'entrait jamais dans le tour:
                # la promotion vit dans `auto_jour_effectif`, qui n'etait
                # donc jamais appele, et le chiffre en attente dormait
                # pour toujours. Entrer ne coute rien — `auto_tour_serie`
                # ressort avant le premier appel a Buffer si le nombre du
                # jour est nul.
                if c and (int(c.get("auto_jour") or 0) > 0
                          or isinstance(c.get("auto_demain"), dict)):
                    auto_tour_serie(d.parent.name)
            except Exception:                               # noqa: BLE001
                pass
        # DEUX RYTHMES, parce que les taches ne coutent pas la meme chose.
        #
        # `tour_classement` et `tour_reddit` ne touchent pas a Buffer et
        # ne font, 99 fois sur 100, que comparer une date — ils restent
        # horaires, ce qui laisse `tour_reddit` scruter toutes les trois
        # heures comme il est regle. Ils vivent dans la boucle existante
        # plutot que dans un second fil: la regle « une seule tache de
        # fond » tient.
        #
        # `rattraper_echecs` (2 appels Buffer par compte) et `menage_r2`
        # (1 appel) passent eux a six heures: a l'heure ils coutaient 72
        # appels par jour sur un budget de 100 (3000 par 30 jours). Un
        # post rate repart donc au pire six heures plus tard, ce qui
        # reste bien avant la fin de la journee.
        if time.time() - dernier_leger > 3600:
            dernier_leger = time.time()
            for tache in (tour_classement, tour_reddit):
                try:
                    tache()
                except Exception:                           # noqa: BLE001
                    pass
        if time.time() - dernier_menage > 21600:
            dernier_menage = time.time()
            for tache in (rattraper_echecs, menage_r2):
                try:
                    tache()
                except Exception:                           # noqa: BLE001
                    pass
        time.sleep(AUTO_TOUR_S)


def mark_published(name, record):
    d = load_published()
    d[name] = record
    save_published(d)
    return record


def find_output(cid, name):
    """Chemin reel d'une video generee, en refusant toute sortie du dossier."""
    name = safe_filename(name)
    base = serie_path(cid)
    if not base:
        return None
    od = Path(remixer.output_dir(base, load_serie(cid)))
    target = od / name
    return target if within(od, target) and target.is_file() else None


def images_dir(serie_nom, mot, creer=False):
    """Dossier de la banque d'images d'un declencheur.

    `clips/_IMAGES/<Serie>/<mot>/`: nomme d'apres ce qu'on dit, pour qu'on
    sache ou deposer sans ouvrir l'app."""
    nom = folder_name(str(mot or "").strip()[:40] or "mot")
    d = IMAGES_DIR / folder_name(serie_nom or "serie") / nom
    if creer:
        d.mkdir(parents=True, exist_ok=True)
    return d


# ------------------------------------------------------------------
# L'EDITEUR : le rail, l'apercu, les images de fond
# ------------------------------------------------------------------
# L'editeur ne cree AUCUNE donnee a lui: il lit les categories de la
# serie et ecrit ses blocs de texte dans `serie["editor"]`. Eteint, la
# serie se comporte exactement comme avant — c'est la condition pour
# qu'on puisse le tester sans risquer le mode qui tourne en production.

EDITEUR_SOUS_DOSSIER = "editeur"


def editeur_dir(cid, creer=False):
    d = SERIES_DIR / cid / EDITEUR_SOUS_DOSSIER
    if creer:
        d.mkdir(parents=True, exist_ok=True)
    return d


def piece_tiree(slot, src, t):
    """Une tuile de la frise: ce clip, a partir de `t`, avec sa vraie duree.

    MEME regle que `pick_trim`: la partie utile du clip (`par_clip`,
    debut/fin), sa vitesse fixee s'il en a une, et la duree de la
    categorie — sauf « garder au complet », ou le clip passe en entier.
    Un clip plus court que la duree demandee passe EN ENTIER: le tirage ne
    doit pas l'etirer sur la frise. `seek` est l'endroit du fichier ou
    l'apercu commence; `src_dur`, la longueur du FICHIER, pour ne pas
    laisser tirer une tuile au-dela de sa fin."""
    a, b, longueur = remixer.plage_utile(str(src), slot)
    vit = float(remixer.clip_regl(slot, src).get("vitesse") or 1.0)
    utile = max(0.1, (b - a) / vit)
    lo = float(slot.get("dur_min") or 0)
    hi = float(slot.get("dur_max") or 0)
    d = min(random.uniform(lo or hi, hi), utile) \
        if hi > 0 and not slot.get("complet") else utile
    return {"id": slot["id"], "name": slot.get("name") or "",
            "clip": os.path.basename(str(src)),
            "debut": round(t, 3), "fin": round(t + d, 3),
            "duree": round(d, 3), "vide": False,
            "seek": round(a, 3), "vitesse": vit,
            "src_dur": round(longueur, 3)}


def editeur_tirage(cid, c=None):
    """UN tirage possible de la serie: la sequence avec ses vraies durees.

    Le rail ne montre pas « la » video, il en montre UNE. Une serie est
    une recette: les clips s'echangent a chaque generation et la longueur
    bouge avec eux. C'est pour ca qu'un bloc de texte s'accroche a une
    CATEGORIE et pas a une seconde — voir `remixer.editor_fenetre`.

    La duree suit la meme regle que `pick_trim`: la plage de la categorie
    si elle en fixe une, sinon le clip en entier."""
    c = c or load_serie(cid)
    if not c:
        return None
    sd = SERIES_DIR / cid
    s = dict(remixer.DEFAULT_SETTINGS)
    s.update(c.get("settings") or {})
    # Une serie SPLIT n'a pas une piste mais trois, et deux phases. Elle a
    # sa propre lecture — meme fonctions que `generate`, meme geometrie.
    if s.get("split") and not s.get("raw"):
        return editeur_tirage_split(cid, c, s, sd)
    # MEME REGLE QUE `pick_sequence`: on saute les categories mises de
    # cote, celles qui s'INCRUSTENT par-dessus la video (elles ne sont pas
    # un plan) et celles d'un split; une categorie peut fournir plusieurs
    # clips (min/max), qui se suivent. Un tirage qui ne suit pas la meme
    # regle que le montage montrerait une video qui n'existera jamais.
    rail, t = [], 0.0
    for slot in c.get("slots", []):
        if slot.get("off") or slot.get("incrust") or slot.get("split_role"):
            continue
        pool = remixer.slot_clips(sd, slot)
        if not pool:
            continue                  # le bac a medias la montre, vide
        lo_n, hi_n = int(slot.get("min", 1)), int(slot.get("max", 1))
        n = random.randint(lo_n, max(lo_n, hi_n))
        for src in random.sample(pool, min(n, len(pool))):
            p = piece_tiree(slot, src, t)
            rail.append(p)
            t = p["fin"]
    return {"rail": rail, "total": round(t, 3),
            "w": int((c.get("settings") or {}).get("width") or 1080),
            "h": int((c.get("settings") or {}).get("height") or 1920)}


def editeur_tirage_split(cid, c, s, sd):
    """Le tirage d'une serie SPLIT. Deux phases, trois pistes.

    On refait ici ce que fait `generate`, avec les memes fonctions —
    `split_slots`, `split_fenetres`, `etapes_tirees` — et surtout la MEME
    geometrie (`split_geom`). Recopier les 216/615/67/818/204 dans
    l'interface, c'est se garantir qu'un jour l'apercu montrera un
    montage que ffmpeg ne fabrique pas."""
    plans, slots_h, slot_b, etapes = remixer.split_slots(c)
    if not slots_h or not slot_b:
        manque = "du haut" if not slots_h else "du bas"
        return {"erreur": f"Aucune catégorie n'est marquée « moitié {manque} »."}

    bags = {}
    textes = [x for x in (c.get("captions") or []) if x.strip()]

    # Phase 1: les plans pleins cadre.
    piste_plans, t = [], 0.0
    for sl in plans:
        pool = remixer.slot_clips(sd, sl)
        if not pool:
            continue
        lo_n, hi_n = int(sl.get("min", 1)), int(sl.get("max", 1))
        for src in random.sample(pool, min(random.randint(lo_n, max(lo_n, hi_n)), len(pool))):
            p = piece_tiree(sl, src, t)
            piste_plans.append(p)
            t = p["fin"]
    t0 = round(t, 3)                       # ou commence le split

    # Phase 2: le split.
    pools_h = [remixer.slot_clips(sd, sl) for sl in slots_h]
    pool_b = remixer.slot_clips(sd, slot_b)
    if not pool_b or any(not x for x in pools_h):
        vide = slot_b["name"] if not pool_b else slots_h[pools_h.index([])]["name"]
        return {"erreur": f"Aucun clip dans « {vide} »."}
    tires_h = [(sl, random.choice(pool)) for sl, pool in zip(slots_h, pools_h)]
    src_b = random.choice(pool_b)
    duree_b = remixer.probe(str(src_b))[0] or 0.0
    try:
        rails, tete, _ancre = remixer.split_fenetres(tires_h, src_b, slot_b, duree_b)
    except Exception as e:                                  # noqa: BLE001
        return {"erreur": str(e)}
    duree_split = round(max(0.0, duree_b - (tete or 0.0)), 3)

    # UN RAIL DU HAUT PEUT S'ARRETER AVANT SA FENETRE: son clip est plus
    # court que le bas, et la moitie haute passe alors au NOIR jusqu'a la
    # coupe suivante (`eof_action=pass`, jamais une image figee). `image`
    # est l'instant ou il n'y a plus rien a montrer. Sans lui, la frise
    # dessinait la tuile jusqu'au bout et l'apercu cherchait une image au
    # dela de la fin du fichier — la ou la vraie video est noire.
    piste_haut = []
    for (sl, src, deb, fin, seek) in rails:
        dur = remixer.probe(str(src))[0] or 0.0
        image = min(fin, deb + max(0.0, dur - (seek or 0.0)))
        piste_haut.append({"id": sl["id"], "name": sl.get("name") or "",
                           "clip": os.path.basename(str(src)),
                           "seek": round(seek, 3),
                           "debut": round(t0 + deb, 3), "fin": round(t0 + fin, 3),
                           "image": round(t0 + image, 3)})
    piste_bas = {"id": slot_b["id"], "name": slot_b.get("name") or "",
                 "clip": os.path.basename(str(src_b)), "seek": round(tete or 0.0, 3),
                 "debut": t0, "fin": round(t0 + duree_split, 3)}

    # La bande commence a la PREMIERE COUPE, pas a zero: avant, le bas
    # montre encore l'accroche et une etape posee dessus decrirait un
    # ecran qui n'est pas la.
    t_et = rails[1][2] if len(rails) > 1 else 0.0
    piste_et, te = [], t0 + t_et
    # Pendant l'accroche, la bande tient le texte du PREMIER RAIL du haut
    # (voir process_split). Sans lui, l'apercu montrait une bande vide la
    # ou la video affiche deja une phrase.
    if t_et > 0.0:
        pool = remixer.slot_captions(rails[0][0], textes)
        if pool:
            piste_et.append({"id": "accroche|" + rails[0][0]["id"],
                             "name": rails[0][0].get("name") or "",
                             "texte": random.choice(pool), "accroche": True,
                             "debut": t0, "fin": round(t0 + t_et, 3)})
    tires_et = remixer.etapes_tirees(etapes, s, textes, True, bags)
    for k, (sl, texte, d) in enumerate(tires_et):
        fin = (t0 + duree_split) if k == len(tires_et) - 1 else min(te + d, t0 + duree_split)
        if te >= t0 + duree_split:
            break                          # commence apres la fin: ne s'affiche pas
        piste_et.append({"id": sl["id"], "name": sl.get("name") or "",
                         "texte": texte or "", "debut": round(te, 3),
                         "fin": round(fin, 3)})
        te += d

    total = round(t0 + duree_split, 3)
    return {"split": True, "total": total, "split_debut": t0,
            "geo": remixer.split_geom(s), "h": int(s["height"]), "w": int(s["width"]),
            "plans": piste_plans, "hauts": piste_haut, "bas": piste_bas,
            "etapes": piste_et,
            "manque_etapes": max(0, len(tires_et)
                                 - sum(1 for e in piste_et if not e.get("accroche")))}


def editeur_clip(cid, slot_id, clip):
    """Le fichier d'un clip tire, pour la lecture dans l'editeur."""
    c = load_serie(cid)
    if not c:
        return None
    slot = next((x for x in c.get("slots", []) if x.get("id") == slot_id), None)
    if not slot:
        return None
    return next((x for x in remixer.slot_clips(SERIES_DIR / cid, slot)
                 if os.path.basename(str(x)) == clip), None)


def voix_dir(cid):
    return SERIES_DIR / cid / remixer.VOIX_SOUS_DOSSIER


def voix_pics(path, n=160):
    """L'allure de l'onde, en `n` barres de 0 a 100, pour la piste de son.
    Decodee a 2 kHz: on dessine une silhouette, pas un spectre."""
    import audioop
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-vn", "-ac", "1",
                        "-ar", "2000", "-f", "s16le", "-"], capture_output=True)
    d = r.stdout
    if not d:
        return []
    pas = max(2, (len(d) // n) // 2 * 2)
    pics = [audioop.max(d[i:i + pas], 2) for i in range(0, len(d) - 1, pas)][:n]
    m = max(pics) or 1
    # Racine: une voix a beaucoup de passages moyens et peu de pics, sans
    # elle l'onde se lisait comme une ligne plate avec trois epines.
    return [int(round((x / m) ** 0.5 * 100)) for x in pics]


def editeur_captions(cid, d):
    """Les captions du tirage AFFICHE dans l'editeur.

    Memes fonctions que l'export (`editor_mots`, `editor_captions_morceaux`)
    mais sur les pieces que l'editeur montre — le clip pris depuis le
    debut (ou son `seek` dans un split), comme l'apercu image par image.
    Les PNG sont dessines ici, par la meme fonction que l'export."""
    import captions
    import transcription
    c = load_serie(cid)
    if not c:
        return None
    s = dict(remixer.DEFAULT_SETTINGS)
    s.update(c.get("settings") or {})
    sd = SERIES_DIR / cid
    slots = {x["id"]: x for x in c.get("slots", [])}
    split = bool(s.get("split") and not s.get("raw"))

    def source(p):
        sl = slots.get(str(p.get("slot") or ""))
        if not sl:
            return None, None
        f = next((x for x in remixer.slot_clips(sd, sl)
                  if os.path.basename(str(x)) == str(p.get("clip") or "")), None)
        return sl, f

    pieces = []
    for p in (d.get("pieces") or [])[:200]:
        sl, f = source(p)
        if not f:
            continue
        try:
            deb, fin = float(p.get("debut") or 0), float(p.get("fin") or 0)
            seek = float(p.get("seek") or 0)
        except (TypeError, ValueError):
            continue
        regl = remixer.clip_regl(sl, f)
        son = bool(sl.get("son") or s.get("parle"))
        if regl.get("son") is not None:
            son = bool(regl["son"])
        if regl.get("volume") is not None and float(regl["volume"]) <= 0.001:
            son = False
        son = son and bool(remixer.probe(str(f))[1])
        vit = float(regl.get("vitesse") or 1.0)
        pieces.append((str(p.get("role") or ""), deb, fin, seek, f, son, vit))

    # Le split ne garde qu'UNE voix, comme `process_split`: le PREMIER
    # rail du haut s'il garde le son (coupee a son `seek` et a sa fin),
    # sinon le bas.
    hauts = sorted((x for x in pieces if x[0] == "haut"), key=lambda x: x[1])
    voix_haut = bool(hauts and hauts[0][5] and hauts[0][1] <= 0.0)
    pistes = []
    for role, deb, fin, seek, f, son, vit in pieces:
        if role == "haut":
            vx = (str(f), seek, fin - deb, 1.0) if (voix_haut and hauts[0][1] == deb) else None
        elif role == "bas":
            vx = (str(f), seek or None, (fin - deb) if seek else None, 1.0) \
                if (son and not voix_haut) else None
        else:
            # La piece commence a `seek` dans le fichier (le debut utile du
            # clip) et en consomme `duree * vitesse`.
            vx = (str(f), seek or None, (fin - deb) * vit, vit) if son else None
        pistes.append((deb, fin - deb, vx))

    sons = []
    for a in (d.get("sons") or [])[:60]:
        f = voix_dir(cid) / safe_filename(str(a.get("fichier") or ""))
        if f.is_file():
            try:
                sons.append((str(f), max(0.0, float(a.get("debut") or 0)), 1.0,
                             max(0.0, float(a.get("entree") or 0)),
                             float(a.get("sortie") or 0) or None))
            except (TypeError, ValueError):
                pass
    if not transcription.disponible():
        return {"morceaux": [], "manque": "whisper-cli introuvable"}
    mots = remixer.editor_mots(c, s, pistes, sons)
    morceaux = remixer.editor_captions_morceaux(c, mots)
    dossier = editeur_dir(cid, creer=True)
    rendus = remixer.editor_captions_rendu(c, s, morceaux, float("inf"), str(dossier))
    out = []
    for (texte, a, b, k), (png, _a, _b, y, _x) in zip(morceaux, rendus):
        out.append({"texte": texte, "debut": a, "fin": b, "cle": k,
                    "png": f"/media/editeur/{cid}/{os.path.basename(png)}",
                    "y": round(y / float(s["height"]), 4)})
    return {"morceaux": out, "n_mots": len(mots)}


# Les styles qu'un bloc de l'editeur peut choisir: ceux de `captions.STYLES`
# qui se lisent sur une video (blanc et noir sans contour disparaissent sur
# un fond de meme couleur).
BLOC_STYLES = ("contour", "pastille", "nu")


def editeur_apercu(cid, bloc, c=None):
    """Dessine un bloc tel qu'il sortira. -> (nom du png, hauteur) ou None.

    MEME fonction que le montage (`captions.render`, via le cache) et
    memes reglages. Un apercu qui redessinerait le texte a sa facon
    mentirait le jour ou les deux divergeraient — c'est la regle de
    l'apercu des templates, elle vaut ici aussi."""
    import captions
    c = c or load_serie(cid)
    if not c:
        return None
    txt = (bloc.get("texte") or "").strip()
    if not txt:
        return None
    s = dict(remixer.DEFAULT_SETTINGS)
    s.update(c.get("settings") or {})
    d = editeur_dir(cid, creer=True)
    out = d / ("b_" + hashlib.sha1(
        f"{txt}|{bloc.get('caption_size')}|{bloc.get('caption_larg')}"
        f"|{bloc.get('caption_lead')}|{bloc.get('style')}".encode("utf-8")).hexdigest()[:12] + ".png")
    r = captions.render(
        txt, s["width"], s["height"], str(out),
        size=int(bloc.get("caption_size") or s.get("caption_size", 56)),
        style=(bloc.get("style") if bloc.get("style") in BLOC_STYLES
               else s.get("caption_style", "contour")),
        font_ps=captions.FONT_CHOICES.get(s.get("caption_font", "")),
        outline=s.get("caption_outline"),
        lead=int(bloc.get("caption_lead") or 0) or None,
        larg=float(bloc.get("caption_larg") or s.get("caption_larg") or 0) or None)
    return (out.name, r[1]) if r else None


def editeur_cadre(cid, slot_id, clip, t=0.0):
    """Une image du clip tire, pour servir de fond a l'apercu."""
    c = load_serie(cid)
    if not c:
        return None
    slot = next((x for x in c.get("slots", []) if x.get("id") == slot_id), None)
    if not slot:
        return None
    src = next((x for x in remixer.slot_clips(SERIES_DIR / cid, slot)
                if os.path.basename(str(x)) == clip), None)
    if not src:
        return None
    d = editeur_dir(cid, creer=True)
    out = d / ("c_" + hashlib.sha1(
        f"{src}|{t:.2f}".encode("utf-8")).hexdigest()[:12] + ".jpg")
    if not out.exists():
        try:
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{max(0.0, t):.3f}",
                            "-i", str(src), "-frames:v", "1", "-q:v", "4", str(out)],
                           check=True, timeout=30)
        except (subprocess.SubprocessError, OSError):
            return None
    return out if out.exists() else None


def badges_dir(serie_nom, creer=False):
    """Dossier des pastilles posees sur la reaction d'un split screen.

    `clips/_BADGES/<Serie>/` — un PNG a fond transparent par pastille, tire
    sans remise comme un clip. Il vit dans `clips/` et porte le NOM de la
    serie pour qu'on y depose un fichier depuis le Finder sans ouvrir
    l'app, comme la banque d'images et le pot de musiques. Relu a chaque
    appel, jamais mis en cache."""
    return BADGES_DIR / folder_name(serie_nom or "serie")


def musique_dir(camp, creer=False):
    """Dossier des musiques d'une campagne, ou None si elle n'existe pas.

    Nomme d'apres la CAMPAGNE et non son numero: le dossier est fait pour
    etre ouvert dans le Finder, `_MUSIQUES/17/` n'aurait rien dit. Le
    renommage d'une campagne renomme le dossier (voir `renommer_musiques`),
    donc rien n'est stocke: on le recalcule a chaque fois.

    `camp` accepte un id (ce que donne une URL) ou la ligne complete, pour
    eviter une lecture de base quand on l'a deja."""
    if not isinstance(camp, dict):
        cid = str(camp or "").strip()
        if not cid.isdigit():
            return None
        camp = plateau.campaign(int(cid))
        if not camp:
            return None
    d = MUSIQUES_DIR / folder_name(camp.get("name") or f"campagne-{camp['id']}")
    if creer:
        d.mkdir(parents=True, exist_ok=True)
    return d


def migrer_musiques():
    """Deplace l'ancien `musiques/<id>/` vers `clips/_MUSIQUES/<Nom>/`.

    Premiere version du pot commun: un dossier a la racine, nomme d'apres
    le numero de la campagne. Illisible dans le Finder, et pas la ou les
    fichiers se deposent. Idempotent: une fois vide, l'ancien dossier
    disparait et la fonction n'a plus rien a faire."""
    vieux = ROOT / "musiques"
    if not vieux.is_dir():
        return
    for d in list(vieux.iterdir()):
        if not d.is_dir() or not d.name.isdigit():
            continue
        cible = musique_dir(d.name, creer=True)
        if cible:
            for f in d.iterdir():
                if f.is_file() and not (cible / f.name).exists():
                    try:
                        os.replace(str(f), str(cible / f.name))
                    except OSError:
                        pass
        _rmdir_vide(d)
    _rmdir_vide(vieux)


def _rmdir_vide(d):
    """Supprime un dossier vide, en tolerant le `.DS_Store` du Finder.

    Sans ca l'ancien dossier survivait indefiniment a la migration: macOS y
    depose un `.DS_Store` des qu'on l'ouvre une fois, et `rmdir` refuse.
    On se retrouvait avec deux dossiers de musiques, dont un mort."""
    try:
        restes = list(d.iterdir())
        if all(f.name in (".DS_Store", ".localized") for f in restes):
            for f in restes:
                f.unlink()
            d.rmdir()
    except OSError:
        pass


def renommer_musiques(camp, nouveau_nom):
    """Suit le renommage d'une campagne, sinon ses musiques disparaissent.

    Le dossier porte le nom: le changer sans deplacer le dossier laisserait
    les fichiers derriere, et la campagne se retrouverait sans musique du
    jour au lendemain sans qu'aucun message ne l'explique."""
    ancien = musique_dir(camp)
    nouveau = MUSIQUES_DIR / folder_name(nouveau_nom or f"campagne-{camp['id']}")
    if not ancien or ancien == nouveau or not ancien.is_dir():
        return
    try:
        if nouveau.exists():
            # Deja pris (deux campagnes de meme nom): on verse dedans
            # plutot que d'ecraser quoi que ce soit.
            for f in ancien.iterdir():
                cible = nouveau / f.name
                if not cible.exists():
                    os.replace(str(f), str(cible))
            if not any(ancien.iterdir()):
                ancien.rmdir()
        else:
            os.replace(str(ancien), str(nouveau))
    except OSError:
        pass


def all_outputs_dir():
    d = OUTPUT_DIR / ALL_OUTPUTS_DIRNAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def serie_output_dirs():
    """(id, nom, dossier_de_sortie) pour chaque serie."""
    res = []
    for meta in list_series():
        cc = load_serie(meta["id"])
        if not cc:
            continue
        od = Path(remixer.output_dir(SERIES_DIR / meta["id"], cc))
        res.append((meta["id"], meta["name"], od))
    return res


def sync_all_outputs():
    """Place un lien physique de chaque video dans un dossier unique.

    Un lien physique ne recopie pas les octets: le fichier apparait a deux
    endroits mais n'occupe l'espace qu'une fois. Supprimer le lien ne
    supprime pas l'original."""
    dest = all_outputs_dir()
    vus = set()
    for cid, nom, od in serie_output_dirs():
        if not od.exists():
            continue
        for f in sorted(od.glob("*.mp4")):
            cible = dest / f.name
            vus.add(cible.name)
            if cible.exists():
                continue
            try:
                os.link(str(f), str(cible))
            except OSError:
                try:
                    shutil.copy2(str(f), str(cible))
                except OSError:
                    pass
    for f in list(dest.glob("*.mp4")):
        if f.name not in vus:
            try:
                f.unlink()
            except OSError:
                pass
    return len(vus)


def all_outputs():
    items = []
    pub = load_published()
    for cid, nom, od in serie_output_dirs():
        if not od.exists():
            continue
        for f in od.glob("*.mp4"):
            try:
                st = f.stat()
            except OSError:
                continue
            items.append({"cid": cid, "serie": nom, "name": f.name,
                          "size": st.st_size, "mtime": st.st_mtime,
                          "published": pub.get(f.name)})
    items.sort(key=lambda x: x["mtime"], reverse=True)
    return {"dir": str(all_outputs_dir()), "count": len(items), "items": items}


def purge_outputs(cid=None):
    """Supprime les videos generees. Ne touche jamais aux clips sources."""
    n = 0
    for c_id, nom, od in serie_output_dirs():
        if cid and c_id != cid:
            continue
        if not od.exists():
            continue
        base = SERIES_DIR / c_id
        # Vider UNE serie dont le dossier est partage ne doit prendre que
        # ses propres videos — sinon « Tout supprimer » sur l'une vidait
        # aussi l'autre. Le grand menage (cid=None) prend tout, comme avant.
        if cid and series_sharing_output(c_id, od):
            fichiers = own_outputs(c_id, od)
        else:
            fichiers = list(od.glob("*.mp4"))
        for f in fichiers:
            try:
                f.unlink()
                n += 1
            except OSError:
                continue
            try:
                (base / "thumbs" / (f.name + ".jpg")).unlink()
            except OSError:
                pass
    # Les lignes du pipeline suivent les fichiers: « pretes a poster » doit
    # retomber a zero quand on vide. Le journal des generations, lui, n'est
    # jamais touche — le compteur des 24 h reste juste.
    try:
        if cid:
            plateau.forget_series(cid)
        else:
            plateau.forget_all_generated()
    except Exception:                                       # noqa: BLE001
        pass
    sync_all_outputs()
    return n


# ------------------------------------------------------------------
# File d'attente : plusieurs series generees l'une apres l'autre
# ------------------------------------------------------------------
def queue_snapshot():
    with QUEUE_LOCK:
        st = dict(QUEUE_STATE)
        st["items"] = [dict(i) for i in QUEUE]
    return st


def queue_add(entries):
    noms = {c["id"]: c["name"] for c in list_series()}
    ajoutes = 0
    with QUEUE_LOCK:
        for e in entries or []:
            cid = str((e or {}).get("cid") or "")
            try:
                count = int((e or {}).get("count") or 0)
            except (TypeError, ValueError):
                count = 0
            if cid not in noms or count <= 0:
                continue
            QUEUE.append({"qid": uuid.uuid4().hex[:8], "cid": cid,
                          "name": noms[cid], "count": min(count, 200),
                          "done": 0, "status": "en attente",
                          "message": "", "error": ""})
            ajoutes += 1
    queue_start()
    return ajoutes


def queue_start():
    with QUEUE_LOCK:
        if QUEUE_STATE["running"]:
            return
        if not any(i["status"] == "en attente" for i in QUEUE):
            return
        QUEUE_STATE["running"] = True
        QUEUE_STATE["stop"] = False
    threading.Thread(target=queue_worker, daemon=True).start()


def queue_stop():
    with QUEUE_LOCK:
        QUEUE_STATE["stop"] = True
        for i in QUEUE:
            if i["status"] == "en attente":
                i["status"] = "annule"


def queue_clear():
    with QUEUE_LOCK:
        QUEUE[:] = [i for i in QUEUE if i["status"] == "en cours"]


def queue_worker():
    while True:
        with QUEUE_LOCK:
            if QUEUE_STATE["stop"]:
                for i in QUEUE:
                    if i["status"] == "en attente":
                        i["status"] = "annule"
                QUEUE_STATE["running"] = False
                QUEUE_STATE["current"] = None
                return
            item = next((i for i in QUEUE if i["status"] == "en attente"), None)
            if not item:
                QUEUE_STATE["running"] = False
                QUEUE_STATE["current"] = None
                return
            item["status"] = "en cours"
            QUEUE_STATE["current"] = item["qid"]
            qid, cid, count = item["qid"], item["cid"], item["count"]

        c = load_serie(cid)
        if not c:
            with QUEUE_LOCK:
                item["status"] = "erreur"
                item["error"] = "Série introuvable"
            continue

        def progress(done, total, msg, _q=qid):
            with QUEUE_LOCK:
                for i in QUEUE:
                    if i["qid"] == _q:
                        i["done"] = done
                        i["message"] = msg

        def stopped():
            with QUEUE_LOCK:
                return QUEUE_STATE["stop"]

        if not claim_serie(cid):
            with QUEUE_LOCK:
                item["status"] = "erreur"
                item["error"] = "Une génération tourne déjà sur cette série."
            continue
        try:
            made = remixer.generate(SERIES_DIR / cid, c, count,
                                    progress=progress, stop_flag=stopped)
            register_made(cid, made)
            with QUEUE_LOCK:
                item["done"] = len(made)
                item["status"] = "arrete" if QUEUE_STATE["stop"] else "termine"
                item["message"] = "%d video(s)" % len(made)
        except Exception as e:                                  # noqa: BLE001
            with QUEUE_LOCK:
                item["status"] = "erreur"
                item["error"] = str(e)
        finally:
            release_serie(cid)
        try:
            sync_all_outputs()
        except Exception:                                       # noqa: BLE001
            pass



# ------------------------------------------------------------------
# HTTP
# ------------------------------------------------------------------

# ------------------------------------------------------------------
# Le niveau CAMPAGNE (base plateau.db) — voir plateau.py
# ------------------------------------------------------------------

# `open` lance l'application associee a un fichier. Le serveur n'ecoute
# que sur 127.0.0.1, mais on refuse quand meme ce qui sort du dossier
# personnel et ce qui est directement executable: une video ou un dossier,
# rien d'autre.
OPENABLE_DENY = {".app", ".sh", ".command", ".scpt", ".workflow",
                 ".pkg", ".dmg", ".terminal", ".jar", ".py"}


def list_fonds():
    """Images de fond disponibles, par ordre alphabetique.

    Lu a chaque appel plutot que mis en cache: on veut pouvoir glisser une
    image dans fonds/ et la voir arriver sans redemarrer le serveur. Le
    dossier contient au plus quelques fichiers, ca ne coute rien."""
    if not FONDS_DIR.is_dir():
        return []
    return sorted(f.name for f in FONDS_DIR.iterdir()
                  if f.is_file() and f.suffix.lower() in FOND_EXTS
                  and not f.name.startswith("."))


def save_avatar(raw_bytes, suffix=""):
    """Range une image en PNG carre-compatible dans avatars/, et renvoie
    son nom de fichier.

    La conversion passe par portable.convertir_image, qui essaie `sips`
    (macOS, seul a lire le HEIC de l'iPhone), puis Pillow, puis ffmpeg.
    On redimensionne au passage: une photo brute de 4 Mo n'a aucune raison
    de peser ca pour une pastille de 40 px.

    Renvoie (nom, None) ou (None, message d'erreur)."""
    AVATARS_DIR.mkdir(exist_ok=True)
    tmp = AVATARS_DIR / f".upload-{uuid.uuid4().hex[:8]}{suffix or '.bin'}"
    try:
        with open(tmp, "wb") as f:
            f.write(raw_bytes)
        name = f"av-{uuid.uuid4().hex[:10]}.png"
        err = portable.convertir_image(tmp, AVATARS_DIR / name, AVATAR_SIDE)
        if err:
            return None, err
        return name, None
    except OSError as e:
        return None, f"Écriture impossible : {e}"
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


def fetch_image(url, timeout=20):
    """Telecharge une image depuis une URL http(s).

    Sert quand on glisse une image depuis une page web: le navigateur ne
    donne alors aucun fichier, juste une adresse, et il ne peut pas lire
    les octets lui-meme a cause du cloisonnement entre sites. C'est donc
    le serveur qui va la chercher."""
    import urllib.error
    import urllib.request
    if not re.match(r"^https?://", str(url or ""), re.I):
        return None, None, "Adresse invalide (http ou https attendu)."
    req = urllib.request.Request(str(url), headers={
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read(AVATAR_MAX_BYTES + 1)
    except (urllib.error.URLError, OSError, ValueError) as e:
        return None, None, f"Téléchargement impossible : {e}"
    if len(data) > AVATAR_MAX_BYTES:
        return None, None, "Image trop lourde (plus de 25 Mo)."
    if not data:
        return None, None, "L'adresse n'a rien renvoyé."
    suffix = os.path.splitext(urlparse(str(url)).path)[1][:8] or ".bin"
    return data, suffix, None


def openable(raw):
    """Chemin sur lequel on accepte de lancer `open`, ou None."""
    if not raw:
        return None
    try:
        p = Path(os.path.expanduser(str(raw))).resolve()
    except OSError:
        return None
    if not p.exists():
        return None
    if not within(Path.home(), p):
        return None
    if p.suffix.lower() in OPENABLE_DENY:
        return None
    return str(p)


def serie_campaign_id(sid):
    """Campagne a laquelle une serie est rattachee, ou None."""
    c = load_serie(sid)
    cid = (c or {}).get("campaign_id")
    return int(cid) if str(cid or "").strip().isdigit() else None


# ------------------------------------------------------------------
# L'IA — Claude Code de la machine (voir ia.py) et la qualite des clips
# (voir qualite.py, qui ne coute rien)
# ------------------------------------------------------------------
# Les videos exemples deposees avant que la campagne existe. Une fois la
# campagne creee, l'exemple est COPIE dans sa serie (`exemple.<ext>`) avec
# une image par plan: c'est ce que le tri montre a Claude pour reconnaitre
# une categorie, et ce que la liste de tournage montre a celui qui filme.
EXEMPLES_DIR = ROOT / "exemples"
# Les contrats deposes a la creation d'une campagne (colonne `contrat`).
CONTRATS_DIR = ROOT / "contrats"
IA_JOBS = {}
IA_LOCK = threading.Lock()

# ------------------------------------------------------------------
# L'APP INSTALLEE : sa version, ses mises a jour, Claude, le modele des
# sous-titres. Une seule tache a la fois (`APP_TACHE`) : telecharger une
# mise a jour et un modele de 570 Mo en meme temps n'a aucun interet.
# ------------------------------------------------------------------
APP_TACHE = {"quoi": "", "etat": "", "message": "", "erreur": "", "resultat": ""}
APP_LOCK = threading.Lock()


def app_lancer(quoi, fonction):
    with APP_LOCK:
        if APP_TACHE["etat"] == "cours":
            raise ValueError("Une autre opération est en cours")
        APP_TACHE.update(quoi=quoi, etat="cours", message="", erreur="", resultat="")

    def fil():
        try:
            r = fonction(lambda m: APP_TACHE.update(message=m))
            APP_TACHE.update(etat="fini", resultat=str(r or ""))
        except Exception as e:                                  # noqa: BLE001
            APP_TACHE.update(etat="erreur", erreur=str(e))
    threading.Thread(target=fil, daemon=True).start()


def app_etat():
    ok, raison = ia.disponible()
    return {"version": maj.version(), "installee": INSTALLEE,
            "code": str(CODE), "donnees": str(ROOT),
            "maj": maj.verifier(),
            "claude": {"ok": ok, "raison": raison},
            "sous_titres": {"whisper": bool(transcription.binaire()),
                            "modele": bool(transcription.modele())},
            "tache": dict(APP_TACHE)}


def terminal(commande):
    """Ouvre le Terminal du Mac sur une commande, pour ce qui demande la
    personne (se connecter a Claude, parler a Claude Code). L'app ne tape
    JAMAIS de mot de passe a sa place : elle ouvre la fenetre, c'est tout.
    La commande est passee a AppleScript en chaine echappee.

    Sous Windows : une console neuve (CREATE_NEW_CONSOLE) sur `cmd /k`,
    qui reste ouverte apres la commande — c'est la que Claude Code tourne."""
    if portable.WINDOWS:
        # La ligne de commande passe en CHAINE, telle quelle : en liste,
        # Python l'echappait (list2cmdline) et cmd recevait des \" — le
        # 19/11, « Connecter Claude » sur Windows affichait l'installation
        # sans la lancer, puis « \"C:\...\claude.exe\" n'est pas reconnu ».
        subprocess.Popen("cmd.exe /k " + commande, creationflags=0x00000010)
        return
    esc = commande.replace("\\", "\\\\").replace('"', '\\"')
    subprocess.Popen(["osascript", "-e", 'tell application "Terminal"',
                      "-e", f'do script "{esc}"', "-e", "activate",
                      "-e", "end tell"])


def _sh(s):
    if portable.WINDOWS:
        return '"' + str(s).replace('"', '') + '"'
    return "'" + str(s).replace("'", "'\\''") + "'"


# L'installateur OFFICIEL de Claude Code, puis Claude lui-meme (il demande
# la connexion au compte au premier lancement).
if portable.WINDOWS:
    INSTALLER_CLAUDE = ('powershell -NoProfile -ExecutionPolicy Bypass -Command '
                        '"irm https://claude.ai/install.ps1 | iex" && '
                        '"%USERPROFILE%\\.local\\bin\\claude.exe"')
    ALLER = "cd /d "
else:
    INSTALLER_CLAUDE = "curl -fsSL https://claude.ai/install.sh | bash && ~/.local/bin/claude"
    ALLER = "cd "


# ------------------------------------------------------------------
# LES CODES D'ACCES (page « Accès »), pour celui qui DONNE l'app.
# Le branchement est dans `acces.txt` (une ligne `url=`, une `secret=`),
# pas dans l'interface — comme notion.txt et discord.txt — et ne part
# jamais dans une copie (verifie par les deux scripts d'emballage).
# Le service lui-meme est dans service-acces/.
# ------------------------------------------------------------------
ACCES_CONF = ROOT / "acces.txt"


def acces_conf():
    conf = {}
    try:
        for ligne in ACCES_CONF.read_text().splitlines():
            if "=" in ligne:
                k, v = ligne.split("=", 1)
                conf[k.strip()] = v.strip()
    except OSError:
        pass
    return conf if conf.get("url") and conf.get("secret") else None


def acces_appel(action, **champs):
    import urllib.error
    import urllib.request
    conf = acces_conf()
    if not conf:
        raise ValueError("Service des codes non branché (acces.txt)")
    req = urllib.request.Request(
        conf["url"].rstrip("/") + "/api/acces", method="POST",
        data=json.dumps(dict(champs, action=action)).encode(),
        headers={"Content-Type": "application/json", "X-Admin": conf["secret"],
                 "User-Agent": "Le-plateau"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read()).get("erreur")
        except ValueError:
            msg = ""
        raise ValueError(msg or f"Service des codes : erreur {e.code}")
    except urllib.error.URLError as e:
        raise ValueError(f"Service des codes injoignable ({e.reason})")


def ia_lancer(travail):
    """Lance `travail(progres)` dans un fil. -> identifiant du job, lu par
    GET /api/ia/jobs/<id>. A part de JOBS: ceux-la sont des generations,
    rattachees a une serie, et plusieurs ecrans les comptent."""
    jid = uuid.uuid4().hex[:12]
    with IA_LOCK:
        IA_JOBS[jid] = {"id": jid, "status": "running", "message": "Démarrage…",
                        "result": None, "error": ""}

    def progres(msg):
        with IA_LOCK:
            IA_JOBS[jid]["message"] = msg

    def fil():
        try:
            r = travail(progres)
            with IA_LOCK:
                IA_JOBS[jid].update(status="done", result=r, message="Terminé")
        except Exception as e:                                  # noqa: BLE001
            with IA_LOCK:
                IA_JOBS[jid].update(status="error", error=str(e), message="Erreur")

    threading.Thread(target=fil, daemon=True).start()
    return jid


# Une video exemple peut arriver en LIEN (Instagram, TikTok, YouTube
# Shorts…): coller l'adresse evite de la telecharger sur son telephone
# puis de la faire passer sur le Mac. `yt-dlp` est un programme a part,
# comme ffmpeg ou whisper-cli (`brew install yt-dlp`) — pas une
# bibliotheque. Sans lui, la case du lien le dit et le depot reste.
YTDLP_CANDIDATS = ("/opt/homebrew/bin/yt-dlp", "/usr/local/bin/yt-dlp")


def ytdlp():
    b = shutil.which("yt-dlp")
    if b:
        return b
    return next((c for c in YTDLP_CANDIDATS if os.access(c, os.X_OK)), None)


def telecharger_exemple(url, progres=None):
    """Le lien -> un fichier dans `exemples/`, comme un depot. -> nom."""
    b = ytdlp()
    if not b:
        raise ValueError("Pour coller un lien, installe yt-dlp : ouvre le Terminal et "
                         "tape « brew install yt-dlp ». Sinon, dépose la vidéo.")
    EXEMPLES_DIR.mkdir(exist_ok=True)
    base = EXEMPLES_DIR / f"{uuid.uuid4().hex[:8]}-lien"
    if progres:
        progres("Récupération de la vidéo…")
    # mp4 d'abord: un seul fichier, rien a recoller. Sinon la meilleure
    # image et le meilleur son, recolles en mp4 par ffmpeg.
    p = subprocess.run(
        [b, "--no-playlist", "--socket-timeout", "20", "--max-filesize", "300M",
         "-f", "b[ext=mp4]/bv*+ba/b", "--merge-output-format", "mp4",
         "--no-progress", "-o", str(base) + ".%(ext)s", url],
        capture_output=True, text=True, timeout=300)
    faits = sorted(EXEMPLES_DIR.glob(base.name + ".*"))
    f = next((x for x in faits if x.suffix.lower() in remixer.VIDEO_EXTS), None)
    if p.returncode or not f:
        for x in faits:
            x.unlink(missing_ok=True)
        err = (p.stderr or "").lower()
        if "login" in err or "private" in err or "rate-limit" in err or "cookies" in err:
            raise ValueError("Ce lien demande d'être connecté (compte privé ou "
                             "Instagram qui bloque) — télécharge la vidéo et dépose-la.")
        if "unsupported url" in err:
            raise ValueError("Ce lien n'est pas une vidéo que je sais récupérer.")
        raise ValueError("Impossible de récupérer la vidéo de ce lien — "
                         "dépose-la à la place.")
    if ia.duree(f) <= 0:
        f.unlink(missing_ok=True)
        raise ValueError("La vidéo récupérée est illisible — dépose-la à la place.")
    return f.name


def exemple_dir(cid):
    return SERIES_DIR / cid / "exemple"


def _nombre(v):
    try:
        return max(0.0, float(v or 0))
    except (TypeError, ValueError):
        return 0.0


def ia_categories(se):
    """[(nom, role, categorie proposee)], dans l'ordre, une seule « haut »
    et une seule « bas »."""
    split = se.get("format") == "split"
    cats = []
    vu_haut = vu_bas = False
    for k in se.get("categories") or []:
        role = k.get("role") if split and k.get("role") in ("haut", "bas", "etape") else ""
        # Une seule categorie « haut »: plusieurs se relaient aux coupes
        # notees A LA MAIN sur le clip du bas (voir split_fenetres), et
        # sans elles la generation refuse de partir.
        if role == "haut":
            if vu_haut:
                continue
            vu_haut = True
        if role == "bas":
            if vu_bas:
                continue
            vu_bas = True
        nom = (str(k.get("nom") or "").strip() or f"Plan {len(cats) + 1}")[:40]
        cats.append((nom, role, k))
    return cats or [("Clips", "", {})]


# Ce que la proposition decide sur une categorie. Le reste (dossier, clips,
# calage, reglages par clip, clips masques) appartient a l'utilisateur et
# survit quand l'exemple arrive apres coup.
IA_SLOT_CLES = ("dur_min", "dur_max", "complet", "split_role", "captions",
                "text_pos", "son", "consigne", "plans", "depart")


def ia_poser(s, role, k):
    for x in IA_SLOT_CLES:
        s.pop(x, None)
    d = _nombre(k.get("duree"))
    delta = min(_nombre(k.get("delta")), d / 2) if d else 0.0
    if role in ("haut", "bas"):
        pass                       # passent en entier: pas de duree
    elif role == "etape":
        s["dur_min"] = s["dur_max"] = round(d or remixer.SPLIT_ETAPE_DEFAUT, 2)
    elif k.get("complet"):
        s["complet"] = 1
    elif d:
        s["dur_min"] = round(max(0.3, d - delta), 2)
        s["dur_max"] = round(d + delta, 2)
    if role:
        s["split_role"] = role
    t = str(k.get("texte") or "").strip()
    if t:
        s["captions"] = [t[:300]]
    if k.get("position") in remixer.captions.POSITIONS:
        s["text_pos"] = k["position"]
    if k.get("son"):
        s["son"] = 1
    if str(k.get("consigne") or "").strip():
        s["consigne"] = str(k["consigne"]).strip()[:600]
    pl = [int(x) for x in (k.get("plans") or []) if str(x).isdigit()]
    if pl:
        s["plans"] = pl[:20]
    # La categorie part de son plan: on prend le clip depuis le debut,
    # comme le plan de l'exemple — un depart tire au sort couperait
    # l'action que la consigne demande de filmer.
    s["depart"] = "debut"
    return s


def _lien_ok(url):
    url = str(url or "").strip()[:500]
    return url if re.match(r"^https?://\S+$", url) else ""


def ia_attacher_exemple(c, fichier, plans, url=None):
    """L'exemple suit la serie, avec une image par plan (celle que le tri
    montre a Claude pour reconnaitre une categorie)."""
    src = EXEMPLES_DIR / safe_filename(fichier or "")
    if not fichier or not src.is_file():
        return
    d = exemple_dir(c["id"])
    if d.is_dir():
        for vieux in d.iterdir():
            vieux.unlink()
    d.mkdir(parents=True, exist_ok=True)
    dst = d / ("exemple" + src.suffix.lower())
    shutil.copy2(str(src), str(dst))
    for i, pl in enumerate(plans or [], 1):
        try:
            a, b = float(pl["debut"]), float(pl["fin"])
        except (KeyError, TypeError, ValueError):
            continue
        img = ia.image(dst, a + (b - a) * 0.6)
        if img:
            (d / f"plan-{i}.jpg").write_bytes(img)
    c.setdefault("ia", {})["exemple"] = dst.name
    # Le lien d'origine (Instagram, TikTok) pour retourner voir la vraie
    # video d'un clic. None = on garde celui d'avant (une reanalyse); un
    # fichier depose a la main n'en a pas, on l'efface.
    if url is not None:
        if _lien_ok(url):
            c["ia"]["exemple_url"] = _lien_ok(url)
        else:
            c["ia"].pop("exemple_url", None)
    save_serie(c)


# Hauteur d'un bloc de l'editeur selon la position demandee, en fraction
# de la hauteur (le HAUT du texte). `None` = le haut par defaut de
# `editor_rendu`, le meme que `caption_y(..., "haut")`.
IA_BLOC_Y = {"haut": None, "milieu": 0.42, "bas": 0.70}


def ia_timeline(slots, parle=False):
    """La FRISE DE L'EDITEUR d'une serie montee par l'IA (demande du 18/11):
    les textes des categories deviennent des blocs, qu'on deplace et
    retouche ensuite a la main dans l'editeur au lieu d'une liste de
    champs.

    Un bloc s'accroche a une categorie, jamais a une seconde (voir
    `remixer.editor_fenetre`) : il part au debut de sa categorie et
    s'arrete au debut de la suivante qui porte un AUTRE texte. Des
    categories voisines au meme texte ne font qu'un bloc — un texte qui
    tient sur trois plans est un seul texte a l'ecran, il ne doit pas
    clignoter aux coupes. Le dernier va jusqu'au bout (`fin` vide).

    En split, seuls les plans d'accroche et les rails du haut portent des
    blocs : la bande garde ses etapes, c'est la forme du split.

    Les textes restent AUSSI sur leurs categories : eteindre l'editeur
    rend exactement la serie d'avant. `ia: True` marque une frise que
    personne n'a encore touchee — `ia_refaire` peut la refaire ; le
    premier enregistrement depuis l'editeur retire la marque."""
    vus = [s for s in slots if s.get("split_role") in (None, "", "haut")]
    blocs, cours = [], None
    for s in vus:
        txt = ((s.get("captions") or [""])[0] or "").strip()
        if cours and txt and _norme(txt) == _norme(cours["texte"]):
            continue
        if cours:
            cours["fin"] = {"slot": s["id"], "off": 0.0}
            blocs.append(cours)
            cours = None
        if txt:
            cours = {"id": uuid.uuid4().hex[:8], "texte": txt[:200],
                     "debut": {"slot": s["id"], "off": 0.0},
                     "fin": {"slot": "", "off": 0.0},
                     "text_y": IA_BLOC_Y.get(s.get("text_pos") or "haut"),
                     "text_x": None, "caption_size": None, "caption_larg": None,
                     "caption_lead": None, "style": None}
    if cours:
        blocs.append(cours)
    # Une serie parlee garde ses sous-titres : quand l'editeur est allume,
    # ce sont SES captions qui les dessinent (les morceaux n'en ont plus).
    return {"actif": True, "ia": True, "blocs": blocs, "audios": [],
            "captions": {"actif": bool(parle), "voix": True, "clips": True,
                         "mots": 1, "caption_size": None, "caption_larg": None,
                         "text_y": None, "corr": {}}}


def ia_refaire(cid, prop, fichier, url=None):
    """La video exemple arrive APRES la campagne: ses categories remplacent
    celles devinees sur le brief. La n-ieme categorie proposee reprend la
    n-ieme case qui a un dossier — son id, son dossier et ses clips ne
    bougent pas, seuls nom, durees, textes et consigne changent. Une case
    en trop est retiree si elle est vide, gardee si elle a des clips (on ne
    jette jamais un clip sans demande)."""
    c = load_serie(cid)
    if not c:
        raise ValueError("Série introuvable")
    se = prop.get("serie") or {}
    base = SERIES_DIR / cid
    anciennes = [x for x in c["slots"] if x.get("split_role") != "etape"]
    libres = list(anciennes)
    root = c.get("source_dir")
    slots = []
    for nom, role, k in ia_categories(se):
        if role == "etape":
            s = new_slot(nom)
        elif libres:
            s = libres.pop(0)
            s["name"] = nom
            # Un dossier encore VIDE prend le nouveau nom: sinon le Finder
            # montre « 2-Galère à se motiver » pour la case « Ouvrir l'app »,
            # et on y range les mauvais clips. Plein, il garde le sien.
            vieux = Path(s.get("path") or "")
            if (s.get("path") and vieux.is_dir() and within(CLIPS_DIR, vieux)
                    and not any(vieux.iterdir())):
                neuf = vieux.parent / folder_name(nom, len(slots) + 1)
                if neuf != vieux and not neuf.exists():
                    try:
                        vieux.rename(neuf)
                        s["path"] = str(neuf)
                    except OSError:
                        pass
        elif root and Path(root).is_dir():
            d = Path(root) / folder_name(nom, len(slots) + 1)
            d.mkdir(exist_ok=True)
            s = new_slot(d.name, str(d))
        else:
            s = new_slot(nom)
        slots.append(ia_poser(s, role, k))
    for s in libres:
        if remixer.slot_clips_all(base, s):
            slots.append(s)
        elif s.get("path"):
            try:
                if not os.listdir(s["path"]):
                    os.rmdir(s["path"])
            except OSError:
                pass
    c["slots"] = slots
    st = c["settings"]
    st["split"] = 1 if se.get("format") == "split" else 0
    if se.get("parle") and not st.get("parle"):
        st.update(parle=1, music_volume_min=0.1, music_volume_max=0.1)
    # La frise suit les nouvelles categories TANT QUE personne n'y a
    # touche : une frise retouchee a la main ne se jette pas.
    if not c.get("editor") or (c["editor"] or {}).get("ia"):
        c["editor"] = ia_timeline(slots, st.get("parle"))
    info = dict(c.get("ia") or {})
    for cle in ("tournage", "questions"):
        if prop.get(cle):
            info[cle] = [str(x)[:300] for x in prop[cle]][:40]
    if prop.get("resume"):
        info["resume"] = str(prop["resume"])[:1000]
    c["ia"] = info
    save_serie(c)
    ia_attacher_exemple(c, fichier, prop.get("plans"), url)
    return serie_detail(cid)


def ia_creer(prop, fichier, brief_texte="", brief_url="", exemple_url="", contrat=""):
    """Cree la campagne et sa serie a partir de la proposition RELUE par
    l'utilisateur. -> {"campaign_id", "serie_id"}."""
    ca = prop.get("campagne") or {}
    se = prop.get("serie") or {}
    nom_c = (str(ca.get("nom") or "").strip() or "Nouvelle campagne")[:80]

    nombre = _nombre
    camp = {"name": nom_c,
            "daily_target": str(int(nombre(ca.get("objectif_jour")))) if nombre(ca.get("objectif_jour")) else "",
            "pay_per_video": (f"{nombre(ca.get('paie_par_video')):g}"
                              if nombre(ca.get("paie_par_video")) else ""),
            "pay_cycle": ca.get("cycle_paie") if ca.get("cycle_paie") in ("hebdo", "2sem", "mensuel") else "",
            "base_pay": str(ca.get("base_pay") or "")[:200],
            "cpm": str(ca.get("cpm") or "")[:200],
            "frequency": str(ca.get("frequence") or "")[:200],
            "notes": str(ca.get("notes") or "")[:4000],
            # Seulement les comptes que le deal exige (relus et corriges
            # dans la proposition). Vide = pas dit, les quatre s'affichent.
            "plateformes": ",".join(k for k in ("ig", "tt", "yt", "fb")
                                    if k in (ca.get("plateformes") or []))}
    if contrat and (CONTRATS_DIR / contrat).is_file():
        camp["contrat"] = contrat
    if brief_texte.strip() or brief_url.strip():
        try:
            b = brief.construire(url=brief_url, texte=brief_texte)
            camp.update(brief_json=json.dumps(b, ensure_ascii=False),
                        brief_url=brief_url.strip(), brief_at=str(b["at"]))
        except Exception:                                       # noqa: BLE001
            # Le brief range est un plus: une page Notion illisible ne
            # doit pas empecher de creer la campagne.
            if brief_url.strip():
                camp["brief_url"] = brief_url.strip()
    camp_id = plateau.create_campaign(camp)

    split = se.get("format") == "split"
    cats = ia_categories(se)

    nom_s = (str(se.get("nom") or "").strip() or nom_c)[:80]
    a_filmer = [(n, k) for n, r, k in cats if r != "etape"]
    root, subs = make_serie_folders(nom_s, [n for n, _ in a_filmer])
    dossiers = iter(subs)
    slots = []
    for nom, role, k in cats:
        s = new_slot(nom) if role == "etape" else new_slot(*next(dossiers))
        slots.append(ia_poser(s, role, k))

    sid = f"{slugify(nom_s)}-{uuid.uuid4().hex[:6]}"
    reglages = dict(remixer.DEFAULT_SETTINGS)
    if se.get("parle"):
        reglages.update(parle=1, music_volume_min=0.1, music_volume_max=0.1)
    if split:
        reglages["split"] = 1
    c = {"id": sid, "name": nom_s,
         "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
         "slots": slots, "source_dir": root,
         "output_dir": make_output_folder(nom_s),
         "settings": reglages, "campaign_id": camp_id,
         "captions": [], "descriptions": [],
         "editor": ia_timeline(slots, reglages.get("parle")),
         "ia": {"resume": str(prop.get("resume") or "")[:1000],
                "tournage": [str(x)[:300] for x in (prop.get("tournage") or [])][:40],
                "questions": [str(x)[:300] for x in (prop.get("questions") or [])][:20]}}
    save_serie(c)

    ia_attacher_exemple(c, fichier, prop.get("plans"), exemple_url)
    return {"campaign_id": camp_id, "serie_id": sid}


def brief_en_texte(b, sep="\n"):
    """Le brut d'un brief range (`brief.construire`) redevenu du texte.
    Chaque ligne y est [profondeur, texte]: l'indentation de Notion."""
    return sep.join((x[1] if isinstance(x, (list, tuple)) else str(x))
                    for x in (b or {}).get("brut") or [])


def vrac_dir(cid):
    """Les clips deposes « en vrac », pas encore ranges. Dans la serie et
    pas dans `clips/`: ce ne sont pas encore des rushes d'une categorie."""
    return SERIES_DIR / cid / "vrac"


def dossier_categorie(cid, slot):
    lie = Path(slot["path"]) if slot.get("path") else None
    if lie and lie.is_dir():
        return lie
    return SERIES_DIR / cid / "slots" / slot["id"]


def image_categorie(cid, c, slot):
    """L'image qui montre a Claude a quoi ressemble la categorie: le plan
    de l'exemple s'il y en a un, sinon un clip deja range."""
    for n in slot.get("plans") or []:
        f = exemple_dir(cid) / f"plan-{n}.jpg"
        if f.is_file():
            return f.read_bytes()
    clips = remixer.slot_clips(SERIES_DIR / cid, slot)
    if clips:
        d = ia.duree(clips[0]) or 1.0
        return ia.image(clips[0], d * 0.5)
    return None


def ranger_clip(cid, slot, f):
    """Deplace un clip du vrac dans sa categorie. -> son nouveau chemin."""
    dd = dossier_categorie(cid, slot)
    dd.mkdir(parents=True, exist_ok=True)
    nom = Path(f).name
    dest, i = dd / nom, 1
    while dest.exists():
        dest = dd / f"{Path(nom).stem}-{i}{Path(nom).suffix}"
        i += 1
    shutil.move(str(f), str(dest))
    remixer.make_thumbnail(str(dest), str(SERIES_DIR / cid / "thumbs" / (dest.name + ".jpg")))
    return dest


def ia_trier(cid, progres):
    """Range les clips du vrac dans leur categorie. Ce qui n'a pas de
    categorie sure RESTE dans le vrac: un clip mal range s'ecrirait dans
    des dizaines de videos avant qu'on s'en apercoive."""
    c = load_serie(cid)
    if not c:
        raise ValueError("Série introuvable")
    vd = vrac_dir(cid)
    clips = sorted(remixer.list_media(str(vd), remixer.VIDEO_EXTS)) if vd.is_dir() else []
    if not clips:
        return {"ranges": [], "restes": []}
    cats = [s for s in c["slots"] if not s.get("off") and s.get("split_role") != "etape"]
    if not cats:
        raise ValueError("Cette série n'a aucune catégorie à remplir")
    progres("Mesure de la qualité…")
    mesures = {str(f): qualite.mesure_en_cache(f) for f in clips}
    if len(cats) == 1:
        tri = {os.path.basename(str(f)): {"categorie": cats[0]["id"], "confiance": 1.0,
                                          "remarque": ""} for f in clips}
    else:
        refs = [{"id": s["id"], "nom": s["name"], "consigne": s.get("consigne", ""),
                 "image": image_categorie(cid, c, s)} for s in cats]
        tri = ia.trier(refs, clips, progres)
    par_id = {s["id"]: s for s in cats}
    ranges, restes = [], []
    remarques = c.get("remarques") or {}
    for f in clips:
        nom = os.path.basename(str(f))
        t = tri.get(nom) or {}
        s = par_id.get(t.get("categorie"))
        av = qualite.avertissements(mesures.get(str(f)),
                                    float((s or {}).get("dur_max") or 0),
                                    bool((s or {}).get("son")))
        if t.get("remarque"):
            av.append(t["remarque"])
        if not s or float(t.get("confiance") or 0) < 0.4:
            restes.append({"clip": nom, "avert": av,
                           "raison": "Aucune catégorie ne correspond" if not s
                           else f"Pas sûr : « {s['name']} » ?"})
            continue
        dest = ranger_clip(cid, s, f)
        if t.get("remarque"):
            remarques[dest.name] = t["remarque"]
        ranges.append({"clip": dest.name, "categorie": s["name"], "avert": av})
    if remarques:
        c = load_serie(cid)
        c["remarques"] = remarques
        save_serie(c)
    return {"ranges": ranges, "restes": restes}


def qualite_serie(cid):
    """{nom du clip: [avertissements]} pour les clips DEJA mesures, et
    combien restent a mesurer — mesures lancees en fond, l'ecran repasse."""
    c = load_serie(cid)
    if not c:
        return None
    out, a_faire = {}, []
    for s in c["slots"]:
        if s.get("split_role") == "etape":
            continue
        for f in remixer.slot_clips_all(SERIES_DIR / cid, s):
            try:
                cle = qualite._cle(str(f))
            except OSError:
                continue
            m = qualite._charger().get(cle)
            if m is None and cle not in qualite._charger():
                a_faire.append(str(f))
                continue
            av = qualite.avertissements(m, float(s.get("dur_max") or 0),
                                        bool(s.get("son")))
            r = (c.get("remarques") or {}).get(Path(f).name)
            if r:
                av.append(r)
            if av:
                out[Path(f).name] = av
    if a_faire:
        _qualite_en_fond(a_faire)
    return {"clips": out, "reste": len(a_faire)}


_QUALITE_EN_COURS = set()


def _qualite_en_fond(chemins):
    neufs = [x for x in chemins if x not in _QUALITE_EN_COURS]
    if not neufs:
        return
    _QUALITE_EN_COURS.update(neufs)

    def fil():
        for x in neufs:
            try:
                qualite.mesure_en_cache(x)
            finally:
                _QUALITE_EN_COURS.discard(x)
    threading.Thread(target=fil, daemon=True).start()


def ia_etape(camp_id=None, serie_id=None):
    """LA prochaine chose a faire, calculee sans IA: l'etat de l'app le
    dit deja, et une reponse instantanee et gratuite vaut mieux qu'une
    devinette. L'assistant la recoit aussi, pour ne pas inventer."""
    c = load_serie(serie_id) if serie_id else None
    if c and not camp_id:
        camp_id = c.get("campaign_id")
    camp = plateau.campaign(int(camp_id)) if str(camp_id or "").isdigit() else None
    if not camp and not c:
        if not plateau.campaigns():
            return "Clique « Nouvelle campagne » à gauche, puis « Avec l'IA » : colle le brief et dépose la vidéo exemple."
        return "Ouvre une campagne à gauche, ou clique « Nouvelle campagne »."
    if not c:
        ses = [x for x in list_series() if str(x.get("campaign_id") or "") == str(camp["id"])]
        if not ses:
            return f"« {camp['name']} » n'a pas encore de série. Crée-la avec « + Série », ou refais la campagne « Avec l'IA »."
        c = load_serie(ses[0]["id"])
        serie_id = c["id"]
    vd = vrac_dir(serie_id)
    if vd.is_dir() and remixer.list_media(str(vd), remixer.VIDEO_EXTS):
        return (f"Des clips attendent dans « {c['name']} » (en haut de l'onglet « Clips ») : "
                f"« Trier », ou choisis leur catégorie à la main.")
    cats = [s for s in c["slots"] if not s.get("off") and s.get("split_role") != "etape"]
    vides = [s for s in cats if not remixer.slot_clips(SERIES_DIR / serie_id, s)]
    if vides:
        s = vides[0]
        quoi = f" — {s['consigne']}" if s.get("consigne") else ""
        return (f"Filme les clips de « {s['name']} »{quoi}. Puis « Déposer tous les clips » "
                f"dans la série « {c['name']} ».")
    maigres = [s for s in cats if len(remixer.slot_clips(SERIES_DIR / serie_id, s)) < 3]
    od = Path(remixer.output_dir(SERIES_DIR / serie_id, c))
    sorties = list(od.glob("*.mp4")) if od.exists() else []
    if not sorties and not plateau.generated_total(serie_id):
        return f"Génère une vidéo pour vérifier le montage : série « {c['name']} », onglet « Générer »."
    if maigres:
        s = maigres[0]
        return (f"Ajoute des prises à « {s['name']} » : avec moins de 3 clips, les vidéos "
                f"se ressemblent trop.")
    if not int(c.get("auto_jour") or 0):
        return f"Branche l'envoi automatique : série « {c['name']} », onglet « Publier »."
    return f"Tout roule : « {c['name']} » envoie {c['auto_jour']} vidéo(s) par jour sur Buffer."


def ia_contexte(camp_id=None, serie_id=None):
    """Ce que l'assistant sait de l'etat, en texte. Court: c'est renvoye a
    chaque question."""
    L = [f"Aujourd'hui : {time.strftime('%Y-%m-%d %H:%M')}"]
    camps = plateau.campaigns()
    L.append("Campagnes : " + (", ".join(x["name"] for x in camps) or "aucune"))
    c = load_serie(serie_id) if serie_id else None
    if c and not camp_id:
        camp_id = c.get("campaign_id")
    camp = plateau.campaign(int(camp_id)) if str(camp_id or "").isdigit() else None
    if camp:
        L.append(f"\nCAMPAGNE OUVERTE : « {camp['name']} » — objectif {plateau.target_of(camp) or '?'} "
                 f"vidéo(s)/jour, postées aujourd'hui {plateau.posted_today(camp['id'])}.")
        if camp.get("notes"):
            L.append("Notes : " + camp["notes"][:800])
        try:
            b = json.loads(camp.get("brief_json") or "{}")
            if b.get("brut"):
                L.append("Brief (début) : " + brief_en_texte(b, " / ")[:1500])
        except ValueError:
            pass
        ses = [x for x in list_series() if str(x.get("campaign_id") or "") == str(camp["id"])]
        L.append("Séries : " + (", ".join(x["name"] for x in ses) or "aucune"))
        if not c and ses:
            c = load_serie(ses[0]["id"])
    if c:
        sid = c["id"]
        L.append(f"\nSÉRIE OUVERTE : « {c['name']} » "
                 f"({'split screen' if c['settings'].get('split') else 'plein cadre'})"
                 f", envoi auto {int(c.get('auto_jour') or 0)}/jour.")
        for s in c["slots"]:
            if s.get("split_role") == "etape":
                L.append(f"- étape (texte dans la bande) : {(s.get('captions') or [''])[0]}")
                continue
            n = len(remixer.slot_clips(SERIES_DIR / sid, s))
            L.append(f"- catégorie « {s['name']} » : {n} clip(s)"
                     + (" (mise de côté)" if s.get("off") else "")
                     + (f" — à filmer : {s['consigne']}" if s.get("consigne") else ""))
        vd = vrac_dir(sid)
        nv = len(remixer.list_media(str(vd), remixer.VIDEO_EXTS)) if vd.is_dir() else 0
        if nv:
            L.append(f"{nv} clip(s) déposé(s), pas encore triés.")
        L.append(f"Vidéos générées en tout : {plateau.generated_total(sid)}.")
        if (c.get("ia") or {}).get("questions"):
            L.append("Questions ouvertes pour le client : " + " / ".join(c["ia"]["questions"]))
    L.append("\nPROCHAINE ÉTAPE (calculée par l'app) : " + ia_etape(camp_id, serie_id))
    return "\n".join(L)




# ------------------------------------------------------------------
# Le monteur et le chef de campagne
# ------------------------------------------------------------------
# On PARLE a l'IA (« raccourcis l'accroche », « 5 par jour sur lovable »).
# Claude rend des actions; `ia_traduire` les change en requetes sur les
# routes de l'interface — les memes gardes, rien de neuf qui ecrive — et
# l'utilisateur les applique d'un clic. Avant d'appliquer, l'interface
# prend une PHOTO de ce qui va bouger (serie.json tel quel, colonnes de la
# campagne): « Annuler » la remet, sans avoir a calculer l'inverse de
# chaque action.
IA_PHOTOS = {}
IA_PHOTOS_MAX = 30
# Ce que l'IA peut changer sur une campagne. Ni identifiants ni mots de
# passe: un chef de campagne n'a aucune raison de les reecrire.
IA_CAMP_COLS = ("name", "daily_target", "pay_per_video", "pay_cycle",
                "pay_anchor", "notes", "paused")


def _norme(t):
    return re.sub(r"[^a-z0-9]+", "", unicodedata.normalize("NFKD", str(t or "").lower())
                  .encode("ascii", "ignore").decode())


def _series_noms():
    """[(id, nom, campaign_id)] sans compter les clips: list_series() le
    fait pour chaque serie, et on n'a besoin que des noms."""
    out = []
    if SERIES_DIR.exists():
        for d in sorted(SERIES_DIR.iterdir()):
            try:
                j = json.loads((d / "serie.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            out.append((d.name, j.get("name") or d.name, j.get("campaign_id")))
    return out


def _trouver(nom, choix, cle):
    """Le meilleur element de `choix` pour `nom`: egalite sans casse ni
    accents, puis inclusion. None si rien ou si l'inclusion est ambigue."""
    n = _norme(nom)
    if not n:
        return None
    egaux = [x for x in choix if _norme(cle(x)) == n]
    if egaux:
        return egaux[0]
    dedans = [x for x in choix if n in _norme(cle(x)) or _norme(cle(x)) in n]
    return dedans[0] if len(dedans) == 1 else None


def _s(v):
    return f"{float(v):.1f}".replace(".", ",")


def _duree_txt(sl):
    a, b = float(sl.get("dur_min") or 0), float(sl.get("dur_max") or 0)
    if sl.get("complet"):
        return "clip entier"
    if not b:
        return "auto"
    return f"{_s(a)} s" if abs(a - b) < 0.01 else f"{_s(a)}–{_s(b)} s"


def ia_contexte_detail(camp_id=None, serie_id=None):
    """L'etat complet de ce qui est ouvert, pour le monteur: les noms
    EXACTS, les durees, les textes, les reglages. Le contexte court de
    l'assistant ne suffit pas a viser une categorie sans se tromper."""
    L = [ia_contexte(camp_id, serie_id)]
    c = load_serie(serie_id) if serie_id else None
    if c and not camp_id:
        camp_id = c.get("campaign_id")
    camp = plateau.campaign(int(camp_id)) if str(camp_id or "").isdigit() else None
    noms = _series_noms()
    camps = {str(x["id"]): x["name"] for x in plateau.campaigns()}
    L.append("\nTOUTES LES SÉRIES : " + "; ".join(
        f"« {n} »" + (f" (campagne {camps[str(k)]})" if str(k) in camps else "")
        for _, n, k in noms))
    if camp:
        pay = plateau.next_payment(camp)
        L.append(f"\nCAMPAGNE « {camp['name']} » EN DÉTAIL : "
                 f"{'EN PAUSE' if camp.get('paused') else 'active'}, "
                 f"objectif_jour {camp.get('daily_target') or '—'}, "
                 f"paie_video {camp.get('pay_per_video') or '—'}, "
                 f"cycle_paie {camp.get('pay_cycle') or '—'}, "
                 f"date_paie {camp.get('pay_anchor') or '—'}"
                 + (f", prochain paiement le {pay['date']} : {pay['montant']} "
                    f"({pay['videos']} vidéos)" if pay else ""))
        if camp.get("notes"):
            L.append("Notes complètes : " + camp["notes"][:2000])
        if not c:
            ses = [i for i, _, k in noms if str(k or "") == str(camp["id"])]
            c = load_serie(ses[0]) if ses else None
    if c:
        st = c["settings"]
        L.append(f"\nSÉRIE « {c['name']} » EN DÉTAIL : taille_texte {st.get('caption_size')}, "
                 f"style_texte {st.get('caption_style')}, melanger_ordre "
                 f"{bool(st.get('shuffle_slots'))}, musique_volume "
                 f"{st.get('music_volume_max')}, sans_musique {bool(st.get('mute'))}, "
                 f"envoi_auto_jour {int(c.get('auto_jour') or 0)}"
                 + (f" (demain {c['auto_demain']['n']})" if c.get("auto_demain") else ""))
        L.append("Catégories, dans l'ordre :")
        for sl in c["slots"]:
            caps = sl.get("captions") or []
            role = {"haut": "moitié haute", "bas": "moitié basse",
                    "etape": "étape (texte dans la bande, sans clip)"}.get(sl.get("split_role"), "")
            # La longueur REELLE des clips: sans elle, « raccourcis de
            # 0,3 s » sur une duree « auto » n'a pas de point de depart.
            longs = ""
            if sl.get("split_role") != "etape":
                ds = sorted(d for d in (remixer.probe(f)[0] for f in
                            remixer.slot_clips(SERIES_DIR / c["id"], sl)) if d)
                if ds:
                    longs = (f" (clips de {_s(ds[0])} s)" if len(ds) == 1 or ds[-1] - ds[0] < 0.05
                             else f" ({len(ds)} clips de {_s(ds[0])} à {_s(ds[-1])} s)")
                else:
                    longs = " (aucun clip)"
            L.append(f"  « {sl['name']} »" + (f" [{role}]" if role else "")
                     + f" durée {_duree_txt(sl)}" + longs
                     + (" · garde son son" if sl.get("son") else "")
                     + (" · MISE DE CÔTÉ" if sl.get("off") else "")
                     + (f" · texte en {sl['text_pos']}" if sl.get("text_pos") else "")
                     + (" · textes : " + " | ".join(f"« {t} »" for t in caps[:6])
                        + (f" (+{len(caps) - 6})" if len(caps) > 6 else "") if caps else " · sans texte"))
        # La FRISE de l'editeur: sans elle, « change le texte du debut »
        # visait les textes des categories, que l'editeur allume ne
        # dessine plus — le changement ne se voyait pas dans la video.
        ed = c.get("editor") or {}
        par = {x["id"]: x["name"] for x in c["slots"]}
        if ed.get("actif"):
            L.append("FRISE DE L'ÉDITEUR : ACTIVE — les textes à l'écran sont CES blocs "
                     "(les textes des catégories ne sont pas dessinés) :")
            for n, bl in enumerate(ed.get("blocs") or [], 1):
                de = (bl.get("debut") or {})
                fi = (bl.get("fin") or {})
                pos = next((k for k, v in IA_BLOC_Y.items()
                            if v is not None and bl.get("text_y") is not None
                            and abs(v - bl["text_y"]) < 0.08), None)
                L.append(f"  bloc {n} [id {bl.get('id')}] « {bl.get('texte')} » : de « "
                         f"{par.get(de.get('slot'), '?')} »"
                         + (f" {float(de.get('off') or 0):+g} s" if de.get("off") else "")
                         + " jusqu'à " + (f"« {par.get(fi.get('slot'), '?')} »"
                                         + (f" {float(fi.get('off') or 0):+g} s" if fi.get("off") else "")
                                         if fi.get("slot") else "la fin")
                         + (f" · {pos}" if pos else (" · haut" if bl.get("text_y") is None else
                                                     f" · y {bl['text_y']:.2f}"))
                         + (f" · taille {int(bl['caption_size'])}" if bl.get("caption_size") else "")
                         + (f" · style {bl['style']}" if bl.get("style") else ""))
            if not ed.get("blocs"):
                L.append("  (aucun bloc : la vidéo sort sans texte)")
        else:
            L.append("FRISE DE L'ÉDITEUR : éteinte — les textes à l'écran sont ceux des catégories.")
        des = c.get("descriptions") or []
        if des:
            L.append(f"Légendes du post ({len(des)}) : " + " | ".join(d[:120] for d in des[:3]))
    return "\n".join(L)


def derniere_video(c):
    od = Path(remixer.output_dir(SERIES_DIR / c["id"], c))
    vids = sorted(od.glob("*.mp4"), key=lambda f: f.stat().st_mtime) if od.exists() else []
    return vids[-1] if vids else None


# Une demande qui parle de ce qu'on VOIT: on joint la derniere video
# exportee, six images. Pas pour une question de paie ou d'objectif — des
# images inutiles ralentissent la reponse et puisent dans l'abonnement.
PARLE_DE_L_IMAGE = re.compile(
    r"vid[ée]o|image|plan|texte|écrit|ecrit|cadr|hook|accroche|on voit|regarde|"
    r"coupe|sombre|flou|gros|petit|début|debut|fin\b|écran|ecran", re.I)


def ia_images_video(c, demande):
    if not c or not PARLE_DE_L_IMAGE.search(demande or ""):
        return []
    v = derniere_video(c)
    if not v:
        return []
    d = ia.duree(v)
    out = []
    for i in range(6):
        t = d * (i + 0.5) / 6
        out.append((f"Dernière vidéo exportée de « {c['name']} » ({_s(d)} s), image à {_s(t)} s",
                    ia.image(v, t)))
    return out


def _champs_categorie(a, sl=None):
    """Les champs d'une action `categorie` -> (corps du PUT pour ce slot,
    phrases). `sl` = l'etat actuel, pour dire « avant -> apres »."""
    sl = sl or {}
    body, dit = {}, []
    if a.get("nom") and a["nom"].strip() != sl.get("name"):
        body["name"] = a["nom"].strip()[:40]
        dit.append(f"renommée « {body['name']} »")
    if a.get("dur_min") is not None or a.get("dur_max") is not None:
        lo = a.get("dur_min") if a.get("dur_min") is not None else a.get("dur_max")
        hi = a.get("dur_max") if a.get("dur_max") is not None else lo
        lo, hi = sorted((max(0.0, float(lo)), max(0.0, float(hi))))
        body.update(dur_min=round(lo, 2), dur_max=round(hi, 2))
        neuf = {"dur_min": lo, "dur_max": hi}
        dit.append(f"durée {_duree_txt(sl)} → {_duree_txt(neuf)}" if sl
                   else f"durée {_duree_txt(neuf)}")
        if sl.get("complet") and a.get("complet") is None:
            body["complet"] = 0
    if a.get("complet") is not None and bool(a["complet"]) != bool(sl.get("complet")):
        body["complet"] = 1 if a["complet"] else 0
        dit.append("chaque clip en entier" if a["complet"] else "plus en entier")
    if a.get("textes") is not None:
        t = [str(x).strip() for x in a["textes"] if str(x).strip()]
        if t != (sl.get("captions") or []):
            body["captions"] = t
            dit.append(("textes → " + " | ".join(f"« {x} »" for x in t[:3])
                        + (f" (+{len(t) - 3})" if len(t) > 3 else "")) if t else "plus de texte")
    if a.get("position_texte") and a["position_texte"] != sl.get("text_pos"):
        body["text_pos"] = a["position_texte"]
        dit.append(f"texte en {a['position_texte']}")
    if a.get("son") is not None and bool(a["son"]) != bool(sl.get("son")):
        body["son"] = 1 if a["son"] else 0
        dit.append("garde son son" if a["son"] else "son coupé")
    if a.get("consigne") is not None and a["consigne"].strip() != (sl.get("consigne") or ""):
        body["consigne"] = a["consigne"].strip()
        dit.append(f"à filmer : {body['consigne'][:80]}")
    return body, dit


def ia_traduire(actions, camp_id=None, serie_id=None):
    """Actions de Claude -> [{texte, requetes, erreur}]. Rien n'est ecrit
    ici: on lit l'etat pour viser juste et dire « avant -> apres ». Les
    requetes visent les routes de l'interface, qui gardent leurs gardes."""
    noms = _series_noms()
    ouverte = load_serie(serie_id) if serie_id else None
    if ouverte and not camp_id:
        camp_id = ouverte.get("campaign_id")
    camp = plateau.campaign(int(camp_id)) if str(camp_id or "").isdigit() else None
    if not ouverte and camp:
        ses = [i for i, _, k in noms if str(k or "") == str(camp["id"])]
        ouverte = load_serie(ses[0]) if len(ses) == 1 else None
    series = {}

    def serie(nom):
        if nom and (not ouverte or _norme(nom) != _norme(ouverte["name"])):
            x = _trouver(nom, noms, lambda t: t[1])
            if not x:
                return None, f"Série « {nom} » introuvable"
            cid = x[0]
        elif ouverte:
            cid = ouverte["id"]
        else:
            return None, "Ouvre une série d'abord, ou dis laquelle"
        if cid not in series:
            series[cid] = load_serie(cid)
        return series[cid], ""

    out = []
    for a in actions or []:
        if not isinstance(a, dict):
            continue
        ty = a.get("type")
        try:
            if ty in ("categorie", "nouvelle_categorie", "ordre", "serie", "generer",
                      "texte_video"):
                c, err = serie(a.get("serie"))
                if not c:
                    out.append({"texte": err, "requetes": [], "erreur": True})
                    continue
                url = f"/api/series/{c['id']}"
                tete = f"« {c['name']} »" if not ouverte or c["id"] != ouverte["id"] else ""
            if ty == "categorie":
                sl = _trouver(a.get("categorie"), c["slots"], lambda x: x["name"])
                if not sl:
                    out.append({"texte": f"Catégorie « {a.get('categorie')} » introuvable"
                                + (f" dans {tete}" if tete else ""), "requetes": [], "erreur": True})
                    continue
                body, dit = _champs_categorie(a, sl)
                req = []
                if body:
                    req.append({"m": "PUT", "url": url, "body": {"slots": [
                        dict(body, id=x["id"]) if x["id"] == sl["id"] else {"id": x["id"]}
                        for x in c["slots"]]}})
                if a.get("mise_de_cote") is not None and bool(a["mise_de_cote"]) != bool(sl.get("off")):
                    req.append({"m": "POST", "url": url + "/hide",
                                "body": {"slot": sl["id"], "hidden": bool(a["mise_de_cote"])}})
                    dit.append("mise de côté" if a["mise_de_cote"] else "remise au tirage")
                if req:
                    out.append({"texte": (tete + " " if tete else "") + f"« {sl['name']} » : " + ", ".join(dit),
                                "requetes": req})
            elif ty == "nouvelle_categorie":
                # Sans le numero: une serie liee a un dossier numerote
                # elle-meme ses categories (« 11-CTA » devenait « 11-11-CTA »).
                nom = re.sub(r"^\d+\s*[-_.]\s*", "",
                             (a.get("nom") or a.get("categorie") or "").strip())[:40]
                if not nom:
                    continue
                body, dit = _champs_categorie(dict(a, nom=None))
                out.append({"texte": (tete + " " if tete else "") + f"nouvelle catégorie « {nom} »"
                            + (" : " + ", ".join(dit) if dit else ""),
                            "requetes": [{"m": "NOUVELLE", "url": url, "nom": nom, "champs": body}]})
            elif ty == "ordre":
                vus, ids = set(), []
                for n in a.get("ordre") or []:
                    sl = _trouver(n, c["slots"], lambda x: x["name"])
                    if sl and sl["id"] not in vus:
                        vus.add(sl["id"]); ids.append(sl["id"])
                ids += [x["id"] for x in c["slots"] if x["id"] not in vus]
                if ids == [x["id"] for x in c["slots"]]:
                    continue
                par = {x["id"]: x["name"] for x in c["slots"]}
                out.append({"texte": (tete + " " if tete else "") + "ordre : " + " → ".join(par[i] for i in ids),
                            "requetes": [{"m": "PUT", "url": url, "body": {"slots": [{"id": i} for i in ids]}}]})
            elif ty == "serie":
                st, body, dit, regl = c["settings"], {}, [], {}
                if a.get("envoi_auto_jour") is not None:
                    n = max(0, min(int(a["envoi_auto_jour"]), 50))
                    if n != int(c.get("auto_jour") or 0):
                        body["auto_jour"] = n
                        dit.append(f"envoi auto {int(c.get('auto_jour') or 0)} → {n}/jour")
                if a.get("taille_texte") and int(a["taille_texte"]) != int(st.get("caption_size") or 0):
                    regl["caption_size"] = max(20, min(int(a["taille_texte"]), 200))
                    dit.append(f"taille du texte {st.get('caption_size')} → {regl['caption_size']}")
                if a.get("style_texte") and a["style_texte"] != st.get("caption_style"):
                    regl["caption_style"] = a["style_texte"]
                    dit.append(f"style du texte → {a['style_texte']}")
                if a.get("melanger_ordre") is not None and bool(a["melanger_ordre"]) != bool(st.get("shuffle_slots")):
                    regl["shuffle_slots"] = bool(a["melanger_ordre"])
                    dit.append("ordre des catégories mélangé" if a["melanger_ordre"] else "ordre fixe")
                if a.get("musique_volume") is not None:
                    v = round(max(0.0, min(float(a["musique_volume"]), 3.0)), 2)
                    if v != st.get("music_volume_max"):
                        regl.update(music_volume_min=v, music_volume_max=v)
                        dit.append(f"volume de la musique {st.get('music_volume_max')} → {v}")
                if a.get("sans_musique") is not None and bool(a["sans_musique"]) != bool(st.get("mute")):
                    regl["mute"] = 1 if a["sans_musique"] else 0
                    dit.append("sans musique" if a["sans_musique"] else "avec musique")
                if a.get("legendes_post") is not None:
                    body["descriptions"] = [str(x) for x in a["legendes_post"] if str(x).strip()]
                    dit.append(f"{len(body['descriptions'])} légende(s) de post")
                if regl:
                    body["settings"] = regl
                if body:
                    out.append({"texte": (tete or f"« {c['name']} »") + " : " + ", ".join(dit),
                                "requetes": [{"m": "PUT", "url": url, "body": body}]})
            elif ty == "texte_video":
                r = ia_bloc(a, c)
                if r.get("erreur"):
                    out.append({"texte": (tete + " " if tete else "") + r["texte"],
                                "requetes": [], "erreur": True})
                elif r:
                    out.append({"texte": (tete + " " if tete else "") + r["texte"],
                                "requetes": [{"m": "PUT", "url": url,
                                              "body": {"editor": r["editor"]}}]})
            elif ty == "generer":
                n = max(1, min(int(a.get("nombre") or 1), 20))
                out.append({"texte": f"exporter {n} vidéo{'s' if n > 1 else ''} de « {c['name']} »",
                            "requetes": [{"m": "GENERER", "serie": c["id"], "n": n}]})
            elif ty == "campagne":
                cp = camp
                if a.get("serie"):
                    x = _trouver(a["serie"], plateau.campaigns(), lambda t: t["name"])
                    cp = x or cp
                if not cp:
                    out.append({"texte": "Ouvre une campagne d'abord, ou dis laquelle",
                                "requetes": [], "erreur": True})
                    continue
                body, dit = {}, []
                def pose(col, val, lib):
                    if str(val) != str(cp.get(col) or ""):
                        body[col] = val
                        dit.append(f"{lib} {cp.get(col) or '—'} → {val if val != '' else '—'}")
                if a.get("nom"):
                    pose("name", a["nom"].strip(), "nom")
                if a.get("objectif_jour") is not None:
                    pose("daily_target", str(max(0, int(a["objectif_jour"]))), "objectif/jour")
                if a.get("paie_video") is not None:
                    pose("pay_per_video", f"{float(a['paie_video']):g}", "paie/vidéo")
                if a.get("cycle_paie") is not None:
                    v = str(a["cycle_paie"]).strip()
                    if plateau.cycle_valide(v) or v == "":
                        pose("pay_cycle", v, "cycle de paie")
                if a.get("date_paie"):
                    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", a["date_paie"]):
                        pose("pay_anchor", a["date_paie"], "jour de paie")
                if a.get("notes") is not None:
                    if a["notes"].strip() != (cp.get("notes") or "").strip():
                        body["notes"] = a["notes"].strip()
                        dit.append("notes réécrites")
                if a.get("pause") is not None and bool(a["pause"]) != bool(cp.get("paused")):
                    body["paused"] = 1 if a["pause"] else 0
                    dit.append("EN PAUSE (ne publie plus)" if a["pause"] else "relancée")
                if body:
                    out.append({"texte": f"campagne « {cp['name']} » : " + ", ".join(dit),
                                "requetes": [{"m": "PUT", "url": f"/api/campaigns/{cp['id']}", "body": body}]})
            elif ty == "tache":
                t = (a.get("texte") or "").strip()[:300]
                if t:
                    out.append({"texte": f"todo : « {t} »",
                                "requetes": [{"m": "POST", "url": "/api/tasks", "body": {"text": t}}]})
        except (TypeError, ValueError):
            out.append({"texte": f"Action « {ty} » illisible", "requetes": [], "erreur": True})
    # Le monteur APPLIQUE tout seul (demande du 18/11) — sauf ce qui touche
    # a ce qui PART EN LIGNE : l'envoi auto vers Buffer et la pause d'une
    # campagne. Un montage se defait par « Annuler »; un post parti, non.
    for o in out:
        o["confirmer"] = any(
            ("auto_jour" in (q.get("body") or {})) or ("paused" in (q.get("body") or {}))
            for q in o.get("requetes") or [])
    return out


def ia_bloc(a, c):
    """Une action `texte_video` sur la frise de l'editeur -> {texte, editor}.

    Travaille sur la copie de la serie gardee par `ia_traduire` (meme objet
    d'une action a l'autre) : deux changements de texte dans le meme
    message s'empilent au lieu que le second efface le premier, parce que
    chaque PUT renvoie la frise ENTIERE (la route la remplace)."""
    ed = c.get("editor") or {}
    if not ed.get("actif"):
        return {"erreur": True, "texte": "La frise de l'éditeur est éteinte : "
                "change plutôt les textes de la catégorie"}
    blocs = ed.setdefault("blocs", [])
    slots = c["slots"]

    def cat(nom):
        return _trouver(nom, slots, lambda x: x["name"]) if nom else None

    vise = None
    ref = str(a.get("bloc") or "").strip()
    if ref:
        vise = next((b for b in blocs if b.get("id") == ref), None)
        if not vise and ref.isdigit() and 0 < int(ref) <= len(blocs):
            vise = blocs[int(ref) - 1]
        if not vise:
            vise = _trouver(ref, blocs, lambda b: b.get("texte") or "")
        if not vise:
            return {"erreur": True, "texte": f"Bloc de texte « {ref} » introuvable sur la frise"}
    if vise and a.get("supprimer"):
        blocs.remove(vise)
        return {"texte": f"texte « {vise['texte'][:60]} » retiré de la frise", "editor": ed}

    neuf = vise is None
    if neuf:
        if not str(a.get("texte") or "").strip():
            return {"erreur": True, "texte": "Nouveau texte sans contenu"}
        d = cat(a.get("de_categorie"))
        if not d:
            return {"erreur": True, "texte": f"Catégorie « {a.get('de_categorie') or '?'} » "
                    "introuvable pour poser le texte"}
        vise = {"id": uuid.uuid4().hex[:8], "texte": "",
                "debut": {"slot": d["id"], "off": 0.0}, "fin": {"slot": "", "off": 0.0},
                "text_y": None, "text_x": None, "caption_size": None,
                "caption_larg": None, "caption_lead": None, "style": None}
    dit = []
    if str(a.get("texte") or "").strip() and a["texte"].strip() != vise.get("texte"):
        if not neuf:
            dit.append(f"« {vise['texte'][:40]} » → « {a['texte'].strip()[:60]} »")
        vise["texte"] = a["texte"].strip()[:200]
    if a.get("de_categorie") and not neuf:
        d = cat(a["de_categorie"])
        if not d:
            return {"erreur": True, "texte": f"Catégorie « {a['de_categorie']} » introuvable"}
        if d["id"] != (vise.get("debut") or {}).get("slot"):
            vise["debut"] = {"slot": d["id"], "off": 0.0}
            dit.append(f"commence sur « {d['name']} »")
    if a.get("jusqua_categorie") is not None:
        j = str(a["jusqua_categorie"]).strip()
        if not j or _norme(j) in ("fin", "la fin", "end"):
            vise["fin"] = {"slot": "", "off": 0.0}
            dit.append("jusqu'à la fin")
        else:
            f = cat(j)
            if not f:
                return {"erreur": True, "texte": f"Catégorie « {j} » introuvable"}
            vise["fin"] = {"slot": f["id"], "off": 0.0}
            dit.append(f"s'arrête au début de « {f['name']} »")
    for cle, bord in (("decalage_debut", "debut"), ("decalage_fin", "fin")):
        if a.get(cle) is not None:
            off = round(max(-60.0, min(float(a[cle]), 60.0)), 3)
            vise.setdefault(bord, {"slot": "", "off": 0.0})["off"] = off
            dit.append(f"{'départ' if bord == 'debut' else 'fin'} décalé de {off:+g} s")
    if a.get("position_texte") in IA_BLOC_Y:
        vise["text_y"] = IA_BLOC_Y[a["position_texte"]]
        vise["text_x"] = None
        dit.append(f"en {a['position_texte']}")
    if a.get("taille_texte"):
        vise["caption_size"] = max(8, min(int(a["taille_texte"]), 300))
        dit.append(f"taille {vise['caption_size']}")
    if a.get("style_texte") in BLOC_STYLES:
        vise["style"] = a["style_texte"]
        dit.append(f"style {a['style_texte']}")
    if neuf:
        blocs.append(vise)
        par = {x["id"]: x["name"] for x in slots}
        return {"texte": f"nouveau texte « {vise['texte'][:60]} » sur « "
                f"{par.get(vise['debut']['slot'])} »" + (", " + ", ".join(dit) if dit else ""),
                "editor": ed}
    if not dit:
        return {}
    return {"texte": f"texte « {vise['texte'][:40]} » : " + ", ".join(dit), "editor": ed}


def ia_photo(series_ids, camp_ids):
    """Ce que les changements vont toucher, tel quel, pour « Annuler »."""
    ph = {"series": {}, "campagnes": {}}
    for cid in series_ids:
        p = serie_path(str(cid))
        if p:
            ph["series"][str(cid)] = (p / "serie.json").read_text(encoding="utf-8")
    for k in camp_ids:
        cp = plateau.campaign(int(k)) if str(k).isdigit() else None
        if cp:
            ph["campagnes"][str(k)] = {c: cp.get(c) or "" for c in IA_CAMP_COLS}
    pid = uuid.uuid4().hex[:12]
    with IA_LOCK:
        IA_PHOTOS[pid] = ph
        while len(IA_PHOTOS) > IA_PHOTOS_MAX:
            IA_PHOTOS.pop(next(iter(IA_PHOTOS)))
    return pid


def ia_annuler(pid):
    with IA_LOCK:
        ph = IA_PHOTOS.pop(pid, None)
    if not ph:
        return False
    for cid, txt in ph["series"].items():
        p = serie_path(cid)
        if p:
            tmp = p / "serie.json.tmp"
            tmp.write_text(txt, encoding="utf-8")
            os.replace(str(tmp), str(p / "serie.json"))
    for k, cols in ph["campagnes"].items():
        old = plateau.campaign(int(k))
        plateau.update_campaign(int(k), cols)
        if old and old.get("name") != cols.get("name"):
            renommer_musiques(old, cols.get("name") or "")
    return True

class Handler(BaseHTTPRequestHandler):
    server_version = "Remixer"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass  # silence: le terminal reste lisible

    # --- helpers de reponse ---

    def send_json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_err(self, msg, status=400):
        self.send_json({"error": msg}, status)

    def recevoir(self, dest):
        """Le corps brut de la requete EST le fichier: l'ecrit dans `dest`
        par blocs, via un .part. -> message d'erreur, ou "" si c'est bon."""
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return "Fichier vide"
        part = Path(str(dest) + ".part")
        try:
            with open(part, "wb") as f:
                reste = n
                while reste > 0:
                    self._corps_lu = True
                    bloc = self.rfile.read(min(1024 * 1024, reste))
                    if not bloc:
                        raise IOError("transfert interrompu")
                    f.write(bloc)
                    reste -= len(bloc)
            os.replace(str(part), str(dest))
        except Exception as e:                                  # noqa: BLE001
            part.unlink(missing_ok=True)
            return f"Envoi échoué : {e}"
        return ""

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        self._corps_lu = True
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    def vider_corps(self):
        """Jette le corps qu'aucun gestionnaire n'a lu.

        PIEGE DEJA PAYE. Un gestionnaire qui repond sans lire le corps de
        la requete laisse ses octets dans la socket. La connexion est
        gardee ouverte (keep-alive), alors ces octets se collent DEVANT
        la requete suivante: le serveur lit « {}GET /api/... » et repond
        501 « Unsupported method ». L'erreur apparait sur une requete
        parfaitement valide, plusieurs secondes plus tard, et ne
        ressemble en rien a sa cause — d'ou une « Erreur 501 » sur la
        page Prospection mise sur le compte d'un redemarrage.

        Vide donc ici, en sortie de do_POST / do_PUT / do_DELETE, et
        seulement si personne n'a lu: les televersements lisent le flux
        par morceaux et posent `_corps_lu` eux-memes."""
        if getattr(self, "_corps_lu", False):
            return
        n = int(self.headers.get("Content-Length") or 0)
        reste = n
        while reste > 0:
            bloc = self.rfile.read(min(65536, reste))
            if not bloc:
                break
            reste -= len(bloc)

    def send_file(self, path, download=False):
        """Sert un fichier, avec support des requetes Range (lecture video)."""
        path = Path(path)
        if not path.exists() or not path.is_file():
            return self.send_err("Fichier introuvable", 404)

        size = path.stat().st_size
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        start, end = 0, size - 1
        status = 200

        rng = self.headers.get("Range")
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                g1, g2 = m.group(1), m.group(2)
                if g1:
                    start = int(g1)
                    end = int(g2) if g2 else size - 1
                elif g2:                       # suffixe: bytes=-500
                    start = max(0, size - int(g2))
                if start >= size:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                end = min(end, size - 1)
                status = 206

        length = end - start + 1
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        # Sans en-tete de cache, le navigateur applique sa propre heuristique
        # et resservait index.html depuis son cache: on modifiait
        # l'interface, on rechargeait, et rien ne changeait a l'ecran.
        # Les fonds sont dans le lot: remplacer une image en gardant son nom
        # doit se voir tout de suite. Les videos, elles, gardent le cache —
        # ce sont des dizaines de Mo.
        if path.suffix.lower() in (".html", ".css", ".js") \
                or within(FONDS_DIR, path):
            self.send_header("Cache-Control", "no-store, must-revalidate")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        if download:
            self.send_header("Content-Disposition",
                             f'attachment; filename="{path.name}"')
        self.end_headers()

        with open(path, "rb") as f:
            f.seek(start)
            remaining = length
            while remaining > 0:
                chunk = f.read(min(256 * 1024, remaining))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return
                remaining -= len(chunk)


    # --- routage ---

    def do_GET(self):
        u = urlparse(self.path)
        p, q = u.path, parse_qs(u.query)
        # Une seule garde pour TOUTES les routes de l'atelier, plutot
        # qu'une par route: sans `template.py`, elles n'existent pas.
        if tpl is None and (p.startswith("/api/templates")
                            or p.startswith("/media/tplapercu")
                            or p.startswith("/media/template")):
            return self.send_err("Les templates ne sont pas dans cette version", 404)
        # Niveau campagne. Monte en tete du bloc d'egalite: le motif
        # ^/api/series/([^/]+)$ plus bas avalerait tout segment unique.
        # Les campagnes qu'on monte encore. A part de /api/campaigns pour
        # la meme raison que le filtre est en SQL: rien de ce qui n'a pas
        # commence ne doit traverser la vue d'ensemble.
        # TEMPLATES. Rien a voir avec le UGC: aucun de ces chemins ne
        # touche `series/`, donc rien n'apparait dans la barre laterale,
        # le graphe, la file, les objectifs ni Buffer.
        if p == "/api/templates":
            return self.send_json({"items": tpl.lister(),
                                   "ocr": tpl.ocr_disponible()})

        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)$", p)
        if m:
            t = tpl.charger(m.group(1))
            if not t:
                return self.send_err("Template introuvable", 404)
            t["rendus"] = tpl.rendus(m.group(1))
            return self.send_json(t)

        if p == "/api/onboarding":
            cs = plateau.campaigns("onbo")
            for c in cs:
                c["brief_n"] = _brief_n(c)
                c.pop("brief_json", None)
            return self.send_json(cs)

        if p == "/api/campaigns":
            cs = plateau.campaigns()
            for c in cs:
                c["target"] = plateau.target_of(c)
                c["posted_today"] = plateau.posted_today(c["id"])
                # Juste de quoi allumer la pastille de l'onglet. Le brief
                # lui-meme se demande a /api/campaigns/<id>/brief.
                c["brief_n"] = _brief_n(c)
                c.pop("brief_json", None)
                c["pay"] = plateau.next_payment(c)
                c["per_video"] = plateau.per_video_amount(c)
                # Relu a chaque appel, jamais mis en cache: une musique
                # deposee doit apparaitre sans redemarrage, comme fonds/.
                # Cree au passage: le dossier doit EXISTER dans le Finder
                # pour qu'on puisse y deposer un fichier sans etre passe
                # par l'app d'abord.
                d = musique_dir(c, creer=True)
                c["music"] = [Path(f).name
                              for f in remixer.list_media(d, remixer.AUDIO_EXTS)] if d else []
                c["music_dir"] = str(d) if d else ""
            return self.send_json(cs)

        # Etat Buffer de chaque campagne: son compte Instagram est-il
        # connecte a Buffer ? A part de /api/campaigns: il interroge Buffer
        # (liste gardee 5 min), la liste des campagnes ne doit pas en
        # dependre pour s'afficher.
        m = re.match(r"^/api/series/([^/]+)/auto$", p)
        if m:
            cid = m.group(1)
            c = load_serie(cid)
            if not c:
                return self.send_err("Série introuvable", 404)
            key = publisher.load_config().get("buffer_api_key")
            # `?frais=1` force la relecture de la liste des comptes. Elle
            # est en cache 6 h — un compte branche chez Buffer a l'instant
            # n'apparaitrait pas avant ce soir, et on chercherait pourquoi.
            if "frais" in q:
                canaux_buffer(frais=True)
            choisis = {ch["id"] for ch in comptes_serie(cid, c)}
            noms_camp = {x["id"]: x["name"] for x in plateau.campaigns()}
            comptes = []
            for ch in canaux_buffer():
                e = auto_etat(f"{cid}|{ch['id']}")
                attente = None
                if ch["id"] in choisis:
                    attente = file_en_attente(key, ch["id"])
                cam = campagne_du_canal(ch["id"])
                comptes.append({"id": ch["id"], "handle": _pseudo(ch.get("name")),
                                "campagne": noms_camp.get(cam, ""),
                                "choisi": ch["id"] in choisis,
                                "envoyees": e.get("envoyees", 0),
                                "en_cours": bool(e.get("en_cours")),
                                "erreur": e.get("erreur") or "",
                                "attente": e.get("attente") or "",
                                "en_attente": attente})
            reste_q, limite_q, reset_q = publisher.budget()
            pas_p = int(c.get("auto_pas") or 0)
            plaf_p = int(c.get("auto_plafond") or 0)
            dem = c.get("auto_demain") if isinstance(c.get("auto_demain"), dict) else None
            return self.send_json({
                "appels_jour": publisher.appels_par_jour().get(
                    time.strftime("%Y-%m-%d"), 0),
                "palier": ({"pas": pas_p, "plafond": plaf_p}
                           if pas_p > 0 and plaf_p > 0 else None),
                "budget": {"reste": reste_q, "limite": limite_q,
                           "reset": reset_q,
                           "heure": publisher.appels_derniere_heure()},
                "fenetre": [AUTO_DEBUT_H, AUTO_FIN_H],
                "auto_jour": int(c.get("auto_jour") or 0),
                "demain": int(dem["n"]) if dem else None,
                "bloque": auto_bloquant(cid, c),
                "legendes": len([d for d in c.get("descriptions", []) if d.strip()]),
                "comptes": comptes})

        if p == "/api/campaigns/buffer":
            frais = "frais" in q
            chans = canaux_buffer(frais=frais)
            res = {}
            for c in plateau.campaigns():
                ch = canal_campagne(c["id"])
                res[c["id"]] = {"handle": _pseudo(c.get("ig_handle")),
                                "connecte": bool(ch)}
            return self.send_json({"campagnes": res,
                                   "comptes": [_pseudo(ch.get("name")) for ch in chans],
                                   "erreur": _CANAUX["erreur"]})

        if p == "/api/prospects":
            items = plateau.prospects((q.get("statut") or [None])[0])
            for it in items:
                if not it.get("message"):
                    it["message"] = brouillon(it)
            return self.send_json({
                "items": items,
                "compte": plateau.compter_prospects(),
                "dernier": _REDDIT["dernier"],
                "erreur": _REDDIT["erreur"],
                "seuils": {"simple": SEUIL_SIMPLE, "parle": SEUIL_PARLE}})

        if p == "/api/videos":
            return self.send_json(plateau.videos())

        if p == "/api/tasks":
            return self.send_json(plateau.tasks())

        if p == "/api/ideas":
            return self.send_json({"sections": plateau.IDEA_SECTIONS,
                                   "labels": plateau.IDEA_LABELS,
                                   "items": plateau.ideas()})

        if p == "/api/checkpath":
            raw = (q.get("p") or [""])[0].strip()
            return self.send_json({"exists": bool(raw) and Path(
                os.path.expanduser(raw)).exists()})

        if p == "/api/queue":
            return self.send_json(queue_snapshot())

        if p == "/api/outputs":
            return self.send_json(all_outputs())

        if p == "/api/publish/config":
            return self.send_json(publisher.status())

        if p == "/api/publish/channels":
            cfg = publisher.load_config()
            try:
                chans = publisher.buffer_channels(cfg.get("buffer_api_key"))
            except publisher.PublishError as e:
                return self.send_err(str(e), 400)
            return self.send_json({"channels": chans})

        if p == "/" or p == "/index.html":
            return self.send_file(WEB_DIR / "index.html")

        if p == "/api/state":
            try:
                sync_all_outputs()
            except Exception:                                   # noqa: BLE001
                pass
            ok, dt, msg = remixer.tools_available()
            return self.send_json({"ffmpeg": ok, "drawtext": dt, "message": msg,
                                   "font": remixer.captions.font_name(),
                                   "fonts": remixer.captions.available_fonts(),
                                   "series": list_series(),
                                   "templates": tpl is not None,
                                   "defaults": remixer.DEFAULT_SETTINGS})

        if p == "/api/app":
            # ?frais : le panneau OUVERT a la main redemande au site s'il y a
            # une mise a jour (sinon le cache d'une heure la cachait a qui
            # venait justement voir).
            if "frais" in parse_qs(urlparse(self.path).query, keep_blank_values=True):
                maj.verifier(forcer=True)
            return self.send_json(app_etat())

        if p == "/api/acces":
            # Les codes d'acces n'existent que dans le plateau de celui qui
            # DONNE l'app : une copie installee n'a ni acces.txt ni raison
            # d'en avoir — refuse meme si quelqu'un en posait un.
            if INSTALLEE:
                return self.send_err("Not found", 404)
            if not acces_conf():
                return self.send_json({"branche": False, "codes": []})
            try:
                r = acces_appel("liste")
            except ValueError as e:
                return self.send_json({"branche": True, "codes": [], "erreur": str(e)})
            return self.send_json({"branche": True, "codes": r.get("codes", [])})

        # L'IA. Rien ici n'appelle Claude: l'etat, la prochaine etape et la
        # qualite se calculent sur la machine.
        if p == "/api/ia":
            ok, raison = ia.disponible()
            return self.send_json({"ok": ok, "raison": raison})

        m = re.match(r"^/api/ia/jobs/([a-f0-9]+)$", p)
        if m:
            with IA_LOCK:
                j = IA_JOBS.get(m.group(1))
                return self.send_json(dict(j)) if j else self.send_err("Tâche introuvable", 404)

        if p == "/api/ia/etape":
            return self.send_json({"etape": ia_etape(
                (q.get("campaign") or [""])[0] or None, (q.get("serie") or [""])[0] or None)})

        m = re.match(r"^/api/series/([^/]+)/qualite$", p)
        if m:
            r = qualite_serie(m.group(1))
            return self.send_json(r) if r is not None else self.send_err("Série introuvable", 404)

        m = re.match(r"^/media/contrat/([^/]+)$", p)
        if m:
            f = CONTRATS_DIR / safe_filename(unquote(m.group(1)))
            return (self.send_file(f) if f.is_file() and within(CONTRATS_DIR, f)
                    else self.send_err("Contrat introuvable", 404))

        m = re.match(r"^/media/exemple/([A-Za-z0-9_-]+)/(plan-\d+\.jpg|exemple\.[a-z0-9]{2,4})$", p)
        if m:
            f = exemple_dir(m.group(1)) / m.group(2)
            return self.send_file(f) if f.is_file() else self.send_err("Image introuvable", 404)

        # L'EDITEUR. Avant le motif ^/api/series/([^/]+)$ par habitude,
        # meme si `[^/]+` ne peut pas avaler un segment supplementaire.
        m = re.match(r"^/api/series/([^/]+)/editor/tirage$", p)
        if m:
            t = editeur_tirage(m.group(1))
            return self.send_json(t) if t else self.send_err("Série introuvable", 404)

        m = re.match(r"^/api/series/([^/]+)/editor/cadre$", p)
        if m:
            try:
                t = float((q.get("t") or ["0"])[0])
            except ValueError:
                t = 0.0
            f = editeur_cadre(m.group(1), (q.get("slot") or [""])[0],
                              safe_filename((q.get("clip") or [""])[0]), t)
            if not f:
                return self.send_err("Pas d'image pour ce clip", 404)
            return self.send_file(f)

        m = re.match(r"^/api/series/([^/]+)/editor/clip$", p)
        if m:
            f = editeur_clip(m.group(1), (q.get("slot") or [""])[0],
                             safe_filename((q.get("clip") or [""])[0]))
            return self.send_file(f) if f else self.send_err("Clip introuvable", 404)

        m = re.match(r"^/media/voix/([A-Za-z0-9_-]+)/(.+)$", p)
        if m:
            d = voix_dir(m.group(1))
            f = d / safe_filename(unquote(m.group(2)))
            if not within(d, f) or not f.is_file():
                return self.send_err("Son introuvable", 404)
            return self.send_file(f)

        m = re.match(r"^/media/editeur/([A-Za-z0-9_-]+)/(.+)$", p)
        if m:
            d = editeur_dir(m.group(1))
            f = d / safe_filename(unquote(m.group(2)))
            if not within(d, f) or not f.exists():
                return self.send_err("Image introuvable", 404)
            return self.send_file(f)

        m = re.match(r"^/api/series/([^/]+)$", p)
        if m:
            c = serie_detail(m.group(1))
            return self.send_json(c) if c else self.send_err("Série introuvable", 404)

        # Le brief ENTIER, et seulement quand on le demande. Il ne voyage
        # pas dans /api/campaigns: cette liste est relue a chaque
        # rafraichissement, et trois pages Notion dedans pesent plus que
        # tout le reste reuni.
        m = re.match(r"^/api/campaigns/(\d+)/brief$", p)
        if m:
            c = plateau.campaign(int(m.group(1)))
            if not c:
                return self.send_err("Campagne introuvable", 404)
            return self.send_json(brief_lu(c))

        m = re.match(r"^/api/campaigns/(\d+)$", p)
        if m:
            c = plateau.campaign(int(m.group(1)))
            if not c:
                return self.send_err("Campagne introuvable", 404)
            c["brief_n"] = _brief_n(c)      # la fiche n'a pas besoin du texte
            c.pop("brief_json", None)
            return self.send_json(c)

        m = re.match(r"^/api/jobs/([a-f0-9]+)$", p)
        if m:
            with JOBS_LOCK:
                j = JOBS.get(m.group(1))
                return self.send_json(dict(j)) if j else self.send_err("Job introuvable", 404)

        # Explorateur de dossiers (lecture seule) pour lier un dossier source.
        if p == "/api/browse":
            raw = (q.get("path") or [""])[0]
            path = real_dir(raw) if raw else str(Path.home())
            if not path:
                return self.send_err(f"Dossier introuvable ou illisible : {raw}", 404)
            parent = str(Path(path).parent)
            return self.send_json({
                "path": path,
                "parent": parent if parent != path else None,
                "shortcuts": home_shortcuts(),
                "folders": remixer.scan_subfolders(path),
                "clips": len(remixer.list_media(path, remixer.VIDEO_EXTS)),
                "audio": len(remixer.list_media(path, remixer.AUDIO_EXTS)),
            })

        if p == "/api/fonds":
            return self.send_json({"fonds": list_fonds()})

        m = re.match(r"^/fonds/(.+)$", p)
        if m:
            f = FONDS_DIR / safe_filename(unquote(m.group(1)))
            # `within` en plus du nettoyage du nom: deux verrous valent
            # mieux qu'un sur une route qui sert des fichiers du disque.
            if not f.exists() or not within(FONDS_DIR, f) \
                    or f.suffix.lower() not in FOND_EXTS:
                return self.send_err("Fond introuvable", 404)
            return self.send_file(f)

        # /media/<cid>/<kind>/<name>   kind = output | thumb | clip | music
        m = re.match(r"^/avatars/(.+)$", p)
        if m:
            f = AVATARS_DIR / safe_filename(unquote(m.group(1)))
            if not f.exists() or not within(AVATARS_DIR, f):
                return self.send_err("Image introuvable", 404)
            return self.send_file(f)

        # Ecoute d'une musique du pot commun, pour verifier ce qu'on a
        # depose avant de lancer un lot de generations.
        m = re.match(r"^/musiques/(\d+)/(.+)$", p)
        if m:
            d = musique_dir(m.group(1))
            f = d / safe_filename(unquote(m.group(2))) if d else None
            if not f or not f.exists() or not within(d, f):
                return self.send_err("Musique introuvable", 404)
            return self.send_file(f)

        # Les montages d'un template. Servis a part de /media/<serie>/...:
        # un template n'est pas une serie et son dossier n'est pas sous
        # `series/` — c'est toute la raison d'etre de cette separation.
        # Les images de l'apercu d'un template: le cadre du reel et le
        # texte dessine. Meme dossier, servi en lecture seule.
        m = re.match(r"^/media/tplapercu/([A-Za-z0-9_-]+)/(.+)$", p)
        if m:
            tid, nom = m.group(1), unquote(m.group(2))
            d = tpl.chemin_template(tid) / tpl.APERCU
            f = d / safe_filename(nom)
            if not within(d, f) or not f.exists():
                return self.send_err("Image introuvable", 404)
            return self.send_file(f)

        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)/cadre$", p)
        if m:
            try:
                i = int((q.get("plan") or ["0"])[0])
            except ValueError:
                return self.send_err("Plan invalide", 400)
            f = tpl.cadre_plan(m.group(1), i)
            if not f:
                return self.send_err("Pas d'image pour ce plan", 404)
            return self.send_file(Path(f))

        m = re.match(r"^/media/template/([A-Za-z0-9_-]+)/(.+)$", p)
        if m:
            tid, nom = m.group(1), unquote(m.group(2))
            d = tpl.chemin_template(tid) / "rendus"
            f = d / safe_filename(nom)
            if not within(d, f) or not f.exists():
                return self.send_err("Vidéo introuvable", 404)
            return self.send_file(f, download=("dl" in q))

        m = re.match(r"^/media/([^/]+)/([a-z]+)/(.+)$", p)
        if m:
            cid, kind, name = m.group(1), m.group(2), unquote(m.group(3))
            base = serie_path(cid)
            if not base:
                return self.send_err("Série introuvable", 404)
            if kind == "output":
                # Les sorties vivent hors du dossier de serie
                # (output/<Serie>/): on valide contre CE dossier.
                od = Path(remixer.output_dir(base, load_serie(cid)))
                target = od / safe_filename(name)
                if not within(od, target):
                    return self.send_err("Chemin refusé", 403)
                return self.send_file(target, download=("dl" in q))
            elif kind == "thumb":
                target = base / "thumbs" / safe_filename(name)
                # Les clips lus dans un dossier lié n'ont pas de vignette
                # pré-générée: on la fabrique a la demande, une seule fois.
                if not target.exists():
                    src = find_source_clip(cid, safe_filename(name)[:-4])
                    if src:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        remixer.make_thumbnail(src, str(target))
            elif kind == "music":
                target = base / "music" / safe_filename(name)
            elif kind == "clip":
                sid = (q.get("slot") or [""])[0]
                if not SAFE_ID.match(sid or ""):
                    return self.send_err("Catégorie invalide", 400)
                cc = load_serie(cid) or {"slots": []}
                slot = next((s for s in cc["slots"] if s["id"] == sid), None)
                if slot and slot.get("path"):
                    # Dossier lié: on ne sert que les fichiers reellement
                    # listes par le moteur, pas un chemin construit a la main.
                    target = Path(slot["path"]) / safe_filename(name)
                    if str(target) not in remixer.slot_clips_all(base, slot):
                        return self.send_err("Fichier introuvable", 404)
                    return self.send_file(target, download=("dl" in q))
                target = base / "slots" / sid / safe_filename(name)
            else:
                return self.send_err("Type inconnu", 400)
            if not within(base, target):
                return self.send_err("Chemin refusé", 403)
            return self.send_file(target, download=("dl" in q))

        return self.send_err("Not found", 404)

    def do_POST(self):
        self._corps_lu = False
        try:
            self._post()
        finally:
            self.vider_corps()

    def _post(self):
        u = urlparse(self.path)
        p = u.path
        # Une seule garde pour TOUTES les routes de l'atelier, plutot
        # qu'une par route: sans `template.py`, elles n'existent pas.
        if tpl is None and (p.startswith("/api/templates")
                            or p.startswith("/media/tplapercu")
                            or p.startswith("/media/template")):
            return self.send_err("Les templates ne sont pas dans cette version", 404)
        if p == "/api/campaigns":
            try:
                cid = plateau.create_campaign(self.body_json())
            except plateau.PlateauError as e:
                return self.send_err(str(e))
            return self.send_json({"id": cid}, 201)

        # ---- L'IA ----
        if p == "/api/ia/exemple":
            qs = parse_qs(u.query)
            nom = safe_filename((qs.get("name") or [""])[0]) or "exemple.mp4"
            if Path(nom).suffix.lower() not in remixer.VIDEO_EXTS:
                return self.send_err("Ce n'est pas une vidéo", 415)
            EXEMPLES_DIR.mkdir(exist_ok=True)
            dest = EXEMPLES_DIR / f"{uuid.uuid4().hex[:8]}-{nom}"
            err = self.recevoir(dest)
            if err:
                return self.send_err(err, 500)
            if ia.duree(dest) <= 0:
                dest.unlink(missing_ok=True)
                return self.send_err(f"« {nom} » n'est pas une vidéo lisible", 415)
            return self.send_json({"fichier": dest.name})

        # Le CONTRAT, a cote du brief: le fichier reste (il sera attache
        # a la campagne), son texte part a Claude avec le brief.
        if p == "/api/ia/contrat":
            qs = parse_qs(u.query)
            nom = safe_filename((qs.get("name") or [""])[0]) or "contrat.pdf"
            if Path(nom).suffix.lower() not in brief.CONTRAT_EXTS:
                return self.send_err("Dépose un PDF ou un document Word", 415)
            CONTRATS_DIR.mkdir(exist_ok=True)
            dest = CONTRATS_DIR / f"{uuid.uuid4().hex[:8]}-{nom}"
            err = self.recevoir(dest)
            if err:
                return self.send_err(err, 500)
            try:
                txt = brief.lire_contrat(dest)
            except brief.BriefError as e:
                dest.unlink(missing_ok=True)
                return self.send_err(str(e), 415)
            if not txt:
                dest.unlink(missing_ok=True)
                return self.send_err(f"Aucun texte dans « {nom} » (un scan ?) — colle-le dans le brief", 415)
            return self.send_json({"fichier": dest.name, "mots": len(txt.split())})

        if p == "/api/ia/exemple/lien":
            url = str(self.body_json().get("url") or "").strip()
            if not re.match(r"^https?://[^\s/]+\.[^\s]+$", url):
                return self.send_err("Colle un lien Instagram, TikTok ou YouTube", 400)
            if re.match(r"^https?://(localhost|127\.|0\.|10\.|192\.168\.|\[)", url, re.I):
                return self.send_err("Lien refusé", 400)
            if not ytdlp():
                return self.send_err("Pour coller un lien, installe yt-dlp : ouvre le Terminal "
                                     "et tape « brew install yt-dlp ». Sinon, dépose la vidéo.", 503)
            return self.send_json({"job": ia_lancer(
                lambda progres: {"fichier": telecharger_exemple(url, progres)})}, 202)

        if p == "/api/ia/proposer":
            d = self.body_json()
            ok, raison = ia.disponible()
            if not ok:
                return self.send_err(raison, 503)
            # La video exemple est FACULTATIVE: on monte souvent la campagne
            # sur le brief, et l'exemple arrive apres (« Ajouter la vidéo
            # exemple » sur la serie, `/api/series/<id>/exemple`).
            f = EXEMPLES_DIR / safe_filename(d.get("fichier") or "") if d.get("fichier") else None
            if f is not None and not f.is_file():
                return self.send_err("Vidéo exemple introuvable — redépose-la", 400)
            texte, url = str(d.get("brief") or ""), str(d.get("brief_url") or "").strip()
            ct = CONTRATS_DIR / safe_filename(d.get("contrat") or "") if d.get("contrat") else None
            if ct is not None and not ct.is_file():
                return self.send_err("Contrat introuvable — redépose-le", 400)
            if not f and not ct and not texte.strip() and not url:
                return self.send_err("Colle le brief ou dépose la vidéo exemple", 400)

            def travail(progres):
                t = texte
                if not t.strip() and url:
                    progres("Lecture du brief Notion…")
                    t = brief_en_texte(brief.construire(url=url))
                if ct:
                    progres("Lecture du contrat…")
                    t = (t or "(aucun brief)") + "\n\nCONTRAT:\n" + brief.lire_contrat(ct)[:60000]
                return ia.proposer_campagne(t, str(f) if f else None, progres)
            return self.send_json({"job": ia_lancer(travail)}, 202)

        if p == "/api/ia/creer":
            d = self.body_json()
            try:
                r = ia_creer(d.get("proposition") or {}, d.get("fichier") or "",
                             str(d.get("brief") or ""), str(d.get("brief_url") or ""),
                             str(d.get("exemple_url") or ""),
                             safe_filename(d.get("contrat") or ""))
            except (plateau.PlateauError, OSError, ValueError) as e:
                return self.send_err(str(e), 400)
            return self.send_json(r, 201)

        if p == "/api/ia/parler":
            d = self.body_json()
            demande = str(d.get("question") or "").strip()[:3000]
            if not demande:
                return self.send_err("Dis-moi quoi faire", 400)
            ok, raison = ia.disponible()
            if not ok:
                return self.send_err(raison, 503)
            hist = [(str(x.get("qui") or ""), str(x.get("texte") or "")[:1500])
                    for x in (d.get("historique") or [])[-10:] if isinstance(x, dict)]
            cid, sid = d.get("campaign_id"), d.get("serie_id")
            c = load_serie(sid) if sid else None
            try:
                r = ia.parler(demande, ia_contexte_detail(cid, sid), hist,
                              ia_images_video(c, demande))
            except ia.IAError as e:
                return self.send_err(str(e), 502)
            ch = ia_traduire(r.get("actions"), cid, sid)
            return self.send_json({"reponse": r.get("reponse") or "", "changements": ch})

        if p == "/api/ia/photo":
            d = self.body_json()
            return self.send_json({"photo": ia_photo(
                [str(x) for x in (d.get("series") or [])][:20],
                [str(x) for x in (d.get("campagnes") or [])][:20])})

        if p == "/api/ia/annuler":
            if not ia_annuler(str(self.body_json().get("photo") or "")):
                return self.send_err("Plus rien à annuler", 404)
            return self.send_json({"ok": True})

        if p == "/api/ia/question":
            d = self.body_json()
            question = str(d.get("question") or "").strip()[:2000]
            if not question:
                return self.send_err("Pose une question", 400)
            ok, raison = ia.disponible()
            if not ok:
                return self.send_err(raison, 503)
            hist = [(str(x.get("qui") or ""), str(x.get("texte") or "")[:1500])
                    for x in (d.get("historique") or [])[-8:] if isinstance(x, dict)]
            try:
                r = ia.repondre(question, ia_contexte(d.get("campaign_id"), d.get("serie_id")), hist)
            except ia.IAError as e:
                return self.send_err(str(e), 502)
            return self.send_json({"reponse": r})

        m = re.match(r"^/api/series/([^/]+)/vrac$", p)
        if m:
            cid = m.group(1)
            if not serie_path(cid):
                return self.send_err("Série introuvable", 404)
            nom = safe_filename((parse_qs(u.query).get("name") or [""])[0])
            if Path(nom).suffix.lower() not in remixer.VIDEO_EXTS:
                return self.send_err(f"Format vidéo non supporté : {Path(nom).suffix or '?'}", 415)
            vd = vrac_dir(cid)
            vd.mkdir(parents=True, exist_ok=True)
            dest, i = vd / nom, 1
            while dest.exists():
                dest = vd / f"{Path(nom).stem}-{i}{Path(nom).suffix}"
                i += 1
            err = self.recevoir(dest)
            if err:
                return self.send_err(err, 500)
            if ia.duree(dest) <= 0:
                dest.unlink(missing_ok=True)
                return self.send_err(f"« {nom} » n'est pas une vidéo lisible", 415)
            return self.send_json({"ok": True, "name": dest.name})

        # Un clip reste du vrac: le ranger a la main, ou le retirer. Le
        # retirer efface la COPIE envoyee au plateau — l'original est
        # toujours sur le telephone ou le disque d'ou il vient.
        m = re.match(r"^/api/series/([^/]+)/vrac/(ranger|retirer)$", p)
        if m:
            cid = m.group(1)
            d = self.body_json()
            f = vrac_dir(cid) / safe_filename(d.get("clip") or "")
            if not d.get("clip") or not f.is_file() or not within(vrac_dir(cid), f):
                return self.send_err("Clip introuvable", 404)
            if m.group(2) == "retirer":
                f.unlink()
                return self.send_json({"ok": True})
            c = load_serie(cid)
            slot = next((x for x in (c or {}).get("slots", []) if x["id"] == d.get("slot")), None)
            if not slot or slot.get("split_role") == "etape":
                return self.send_err("Catégorie introuvable", 404)
            return self.send_json({"ok": True, "name": ranger_clip(cid, slot, f).name})

        # La video exemple arrive APRES la campagne: Claude la lit avec le
        # brief de la campagne et propose les categories, qu'on relit avant
        # `ia_refaire`. Meme analyse que la creation, rien de plus.
        m = re.match(r"^/api/series/([^/]+)/exemple(/appliquer)?$", p)
        if m:
            cid = m.group(1)
            c = load_serie(cid)
            if not c:
                return self.send_err("Série introuvable", 404)
            d = self.body_json()
            if d.get("refaire") and not m.group(2):
                # « Réanalyser »: la video deja attachee repart dans
                # exemples/ comme un nouveau depot — `ia_attacher_exemple`
                # vide le dossier de la serie avant de recopier.
                vieux = next(iter(sorted(exemple_dir(cid).glob("exemple.*"))), None) \
                    if exemple_dir(cid).is_dir() else None
                if not vieux:
                    return self.send_err("Cette série n'a pas de vidéo exemple", 400)
                EXEMPLES_DIR.mkdir(exist_ok=True)
                nom = f"{uuid.uuid4().hex[:8]}-reanalyse{vieux.suffix.lower()}"
                shutil.copy2(str(vieux), str(EXEMPLES_DIR / nom))
                d["fichier"] = nom
            f = EXEMPLES_DIR / safe_filename(d.get("fichier") or "")
            if not d.get("fichier") or not f.is_file():
                return self.send_err("Dépose d'abord la vidéo exemple", 400)
            if m.group(2):
                try:
                    return self.send_json(ia_refaire(
                        cid, d.get("proposition") or {}, d["fichier"],
                        d.get("exemple_url") if "exemple_url" in d else None))
                except (OSError, ValueError) as e:
                    return self.send_err(str(e), 400)
            ok, raison = ia.disponible()
            if not ok:
                return self.send_err(raison, 503)
            camp = (plateau.campaign(int(c["campaign_id"]))
                    if str(c.get("campaign_id") or "").isdigit() else None) or {}
            try:
                b = json.loads(camp.get("brief_json") or "{}")
            except ValueError:
                b = {}
            t = brief_en_texte(b) or ""
            if camp.get("notes"):
                t += "\n\nRègles notées sur la campagne :\n" + camp["notes"]
            if not t.strip():
                t = f"(pas de brief) Série « {c['name']} »"
            return self.send_json({"job": ia_lancer(
                lambda progres: ia.proposer_campagne(t, str(f), progres)),
                "fichier": f.name}, 202)

        m = re.match(r"^/api/series/([^/]+)/trier$", p)
        if m:
            cid = m.group(1)
            if not serie_path(cid):
                return self.send_err("Série introuvable", 404)
            return self.send_json({"job": ia_lancer(lambda pr: ia_trier(cid, pr))}, 202)

        if p == "/api/videos":
            try:
                vid = plateau.create_video(self.body_json())
            except plateau.PlateauError as e:
                return self.send_err(str(e))
            return self.send_json({"id": vid}, 201)

        if p == "/api/tasks":
            d = self.body_json()
            try:
                tid = plateau.create_task(d.get("text"), d.get("recurrent"))
            except plateau.PlateauError as e:
                return self.send_err(str(e))
            return self.send_json({"id": tid}, 201)

        if p == "/api/ideas":
            d = self.body_json()
            try:
                iid = plateau.create_idea(d.get("text"), d.get("section"))
            except plateau.PlateauError as e:
                return self.send_err(str(e))
            return self.send_json({"id": iid}, 201)

        # Deposer le reel de reference. Corps brut, comme l'envoi d'un
        # clip dans une serie (`/api/series/<id>/upload`).
        if p == "/api/templates/deposer":
            # `_post` ne garde que le chemin: la query se relit ici.
            qs = parse_qs(u.query)
            nom = safe_filename((qs.get("name") or [""])[0])
            nom = nom or f"reel-{uuid.uuid4().hex[:6]}.mp4"
            tpl.SOURCES.mkdir(parents=True, exist_ok=True)
            dest = tpl.SOURCES / nom
            tige, i = Path(nom).stem, 1
            while dest.exists():
                dest = tpl.SOURCES / f"{tige}-{i}{Path(nom).suffix}"
                i += 1
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0:
                return self.send_err("Fichier vide", 400)
            part = dest.with_suffix(dest.suffix + ".part")
            try:
                with open(part, "wb") as f:
                    reste = n
                    while reste > 0:
                        self._corps_lu = True
                        bloc = self.rfile.read(min(1024 * 1024, reste))
                        if not bloc:
                            raise IOError("transfert interrompu")
                        f.write(bloc)
                        reste -= len(bloc)
                os.replace(str(part), str(dest))
            except Exception as e:                              # noqa: BLE001
                part.unlink(missing_ok=True)
                return self.send_err(f"Dépôt échoué : {e}", 500)
            if tpl.duree(dest) <= 0:
                dest.unlink(missing_ok=True)
                return self.send_err(f"« {nom} » n'est pas une vidéo lisible", 415)
            return self.send_json({"fichier": dest.name})

        # Analyser rend un BROUILLON: rien n'est range tant qu'on n'a pas
        # nomme le template. On corrige d'abord, on enregistre ensuite.
        if p == "/api/templates/analyser":
            d = self.body_json()
            f = tpl.SOURCES / safe_filename(d.get("fichier") or "")
            if not f.exists():
                return self.send_err("Fichier introuvable", 404)
            try:
                return self.send_json(tpl.analyser(str(f), fine=bool(d.get("fine"))))
            except Exception as e:                              # noqa: BLE001
                return self.send_err(f"Analyse : {e}", 500)

        if p == "/api/templates":
            d = self.body_json()
            t = d.get("template") or {}
            if not t.get("plans"):
                return self.send_err("Template vide", 400)
            src = tpl.SOURCES / safe_filename(d.get("fichier") or "")
            tid = tpl.ranger(t, nom=(d.get("nom") or "").strip() or None,
                             source=str(src) if src.exists() else None,
                             garder_musique=bool(d.get("musique", True)))
            # Les plans coches « garder » sont decoupes maintenant: le
            # template devient autonome et survit a la disparition du reel.
            soucis = (tpl.majuscules_origine(tid, str(src) if src.exists() else None)
                      if any(p.get("garder") for p in (t.get("plans") or [])) else [])
            r = tpl.charger(tid)
            r["soucis"] = soucis
            return self.send_json(r)

        # Un clip pour un plan. Corps brut, comme le reel de reference.
        # Le navigateur ne donne JAMAIS le chemin d'un fichier choisi — il
        # ne donne que son contenu. On le recopie donc dans le template,
        # ce qui a un avantage: le montage reste rejouable meme si la
        # video d'origine quitte la photothèque.
        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)/clip$", p)
        if m:
            tid = m.group(1)
            if not tpl.charger(tid):
                return self.send_err("Template introuvable", 404)
            qs = parse_qs(u.query)
            nom = safe_filename((qs.get("name") or [""])[0]) or f"{uuid.uuid4().hex[:8]}.mp4"
            d = tpl.chemin_template(tid) / "clips"
            d.mkdir(parents=True, exist_ok=True)
            dest = d / nom
            tige, i = Path(nom).stem, 1
            while dest.exists():
                dest = d / f"{tige}-{i}{Path(nom).suffix}"
                i += 1
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0:
                return self.send_err("Fichier vide", 400)
            part = dest.with_suffix(dest.suffix + ".part")
            try:
                with open(part, "wb") as f:
                    reste = n
                    while reste > 0:
                        self._corps_lu = True
                        bloc = self.rfile.read(min(1024 * 1024, reste))
                        if not bloc:
                            raise IOError("transfert interrompu")
                        f.write(bloc)
                        reste -= len(bloc)
                os.replace(str(part), str(dest))
            except Exception as e:                              # noqa: BLE001
                part.unlink(missing_ok=True)
                return self.send_err(f"Envoi échoué : {e}", 500)
            # UNE IMAGE TIENT LA PLACE D'UN PLAN. On la fige tout de
            # suite a la duree exacte de ce plan: l'aval ne voit alors
            # qu'un clip ordinaire, et surtout elle ne peut plus etre
            # « trop courte ».
            t = tpl.charger(tid)
            if tpl.est_image(dest):
                try:
                    i = int((qs.get("plan") or ["0"])[0])
                except (TypeError, ValueError):
                    i = 0
                plans_ = t.get("plans") or []
                if not (0 <= i < len(plans_)):
                    dest.unlink(missing_ok=True)
                    return self.send_err("Plan inconnu", 400)
                # Le nom de la video figee se derive du nom SANS son
                # extension: « photo.jpg » et « photo.heic » donnaient
                # tous deux « photo-fige.mp4 », et le second ecrasait le
                # clip du premier plan en silence.
                fige = dest.with_name(Path(dest).stem + "-fige.mp4")
                k = 1
                while fige.exists():
                    fige = dest.with_name(f"{Path(dest).stem}-fige-{k}.mp4")
                    k += 1
                # On GARDE l'original a cote de la version figee. Il etait
                # efface, et le jour ou la facon de poser l'image a change
                # (rognee -> entiere sur fond noir), les photos deja
                # envoyees n'ont pas pu etre refaites: il a fallu les
                # redeposer une a une. Une photo pese quelques megaoctets,
                # la garder coute moins cher que la redemander.
                souci = tpl.image_en_video(dest, fige, plans_[i]["duree"],
                                           t.get("w") or 1080,
                                           t.get("h") or 1920,
                                           t.get("fps") or 30)
                if souci:
                    dest.unlink(missing_ok=True)
                    return self.send_err(souci, 415)
                return self.send_json({"chemin": str(fige), "nom": dest.name,
                                       "duree": round(tpl.duree(fige), 3),
                                       "image": True})
            d_sec = tpl.duree(dest)
            if d_sec <= 0:
                dest.unlink(missing_ok=True)
                return self.send_err(
                    f"« {nom} » n'est ni une vidéo ni une image lisible", 415)
            return self.send_json({"chemin": str(dest), "nom": dest.name,
                                   "duree": round(d_sec, 3)})

        # Ouvrir le dossier des montages dans le Finder. Il est cree au
        # passage: un dossier qui n'a jamais servi n'existe pas encore, et
        # le Finder repondrait « introuvable » sur un template tout neuf.
        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)/dossier$", p)
        if m:
            tid = m.group(1)
            if not tpl.charger(tid):
                return self.send_err("Template introuvable", 404)
            d = tpl.dossier_rendus(tid, creer=True)
            err = portable.reveler(d)
            if err:
                return self.send_err(err, 500)
            return self.send_json({"dossier": d})

        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)/apercu$", p)
        if m:
            d = self.body_json()
            try:
                i = int(d.get("plan") or 0)
            except (TypeError, ValueError):
                return self.send_err("Plan invalide", 400)
            try:
                r = tpl.apercu_texte(m.group(1), i,
                                     taille=d.get("taille"), larg=d.get("larg"),
                                     lead=d.get("lead"), texte=d.get("texte"))
            except Exception as e:                              # noqa: BLE001
                return self.send_err(f"Aperçu : {e}", 500)
            if not r:
                return self.send_err("Rien à dessiner", 400)
            nom, hpx, w, h = r
            # `v` casse le cache du navigateur: le fichier garde le meme
            # nom d'un reglage a l'autre, sinon on reverrait l'ancien.
            return self.send_json({"png": f"/media/tplapercu/{m.group(1)}/{nom}"
                                          f"?v={int(time.time() * 1000)}",
                                   "h": hpx, "w": w, "video_h": h})

        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)/remesurer$", p)
        if m:
            try:
                faits, souci = tpl.remesurer(m.group(1))
            except Exception as e:                              # noqa: BLE001
                return self.send_err(f"Mesure : {e}", 500)
            if souci:
                return self.send_err(souci, 400)
            return self.send_json({"ok": True, "plans": faits,
                                   "template": tpl.charger(m.group(1))})

        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)/monter$", p)
        if m:
            tid = m.group(1)
            t = tpl.charger(tid)
            if not t:
                return self.send_err("Template introuvable", 404)
            clips = [str(x) for x in (self.body_json().get("clips") or [])]
            soucis = tpl.controler(t, clips)
            manquant = [x for x in soucis if x["souci"] == "aucun clip"]
            if manquant:
                return self.send_err(
                    f"Il manque un clip pour le plan {manquant[0]['plan']}", 400)
            try:
                fichier = tpl.monter(tid, clips)
            except Exception as e:                              # noqa: BLE001
                return self.send_err(f"Montage : {e}", 500)
            return self.send_json({"fichier": os.path.basename(fichier),
                                   "avertissements": soucis})

        # Une campagne a monter: un nom suffit, le reste se remplit dans
        # la fiche et dans l'arbre des comptes.
        if p == "/api/onboarding":
            d = self.body_json()
            nom = (d.get("name") or "").strip()
            if not nom:
                return self.send_err("Donne un nom à la campagne", 400)
            try:
                cid = plateau.create_campaign({"name": nom, "stage": "onbo",
                                               "convo_url": (d.get("convo_url") or "").strip(),
                                               "convo_ou": (d.get("convo_ou") or "").strip()})
            except plateau.PlateauError as e:
                return self.send_err(str(e), 400)
            return self.send_json(plateau.campaign(cid))

        # « Envoyer vers la vue d'ensemble »: on vide l'etape, rien n'est
        # recopie. Le brief, les identifiants et les pseudos etaient deja
        # sur cette campagne — c'est tout l'interet de l'etape.
        m = re.match(r"^/api/campaigns/(\d+)/lancer$", p)
        if m:
            cid = int(m.group(1))
            c = plateau.campaign(cid)
            if not c:
                return self.send_err("Campagne introuvable", 404)
            plateau.update_campaign(cid, {"stage": ""})
            return self.send_json(plateau.campaign(cid))

        m = re.match(r"^/api/campaigns/(\d+)/posted$", p)
        if m:
            cid = int(m.group(1))
            if not plateau.campaign(cid):
                return self.send_err("Campagne introuvable", 404)
            delta = self.body_json().get("delta")
            try:
                delta = int(delta)
            except (TypeError, ValueError):
                return self.send_err("delta doit être +1 ou -1", 400)
            n = plateau.bump_posted(cid, 1 if delta > 0 else -1)
            return self.send_json({"posted_today": n})

        # Lire (ou relire) le brief. Deux entrees, une seule sortie:
        # un lien Notion, ou du texte colle quand il n'y a pas de jeton
        # — ou quand le brief n'est pas dans Notion du tout.
        m = re.match(r"^/api/campaigns/(\d+)/brief$", p)
        if m:
            cid = int(m.group(1))
            c = plateau.campaign(cid)
            if not c:
                return self.send_err("Campagne introuvable", 404)
            d = self.body_json()
            url = (d.get("url") or "").strip()
            texte = d.get("texte") or ""
            # « Relire » sans rien passer: on reprend le lien deja range.
            if not url and not texte.strip():
                url = c.get("brief_url") or ""
            try:
                b = brief.construire(url=url, texte=texte)
            except brief.BriefError as e:
                return self.send_err(str(e), 400)
            except Exception as e:                          # noqa: BLE001
                return self.send_err(f"Brief : {e}", 500)
            plateau.update_campaign(cid, {
                "brief_url": b.get("url") or (c.get("brief_url") or ""),
                "brief_json": json.dumps(b, ensure_ascii=False),
                "brief_at": str(b.get("at") or "")})
            return self.send_json(brief_lu(plateau.campaign(cid)))

        m = re.match(r"^/api/campaigns/(\d+)/avatar/([a-z_]+)$", p)
        if m:
            cid, field = int(m.group(1)), m.group(2)
            if field not in plateau.AVATAR_COLS:
                return self.send_err(f"Champ inconnu : {field}", 400)
            c = plateau.campaign(cid)
            if not c:
                return self.send_err("Campagne introuvable", 404)

            ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip()
            if ctype == "application/json":
                # Glisser une image depuis une page web ne donne pas de
                # fichier, juste une adresse: le serveur va la chercher.
                data, suffix, err = fetch_image(self.body_json().get("url"))
                if err:
                    return self.send_err(err, 400)
            else:
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    n = 0
                if n <= 0:
                    return self.send_err("Fichier vide.", 400)
                if n > AVATAR_MAX_BYTES:
                    return self.send_err("Image trop lourde (plus de 25 Mo).", 400)
                self._corps_lu = True
                data = self.rfile.read(n)
                suffix = {"image/png": ".png", "image/jpeg": ".jpg",
                          "image/webp": ".webp", "image/gif": ".gif",
                          "image/heic": ".heic", "image/heif": ".heic",
                          "image/tiff": ".tif", "image/bmp": ".bmp"}.get(ctype, ".bin")

            # Tout est converti en PNG redimensionne, quel que soit le
            # format d'entree: c'est ce qui fait marcher les HEIC de
            # l'iPhone, que les navigateurs ne savent pas afficher.
            name, err = save_avatar(data, suffix)
            if err:
                return self.send_err(err, 400)

            old_name = c.get(field) or ""
            plateau.update_campaign(cid, {field: name})
            if old_name and old_name != name:
                try:
                    (AVATARS_DIR / safe_filename(old_name)).unlink()
                except OSError:
                    pass
            return self.send_json({"ok": True, "file": name})

        if p == "/api/open":
            data = self.body_json()
            target = openable(data.get("file"))
            if not target:
                return self.send_err(
                    "Fichier introuvable, ou hors de ton dossier personnel : "
                    f"{data.get('file')}", 404)
            err = (portable.reveler(target) if data.get("reveal")
                   else portable.ouvrir(target))
            if err:
                return self.send_err(err, 500)
            return self.send_json({"ok": True})

        if p == "/api/queue":
            data = self.body_json()
            n = queue_add(data.get("items") or [])
            snap = queue_snapshot()
            snap["added"] = n
            return self.send_json(snap)

        if p == "/api/queue/stop":
            queue_stop()
            return self.send_json(queue_snapshot())

        if p == "/api/queue/clear":
            queue_clear()
            return self.send_json(queue_snapshot())

        if p == "/api/prospects/scruter":
            _REDDIT["t"] = 0.0            # forcer le passage, sans attendre l'heure
            return self.send_json({"nouveaux": tour_reddit(),
                                   "erreur": _REDDIT["erreur"]})

        if p == "/api/classement/publier":
            try:
                n = publier_classement()
            except classement.ClassementError as e:
                return self.send_err(str(e), 400)
            return self.send_json({"lignes": n})

        if p == "/api/publish/test":
            cfg = publisher.load_config()
            which = (self.body_json().get("what") or "both")
            res = {}
            if which in ("buffer", "both"):
                try:
                    org = publisher.buffer_organization_id(cfg.get("buffer_api_key"))
                    chans = publisher.buffer_channels(cfg.get("buffer_api_key"), org)
                    res["buffer"] = {"ok": True, "organization": org,
                                     "instagram_channels": len(chans)}
                except publisher.PublishError as e:
                    res["buffer"] = {"ok": False, "error": str(e)}
            if which in ("r2", "both"):
                try:
                    publisher.r2_check(cfg)
                    res["r2"] = {"ok": True}
                except publisher.PublishError as e:
                    res["r2"] = {"ok": False, "error": str(e)}
            return self.send_json(res)

        if p == "/api/publish":
            data = self.body_json()
            cid = data.get("cid") or ""
            name = data.get("name") or ""
            try:
                rec = publier(cid, name, channel_id=data.get("channel_id"),
                              caption=data.get("caption"),
                              mode=data.get("mode") or "addToQueue",
                              due_at=data.get("due_at"))
            except publisher.PublishError as e:
                return self.send_err(str(e), 400)
            return self.send_json(rec)

        if p == "/api/outputs/sync":
            return self.send_json({"count": sync_all_outputs(),
                                   "dir": str(all_outputs_dir())})

        if p == "/api/outputs/reveal":
            portable.ouvrir(all_outputs_dir())
            return self.send_json({"ok": True})

        if p == "/api/acces":
            if INSTALLEE:
                return self.send_err("Not found", 404)
            d = self.body_json()
            action = d.get("action")
            if action not in ("creer", "retirer", "reactiver", "liberer", "supprimer"):
                return self.send_err("Action inconnue", 400)
            try:
                r = acces_appel(action, nom=d.get("nom", ""), code=d.get("code", ""))
            except ValueError as e:
                return self.send_err(str(e), 502)
            if r.get("erreur"):
                return self.send_err(r["erreur"], 400)
            return self.send_json(r)

        # --- L'app installee ------------------------------------------
        if p == "/api/app/maj":
            try:
                app_lancer("maj", lambda dit: maj.preparer(dit))
            except ValueError as e:
                return self.send_err(str(e), 409)
            return self.send_json({"ok": True})

        if p == "/api/app/modele":
            if transcription.modele():
                return self.send_json({"ok": True, "deja": True})
            try:
                app_lancer("modele", lambda dit: transcription.telecharger_modele(
                    lambda f: dit(f"{int(f * 100)} %")))
            except ValueError as e:
                return self.send_err(str(e), 409)
            return self.send_json({"ok": True})

        if p in ("/api/app/redemarrer", "/api/app/quitter"):
            # Seulement l'app installee : son lanceur relance (code 3) ou
            # s'arrete (code 0). La copie de travail se lance a la main,
            # personne ne la relancerait.
            if not INSTALLEE:
                return self.send_err("Seulement dans l'app installée", 400)
            code = 3 if p.endswith("redemarrer") else 0
            threading.Timer(0.4, lambda: os._exit(code)).start()
            return self.send_json({"ok": True})

        if p == "/api/app/claude":
            quoi = (self.body_json().get("quoi") or "")
            if quoi == "connecter":
                # L'installateur OFFICIEL de Claude Code, puis la connexion
                # au compte (le navigateur s'ouvre, la personne se connecte).
                # Deja installe: lancer `claude` suffit, il demande la
                # connexion au premier lancement.
                b = ia.binaire()
                terminal(_sh(b) if b else INSTALLER_CLAUDE)
            elif quoi == "modifier":
                b = ia.binaire()
                if not b:
                    return self.send_err("Connecte Claude d'abord", 400)
                # Claude Code s'ouvre DANS le dossier du code : il y lit
                # CLAUDE.md, qui lui explique l'app.
                terminal(f"{ALLER}{_sh(CODE)} && {_sh(b)}")
            else:
                return self.send_err("Action inconnue", 400)
            return self.send_json({"ok": True})

        if p == "/api/series":
            data = self.body_json()
            name = (data.get("name") or "").strip() or "Nouvelle série"
            slots = data.get("slots") or ["Accroche", "Corps", "Fin"]
            # Campagne de rattachement. Sans elle la serie serait orpheline
            # et n'apparaitrait nulle part sous son deal.
            camp = str(data.get("campaign_id") or "").strip()
            camp = int(camp) if camp.isdigit() and plateau.campaign(int(camp)) else None
            cats = [str(s).strip()[:40] for s in slots if str(s).strip()] or ["Clips"]
            cid = f"{slugify(name)}-{uuid.uuid4().hex[:6]}"

            # Les dossiers sont crees sur le disque et lies tout de suite:
            # l'utilisateur n'a plus qu'a y glisser ses rushes.
            try:
                root, subs = make_serie_folders(name, cats)
            except OSError as e:
                return self.send_err(f"Impossible de créer les dossiers : {e}", 500)

            c = {"id": cid, "name": name[:80],
                 "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
                 "slots": [new_slot(n, p) for n, p in subs],
                 "source_dir": root,
                 "output_dir": make_output_folder(name),
                 "settings": dict(remixer.DEFAULT_SETTINGS,
                                  # Serie parlee: la voix est la bande-son,
                                  # la musique passe dessous a 10 %.
                                  **({"parle": 1, "music_volume_min": 0.1,
                                      "music_volume_max": 0.1}
                                     if data.get("parle") else {})),
                 "campaign_id": camp,
                 "captions": [], "descriptions": []}
            save_serie(c)
            return self.send_json(serie_detail(cid), 201)

        m = re.match(r"^/api/series/([^/]+)/editor/captions$", p)
        if m:
            d = self.body_json() or {}
            try:
                r = editeur_captions(m.group(1), d)
            except Exception as e:                              # noqa: BLE001
                return self.send_err(f"Captions : {e}", 500)
            return self.send_json(r) if r is not None else self.send_err("Série introuvable", 404)

        m = re.match(r"^/api/series/([^/]+)/editor/apercu$", p)
        if m:
            d = self.body_json()
            try:
                r = editeur_apercu(m.group(1), d or {})
            except Exception as e:                              # noqa: BLE001
                return self.send_err(f"Aperçu : {e}", 500)
            if not r:
                return self.send_err("Rien à dessiner", 400)
            nom, hpx = r
            # `v` casse le cache du navigateur: deux reglages differents
            # peuvent retomber sur le meme nom de fichier.
            return self.send_json({"png": f"/media/editeur/{m.group(1)}/{nom}"
                                          f"?v={int(time.time() * 1000)}",
                                   "h": hpx})

        m = re.match(r"^/api/series/([^/]+)/generate$", p)
        if m:
            cid = m.group(1)
            if not serie_path(cid):
                return self.send_err("Série introuvable", 404)
            ok, _, msg = remixer.tools_available()
            if not ok:
                return self.send_err(msg, 500)
            count = self.body_json().get("count", 1)
            try:
                count = max(1, min(int(count), 200))
            except (TypeError, ValueError):
                return self.send_err("Nombre invalide", 400)
            jid, err = start_job(cid, count)
            if not jid:
                return self.send_err(err, 409)
            return self.send_json({"job": jid}, 202)

        # Lie un dossier source: une categorie par sous-dossier.
        m = re.match(r"^/api/series/([^/]+)/link$", p)
        if m:
            cid = m.group(1)
            c = load_serie(cid)
            if not c:
                return self.send_err("Série introuvable", 404)
            data = self.body_json()
            root = real_dir(data.get("path"))
            if not root:
                return self.send_err(
                    f"Dossier introuvable ou illisible : {data.get('path')}", 400)

            subs = remixer.scan_subfolders(root)
            music_dir = None
            picked = []
            for s in subs:
                # Un sous-dossier qui ne contient que de l'audio devient la
                # source des musiques, pas une categorie de clips.
                if s["audio"] and not s["clips"]:
                    if music_dir is None:
                        music_dir = s["path"]
                    continue
                picked.append(s)

            if not picked:
                if remixer.list_media(root, remixer.VIDEO_EXTS):
                    picked = [{"name": Path(root).name, "path": root}]
                else:
                    return self.send_err(
                        "Ce dossier ne contient ni sous-dossier de clips ni vidéo. "
                        "Crée un sous-dossier par catégorie et mets tes clips dedans.", 400)

            # Un sous-dossier deja lie garde ses reglages (min/max, nom).
            by_path = {s.get("path"): s for s in c["slots"] if s.get("path")}
            slots = []
            for s in picked:
                old = by_path.get(s["path"])
                if old:
                    slots.append(old)
                else:
                    slots.append(new_slot(s["name"][:40], s["path"]))

            c["slots"] = slots
            c["source_dir"] = root
            if music_dir:
                c["music_dir"] = music_dir
            save_serie(c)
            return self.send_json(serie_detail(cid))

        # Ajoute une categorie ET cree son dossier si la serie est liee.
        m = re.match(r"^/api/series/([^/]+)/slots$", p)
        if m:
            cid = m.group(1)
            c = load_serie(cid)
            if not c:
                return self.send_err("Série introuvable", 404)
            name = (self.body_json().get("name") or "Nouvelle catégorie").strip()[:40]

            root = c.get("source_dir")
            if root and Path(root).is_dir():
                d = Path(root) / folder_name(name, len(c["slots"]) + 1)
                try:
                    d.mkdir(exist_ok=True)
                except OSError as e:
                    return self.send_err(f"Impossible de créer le dossier : {e}", 500)
                c["slots"].append(new_slot(d.name, str(d)))
            else:
                c["slots"].append(new_slot(name))
            save_serie(c)
            return self.send_json(serie_detail(cid))

        # Masque ou demasque un clip. Le fichier ne bouge pas: il sort du
        # tirage, c'est tout. C'est le seul moyen d'ecarter un clip d'un
        # dossier lie, ou l'app ne supprime ni ne deplace jamais rien — et
        # contrairement au X, ca se defait.
        m = re.match(r"^/api/series/([^/]+)/hide$", p)
        if m:
            cid = m.group(1)
            c = load_serie(cid)
            if not c:
                return self.send_err("Série introuvable", 404)
            b = self.body_json()
            sid = (b.get("slot") or "").strip()
            # On teste le nom BRUT: `safe_filename("")` invente un nom de
            # secours (« fichier-a1b2c3 »), donc il ne peut jamais servir a
            # distinguer « pas de clip fourni » de « clip fourni ».
            brut = str(b.get("name") or "").strip()
            name = safe_filename(brut) if brut else ""
            if not SAFE_ID.match(sid):
                return self.send_err("Catégorie invalide", 400)
            slot = next((s for s in c["slots"] if s["id"] == sid), None)
            if slot is None:
                return self.send_err("Catégorie introuvable", 400)

            # Sans nom de clip, c'est la CATEGORIE entiere qu'on met de
            # cote: elle ne sort plus au tirage, mais elle garde son nom,
            # ses reglages et ses clips. C'est ce que « Retirer » ne sait
            # pas faire — lui, il la supprime.
            if not name:
                if b.get("hidden"):
                    slot["off"] = 1
                else:
                    slot.pop("off", None)
                save_serie(c)
                return self.send_json(serie_detail(cid))
            # Le clip doit exister pour de vrai: sinon `hidden` se remplirait
            # de noms fantomes que plus rien ne viendrait purger.
            base = SERIES_DIR / cid
            if name not in {Path(x).name
                            for x in remixer.slot_clips_all(base, slot)}:
                return self.send_err("Clip introuvable", 404)
            hid = [h for h in (slot.get("hidden") or []) if h != name]
            if b.get("hidden"):
                hid.append(name)
            if hid:
                slot["hidden"] = sorted(hid)
            else:
                slot.pop("hidden", None)   # pas de cle vide dans serie.json
            save_serie(c)
            return self.send_json(serie_detail(cid))

        # Ouvre le dossier de la serie dans le Finder.
        m = re.match(r"^/api/series/([^/]+)/reveal$", p)
        if m:
            c = load_serie(m.group(1))
            if not c:
                return self.send_err("Série introuvable", 404)
            corps = self.body_json()
            which = (corps.get("what") or "source")
            if which == "images":
                target = str(images_dir(c.get("name"), corps.get("mot"), creer=True))
            else:
                target = (c.get("source_dir") if which == "source"
                          else str(remixer.output_dir(SERIES_DIR / c["id"], c)))
            if not target or not Path(target).is_dir():
                return self.send_err("Dossier introuvable", 404)
            err = portable.ouvrir(target)
            if err:
                return self.send_err(err, 500)
            return self.send_json({"ok": True, "path": target})

        m = re.match(r"^/api/series/([^/]+)/unlink$", p)
        if m:
            cid = m.group(1)
            c = load_serie(cid)
            if not c:
                return self.send_err("Série introuvable", 404)
            for s in c["slots"]:
                s.pop("path", None)
            c.pop("source_dir", None)
            c.pop("music_dir", None)
            save_serie(c)
            return self.send_json(serie_detail(cid))

        m = re.match(r"^/api/jobs/([a-f0-9]+)/stop$", p)
        if m:
            with JOBS_LOCK:
                j = JOBS.get(m.group(1))
                if not j:
                    return self.send_err("Job introuvable", 404)
                j["stop"] = True
                j["message"] = "Arrêt après la vidéo en cours…"
            return self.send_json({"ok": True})

        return self.send_err("Not found", 404)

    def do_PUT(self):
        self._corps_lu = False
        try:
            self._put()
        finally:
            self.vider_corps()

    def _put(self):
        u = urlparse(self.path)
        if urlparse(self.path).path == "/api/publish/config":
            data = self.body_json()
            cfg = publisher.load_config()
            if data.get("buffer_api_key"):
                cfg["buffer_api_key"] = str(data["buffer_api_key"]).strip()
            if isinstance(data.get("r2"), dict):
                r2 = cfg.get("r2") or {}
                for k in ("account_id", "bucket", "access_key_id",
                          "secret_access_key", "public_base_url"):
                    if data["r2"].get(k):
                        r2[k] = str(data["r2"][k]).strip()
                cfg["r2"] = r2
            for k in ("default_channel_id", "default_caption"):
                if k in data:
                    cfg[k] = str(data[k] or "")
            publisher.save_config(cfg)
            return self.send_json(publisher.status(cfg))

        p, q = u.path, parse_qs(u.query)
        # Meme garde que les autres verbes: sans `template.py`, ces
        # routes n'existent pas dans cette copie.
        if tpl is None and p.startswith("/api/templates"):
            return self.send_err("Les templates ne sont pas dans cette version", 404)

        m = re.match(r"^/api/prospects/(\d+)$", p)
        if m:
            data = self.body_json()
            try:
                plateau.juger_prospect(int(m.group(1)), data.get("statut") or "nouveau",
                                       data.get("message"))
            except plateau.PlateauError as e:
                return self.send_err(str(e), 400)
            return self.send_json({"ok": True})

        m = re.match(r"^/api/campaigns/(\d+)$", p)
        if m:
            camp = plateau.campaign(int(m.group(1)))
            if not camp:
                return self.send_err("Campagne introuvable", 404)
            data = self.body_json()
            # `paused` EST UN DRAPEAU, pas un nombre. Les colonnes de
            # campagne sont du TEXTE: un 0 envoye en JSON ressortait en
            # "0", et "0" est VRAI en Python — la campagne restait en
            # pause en croyant avoir ete relancee, sans la moindre erreur.
            # On ne touche pas a `_clean`: ailleurs, 0 est une valeur
            # legitime (un warmup de 0 h, un revenu a 0).
            if "paused" in data:
                data = dict(data)
                data["paused"] = "" if data["paused"] in (0, "0", "", False, None) else "1"
            try:
                plateau.update_campaign(int(m.group(1)), data)
            except plateau.PlateauError as e:
                return self.send_err(str(e))
            # Le dossier de musiques porte le nom de la campagne: il suit le
            # renommage, sinon les fichiers resteraient sous l'ancien nom et
            # la campagne se retrouverait muette sans explication.
            if "name" in data and str(data["name"] or "") != (camp.get("name") or ""):
                renommer_musiques(camp, str(data["name"] or ""))
            return self.send_json({"ok": True})

        # Musique du pot commun d'une campagne. Meme protocole que l'upload
        # d'une serie: le corps de la requete EST le fichier.
        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)$", p)
        if m:
            t = tpl.charger(m.group(1))
            if not t:
                return self.send_err("Template introuvable", 404)
            d = self.body_json()
            if "plans" in d:
                t["plans"] = d["plans"]
            if "nom" in d:
                t["nom"] = (d["nom"] or "").strip() or t.get("nom")
            tpl.ranger(t)
            soucis = tpl.majuscules_origine(m.group(1))
            r = tpl.charger(m.group(1))
            r["soucis"] = soucis
            r["rendus"] = tpl.rendus(m.group(1))
            return self.send_json(r)

        m = re.match(r"^/api/campaigns/(\d+)/music$", p)
        if m:
            cid = m.group(1)
            if not plateau.campaign(int(cid)):
                return self.send_err("Campagne introuvable", 404)
            dest_dir = musique_dir(cid, creer=True)
            name = safe_filename((q.get("name") or [""])[0])
            ext = Path(name).suffix.lower()
            if ext not in remixer.AUDIO_EXTS:
                return self.send_err(f"Format audio non supporté : {ext or '?'}", 415)

            dest = dest_dir / name
            if not within(dest_dir, dest):
                return self.send_err("Chemin refusé", 403)
            stem, i = Path(name).stem, 1
            while dest.exists():
                dest = dest_dir / f"{stem}-{i}{ext}"
                i += 1

            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = 0
            if n <= 0:
                return self.send_err("Fichier vide", 400)
            if n > MUSIQUE_MAX_BYTES:
                return self.send_err("Fichier trop lourd (plus de 200 Mo).", 413)

            tmp = dest.with_suffix(dest.suffix + ".part")
            try:
                with open(tmp, "wb") as f:
                    remaining = n
                    while remaining > 0:
                        self._corps_lu = True
                        chunk = self.rfile.read(min(1024 * 1024, remaining))
                        if not chunk:
                            raise IOError("transfert interrompu")
                        f.write(chunk)
                        remaining -= len(chunk)
                os.replace(str(tmp), str(dest))
            except Exception as e:                              # noqa: BLE001
                tmp.unlink(missing_ok=True)
                return self.send_err(f"Upload échoué : {e}", 500)

            # Une capture d'ecran .mp4 SANS piste audio passerait l'examen
            # de l'extension et ferait echouer tout le lot au montage:
            # `assemble` reference `[2:a]`, un flux qui n'existerait pas.
            # On le refuse ici, ou l'erreur est comprehensible.
            dur, a_du_son = remixer.probe(str(dest))
            if dur <= 0 or not a_du_son:
                dest.unlink(missing_ok=True)
                return self.send_err(
                    f"« {name} » n'a aucune piste audio lisible : "
                    "ce fichier ne peut pas servir de musique.", 415)
            return self.send_json({"ok": True, "name": dest.name})

        m = re.match(r"^/api/videos/(\d+)$", p)
        if m:
            try:
                plateau.update_video(int(m.group(1)), self.body_json())
            except plateau.PlateauError as e:
                return self.send_err(str(e))
            return self.send_json({"ok": True})

        m = re.match(r"^/api/tasks/(\d+)$", p)
        if m:
            d = self.body_json()
            try:
                plateau.update_task(int(m.group(1)), text=d.get("text"),
                                    done=d.get("done"), recurrent=d.get("recurrent"))
            except plateau.PlateauError as e:
                return self.send_err(str(e))
            return self.send_json({"ok": True})

        m = re.match(r"^/api/ideas/(\d+)$", p)
        if m:
            d = self.body_json()
            try:
                plateau.update_idea(int(m.group(1)), text=d.get("text"),
                                    section=d.get("section"))
            except plateau.PlateauError as e:
                return self.send_err(str(e))
            return self.send_json({"ok": True})

        m = re.match(r"^/api/series/([^/]+)$", p)
        if m:
            cid = m.group(1)
            c = load_serie(cid)
            if not c:
                return self.send_err("Série introuvable", 404)
            data = self.body_json()

            if "name" in data:
                c["name"] = (str(data["name"]).strip() or c["name"])[:80]
            if "campaign_id" in data:
                v = str(data["campaign_id"] or "").strip()
                if v and (not v.isdigit() or not plateau.campaign(int(v))):
                    return self.send_err("Campagne introuvable", 400)
                c["campaign_id"] = int(v) if v else None
            if "paused" in data:
                # Serie mise de cote: elle reste entiere, elle sort juste de
                # la file d'attente et passe en gris dans la barre laterale.
                c["paused"] = 1 if data["paused"] else 0
            if "buffer_comptes" in data:
                # Comptes Buffer choisis pour la serie. Liste vide = le
                # compte de sa campagne (voir comptes_serie).
                c["buffer_comptes"] = [str(x) for x in (data["buffer_comptes"] or [])
                                       if re.fullmatch(r"[A-Za-z0-9_-]{1,64}", str(x))][:10]
            if "images_regles" in data:
                # Chaque declencheur a son dossier, cree tout de suite: le
                # but est de pouvoir y glisser des images avant meme d'avoir
                # genere quoi que ce soit.
                regles = []
                for r in (data["images_regles"] or [])[:40]:
                    mot = str((r or {}).get("mot") or "").strip()[:60]
                    if not mot:
                        continue
                    fin = str((r or {}).get("fin") or "phrase")[:60]
                    if not (fin in ("phrase", "suivant") or fin.startswith("mot:")):
                        fin = "phrase"
                    regles.append({"mot": mot, "fin": fin,
                                   "dossier": str(images_dir(c.get("name"), mot, creer=True))})
                c["images_regles"] = regles
            if "auto_jour" in data:
                # Videos generees ET envoyees a Buffer chaque jour (boucle_auto).
                try:
                    n = max(0, min(int(data["auto_jour"] or 0), 50))
                except (TypeError, ValueError):
                    return self.send_err("Nombre invalide", 400)
                # D'ABORD solder un changement en attente dont le jour est
                # venu. La promotion ne vivait que dans la boucle de fond:
                # regler le chiffre deux jours de suite ECRASAIT celui de la
                # veille avant qu'il n'ait servi une seule journee. Constate:
                # 23 pose un soir, 26 le lendemain, et la serie tournait
                # toujours a 20.
                _, c = auto_jour_effectif(cid, c)
                # Journee deja lancee: le nouveau chiffre ne s'applique que
                # demain, sinon l'augmenter enverrait la difference tout de
                # suite par-dessus les posts du jour.
                if auto_envoyees_aujourdhui(cid, c):
                    c["auto_demain"] = {"n": n, "depuis": time.strftime("%Y-%m-%d")}
                else:
                    c["auto_jour"] = n
                    c.pop("auto_demain", None)
            if "archive" in data:
                if data["archive"]: c["archive"] = 1
                else: c.pop("archive", None)
            if "auto_palier" in data:
                # Monter de `pas` par jour jusqu'a `plafond` (`monter_palier`).
                # Le jour de depart est AUJOURD'HUI: le premier cran tombe
                # demain, le chiffre du jour ne bouge pas.
                pl = data["auto_palier"] or {}
                try:
                    pas = max(0, min(int(pl.get("pas") or 0), 50))
                    plaf = max(0, min(int(pl.get("plafond") or 0), 50))
                except (TypeError, ValueError):
                    return self.send_err("Nombre invalide", 400)
                if pas and plaf:
                    c.update(auto_pas=pas, auto_plafond=plaf,
                             auto_palier_jour=time.strftime("%Y-%m-%d"))
                else:
                    for k in ("auto_pas", "auto_plafond", "auto_palier_jour"):
                        c.pop(k, None)
            if "editor" in data:
                # L'EDITEUR. `actif` eteint, rien de tout ca n'est lu a la
                # generation et la serie se comporte comme avant: c'est ce
                # qui permet de le tester sans toucher au mode qui tourne.
                #
                # Un bloc s'accroche a une CATEGORIE et a un decalage, pas
                # a une seconde: la longueur d'une video change de 48 %
                # d'un tirage a l'autre (voir `remixer.editor_fenetre`).
                ed = data["editor"] or {}
                blocs = []
                for b in (ed.get("blocs") or [])[:60]:
                    txt = str((b or {}).get("texte") or "")[:200]
                    if not txt.strip():
                        continue
                    def _bord(k):
                        r = (b.get(k) or {})
                        try:
                            off = max(-60.0, min(float(r.get("off") or 0.0), 60.0))
                        except (TypeError, ValueError):
                            off = 0.0
                        return {"slot": str(r.get("slot") or "")[:64],
                                "off": round(off, 3)}
                    def _num(k, lo, hi, defaut=None):
                        if b.get(k) in (None, ""):
                            return defaut
                        try:
                            return round(max(lo, min(float(b[k]), hi)), 4)
                        except (TypeError, ValueError):
                            return defaut
                    blocs.append({
                        "id": str(b.get("id") or uuid.uuid4().hex[:8])[:32],
                        "texte": txt,
                        "debut": _bord("debut"), "fin": _bord("fin"),
                        "text_y": _num("text_y", 0.0, 1.0),
                        "text_x": _num("text_x", -0.5, 0.5),
                        "caption_size": _num("caption_size", 8, 300),
                        "caption_larg": _num("caption_larg", 0.1, 1.0),
                        "caption_lead": _num("caption_lead", 0, 400),
                        # Le style du texte, choisi PAR BLOC comme dans
                        # CapCut (contour, fond, sans contour). Absent, la
                        # serie decide (`caption_style`).
                        "style": (b.get("style") if b.get("style") in BLOC_STYLES
                                  else None)})
                # Les voix off: un fichier de `voix/`, une ancre, un volume.
                # La duree et l'onde sont gardees pour dessiner la piste
                # sans relire le fichier a chaque ouverture.
                audios = []
                for a in (ed.get("audios") or [])[:60]:
                    a = a or {}
                    fichier = safe_filename(str(a.get("fichier") or ""))
                    if not fichier or not (voix_dir(cid) / fichier).is_file():
                        continue
                    r = a.get("debut") or {}
                    try:
                        off = round(max(-60.0, min(float(r.get("off") or 0.0), 60.0)), 3)
                    except (TypeError, ValueError):
                        off = 0.0
                    ancre = {"slot": str(r.get("slot") or "")[:64], "off": off}
                    try:
                        vol = round(max(0.0, min(float(a.get("volume", 1.0)), 3.0)), 3)
                        dur = round(max(0.0, float(a.get("dur") or 0)), 3)
                    except (TypeError, ValueError):
                        vol, dur = 1.0, 0.0
                    pics = [int(max(0, min(int(x), 100))) for x in (a.get("pics") or [])[:400]
                            if isinstance(x, (int, float))]
                    v = {"id": str(a.get("id") or uuid.uuid4().hex[:8])[:32],
                         "fichier": fichier, "debut": ancre,
                         "volume": vol, "dur": dur, "pics": pics}
                    # Le morceau garde du fichier: rogner une voix off ne
                    # touche jamais au fichier lui-meme.
                    try:
                        e = max(0.0, float(a.get("entree") or 0.0))
                        so = float(a.get("sortie") or 0.0)
                    except (TypeError, ValueError):
                        e, so = 0.0, 0.0
                    if dur:
                        e, so = min(e, dur), min(so, dur)
                    if so and so <= e + 0.1:
                        e, so = 0.0, 0.0
                    if e > 0.001:
                        v["entree"] = round(e, 3)
                    if so and (not dur or so < dur - 0.01):
                        v["sortie"] = round(so, 3)
                    audios.append(v)
                cc = ed.get("captions") or {}
                def _cc(k, lo, hi):
                    try:
                        return round(max(lo, min(float(cc[k]), hi)), 4) if cc.get(k) not in (None, "") else None
                    except (TypeError, ValueError):
                        return None
                caps = {"actif": bool(cc.get("actif")),
                        "voix": cc.get("voix", True) is not False,
                        "clips": cc.get("clips", True) is not False,
                        "mots": int(_cc("mots", 1, 6) or 1),
                        "caption_size": _cc("caption_size", 20, 300),
                        "caption_larg": _cc("caption_larg", 0.2, 1.0),
                        "text_y": _cc("text_y", 0.0, 1.0),
                        "corr": {str(k)[:200]: str(v)[:200]
                                 for k, v in list((cc.get("corr") or {}).items())[:2000]}}
                c["editor"] = {"actif": bool(ed.get("actif")), "blocs": blocs,
                               "audios": audios, "captions": caps}
            if "captions" in data:
                c["captions"] = [str(x)[:200] for x in (data["captions"] or [])][:500]
            if "descriptions" in data:
                # Legendes du post Instagram (a ne pas confondre avec
                # `captions`, qui est le texte incruste dans l'image).
                # Instagram coupe a 2200 caracteres.
                c["descriptions"] = [str(x)[:2200]
                                     for x in (data["descriptions"] or [])
                                     if str(x).strip()][:200]
            if "music_dir" in data:
                md = data["music_dir"]
                if md:
                    d = real_dir(md)
                    if not d:
                        return self.send_err(f"Dossier introuvable : {md}", 400)
                    c["music_dir"] = d
                else:
                    c.pop("music_dir", None)
            if "settings" in data:
                for k, v in (data["settings"] or {}).items():
                    if k in remixer.DEFAULT_SETTINGS:
                        try:
                            c["settings"][k] = type(remixer.DEFAULT_SETTINGS[k])(v)
                        except (TypeError, ValueError):
                            pass
                # Jamais de ralenti: une vitesse < 1 etirerait le clip pour
                # atteindre la duree demandee, ce qui se voit tout de suite.
                for k in ("speed_min", "speed_max"):
                    if c["settings"].get(k, 1.0) < 1.0:
                        c["settings"][k] = 1.0
                if c["settings"]["speed_max"] < c["settings"]["speed_min"]:
                    c["settings"]["speed_max"] = c["settings"]["speed_min"]
            if "slots" in data:
                existing = {s["id"]: s for s in c["slots"]}
                out = []
                for s in data["slots"] or []:
                    sid = s.get("id")
                    slot = existing.get(sid) if sid in existing else new_slot("Catégorie")
                    slot = dict(slot)
                    slot["name"] = (str(s.get("name", slot["name"])).strip()
                                    or slot["name"])[:40]
                    if "path" in s:
                        if s["path"]:
                            d = real_dir(s["path"])
                            if not d:
                                return self.send_err(
                                    f"Dossier introuvable : {s['path']}", 400)
                            slot["path"] = d
                        else:
                            slot.pop("path", None)
                    try:
                        slot["min"] = max(0, min(int(s.get("min", slot["min"])), 10))
                        slot["max"] = max(slot["min"], min(int(s.get("max", slot["max"])), 10))
                    except (TypeError, ValueError):
                        pass
                    # Duree cible du clip final, en secondes. 0 = automatique
                    # (rognage en pourcentage).
                    for k in ("dur_min", "dur_max"):
                        if k in s:
                            try:
                                slot[k] = max(0.0, min(float(s[k] or 0), 600.0))
                            except (TypeError, ValueError):
                                slot[k] = 0.0
                    if slot.get("dur_max") and slot.get("dur_min", 0) > slot["dur_max"]:
                        slot["dur_min"] = slot["dur_max"]
                    if "allow_zoom" in s:
                        slot["allow_zoom"] = bool(s["allow_zoom"])
                    # Pas de sous-titres sur cette categorie (son qui
                    # n'est pas une voix: musique).
                    if "sans_st" in s:
                        if s["sans_st"]:
                            slot["sans_st"] = 1
                        else:
                            slot.pop("sans_st", None)
                    # La musique n'entre qu'a partir de cette categorie.
                    if "musique_ici" in s:
                        if s["musique_ici"]:
                            slot["musique_ici"] = 1
                        else:
                            slot.pop("musique_ici", None)
                    # Son du clip garde (la video de fond d'un react).
                    if "son" in s:
                        if s["son"]:
                            slot["son"] = 1
                        else:
                            slot.pop("son", None)
                    # Role dans un split screen: "" (plan plein cadre
                    # avant le split), "haut", "bas" ou "etape" (un texte
                    # et une duree, sans clip). Voir remixer.split_slots.
                    if "split_role" in s:
                        r = str(s["split_role"] or "")
                        if r in ("haut", "bas", "etape"):
                            slot["split_role"] = r
                        else:
                            slot.pop("split_role", None)
                        # Une etape n'a PAS de clip: son dossier n'a aucune
                        # raison d'exister et huit dossiers vides a cote des
                        # deux vrais font croire qu'il faut les remplir. On
                        # ne retire que le lien, et le dossier seulement
                        # s'il est VIDE — jamais un clip sans demande.
                        if r == "etape" and slot.get("path"):
                            d = slot.pop("path")
                            try:
                                if not os.listdir(d):
                                    os.rmdir(d)
                            except OSError:
                                pass
                    # Reperes de calage, PAR CLIP et pas par categorie:
                    # {"<fichier>": {"ancre": s, "coupes": [s], "depart": s}}.
                    # Voir remixer.repere -- l'instant du score n'est pas au
                    # meme endroit d'un match a l'autre.
                    if "sync" in s:
                        marques = {}
                        for nom, v in (s["sync"] or {}).items():
                            if not isinstance(v, dict):
                                continue
                            e = {}
                            for k in ("ancre", "depart"):
                                if k in v:
                                    try:
                                        e[k] = max(0.0, min(float(v[k]), 3600.0))
                                    except (TypeError, ValueError):
                                        pass
                            cs = v.get("coupes")
                            if cs is not None:
                                if not isinstance(cs, list):
                                    cs = [cs]
                                vals = []
                                for x in cs:
                                    try:
                                        vals.append(max(0.0, min(float(x), 3600.0)))
                                    except (TypeError, ValueError):
                                        pass
                                if vals:
                                    e["coupes"] = sorted(vals)
                            if e:
                                marques[str(nom)[:200]] = e
                        if marques:
                            slot["sync"] = marques
                        else:
                            slot.pop("sync", None)
                    # « Garder au complet »: chaque clip de la categorie
                    # passe en entier (entre SON debut et SA fin, voir
                    # `par_clip`), quelle que soit la duree reglee.
                    if "complet" in s:
                        if s["complet"]:
                            slot["complet"] = 1
                        else:
                            slot.pop("complet", None)
                    # Reglages PAR CLIP, ranges sous le nom du fichier comme
                    # les reperes de sync: les clips d'une categorie ne se
                    # valent pas — l'un a une fin ratee, l'autre est trop
                    # lent. Voir remixer.clip_regl.
                    if "par_clip" in s:
                        regl = {}
                        for nom, v in (s["par_clip"] or {}).items():
                            if not isinstance(v, dict):
                                continue
                            e = {}
                            for k, lo, hi in (("debut", 0.0, 3600.0), ("fin", 0.0, 3600.0),
                                              ("vitesse", 0.25, 4.0), ("volume", 0.0, 3.0)):
                                if v.get(k) is not None:
                                    try:
                                        e[k] = round(max(lo, min(float(v[k]), hi)), 3)
                                    except (TypeError, ValueError):
                                        pass
                            if e.get("debut") is not None and e.get("fin") is not None \
                                    and e["fin"] <= e["debut"] + 0.1:
                                e.pop("fin")
                            if v.get("son") is not None:
                                e["son"] = bool(v["son"])
                            if v.get("miroir"):
                                e["miroir"] = True
                            cd = v.get("cadre")
                            if isinstance(cd, dict):
                                try:
                                    z = max(1.0, min(float(cd.get("z") or 1), 5.0))
                                    x = max(-1.0, min(float(cd.get("x") or 0), 1.0))
                                    y = max(-1.0, min(float(cd.get("y") or 0), 1.0))
                                    if z > 1.001 or abs(x) > 0.001 or abs(y) > 0.001:
                                        e["cadre"] = {"z": round(z, 3), "x": round(x, 4),
                                                      "y": round(y, 4)}
                                except (TypeError, ValueError):
                                    pass
                            if e:
                                regl[str(nom)[:200]] = e
                        if regl:
                            slot["par_clip"] = regl
                        else:
                            slot.pop("par_clip", None)
                    # Categorie incrustee: son clip n'est pas un plan du
                    # montage, il est detoure et pose par-dessus la video.
                    if "incrust" in s:
                        if s["incrust"]:
                            slot["incrust"] = 1
                        else:
                            slot.pop("incrust", None)
                    # La tete incrustee se montre sur CETTE categorie.
                    if "incrust_sur" in s:
                        if s["incrust_sur"] and not slot.get("incrust"):
                            slot["incrust_sur"] = 1
                        else:
                            slot.pop("incrust_sur", None)
                    # Miroir horizontal, propre a la categorie.
                    if "flip" in s:
                        if s["flip"]:
                            slot["flip"] = 1
                        else:
                            slot.pop("flip", None)   # pas de cle inutile
                    # Vitesse propre a la categorie. 0 = suivre la serie.
                    # Bornee a [1, 4]: jamais de ralenti.
                    for k in ("speed_min", "speed_max"):
                        if k in s:
                            try:
                                val = float(s[k] or 0)
                            except (TypeError, ValueError):
                                val = 0.0
                            slot[k] = 0.0 if val <= 0 else max(1.0, min(val, 4.0))
                    if slot.get("speed_max") and slot.get("speed_min", 0) > slot["speed_max"]:
                        slot["speed_min"] = slot["speed_max"]
                    if s.get("text_pos") in remixer.captions.POSITIONS:
                        slot["text_pos"] = s["text_pos"]
                    # Ce qu'il faut filmer pour cette categorie (ecrit par
                    # l'IA a la creation, corrigeable a la main). Lu par le
                    # tri, qui s'en sert pour reconnaitre un clip.
                    if "consigne" in s:
                        t = str(s["consigne"] or "").strip()[:600]
                        if t:
                            slot["consigne"] = t
                        else:
                            slot.pop("consigne", None)
                    if "captions" in s:
                        slot["captions"] = [str(x)[:300]
                                            for x in (s["captions"] or []) if str(x).strip()][:200]
                    out.append(slot)
                if out:
                    # Les dossiers des slots supprimes sont conserves sur
                    # disque: on ne detruit jamais des clips sans demande.
                    c["slots"] = out
            save_serie(c)
            return self.send_json(serie_detail(cid))

        # Upload en flux brut: le corps de la requete EST le fichier.
        m = re.match(r"^/api/series/([^/]+)/upload$", p)
        if m:
            cid = m.group(1)
            base = serie_path(cid)
            if not base:
                return self.send_err("Série introuvable", 404)

            kind = (q.get("kind") or ["clip"])[0]
            name = safe_filename((q.get("name") or [""])[0])
            ext = Path(name).suffix.lower()

            if kind == "music":
                if ext not in remixer.AUDIO_EXTS:
                    return self.send_err(f"Format audio non supporté: {ext or '?'}", 415)
                dest_dir = base / "music"
            elif kind == "voix":
                # Une voix off de l'editeur. Pas dans `music/`: la musique
                # est tiree au sort, une voix off est posee a un endroit.
                if ext not in remixer.AUDIO_EXTS:
                    return self.send_err(f"Format audio non supporté: {ext or '?'}", 415)
                dest_dir = voix_dir(cid)
            else:
                sid = (q.get("slot") or [""])[0]
                if not SAFE_ID.match(sid or ""):
                    return self.send_err("Catégorie invalide", 400)
                if ext not in remixer.VIDEO_EXTS:
                    return self.send_err(f"Format vidéo non supporté: {ext or '?'}", 415)
                cc = load_serie(cid) or {"slots": []}
                slot = next((s for s in cc["slots"] if s["id"] == sid), None)
                # UN DOSSIER LIE N'EST INTOUCHABLE QUE S'IL EST A L'UTILISATEUR.
                # La regle protege un dossier de Drive ou d'un disque externe,
                # ou l'app ne doit ni supprimer ni deplacer quoi que ce soit.
                # Mais toute serie creee par l'app a des dossiers lies — sous
                # `clips/`, crees par `make_serie_folders` — et refuser d'y
                # deposer un fichier rendait l'editeur inutilisable: on ne
                # pouvait remplir aucun nouveau projet sans passer par le
                # Finder. AJOUTER un fichier dans un dossier de `clips/`,
                # c'est ce que l'utilisateur ferait a la main; seuls la
                # suppression et le deplacement restent interdits.
                if slot and slot.get("path"):
                    lie = Path(slot["path"])
                    if not (lie.is_dir() and within(CLIPS_DIR, lie)):
                        return self.send_err(
                            "Cette catégorie lit un dossier lié. Ajoute le fichier "
                            "directement dans ce dossier — l'app le verra tout de suite.", 409)
                    dest_dir = lie
                else:
                    dest_dir = base / "slots" / sid

            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = dest_dir / name
            # On verifie qu'on reste DANS le dossier de destination, pas dans
            # celui de la serie: un dossier lie vit sous `clips/` et la garde
            # d'avant (`within(base, ...)`) le refusait a coup sur. Le nom est
            # deja passe par `safe_filename`, et `dest_dir` est soit sous la
            # serie, soit un dossier de `clips/` verifie plus haut.
            if not within(dest_dir, dest):
                return self.send_err("Chemin refusé", 403)

            stem, i = Path(name).stem, 1
            while dest.exists():
                dest = dest_dir / f"{stem}-{i}{ext}"
                i += 1

            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0:
                return self.send_err("Fichier vide", 400)

            tmp = dest.with_suffix(dest.suffix + ".part")
            try:
                with open(tmp, "wb") as f:
                    remaining = n
                    while remaining > 0:
                        self._corps_lu = True
                        chunk = self.rfile.read(min(1024 * 1024, remaining))
                        if not chunk:
                            raise IOError("transfert interrompu")
                        f.write(chunk)
                        remaining -= len(chunk)
                os.replace(str(tmp), str(dest))
            except Exception as e:                              # noqa: BLE001
                tmp.unlink(missing_ok=True)
                return self.send_err(f"Upload échoué: {e}", 500)

            if kind == "voix":
                dur, _ = remixer.probe(str(dest))
                if dur <= 0:
                    dest.unlink(missing_ok=True)
                    return self.send_err(f"« {name} » n'est pas un son lisible par ffmpeg.", 415)
                return self.send_json({"ok": True, "name": dest.name,
                                       "dur": round(dur, 3), "pics": voix_pics(dest)})

            if kind != "music":
                dur, _ = remixer.probe(str(dest))
                if dur <= 0:
                    dest.unlink(missing_ok=True)
                    return self.send_err(
                        f"« {name} » n'est pas une vidéo lisible par ffmpeg.", 415)
                remixer.make_thumbnail(str(dest),
                                       str(base / "thumbs" / (dest.name + ".jpg")))

            return self.send_json({"ok": True, "name": dest.name})

        return self.send_err("Not found", 404)

    def do_DELETE(self):
        self._corps_lu = False
        try:
            self._delete()
        finally:
            self.vider_corps()

    def _delete(self):
        u = urlparse(self.path)
        p, q = u.path, parse_qs(u.query)
        # Une seule garde pour TOUTES les routes de l'atelier, plutot
        # qu'une par route: sans `template.py`, elles n'existent pas.
        if tpl is None and (p.startswith("/api/templates")
                            or p.startswith("/media/tplapercu")
                            or p.startswith("/media/template")):
            return self.send_err("Les templates ne sont pas dans cette version", 404)

        m = re.match(r"^/api/campaigns/(\d+)$", p)
        if m:
            # Les videos sont conservees (ON DELETE SET NULL): un deal qui
            # se termine ne doit pas effacer son historique de publication.
            plateau.delete_campaign(int(m.group(1)))
            return self.send_json({"ok": True})

        # Retirer le brief sans toucher a la campagne: un deal dont le
        # brief change de source repart de zero sans etre recree.
        m = re.match(r"^/api/campaigns/(\d+)/brief$", p)
        if m:
            cid = int(m.group(1))
            if not plateau.campaign(cid):
                return self.send_err("Campagne introuvable", 404)
            plateau.update_campaign(cid, {"brief_url": "", "brief_json": "",
                                          "brief_at": ""})
            return self.send_json({"ok": True})

        # Un montage en particulier. Avant le template lui-meme, sinon le
        # motif plus court avalerait ce chemin.
        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)/rendus/(.+)$", p)
        if m:
            tid, nom = m.group(1), unquote(m.group(2))
            if not tpl.charger(tid):
                return self.send_err("Template introuvable", 404)
            if not tpl.supprimer_rendu(tid, nom):
                return self.send_err("Vidéo introuvable", 404)
            return self.send_json({"ok": True})

        m = re.match(r"^/api/templates/([A-Za-z0-9_-]+)$", p)
        if m:
            return self.send_json({"ok": tpl.supprimer(m.group(1))})

        m = re.match(r"^/api/campaigns/(\d+)/music$", p)
        if m:
            d = musique_dir(m.group(1))
            if not d:
                return self.send_err("Campagne introuvable", 404)
            f = d / safe_filename((q.get("name") or [""])[0])
            if not within(d, f):
                return self.send_err("Chemin refusé", 403)
            f.unlink(missing_ok=True)
            return self.send_json({"ok": True})

        m = re.match(r"^/api/videos/(\d+)$", p)
        if m:
            plateau.delete_video(int(m.group(1)))
            return self.send_json({"ok": True})

        m = re.match(r"^/api/tasks/(\d+)$", p)
        if m:
            plateau.delete_task(int(m.group(1)))
            return self.send_json({"ok": True})

        m = re.match(r"^/api/ideas/(\d+)$", p)
        if m:
            plateau.delete_idea(int(m.group(1)))
            return self.send_json({"ok": True})

        if p == "/api/outputs":
            return self.send_json({"ok": True, "deleted": purge_outputs()})

        m = re.match(r"^/api/series/([^/]+)/outputs$", p)
        if m:
            if not serie_path(m.group(1)):
                return self.send_err("Série introuvable", 404)
            return self.send_json({"ok": True,
                                   "deleted": purge_outputs(m.group(1))})

        m = re.match(r"^/api/series/([^/]+)$", p)
        if m:
            cid = m.group(1)
            base = serie_path(cid)
            if not base:
                return self.send_err("Série introuvable", 404)
            c = load_serie(cid)
            od = Path(remixer.output_dir(base, c))
            # Lu AVANT tout effacement: series_sharing_output relit les
            # serie.json (celui-ci compris, pour s'exclure), own_outputs
            # relit les lignes du pipeline que forget_series va retirer.
            partage = series_sharing_output(cid, od)
            a_elle = own_outputs(cid, od) if partage else []
            shutil.rmtree(str(base), ignore_errors=True)
            # Le dossier de sortie vit hors de la serie: il faut le
            # retirer explicitement. Les clips sources, eux, ne sont
            # jamais touches.
            #
            # Sauf s'il est partage avec une autre serie (meme nom, creee
            # avant que les dossiers soient numerotes): le rmtree effacait
            # alors les videos de l'autre. On ne retire que les fichiers
            # que le pipeline attribue a celle-ci, et le dossier reste.
            if partage:
                for f in a_elle:
                    try:
                        f.unlink()
                    except OSError:
                        pass
                sync_all_outputs()
            elif within(OUTPUT_DIR, od):
                shutil.rmtree(str(od), ignore_errors=True)
            # Les lignes du pipeline suivent les fichiers. Sans ca, les
            # videos de la serie restaient dans la liste, le calendrier et
            # le compteur « pretes a poster » en pointant vers des .mp4
            # effaces. forget_series met de cote celles deja postees: on
            # supprime une recette de montage, pas un historique.
            try:
                plateau.forget_series(cid)
            except Exception:                                   # noqa: BLE001
                pass
            return self.send_json({"ok": True})

        m = re.match(r"^/api/series/([^/]+)/file$", p)
        if m:
            cid = m.group(1)
            base = serie_path(cid)
            if not base:
                return self.send_err("Série introuvable", 404)
            kind = (q.get("kind") or [""])[0]
            name = safe_filename((q.get("name") or [""])[0])

            if kind == "output":
                od = Path(remixer.output_dir(base, load_serie(cid)))
                target = od / name
                if not within(od, target):
                    return self.send_err("Chemin refusé", 403)
                Path(target).unlink(missing_ok=True)
                Path(base / "thumbs" / (name + ".jpg")).unlink(missing_ok=True)
                # Sans ca la ligne du pipeline (table videos) survit au
                # fichier: elle reste affichee "Prete", avec un lien mort.
                # purge_outputs() (Tout supprimer) le fait deja; le X a
                # l'unite doit se comporter pareil.
                try:
                    v = plateau.video_by_path(str(target))
                    if v:
                        plateau.delete_video(v["id"])
                except Exception:                               # noqa: BLE001
                    pass
                sync_all_outputs()
                return self.send_json({"ok": True})
            elif kind == "music":
                target, thumb = base / "music" / name, None
            elif kind == "clip":
                sid = (q.get("slot") or [""])[0]
                if not SAFE_ID.match(sid or ""):
                    return self.send_err("Catégorie invalide", 400)
                cc = load_serie(cid) or {"slots": []}
                slot = next((s for s in cc["slots"] if s["id"] == sid), None)
                if slot and slot.get("path"):
                    # On ne touche JAMAIS aux fichiers d'un dossier lié.
                    return self.send_err(
                        "Ce clip vit dans un dossier lié : l'app ne le supprimera pas. "
                        "Retire-le depuis le Finder si tu veux vraiment l'effacer.", 409)
                target = base / "slots" / sid / name
                thumb = base / "thumbs" / (name + ".jpg")
            else:
                return self.send_err("Type inconnu", 400)

            if not within(base, target):
                return self.send_err("Chemin refusé", 403)
            Path(target).unlink(missing_ok=True)
            if thumb:
                Path(thumb).unlink(missing_ok=True)
            return self.send_json({"ok": True})

        return self.send_err("Not found", 404)


def deja_lance(port):
    """Le plateau tourne-t-il DEJA sur ce port ?

    Sans ce test, un deuxieme lancement (double-clic de trop sur
    Lancer.command) trouvait le port occupe, demarrait discretement sur
    8766 et ouvrait une DEUXIEME app, avec sa propre base ouverte deux
    fois. On preferait ouvrir l'existante."""
    import urllib.request                               # noqa: PLC0415
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/fonds",
                                    timeout=1.5) as r:
            return r.status == 200
    except Exception:                                   # noqa: BLE001
        return False


def free_port(start):
    """Premier port libre a partir de `start`.

    SO_REUSEADDR est indispensable ici: sans lui, un port encore en TIME_WAIT
    (juste apres un arret du serveur) parait occupe alors que le serveur
    saurait s'y attacher — et l'app changerait d'adresse a chaque relance.
    """
    for port in range(start, start + 20):
        with socket.socket() as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return start


def main():
    # La console Windows n'est pas en UTF-8 par defaut: le message de
    # demarrage contient « Séries », « Vidéos »... et plantait si la sortie
    # etait redirigee vers un fichier.
    for flux in (sys.stdout, sys.stderr):
        try:
            flux.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    ok, drawtext, msg = remixer.tools_available()
    SERIES_DIR.mkdir(exist_ok=True)
    plateau.init()          # cree plateau.db et ses colonnes si besoin
    migrer_musiques()
    caught = backfill_outputs()

    if not (WEB_DIR / "index.html").exists():
        sys.exit(f"ERREUR: {WEB_DIR / 'index.html'} est introuvable.")

    if deja_lance(PORT):
        url = f"http://127.0.0.1:{PORT}"
        print("=== Le plateau ===")
        print(f"  Il tourne deja sur {url} — j'ouvre cette fenetre-la.")
        print("  (rien de nouveau n'a ete demarre)\n")
        webbrowser.open(url)
        return

    # Envoi quotidien vers Buffer (series avec `auto_jour`). Lance ICI et
    # pas a l'import: les scripts qui importent server.py ne doivent pas
    # se mettre a generer et publier.
    threading.Thread(target=boucle_auto, daemon=True).start()

    port = free_port(PORT)
    url = f"http://127.0.0.1:{port}"

    print("=== Le plateau ===")
    print(f"  Système:  {portable.systeme()}")
    if not ok:
        print(f"  ffmpeg:   MANQUANT — {msg}")
        print("            Sans lui, rien ne peut être monté.")
        print("            macOS   : brew install ffmpeg")
        print("            Windows : winget install ffmpeg")
        print("            Linux   : sudo apt install ffmpeg")
    else:
        print("  ffmpeg:   OK")
    if not drawtext:
        print("  Textes:   DÉSACTIVÉS — installe Pillow pour les activer :")
        print("            python3 -m pip install pillow")
    print(f"  Séries:   {SERIES_DIR}")
    print(f"  Base:     {plateau.DB_FILE.name} "
          f"({len(plateau.campaigns())} campagnes, {len(plateau.videos())} vidéos"
          f"{f', {caught} rattrapée(s)' if caught else ''})")
    print(f"\n  Ouvre {url}")
    print("  (Ctrl+C pour arrêter)\n")

    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    srv.daemon_threads = True
    # PLATEAU_SANS_NAVIGATEUR: l'app installee ouvre elle-meme sa fenetre
    # (et un essai lance en fond ne doit pas ouvrir d'onglet).
    if not os.environ.get("PLATEAU_SANS_NAVIGATEUR"):
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêté.")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
