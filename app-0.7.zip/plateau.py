#!/usr/bin/env python3
"""
Le plateau — le niveau CAMPAGNE.
---------------------------------
Une CAMPAGNE, c'est le deal: le client, les comptes crees pour lui, les
mots de passe, ce qu'il paie, le rythme qu'il exige. Elle contient des
SERIES (les recettes de montage, cote remixer.py) et des VIDEOS.

Cette couche est le portage de l'ancien PLATEAU, qui tournait en Node avec
`node:sqlite`. Python a `sqlite3` dans sa bibliotheque standard, donc le
projet reste a zero dependance.

Le fichier plateau.db reste sur ce Mac. Les mots de passe y sont en clair,
comme avant: le serveur n'ecoute que sur 127.0.0.1 et .gitignore exclut la
base.
"""

import calendar
import re
import sqlite3
import threading
import time
from datetime import date, timedelta
from pathlib import Path

from chemins import DONNEES as ROOT
DB_FILE = ROOT / "plateau.db"

# Les cinq etats d'une video, dans l'ordre du pipeline. L'ordre compte: il
# sert de tri pour la colonne Statut et de disposition pour le pipeline.
STATUSES = ["Idée", "À tourner", "Monté", "Prêt", "Posté"]
STATUS_KEY = {"Idée": "idee", "À tourner": "tourner", "Monté": "monte",
              "Prêt": "pret", "Posté": "poste"}

# Liste blanche des colonnes modifiables. Le serveur Node d'origine
# interpolait les noms de colonnes directement dans le SQL; ici rien
# n'entre dans une requete sans etre passe par ces listes.
CAMPAIGN_COLS = [
    "name", "google_email", "google_password",
    "tt_login", "tt_password", "tt_min_views", "tt_handle",
    "ig_login", "ig_password", "ig_min_views", "ig_handle",
    "yt_login", "yt_password", "yt_min_views", "yt_handle",
    "fb_login", "fb_password", "fb_min_views", "fb_handle",
    "base_pay", "cpm", "frequency", "notes",
    # Photos de profil. Chaque colonne ne contient qu'un NOM de fichier,
    # jamais un chemin: les images vivent toutes dans avatars/, et une
    # base copiee sur une autre machine reste utilisable.
    "avatar", "google_avatar", "tt_avatar", "ig_avatar", "yt_avatar", "fb_avatar",
    # Objectif de publications par jour, saisi a la main. Sert aux deals au
    # CPM, ou il n'y a pas de quota impose mais ou on se fixe une cadence:
    # `frequency` est du texte libre et ne dit rien dans ce cas.
    "daily_target",
    # Paiement. `base_pay` et `cpm` restent du texte libre negocie avec le
    # client; ces trois-ci sont structures pour qu'on puisse CALCULER une
    # prochaine echeance et un montant.
    #   pay_per_video : montant touche par video postee (nombre)
    #   pay_cycle     : "hebdo" | "2sem" | "mensuel" | ""  (vide = pas de suivi)
    #   pay_anchor    : une date de paiement connue (AAAA-MM-JJ), point de
    #                   depart du cycle. Sans elle on ne sait pas sur quel
    #                   jour tombe l'echeance.
    "pay_per_video", "pay_cycle", "pay_anchor",
    # Le brief du client, rapporte d'une page Notion ou colle a la main.
    #   brief_url  : la page d'origine, pour y retourner d'un clic
    #   brief_json : le brief RANGE + le texte brut dont il sort (voir
    #                brief.py). Le brut est garde pour pouvoir retrier
    #                sans redemander la page — meme raison que le cache
    #                des transcriptions.
    #   brief_at   : date de la derniere lecture (horodatage unix)
    # Volontairement en TEXT comme tout le reste de cette liste: un brief
    # n'est jamais interroge en SQL, il est lu en entier ou pas du tout.
    "brief_url", "brief_json", "brief_at",
    # ONBOARDING — un deal signe mais pas encore lance.
    #
    # `stage` vaut "onbo" tant qu'on monte les comptes, "" des qu'on
    # poste. Une etape, PAS une seconde table: le brief, les identifiants,
    # les pseudos et les mots de passe sont deja les colonnes d'une
    # campagne. Lancer, c'est vider ce champ — rien a recopier, donc rien
    # a perdre en recopiant.
    #
    # Le filtre est fait en SQL (`campaigns(stage=...)`) et pas dans le
    # navigateur: la vue d'ensemble, la file, le suivi du jour et Buffer
    # lisent tous la meme liste, et un oubli de filtre dans l'un d'eux
    # ferait apparaitre un compte inexistant dans un objectif quotidien.
    "stage",
    # Ou se passe la conversation du deal (Discord, Slack, un courriel).
    # `convo_ou` reste du texte libre: un numero WhatsApp n'est pas une URL.
    "convo_url", "convo_ou",
    # Etat de chaque compte a creer: "" (a creer) | "cree" | "warmup" |
    # "pret". Une colonne par plateforme, comme `tt_login` et `tt_handle`
    # juste au-dessus — c'est le grain de cette table.
    "google_etat", "ig_etat", "tt_etat", "yt_etat", "fb_etat",
    # Quand chaque compte est passe en warmup (horodatage unix, en texte
    # comme tout le reste de cette liste). Sert au decompte du warmup
    # (duree dans `warm_h`, 48 h par defaut): un
    # compte tout neuf qui poste tout de suite se fait sanctionner.
    # Une colonne par plateforme, car on ne les chauffe pas le meme jour.
    "google_warm_at", "ig_warm_at", "tt_warm_at", "yt_warm_at", "fb_warm_at",
    # Ce que le deal rapporterait par mois, une fois lance. Un nombre
    # NU, sans devise ni unite: `base_pay` existe deja mais c'est du
    # texte libre negocie, et il contient aussi bien « 750/month » que
    # « 16/video » ou « 0$ ». Impossible d'additionner ca; ce champ-ci
    # sert justement a faire une somme.
    "revenu_mois",
    # Le minimum de vues exige par le deal, par video. Un nombre NU lui
    # aussi: c'est une CONDITION du contrat, pas une mesure. Il ne
    # s'additionne donc pas entre campagnes (10 k chez l'un et 10 k chez
    # l'autre ne font pas 20 k) — contrairement a `revenu_mois`, qui a
    # un total en tete d'ecran.
    "min_vues",
    # Les BONUS du deal (« +50 $ a 50K vues, +100 $ a 100K »), a part de la
    # paie de base : melanges dans `base_pay`, ils en faisaient un
    # paragraphe qu'on ne savait plus lire ni corriger (19/11).
    "bonus",
    # Le STATUT de la campagne (22/11) : ce qu'il reste a faire POUR ELLE,
    # en une phrase (« envoyer les 5 brouillons dans #video-approval »).
    # Pas un etat calcule — une note de pilotage, lue d'un coup d'oeil
    # dans une bulle sur sa pastille de la vue d'ensemble. Vide = rien.
    "statut",
    # La duree du warmup, EN HEURES, pour cette campagne. Vide = 48 h,
    # la valeur par defaut d'avant cette colonne: un client peut exiger
    # une semaine de chauffe comme il peut n'en demander aucune, et
    # c'est une clause du deal, donc une colonne de la campagne.
    "warm_h",
    # Campagne en pause: "1" ou "" (comme les autres colonnes texte de
    # cette liste). L'anneau de la vue d'ensemble passe au gris et la
    # campagne sort du suivi du jour — elle n'est juste plus dans le rythme
    # actif, sans qu'on efface son objectif ou son historique.
    "paused",
    # Les plateformes ou le deal exige de poster, « ig,tt,yt » (cles de
    # PLATFORMS dans l'interface). Vide = pas dit: on montre les quatre,
    # comme avant cette colonne. Lu dans le brief et le contrat par l'IA
    # a la creation, pour n'ouvrir que les comptes qu'il faut.
    "plateformes",
    # Le contrat depose a la creation: un NOM de fichier dans contrats/,
    # jamais un chemin (meme regle que les avatars).
    "contrat",
]

# Cycles de paiement. `mensuel` avance de mois en mois et non de 30 jours:
# un client qui paie le 5 paie le 5, pas le 5 puis le 4 puis le 3.
# Les autres sont un nombre de jours. `pay_cycle` accepte aussi un nombre
# brut ("15", "10"...) pour un rythme qui ne figure pas dans la liste —
# tous les clients ne paient pas sur une semaine ronde.
PAY_CYCLES = {"hebdo": ("chaque semaine", 7),
              "2sem":  ("aux 2 semaines", 14),
              "15j":   ("aux 15 jours", 15),
              "mensuel": ("chaque mois", None)}


def cycle_jours(cycle):
    """Nombre de jours d'un cycle, ou None s'il est mensuel/invalide."""
    cycle = str(cycle or "").strip()
    if cycle in PAY_CYCLES:
        return PAY_CYCLES[cycle][1]
    if cycle.isdigit() and 0 < int(cycle) <= 365:
        return int(cycle)
    return None


def cycle_valide(cycle):
    cycle = str(cycle or "").strip()
    return cycle == "mensuel" or cycle_jours(cycle) is not None


def cycle_label(cycle):
    cycle = str(cycle or "").strip()
    if cycle in PAY_CYCLES:
        return PAY_CYCLES[cycle][0]
    n = cycle_jours(cycle)
    return f"tous les {n} jours" if n else cycle
AVATAR_COLS = ["avatar", "google_avatar", "tt_avatar", "ig_avatar",
               "yt_avatar", "fb_avatar"]
VIDEO_COLS = ["title", "campaign_id", "serie_id", "status", "file_path",
              "publish_date", "notes"]

PLATFORMS = [
    {"key": "tt", "label": "TikTok",    "url": "https://www.tiktok.com/@{}"},
    {"key": "ig", "label": "Instagram", "url": "https://www.instagram.com/{}/"},
    {"key": "yt", "label": "YouTube",   "url": "https://www.youtube.com/@{}"},
    {"key": "fb", "label": "Facebook",  "url": "https://www.facebook.com/{}"},
]

_local = threading.local()


class PlateauError(Exception):
    """Erreur affichable telle quelle par l'interface."""


def db():
    """Connexion propre au fil courant.

    Le serveur est multi-thread (ThreadingHTTPServer) et une connexion
    sqlite3 ne se partage pas entre fils. Une par fil, gardee ouverte."""
    con = getattr(_local, "con", None)
    if con is None:
        con = sqlite3.connect(DB_FILE, timeout=10)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode = WAL")
        con.execute("PRAGMA foreign_keys = ON")
        _local.con = con
    return con


# ------------------------------------------------------------------
# Schema
# ------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS campaigns (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT NOT NULL,
  google_email    TEXT NOT NULL DEFAULT '',
  google_password TEXT NOT NULL DEFAULT '',
  tt_login        TEXT NOT NULL DEFAULT '',
  tt_password     TEXT NOT NULL DEFAULT '',
  tt_min_views    TEXT NOT NULL DEFAULT '',
  tt_handle       TEXT NOT NULL DEFAULT '',
  ig_login        TEXT NOT NULL DEFAULT '',
  ig_password     TEXT NOT NULL DEFAULT '',
  ig_min_views    TEXT NOT NULL DEFAULT '',
  ig_handle       TEXT NOT NULL DEFAULT '',
  yt_login        TEXT NOT NULL DEFAULT '',
  yt_password     TEXT NOT NULL DEFAULT '',
  yt_min_views    TEXT NOT NULL DEFAULT '',
  yt_handle       TEXT NOT NULL DEFAULT '',
  fb_login        TEXT NOT NULL DEFAULT '',
  fb_password     TEXT NOT NULL DEFAULT '',
  fb_min_views    TEXT NOT NULL DEFAULT '',
  fb_handle       TEXT NOT NULL DEFAULT '',
  base_pay        TEXT NOT NULL DEFAULT '',
  cpm             TEXT NOT NULL DEFAULT '',
  frequency       TEXT NOT NULL DEFAULT '',
  notes           TEXT NOT NULL DEFAULT '',
  avatar          TEXT NOT NULL DEFAULT '',
  google_avatar   TEXT NOT NULL DEFAULT '',
  tt_avatar       TEXT NOT NULL DEFAULT '',
  ig_avatar       TEXT NOT NULL DEFAULT '',
  yt_avatar       TEXT NOT NULL DEFAULT '',
  fb_avatar       TEXT NOT NULL DEFAULT '',
  daily_target    TEXT NOT NULL DEFAULT '',
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS videos (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT NOT NULL,
  campaign_id  INTEGER REFERENCES campaigns(id) ON DELETE SET NULL,
  serie_id     TEXT NOT NULL DEFAULT '',
  status       TEXT NOT NULL DEFAULT 'Idée',
  file_path    TEXT NOT NULL DEFAULT '',
  publish_date TEXT NOT NULL DEFAULT '',
  notes        TEXT NOT NULL DEFAULT '',
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Journal des +1 / -1 du suivi du jour. En AJOUT SEUL, et sans aucun role
-- dans le calcul du compteur: il sert uniquement a repondre a « j'etais a
-- 6, pourquoi suis-je a 3 ». Le compteur, lui, se deduit de vraies videos,
-- et c'est voulu — mais une ligne de video peut etre effacee ou changee de
-- statut par dix chemins differents, et sans trace on ne peut rien dire.
CREATE TABLE IF NOT EXISTS journal_posts (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  campaign_id INTEGER NOT NULL,
  day         TEXT NOT NULL,
  delta       INTEGER NOT NULL,
  apres       INTEGER NOT NULL DEFAULT 0,
  at          REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jpost ON journal_posts(campaign_id, day);

-- Annonces Reddit reperees par la prospection. `reddit_id` est unique:
-- la meme annonce revue au passage suivant ne doit pas revenir dans la
-- pile si elle a deja ete jugee. On n'efface jamais une ligne refusee,
-- sinon elle reapparaitrait a chaque tour.
CREATE TABLE IF NOT EXISTS prospects (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  reddit_id  TEXT NOT NULL UNIQUE,
  titre      TEXT NOT NULL DEFAULT '',
  texte      TEXT NOT NULL DEFAULT '',
  auteur     TEXT NOT NULL DEFAULT '',
  sub        TEXT NOT NULL DEFAULT '',
  url        TEXT NOT NULL DEFAULT '',
  montant    INTEGER NOT NULL DEFAULT 0,
  parle      INTEGER NOT NULL DEFAULT 0,
  publie_at  REAL NOT NULL DEFAULT 0,
  vu_at      REAL NOT NULL DEFAULT 0,
  statut     TEXT NOT NULL DEFAULT 'nouveau',
  message    TEXT NOT NULL DEFAULT '',
  cpm        INTEGER NOT NULL DEFAULT 0,
  tiktok     INTEGER NOT NULL DEFAULT 0,
  doit_poster INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_prosp_statut ON prospects(statut);

-- Journal des generations. Volontairement separe de `videos`: le
-- compteur « generees ces 24 h » doit survivre a la suppression des
-- fichiers, alors que « pretes a poster » compte ce qui existe encore.
-- On n'efface jamais de ligne ici.
CREATE TABLE IF NOT EXISTS generations (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  serie_id  TEXT NOT NULL DEFAULT '',
  name      TEXT NOT NULL DEFAULT '',
  at        REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_gen_at    ON generations(at);
CREATE INDEX IF NOT EXISTS idx_gen_serie ON generations(serie_id);

-- Publications dont la video a disparu du pipeline. Meme raison d'etre
-- que `generations`: vider les videos generees ne doit pas effacer le
-- fait qu'on a poste. Chaque ligne dit « cette campagne, ce jour-la,
-- N publications dont il ne reste plus de trace dans `videos` ».
CREATE TABLE IF NOT EXISTS posts_kept (
  campaign_id INTEGER NOT NULL,
  day         TEXT NOT NULL,
  n           INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (campaign_id, day)
);

CREATE INDEX IF NOT EXISTS idx_videos_campaign ON videos(campaign_id);
CREATE INDEX IF NOT EXISTS idx_videos_serie    ON videos(serie_id);
CREATE INDEX IF NOT EXISTS idx_videos_date     ON videos(publish_date);

-- Liste de taches. Volontairement minimale: pas d'etat intermediaire, pas
-- d'echeance. Une tache est faite ou elle ne l'est pas.
--
-- `done_on` porte TOUTE la logique du report: on y ecrit le jour ou la
-- case a ete cochee, et on compare a la date du jour a l'affichage.
--   recurrente  -> cochee seulement si done_on == aujourd'hui, donc elle
--                  se decoche toute seule au changement de date
--   ponctuelle  -> cochee le jour meme (on peut se decocher), puis elle
--                  disparait; si elle n'est jamais cochee, done_on reste
--                  vide et elle reste la indefiniment — c'est le report
--                  demande, obtenu sans rien faire tourner a minuit.
CREATE TABLE IF NOT EXISTS tasks (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  text       TEXT NOT NULL,
  recurrent  INTEGER NOT NULL DEFAULT 0,
  done_on    TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Idees de contenu, rangees par rubrique. Un bloc-notes, pas un pipeline:
-- une idee n'a pas de statut, elle existe ou on l'efface.
CREATE TABLE IF NOT EXISTS ideas (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  text       TEXT NOT NULL,
  section    TEXT NOT NULL DEFAULT 'autre',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""


def init():
    """Cree la base si besoin, ajoute les colonnes manquantes.

    Une base creee par une version anterieure n'a pas forcement toutes les
    colonnes: on les ajoute une par une plutot que de refuser de demarrer."""
    con = db()
    con.executescript(SCHEMA)
    have = {r["name"] for r in con.execute("PRAGMA table_info(campaigns)")}
    for col in CAMPAIGN_COLS:
        if col not in have:
            con.execute(f"ALTER TABLE campaigns ADD COLUMN {col} TEXT NOT NULL DEFAULT ''")
    have = {r["name"] for r in con.execute("PRAGMA table_info(prospects)")}
    for col in ("cpm", "tiktok", "doit_poster"):
        if col not in have:
            con.execute(f"ALTER TABLE prospects ADD COLUMN {col} INTEGER NOT NULL DEFAULT 0")
    have = {r["name"] for r in con.execute("PRAGMA table_info(videos)")}
    if "serie_id" not in have:
        con.execute("ALTER TABLE videos ADD COLUMN serie_id TEXT NOT NULL DEFAULT ''")
    con.commit()


# ------------------------------------------------------------------
# Lecture
# ------------------------------------------------------------------

def campaigns(stage=""):
    """Les campagnes d'une ETAPE, avec deux champs calcules en SQL:
    `video_count` et `next_date` (prochaine publication pas encore postee).

    `stage` vaut "" pour les campagnes en service — celles de la vue
    d'ensemble — et "onbo" pour celles qu'on monte encore. Le defaut est
    "" a dessein: tout le code existant appelle `campaigns()` sans
    argument et doit continuer a ne voir QUE les campagnes lancees. Une
    campagne en onboarding n'a pas de compte, pas de serie et pas
    d'objectif; la laisser entrer dans le suivi du jour afficherait un
    retard sur un deal qui n'a pas commence."""
    rows = db().execute("""
        SELECT c.*,
          (SELECT COUNT(*) FROM videos v WHERE v.campaign_id = c.id) AS video_count,
          (SELECT MIN(v.publish_date) FROM videos v
             WHERE v.campaign_id = c.id
               AND v.publish_date >= date('now','localtime')
               AND v.status != 'Posté') AS next_date
        FROM campaigns c
        WHERE COALESCE(c.stage,'') = ?
        ORDER BY c.name COLLATE NOCASE
    """, (stage,)).fetchall()
    return [dict(r) for r in rows]


def campaign(cid):
    r = db().execute("SELECT * FROM campaigns WHERE id = ?", (cid,)).fetchone()
    return dict(r) if r else None


def videos():
    """Toutes les videos. Celles sans date passent en dernier — sinon la
    chaine vide se trierait avant toutes les vraies dates."""
    rows = db().execute("""
        SELECT v.*, c.name AS campaign_name
        FROM videos v LEFT JOIN campaigns c ON c.id = v.campaign_id
        ORDER BY CASE WHEN v.publish_date = '' THEN 1 ELSE 0 END,
                 v.publish_date, v.id DESC
    """).fetchall()
    return [dict(r) for r in rows]


def video_by_path(path):
    r = db().execute("SELECT * FROM videos WHERE file_path = ?", (str(path),)).fetchone()
    return dict(r) if r else None


# ------------------------------------------------------------------
# Ecriture
# ------------------------------------------------------------------

def _clean(data, cols):
    """Ne garde que les colonnes autorisees, et normalise les valeurs.

    Toutes les colonnes texte sont NOT NULL: un None venant du JSON
    deviendrait une erreur d'insertion, on le ramene a la chaine vide."""
    out = {}
    for k in cols:
        if k not in data:
            continue
        v = data[k]
        if k in ("campaign_id",):
            out[k] = int(v) if str(v or "").strip().isdigit() else None
        else:
            out[k] = "" if v is None else str(v)
    return out


# LE WARMUP DEMARRE QUAND LE COMPTE ARRIVE (22/11) : entrer le pseudo
# TikTok ou Instagram d'une campagne pose l'heure de depart de son warmup
# (`*_warm_at`, la meme colonne que l'onboarding), et sa pastille porte une
# aura orange tant qu'il dure (`warm_h`, 48 h par defaut) — on voit d'un
# coup d'oeil quelle campagne vient de commencer. Seulement quand le pseudo
# APPARAIT (vide -> rempli) et que le compte n'a pas deja de depart : un
# pseudo corrige ne relance pas la chauffe. En onboarding, c'est le clic
# « warmup » qui decide, pas la saisie.
WARM_AUTO = ("tt", "ig")


def _warmup_au_pseudo(d, avant=None):
    avant = avant or {}
    if (d.get("stage", avant.get("stage")) or "") == "onbo":
        return d
    for p in WARM_AUTO:
        neuf = (d.get(f"{p}_handle") or "").strip()
        if neuf and not (avant.get(f"{p}_handle") or "").strip() \
                and not (d.get(f"{p}_warm_at") or avant.get(f"{p}_warm_at") or "").strip():
            d[f"{p}_warm_at"] = str(int(time.time()))
    return d


def create_campaign(data):
    d = _clean(data, CAMPAIGN_COLS)
    if not d.get("name", "").strip():
        raise PlateauError("Le nom de la campagne est requis")
    d = _warmup_au_pseudo(d)
    con = db()
    keys = list(d)
    cur = con.execute(
        f"INSERT INTO campaigns ({','.join(keys)}) VALUES ({','.join('?' * len(keys))})",
        [d[k] for k in keys])
    con.commit()
    return cur.lastrowid


def update_campaign(cid, data):
    d = _clean(data, CAMPAIGN_COLS)
    if "name" in d and not d["name"].strip():
        raise PlateauError("Le nom de la campagne est requis")
    if not d:
        raise PlateauError("Rien à modifier")
    if any(f"{p}_handle" in d for p in WARM_AUTO):
        d = _warmup_au_pseudo(d, campaign(cid) or {})
    con = db()
    con.execute(f"UPDATE campaigns SET {','.join(k + ' = ?' for k in d)} WHERE id = ?",
                [d[k] for k in d] + [cid])
    con.commit()
    return con.total_changes


def delete_campaign(cid):
    """Supprime la campagne. Ses videos sont conservees (la cle etrangere
    est ON DELETE SET NULL) — on ne veut pas perdre un historique de
    publication parce qu'un deal se termine."""
    con = db()
    con.execute("DELETE FROM campaigns WHERE id = ?", (cid,))
    con.execute("DELETE FROM posts_kept WHERE campaign_id = ?", (cid,))
    con.commit()


def create_video(data):
    d = _clean(data, VIDEO_COLS)
    if not d.get("title", "").strip():
        raise PlateauError("Le titre est requis")
    if d.get("status") and d["status"] not in STATUSES:
        raise PlateauError(f"Statut inconnu : {d['status']}")
    con = db()
    keys = list(d)
    cur = con.execute(
        f"INSERT INTO videos ({','.join(keys)}) VALUES ({','.join('?' * len(keys))})",
        [d[k] for k in keys])
    con.commit()
    return cur.lastrowid


def update_video(vid, data):
    d = _clean(data, VIDEO_COLS)
    if "title" in d and not d["title"].strip():
        raise PlateauError("Le titre est requis")
    if d.get("status") and d["status"] not in STATUSES:
        raise PlateauError(f"Statut inconnu : {d['status']}")
    if not d:
        raise PlateauError("Rien à modifier")
    con = db()
    con.execute(f"UPDATE videos SET {','.join(k + ' = ?' for k in d)} WHERE id = ?",
                [d[k] for k in d] + [vid])
    con.commit()


def delete_video(vid, keep_posted=False):
    """Supprime une video du pipeline.

    `keep_posted` sert aux suppressions en masse (vider les videos
    generees): la video s'en va, mais si elle avait ete postee le compteur
    du jour ne doit pas reculer. Une suppression a l'unite, elle, est un
    geste delibere sur cette ligne precise: elle emporte tout."""
    con = db()
    if keep_posted:
        _keep_posted(con, "id = ?", (vid,))
    con.execute("DELETE FROM videos WHERE id = ?", (vid,))
    con.commit()


def _keep_posted(con, where, params):
    """Met de cote les publications des videos que `where` va supprimer.

    A appeler AVANT le DELETE, sinon il n'y a plus rien a compter."""
    rows = con.execute(
        "SELECT campaign_id, publish_date, COUNT(*) AS n FROM videos "
        f"WHERE ({where}) AND status = 'Posté' AND publish_date != '' "
        "AND campaign_id IS NOT NULL GROUP BY campaign_id, publish_date",
        params).fetchall()
    for r in rows:
        con.execute(
            "INSERT INTO posts_kept (campaign_id, day, n) VALUES (?,?,?) "
            "ON CONFLICT(campaign_id, day) DO UPDATE SET n = n + excluded.n",
            (r["campaign_id"], r["publish_date"], r["n"]))
    return sum(r["n"] for r in rows)


# ------------------------------------------------------------------
# Le pont avec le moteur de generation
# ------------------------------------------------------------------

def log_generation(serie_id, name, at=None):
    """Inscrit une generation au journal. Idempotent sur (serie, nom)."""
    import time as _t
    con = db()
    seen = con.execute("SELECT 1 FROM generations WHERE serie_id = ? AND name = ?",
                       (serie_id, name)).fetchone()
    if seen:
        return False
    con.execute("INSERT INTO generations (serie_id, name, at) VALUES (?,?,?)",
                (serie_id, name, float(at if at is not None else _t.time())))
    con.commit()
    return True


def generated_since(ts, serie_id=None):
    """Nombre de videos generees depuis `ts` (horodatage Unix)."""
    if serie_id is None:
        return db().execute("SELECT COUNT(*) FROM generations WHERE at >= ?",
                            (float(ts),)).fetchone()[0]
    return db().execute(
        "SELECT COUNT(*) FROM generations WHERE at >= ? AND serie_id = ?",
        (float(ts), serie_id)).fetchone()[0]


def generated_total(serie_id):
    """Tout ce qui est sorti de cette serie depuis toujours.

    Le journal, pas les fichiers: vider les videos generees ne rend pas
    les combinaisons de clips neuves. C'est ce compte qui dit si une
    recette commence a se repeter."""
    return db().execute("SELECT COUNT(*) FROM generations WHERE serie_id = ?",
                        (serie_id,)).fetchone()[0]


# ------------------------------------------------------------------
# Prospection Reddit
# ------------------------------------------------------------------

def ajouter_prospect(p):
    """Range une annonce. Renvoie True si elle est nouvelle.

    `INSERT OR IGNORE` sur `reddit_id`: une annonce deja jugee (acceptee
    ou refusee) ne doit pas remonter dans la pile au passage suivant."""
    import time as _t
    con = db()
    cur = con.execute(
        "INSERT OR IGNORE INTO prospects "
        "(reddit_id,titre,texte,auteur,sub,url,montant,parle,publie_at,vu_at,"
        " cpm,tiktok,doit_poster) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (p["id"], p["titre"][:300], p["texte"][:4000], p["auteur"], p["sub"],
         p["url"], int(p.get("montant") or 0), int(p.get("parle") or 0),
         float(p.get("quand") or 0), _t.time(),
         int(p.get("cpm") or 0), int(p.get("tiktok") or 0),
         int(p.get("doit_poster") or 0)))
    con.commit()
    return cur.rowcount > 0


def prospects(statut=None, limite=200):
    q = "SELECT * FROM prospects"
    args = []
    if statut:
        q += " WHERE statut = ?"
        args.append(statut)
    q += " ORDER BY publie_at DESC LIMIT ?"
    args.append(int(limite))
    return [dict(r) for r in db().execute(q, args)]


def compter_prospects():
    return {r["statut"]: r["n"] for r in db().execute(
        "SELECT statut, COUNT(*) AS n FROM prospects GROUP BY statut")}


def juger_prospect(pid, statut, message=None):
    """`statut` = nouveau | accepte | refuse | envoye."""
    if statut not in ("nouveau", "accepte", "refuse", "envoye"):
        raise PlateauError("Statut inconnu")
    con = db()
    if message is None:
        con.execute("UPDATE prospects SET statut=? WHERE id=?", (statut, int(pid)))
    else:
        con.execute("UPDATE prospects SET statut=?, message=? WHERE id=?",
                    (statut, str(message)[:4000], int(pid)))
    con.commit()
    return True


def forget_series(serie_id):
    """Supprime les videos d'une serie du pipeline.

    Le journal des generations reste, et les publications deja faites sont
    mises de cote: on vide des fichiers, pas un historique."""
    con = db()
    _keep_posted(con, "serie_id = ?", (serie_id,))
    n = con.execute("DELETE FROM videos WHERE serie_id = ?", (serie_id,)).rowcount
    con.commit()
    return n


def series_video_paths(serie_id):
    """Chemins des fichiers qu'une serie a produits, d'apres le pipeline.

    C'est la seule trace fiable de « qui a fait quoi » quand deux series
    partagent un dossier de sortie: le nom du fichier ne dit pas de quelle
    serie il sort. A lire AVANT forget_series, qui efface ces lignes."""
    rows = db().execute(
        "SELECT file_path FROM videos WHERE serie_id = ? AND file_path != ''",
        (serie_id,)).fetchall()
    return [r[0] for r in rows]


def forget_all_generated():
    """Supprime du pipeline toutes les videos issues du moteur."""
    con = db()
    _keep_posted(con, "serie_id != ''", ())
    n = con.execute("DELETE FROM videos WHERE serie_id != ''").rowcount
    con.commit()
    return n


def register_output(path, serie_id, serie_name, campaign_id=None, status="Prêt"):
    """Inscrit une video fraichement generee dans le pipeline.

    C'est ce qui justifie la fusion: sans ca, il faudrait ressaisir a la
    main dans le calendrier chaque video sortie du moteur. Idempotent —
    regenerer ne cree pas de doublon pour un meme fichier."""
    path = str(path)
    if video_by_path(path):
        return None
    stamp = Path(path).stem
    return create_video({
        "title": f"{serie_name} — {stamp}",
        "campaign_id": campaign_id,
        "serie_id": serie_id,
        "status": status,
        "file_path": path,
    })


def mark_posted(path, when=""):
    """Passe une video a « Posté ». Appele apres un envoi Buffer reussi."""
    v = video_by_path(str(path))
    if not v:
        return False
    data = {"status": "Posté"}
    if when:
        data["publish_date"] = when
    update_video(v["id"], data)
    return True


# Mots qui trahissent un forfait PERIODIQUE et non un tarif par video.
# « 750/month » est un montant mensuel: le compter comme un tarif par video
# ferait grimper le total du jour d'un argent qu'on ne touche pas a chaque
# publication.
_PERIODES = ("mois", "month", "semaine", "week", "jour", "day",
             "année", "annee", "year", "/an", "/mo", "hebdo")


def per_video_amount(c):
    """Ce que rapporte UNE publication, ou 0 si ce n'est pas ce modele-la.

    `pay_per_video` gagne quand il est rempli: c'est le champ structure.
    Sinon on lit `base_pay`, du texte libre negocie avec le client
    (« 16$/video », « 33/video », « 30$ »).

    Rendre 0 est un resultat normal, pas un echec: une campagne au CPM ne
    rapporte pas un montant connu a la publication — ca depend des vues —
    et un forfait mensuel ne se decoupe pas par video. Dans les deux cas on
    n'affiche rien plutot qu'un chiffre invente."""
    v = _nombre(c.get("pay_per_video"))
    if v > 0:
        return v
    txt = str(c.get("base_pay") or "").strip().lower()
    if not txt or any(mot in txt for mot in _PERIODES):
        return 0.0
    return _nombre(txt)


def target_of(c):
    """Objectif de publications par jour pour cette campagne.

    L'objectif saisi a la main gagne toujours: `frequency` est du texte
    libre negocie avec le client (« 1 par jours »), alors que
    `daily_target` est ce que TOI tu vises — utile sur un deal au CPM, ou
    le client n'impose rien."""
    t = str(c.get("daily_target") or "").strip()
    if t.isdigit() and int(t) > 0:
        return int(t)
    return daily_quota(c.get("frequency"))


def posted_today(cid, day=None):
    """Nombre de publications de cette campagne aujourd'hui.

    Deux sources qui s'additionnent: les videos encore dans le pipeline, et
    celles qui ont ete supprimees en masse apres coup (`posts_kept`). Sans
    la seconde, vider les videos generees ferait reculer le compteur du
    jour, alors qu'on a bel et bien poste."""
    day = day or _today()
    con = db()
    n = con.execute(
        "SELECT COUNT(*) FROM videos WHERE campaign_id = ? "
        "AND status = 'Posté' AND publish_date = ?", (cid, day)).fetchone()[0]
    return n + _kept(cid, day)


def _kept(cid, day):
    row = db().execute("SELECT n FROM posts_kept WHERE campaign_id = ? AND day = ?",
                       (cid, day)).fetchone()
    return max(0, row["n"]) if row else 0


def _today():
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d")


def journal_du_jour(cid, day=None):
    """Les +1 / -1 enregistres aujourd'hui pour cette campagne."""
    day = day or _today()
    return [dict(r) for r in db().execute(
        "SELECT * FROM journal_posts WHERE campaign_id=? AND day=? ORDER BY id",
        (cid, day))]


def _noter_post(con, cid, day, delta):
    """Compte du jour, et trace en AJOUT SEUL de ce qui vient d'etre fait.

    Le compteur se deduit de vraies videos — c'est voulu, tout raconte la
    meme chose. Mais une ligne de video peut disparaitre ou changer de
    statut par plusieurs chemins, et le compteur recule alors sans qu'on
    sache pourquoi. Ce journal ne sert a rien d'autre qu'a repondre a la
    question « j'etais a 6, pourquoi suis-je a 3 »."""
    import time as _t
    n = posted_today(cid, day)
    con.execute("INSERT INTO journal_posts (campaign_id,day,delta,apres,at) "
                "VALUES (?,?,?,?,?)", (cid, day, 1 if delta > 0 else -1, n, _t.time()))
    con.commit()
    return n


def bump_posted(cid, delta):
    """Marque (+1) ou demarque (-1) une video comme postee aujourd'hui.

    On ne tient pas un compteur separe: on agit sur de vraies videos, pour
    que le calendrier, le pipeline et ce compteur racontent toujours la
    meme chose.

    +1 prend en priorite une video deja prete (c'est le vrai geste: on a
    genere, on poste). S'il n'y en a plus, on cree une ligne pour garder
    la trace du post.
    -1 remet la derniere postee du jour en « Prêt », ou supprime la ligne
    si elle avait ete creee par ce meme bouton."""
    day = _today()
    con = db()
    if delta > 0:
        row = con.execute(
            "SELECT id FROM videos WHERE campaign_id = ? AND status = 'Prêt' "
            "ORDER BY publish_date = '' DESC, publish_date, id LIMIT 1",
            (cid,)).fetchone()
        if row:
            update_video(row["id"], {"status": "Posté", "publish_date": day})
        else:
            c = campaign(cid) or {}
            create_video({"title": f"{c.get('name','Campagne')} — post du {day}",
                          "campaign_id": cid, "status": "Posté",
                          "publish_date": day, "notes": "Ajouté depuis le suivi du jour"})
    elif delta < 0:
        row = con.execute(
            "SELECT id, notes, file_path FROM videos WHERE campaign_id = ? "
            "AND status = 'Posté' AND publish_date = ? ORDER BY id DESC LIMIT 1",
            (cid, day)).fetchone()
        if not row:
            # Plus de ligne a defaire: on retire alors une publication mise
            # de cote, sinon le bouton moins resterait sans effet apres un
            # « tout supprimer ».
            if _kept(cid, day):
                con.execute("UPDATE posts_kept SET n = n - 1 "
                            "WHERE campaign_id = ? AND day = ?", (cid, day))
                con.execute("DELETE FROM posts_kept WHERE campaign_id = ? "
                            "AND day = ? AND n <= 0", (cid, day))
                con.commit()
            return _noter_post(con, cid, day, delta)
        if row["notes"] == "Ajouté depuis le suivi du jour" and not row["file_path"]:
            delete_video(row["id"])
        else:
            update_video(row["id"], {"status": "Prêt", "publish_date": ""})
    return _noter_post(con, cid, day, delta)


def _avance(d, cycle, n=1):
    """Avance une date de `n` cycles."""
    jours = cycle_jours(cycle)
    if jours:
        return d + timedelta(days=jours * n)
    # mensuel: meme quantieme le mois suivant. Le 31 janvier avance au
    # 28/29 fevrier plutot que de deborder sur mars.
    mois = d.month - 1 + n
    an = d.year + mois // 12
    mois = mois % 12 + 1
    dernier = calendar.monthrange(an, mois)[1]
    return date(an, mois, min(d.day, dernier))


def next_payment(c, today=None):
    """Prochaine echeance de paiement d'une campagne.

    Renvoie None si la campagne n'a pas de suivi de paiement, sinon
    {date, montant, videos, depuis, cycle}. Le montant est le nombre de
    videos postees depuis l'echeance PRECEDENTE, multiplie par le tarif —
    c'est ce qu'on doit toucher a la prochaine.
    """
    cycle = str(c.get("pay_cycle") or "").strip()
    if not cycle_valide(cycle):
        return None
    ancre = _date(c.get("pay_anchor"))
    if not ancre:
        return None

    today = today or date.today()
    # On recalcule TOUJOURS depuis l'ancre, jamais de proche en proche.
    # En avancant pas a pas, un paiement le 31 janvier donnait le 28
    # fevrier (correct), puis le 28 mars (faux): le quantieme d'origine
    # etait perdu des le premier mois court.
    n = 0
    suivante = ancre
    while suivante < today and n < 2000:
        n += 1
        suivante = _avance(ancre, cycle, n)
    precedente = _avance(ancre, cycle, n - 1) if n else _avance(ancre, cycle, -1)

    tarif = _nombre(c.get("pay_per_video"))
    # Le compte se fait TOUJOURS, meme sans tarif: savoir combien de videos
    # tombent dans la periode est utile en soi. Seul le montant depend du
    # tarif. (Avant, une campagne qui suivait ses dates sans declarer de
    # tarif affichait « 0 vidéo » alors qu'elle en avait.)
    n = db().execute(
        "SELECT COUNT(*) FROM videos WHERE campaign_id = ? AND status = 'Posté' "
        "AND publish_date >= ? AND publish_date < ?",
        (c["id"], precedente.isoformat(), suivante.isoformat())).fetchone()[0]
    return {"date": suivante.isoformat(), "depuis": precedente.isoformat(),
            "cycle": cycle, "cycle_label": cycle_label(cycle), "videos": n,
            "tarif": tarif, "montant": round(n * tarif, 2) if tarif else 0,
            "jours": (suivante - today).days}


def _date(v):
    try:
        return date.fromisoformat(str(v or "")[:10])
    except ValueError:
        return None


def _nombre(v):
    """Lit un montant saisi a la main: « 16 », « 16$ », « 16,50 »."""
    txt = str(v or "").replace(",", ".")
    m = re.search(r"\d+(?:\.\d+)?", txt)
    return float(m.group(0)) if m else 0.0


def daily_quota(frequency):
    """Nombre de videos par jour lu dans le champ libre `frequency`.

    Le champ est saisi a la main (« 1 par jours », « 3 per day »,
    « 2 / semaine »). On ne renvoie un nombre que si la phrase parle bien
    d'un rythme quotidien — « 3 par semaine » ne doit pas devenir 3/jour."""
    txt = str(frequency or "")
    m = re.search(r"(\d+)", txt)
    if not m:
        return None
    if re.search(r"semaine|week|mois|month", txt, re.I):
        return None
    if not re.search(r"jour|day|quotidien|daily", txt, re.I):
        return None
    return int(m.group(1))


# ------------------------------------------------------------------
# Liste de taches et idees de contenu
# ------------------------------------------------------------------

# Rubriques des idees de contenu. Liste blanche: `section` finit dans une
# requete, et une valeur libre ferait apparaitre des colonnes fantomes a
# l'ecran.
IDEA_SECTIONS = ["ugc", "histoire", "thoughts", "trading", "autre"]
IDEA_LABELS = {"ugc": "UGC", "histoire": "Histoire", "thoughts": "Thoughts",
               "trading": "Trading", "autre": "Autre"}


def tasks(day=None):
    """Les taches a montrer aujourd'hui, avec leur etat du jour.

    Rien n'est recalcule ni deplace au changement de date: l'etat se deduit
    de `done_on`. Une tache ponctuelle cochee un AUTRE jour que celui
    demande est retiree de la liste — elle est finie. Une tache jamais
    cochee reste, quel que soit son age: c'est le report d'un jour a
    l'autre."""
    day = day or _today()
    out = []
    for r in db().execute("SELECT * FROM tasks ORDER BY recurrent DESC, id"):
        t = dict(r)
        if not t["recurrent"] and t["done_on"] and t["done_on"] != day:
            continue
        t["done"] = (t["done_on"] == day)
        out.append(t)
    return out


def create_task(text, recurrent=False):
    text = str(text or "").strip()
    if not text:
        raise PlateauError("La tâche est vide")
    con = db()
    cur = con.execute("INSERT INTO tasks (text, recurrent) VALUES (?,?)",
                      (text[:500], 1 if recurrent else 0))
    con.commit()
    return cur.lastrowid


def update_task(tid, text=None, done=None, recurrent=None, day=None):
    sets, vals = [], []
    if text is not None:
        t = str(text).strip()
        if not t:
            raise PlateauError("La tâche est vide")
        sets.append("text = ?")
        vals.append(t[:500])
    if done is not None:
        # Cocher, c'est inscrire LE JOUR. Decocher efface: la tache
        # redevient a faire, et repartira donc demain comme aujourd'hui.
        sets.append("done_on = ?")
        vals.append((day or _today()) if done else "")
    if recurrent is not None:
        sets.append("recurrent = ?")
        vals.append(1 if recurrent else 0)
    if not sets:
        raise PlateauError("Rien à modifier")
    con = db()
    con.execute(f"UPDATE tasks SET {','.join(sets)} WHERE id = ?", vals + [tid])
    con.commit()


def delete_task(tid):
    con = db()
    con.execute("DELETE FROM tasks WHERE id = ?", (tid,))
    con.commit()


def ideas():
    return [dict(r) for r in
            db().execute("SELECT * FROM ideas ORDER BY id DESC")]


def create_idea(text, section="autre"):
    text = str(text or "").strip()
    if not text:
        raise PlateauError("L'idée est vide")
    section = str(section or "autre").strip().lower()
    if section not in IDEA_SECTIONS:
        section = "autre"
    con = db()
    cur = con.execute("INSERT INTO ideas (text, section) VALUES (?,?)",
                      (text[:2000], section))
    con.commit()
    return cur.lastrowid


def update_idea(iid, text=None, section=None):
    sets, vals = [], []
    if text is not None:
        t = str(text).strip()
        if not t:
            raise PlateauError("L'idée est vide")
        sets.append("text = ?")
        vals.append(t[:2000])
    if section is not None:
        s = str(section).strip().lower()
        if s not in IDEA_SECTIONS:
            raise PlateauError(f"Rubrique inconnue : {section}")
        sets.append("section = ?")
        vals.append(s)
    if not sets:
        raise PlateauError("Rien à modifier")
    con = db()
    con.execute(f"UPDATE ideas SET {','.join(sets)} WHERE id = ?", vals + [iid])
    con.commit()


def delete_idea(iid):
    con = db()
    con.execute("DELETE FROM ideas WHERE id = ?", (iid,))
    con.commit()
