"""LE PLATEAU SUR LE TELEPHONE (23/11).

On filme avec son telephone : c'est de la que partent les clips et la
prise du jour, et c'est la qu'on veut recuperer la video montee pour la
poster. Le telephone ouvre donc une PETITE page servie par l'ordinateur,
sur le meme wifi.

Ce module ne connait ni les series ni le serveur : il tient QUI a le droit
d'entrer. Les routes sont dans `server.HandlerTel`.

Trois choix, a ne pas defaire :

- ETEINT PAR DEFAUT. Ouvrir un port sur le reseau de la maison est une
  decision de la personne, pas de l'app.
- UN CODE, TAPE UNE FOIS PAR TELEPHONE. Six chiffres ; le telephone recoit
  en echange un jeton long, garde dans un cookie. On ne range ici que
  l'EMPREINTE du jeton : lire `telephone.json` ne donne pas l'entree.
  Cinq essais rates ferment la porte dix minutes — un million de codes a
  cinq essais par dix minutes, ca fait 0,07 % de chances par jour.
- LE TELEPHONE NE PARLE JAMAIS AU SERVEUR PRINCIPAL. Celui-la reste sur
  127.0.0.1 (voir `Handler.porte`) et connait les mots de passe des
  comptes ; le telephone a son propre port et une liste fermee de routes.

La connexion n'est PAS chiffree (http sur le wifi) : quelqu'un qui ecoute
le meme wifi peut voir passer une video. C'est pour ca que rien de ce que
le telephone peut lire ne contient un mot de passe ou une cle.
"""
import hashlib
import hmac
import ipaddress
import json
import os
import secrets
import socket
import subprocess
import threading
import time

from chemins import DONNEES

FICHIER = DONNEES / "telephone.json"
VERROU = threading.Lock()
ESSAIS_MAX = 5
BLOCAGE_S = 600
TELEPHONES_MAX = 10          # au-dela, le plus ancien sort
COOKIE = "plateau_tel"

_etat = None                 # {"actif": bool, "code": str, "jetons": {empreinte: {...}}}
_rates = []                  # instants des essais rates (memoire seule)


def _charger():
    global _etat
    if _etat is None:
        try:
            d = json.loads(FICHIER.read_text())
        except (OSError, ValueError):
            d = {}
        _etat = {"actif": bool(d.get("actif")), "code": str(d.get("code") or ""),
                 "jetons": d.get("jetons") if isinstance(d.get("jetons"), dict) else {}}
    return _etat


def _ecrire():
    tmp = FICHIER.with_suffix(".part")
    tmp.write_text(json.dumps(_etat, indent=1, ensure_ascii=False))
    os.chmod(str(tmp), 0o600)          # le code d'entree est dedans
    os.replace(str(tmp), str(FICHIER))


def _code_neuf():
    return f"{secrets.randbelow(1000000):06d}"


def _empreinte(jeton):
    return hashlib.sha256(str(jeton).encode("utf-8")).hexdigest()


def etat():
    with VERROU:
        e = _charger()
        return {"actif": e["actif"], "code": e["code"], "telephones": len(e["jetons"])}


def regler(actif=None, debrancher=False):
    """Allume, eteint, ou met tous les telephones dehors (nouveau code)."""
    with VERROU:
        e = _charger()
        # Un reglage vient de l'ORDINATEUR : il leve aussi le blocage des
        # essais rates — sinon cinq mauvais codes tapes par un autre
        # fermeraient la porte dix minutes a la personne elle-meme.
        _rates.clear()
        if debrancher:
            e["jetons"] = {}
            e["code"] = _code_neuf()
        if actif is not None:
            e["actif"] = bool(actif)
        if e["actif"] and not e["code"]:
            e["code"] = _code_neuf()
        _ecrire()
    return etat()


def entrer(code, nom=""):
    """-> (jeton, "") si le code est bon, ("", raison) sinon."""
    with VERROU:
        e = _charger()
        t = time.time()
        _rates[:] = [x for x in _rates if t - x < BLOCAGE_S]
        if len(_rates) >= ESSAIS_MAX:
            return "", f"Trop d'essais — réessaie dans {int((BLOCAGE_S - (t - _rates[0])) // 60) + 1} min"
        saisi = "".join(ch for ch in str(code or "") if ch.isdigit())
        if not e["actif"] or not e["code"] or not hmac.compare_digest(saisi, e["code"]):
            _rates.append(t)
            return "", "Code refusé"
        jeton = secrets.token_urlsafe(32)
        e["jetons"][_empreinte(jeton)] = {"nom": str(nom or "")[:60], "le": int(t)}
        while len(e["jetons"]) > TELEPHONES_MAX:
            del e["jetons"][min(e["jetons"], key=lambda k: e["jetons"][k].get("le", 0))]
        _ecrire()
        return jeton, ""


def connu(jeton):
    if not jeton:
        return False
    with VERROU:
        e = _charger()
        return bool(e["actif"]) and _empreinte(jeton) in e["jetons"]


def sortir(jeton):
    with VERROU:
        e = _charger()
        if e["jetons"].pop(_empreinte(jeton), None) is not None:
            _ecrire()


def du_reseau_local(ip):
    """Le telephone est-il sur le meme reseau ? Une adresse publique n'a
    rien a faire ici : le port ne doit servir que la maison."""
    try:
        a = ipaddress.ip_address(str(ip).split("%")[0])
    except ValueError:
        return False
    if getattr(a, "ipv4_mapped", None):
        a = a.ipv4_mapped
    return a.is_private or a.is_loopback or a.is_link_local


def adresse_ip():
    """L'adresse de l'ordinateur sur le wifi. Une socket UDP « connectee »
    n'envoie RIEN : elle fait seulement choisir au systeme la carte reseau
    qui sortirait, et on lit son adresse."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()
    return ip if du_reseau_local(ip) and not ip.startswith("127.") else ""


def nom_local():
    """« Mon-Mac.local » : le nom que le Mac annonce sur le reseau. Il ne
    change pas quand la box redonne une autre adresse — l'icone posee sur
    l'ecran d'accueil du telephone continue de marcher."""
    try:
        if os.uname().sysname != "Darwin":
            return ""
        n = subprocess.run(["scutil", "--get", "LocalHostName"], capture_output=True,
                           text=True, timeout=3).stdout.strip()
    except (OSError, AttributeError, subprocess.SubprocessError):
        return ""
    return (n + ".local").lower() if n and all(c.isalnum() or c == "-" for c in n) else ""


def qr_png(texte):
    """Le QR de l'adresse, dessine par CoreImage (dans macOS, via PyObjC —
    deja la pour les textes). Ailleurs : None, et l'adresse se tape."""
    try:
        import AppKit                                   # noqa: PLC0415
        import Quartz                                   # noqa: PLC0415
        from Foundation import NSData                   # noqa: PLC0415
        b = str(texte).encode("utf-8")
        f = Quartz.CIFilter.filterWithName_("CIQRCodeGenerator")
        f.setValue_forKey_(NSData.dataWithBytes_length_(b, len(b)), "inputMessage")
        f.setValue_forKey_("M", "inputCorrectionLevel")
        img = f.outputImage().imageByApplyingTransform_(
            Quartz.CGAffineTransformMakeScale(10, 10))
        rep = AppKit.NSBitmapImageRep.alloc().initWithCIImage_(img)
        png = rep.representationUsingType_properties_(AppKit.NSBitmapImageFileTypePNG, {})
        return bytes(png) if png else None
    except Exception:                                   # noqa: BLE001
        return None
