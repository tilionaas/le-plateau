"""L'IA du plateau — Claude Code, celui qui est DEJA sur la machine.

Pas de cle d'API ni de SDK: on appelle le programme `claude` comme on
appelle `ffmpeg` ou `whisper-cli`. Il passe par le compte Claude de la
personne (son abonnement), et la regle « zero dependance » tient: rien a
installer cote Python.

Mesure le 09/11 sur le Mac de Tilio: une image + une question, 3,9 s de
bout en bout, reponse JSON validee par un schema. Ce qui coute ce temps,
c'est le DEMARRAGE de Claude Code, pas la reponse: on regroupe donc les
questions (un appel pour trier six clips, pas six appels).

Trois choix qui comptent, tous dans `demander`:
  --system-prompt   remplace le prompt de Claude Code (~20 000 jetons) par
                    le notre (~300). Sans ca, chaque question puisait dans
                    les limites de l'abonnement pour rien.
  --tools ""        aucun outil: Claude ne lit pas le disque, ne lance
                    rien. Il regarde ce qu'on lui donne et repond.
  --setting-sources "" et un dossier de travail neutre: le CLAUDE.md du
                    projet et celui de l'utilisateur ne sont pas charges —
                    ils parlent a un developpeur, pas a l'assistant.
Les images partent DANS le message (`--input-format stream-json`), en
base64: pas besoin d'ouvrir l'outil de lecture de fichiers, et pas de
tour de boucle par image.
"""
import base64
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path


class IAError(Exception):
    pass


# Ou chercher `claude` quand le PATH du serveur ne le voit pas: lance
# depuis le Finder (un .command), le PATH est celui de launchd, sans
# ~/.local/bin.
CANDIDATS = ("~/.local/bin/claude", "~/.local/bin/claude.exe",
             "~/AppData/Roaming/npm/claude.cmd", "/opt/homebrew/bin/claude",
             "/usr/local/bin/claude", "~/.claude/local/claude")

# Deux modeles, choisis par tache. Haiku pour le tri et les questions:
# rapide, et ca menage les limites de l'abonnement. Sonnet pour monter une
# campagne: un seul appel, et c'est lui qui decide de toute la recette.
RAPIDE = "haiku"
SOIGNE = "sonnet"

SYSTEME = (
    "Tu es l'assistant du plateau, une app locale de création de vidéos UGC "
    "(TikTok, Reels). Tu parles français québécois simple, direct, sans "
    "jargon technique: l'utilisateur n'est pas développeur. Tu ne promets "
    "jamais une fonction qui n'existe pas dans le plateau.")

# Taille des images envoyees. 360 px de large suffisent pour reconnaitre
# un plan et lire un texte a l'ecran, et une image de 360 x 640 coute
# ~300 jetons: trente plans tiennent dans un seul message.
LARGEUR = 360


def binaire():
    b = shutil.which("claude")
    if b:
        return b
    for c in CANDIDATS:
        p = Path(os.path.expanduser(c))
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    return None


def disponible():
    """(oui/non, raison). Ne lance rien: savoir si Claude Code est
    CONNECTE coute un appel, on l'apprend au premier vrai."""
    if not binaire():
        return False, ("Claude Code n'est pas installé sur cet ordinateur "
                       "(claude.com/claude-code)")
    return True, ""


def _neutre():
    d = Path(tempfile.gettempdir()) / "plateau-ia"
    d.mkdir(exist_ok=True)
    return str(d)


def demander(texte, images=(), schema=None, modele=RAPIDE, systeme=None,
             delai=300):
    """Une question a Claude. `images` = [(legende, octets jpeg)], posees
    AVANT le texte, chacune precedee de sa legende: « Plan 3 (2,4 s) »
    ne se devine pas sur l'image. Rend le JSON valide par `schema`, ou le
    texte de la reponse sans schema."""
    b = binaire()
    if not b:
        raise IAError(disponible()[1])
    contenu = []
    for legende, octets in images:
        if not octets:
            continue
        if legende:
            contenu.append({"type": "text", "text": legende})
        contenu.append({"type": "image", "source": {
            "type": "base64", "media_type": "image/jpeg",
            "data": base64.b64encode(octets).decode()}})
    contenu.append({"type": "text", "text": texte})
    msg = {"type": "user", "message": {"role": "user", "content": contenu}}
    cmd = [b, "-p", "--output-format", "stream-json", "--verbose",
           "--input-format", "stream-json", "--model", modele,
           "--system-prompt", systeme or SYSTEME,
           "--tools", "", "--setting-sources", "", "--strict-mcp-config",
           "--no-session-persistence"]
    if schema:
        cmd += ["--json-schema", json.dumps(schema)]
    try:
        p = subprocess.run(cmd, input=json.dumps(msg) + "\n", text=True,
                           capture_output=True, timeout=delai, cwd=_neutre())
    except subprocess.TimeoutExpired:
        raise IAError("Claude n'a pas répondu à temps — réessaie")
    fin = None
    for ligne in p.stdout.splitlines():
        try:
            d = json.loads(ligne)
        except ValueError:
            continue
        if d.get("type") == "result":
            fin = d
    if not fin:
        err = (p.stderr or p.stdout or "").strip()[-300:]
        raise IAError(_traduire(err) or "Claude Code n'a rien répondu")
    if fin.get("is_error"):
        raise IAError(_traduire(str(fin.get("result") or "")) or "Erreur de Claude Code")
    if schema:
        so = fin.get("structured_output")
        if so is None:
            try:
                so = json.loads(fin.get("result") or "")
            except ValueError:
                raise IAError("Réponse de Claude illisible — réessaie")
        return so
    return (fin.get("result") or "").strip()


def _traduire(err):
    """Les erreurs de Claude Code qu'on sait expliquer."""
    e = err.lower()
    if "login" in e or "api key" in e or "authenticat" in e or "oauth" in e:
        return ("Claude Code n'est pas connecté. Ouvre le Terminal, tape "
                "« claude », connecte-toi, puis réessaie.")
    if "usage limit" in e or "rate limit" in e or "limit reached" in e:
        return ("Limite de ton abonnement Claude atteinte pour l'instant — "
                "réessaie plus tard.")
    return err


# ------------------------------------------------------------------
# Images d'une video
# ------------------------------------------------------------------
def image(chemin, t, largeur=LARGEUR):
    """Une image du film a l'instant `t`, en JPEG."""
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t):.3f}", "-i", str(chemin),
         "-frames:v", "1", "-vf", f"scale={largeur}:-2",
         "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "5", "pipe:1"],
        capture_output=True)
    return p.stdout or None


def duree(chemin):
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "format=duration", "-of", "csv=p=0", str(chemin)],
                       capture_output=True, text=True)
    try:
        return float(p.stdout.strip())
    except ValueError:
        return 0.0


_SCD = re.compile(r"lavfi\.scd\.time:\s*([0-9.]+)")
# Memes reglages que l'atelier des templates (template.py, qui n'est pas
# dans la copie partagee — d'ou cette version a part): seuil 10 mesure sur
# des reels montes a la main, et un plan de moins de 0,25 s est un flash.
COUPE_SEUIL = 10.0
PLAN_MINI = 0.25
# Pour l'IA, le seuil est PLUS BAS que celui des templates. Un UGC filme
# souvent un ECRAN puis un autre ecran : la coupe change peu de pixels. Sur
# la reference TrueCurrent (« No way I've traded… »), deux des cinq coupes
# mesuraient 9,8 et 7,9 : a 10, la video sortait en 4 plans au lieu de 6.
# Une coupe en trop ne coute rien (Claude regroupe deux plans qui montrent
# la meme chose) ; une coupe manquee fond deux categories en une.
COUPE_SEUIL_IA = 5.0
# Au-dela, la video exemple est un tuto de dix minutes, pas un reel: on ne
# montre a Claude que les premiers plans.
PLANS_MAX = 30


def coupes_douces(chemin, fin):
    """Les changements de plan qui NE SONT PAS une coupe seche : fondu
    enchaine, fondu par le noir, flash, glissement. `scdet` compare deux
    images qui se suivent ; dans un fondu aucune paire ne change assez, et
    il ne voit rien — mesure le 23/11 sur quatre videos fabriquees : un
    fondu, un fondu par le noir et un glissement passaient pour UN seul
    plan. Or une coupe manquee fond deux categories en une.

    Une passe sur tout le film (15 images/s, 32x57 en gris) :
      - un CREUX noir ou un ECLAIR blanc entre deux zones normales ;
      - un changement ETALE sur 3 images ou plus (0,2 s), au bout duquel
        l'image n'est plus la meme. Une coupe seche tient en une image.
    -> les instants, a ajouter aux coupes de scdet."""
    cad, px = 15, 32 * 57
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-t", "180", "-i", str(chemin),
         "-vf", f"fps={cad},scale=32:57,format=gray", "-f", "rawvideo", "pipe:1"],
        capture_output=True)
    n = len(p.stdout) // px
    if n < 8:
        return []
    F = [p.stdout[i * px:(i + 1) * px] for i in range(n)]
    L = [sum(f) / px for f in F]
    dif = lambda a, b: sum(abs(x - y) for x, y in zip(a, b)) / px       # noqa: E731
    D = [0.0] + [dif(F[i], F[i - 1]) for i in range(1, n)]
    out, pris = [], [False] * n
    voisin = int(cad * 0.6)
    # Creux noir / eclair blanc : l'extreme, s'il y a de l'image normale des
    # deux cotes (un film qui s'OUVRE du noir n'est pas une coupe).
    for i in range(1, n - 1):
        g, d = L[max(0, i - voisin):i], L[i + 1:i + 1 + voisin]
        if not g or not d or pris[i]:
            continue
        if (L[i] < 22 and L[i] <= min(g + d) and max(g) > L[i] + 20 and max(d) > L[i] + 20) \
                or (L[i] > 215 and L[i] >= max(g + d) and min(g) < L[i] - 35
                    and min(d) < L[i] - 35):
            out.append(i / cad)
            for j in range(max(0, i - voisin), min(n, i + voisin + 1)):
                pris[j] = True
    # Changement etale. « Change » se juge contre le mouvement HABITUEL du
    # film (la mediane) : une personne qui gesticule fait deja 4 a 6 par
    # image, et un seuil fixe a 3,5 voyait une « transition » de dix
    # secondes — trop longue, donc jetee, et le vrai fondu avec elle.
    seuil = max(3.5, 1.8 * sorted(D)[n // 2])
    i = 1
    while i < n:
        if D[i] > seuil and not pris[i]:
            j = i
            while j + 1 < n and D[j + 1] > seuil and not pris[j + 1]:
                j += 1
            k = j - i + 1
            # Plus d'1,2 s : ce n'est plus une transition, c'est un plan
            # qui bouge. Et l'image d'arrivee doit etre une AUTRE image.
            if 3 <= k <= int(cad * 1.2) and dif(F[i - 1], F[j]) > 20:
                out.append((i - 1) / cad)
            i = j + 1
        else:
            i += 1
    return sorted(round(t, 3) for t in out if 0.25 < t < fin - 0.25)


def plans(chemin):
    """[(debut, fin)] de chaque plan de la video exemple."""
    fin = duree(chemin)
    if fin <= 0:
        raise IAError("La vidéo exemple est illisible")
    p = subprocess.run(["ffmpeg", "-v", "info", "-i", str(chemin), "-vf",
                        f"scdet=threshold={COUPE_SEUIL_IA}", "-f", "null", "-"],
                       capture_output=True, text=True)
    cs = sorted({round(float(t), 3) for t in _SCD.findall(p.stderr)})
    # Les coupes douces, sauf la ou scdet a deja coupe (a 0,3 s pres : un
    # flash se voit des deux facons, et une seule coupe suffit).
    try:
        for t in coupes_douces(chemin, fin):
            if all(abs(t - c) > 0.3 for c in cs):
                cs.append(t)
        cs.sort()
    except Exception:                                   # noqa: BLE001
        pass
    bornes = [0.0] + [t for t in cs if 0 < t < fin] + [fin]
    out = []
    for a, b in zip(bornes, bornes[1:]):
        if out and (b - a) < PLAN_MINI:
            out[-1] = (out[-1][0], b)
        else:
            out.append((a, b))
    if len(out) > 1 and out[0][1] - out[0][0] < PLAN_MINI:
        out[1] = (out[0][0], out[1][1])
        out.pop(0)
    return [(round(a, 3), round(b, 3)) for a, b in out][:PLANS_MAX]


# ------------------------------------------------------------------
# Monter une campagne depuis un brief et une video exemple
# ------------------------------------------------------------------
SCHEMA_CAMPAGNE = {
    "type": "object", "additionalProperties": False,
    "required": ["resume", "campagne", "serie", "reglages", "tournage", "questions"],
    "properties": {
        "resume": {"type": "string"},
        "campagne": {
            "type": "object", "additionalProperties": False,
            "required": ["nom", "plateformes", "objectif_jour", "paie_par_video",
                         "cycle_paie", "base_pay", "min_vues", "bonus", "cpm",
                         "frequence", "notes"],
            "properties": {
                "nom": {"type": "string"},
                "plateformes": {"type": "array", "items": {
                    "type": "string", "enum": ["ig", "tt", "yt", "fb"]}},
                "objectif_jour": {"type": "integer"},
                "paie_par_video": {"type": "number"},
                "cycle_paie": {"type": "string", "enum": ["", "hebdo", "2sem", "mensuel"]},
                "base_pay": {"type": "string"},
                "min_vues": {"type": "integer"},
                "bonus": {"type": "string"},
                "cpm": {"type": "string"},
                "frequence": {"type": "string"},
                "notes": {"type": "string"}}},
        "serie": {
            "type": "object", "additionalProperties": False,
            "required": ["nom", "format", "parle", "prise", "categories"],
            "properties": {
                "nom": {"type": "string"},
                "format": {"type": "string", "enum": ["plein", "split"]},
                "parle": {"type": "boolean"},
                "prise": {"type": "boolean"},
                "categories": {"type": "array", "items": {
                    "type": "object", "additionalProperties": False,
                    "required": ["nom", "role", "plans", "duree", "delta",
                                 "texte", "position", "son", "complet", "consigne", "script",
                                 "silences", "musique_ici", "miroir",
                                 "zoom_de", "zoom_a", "transition", "transition_duree"],
                    "properties": {
                        "nom": {"type": "string"},
                        "role": {"type": "string", "enum": ["", "haut", "bas", "etape"]},
                        "plans": {"type": "array", "items": {"type": "integer"}},
                        "duree": {"type": "number"},
                        "delta": {"type": "number"},
                        "texte": {"type": "string"},
                        "position": {"type": "string", "enum": ["haut", "milieu", "bas"]},
                        "son": {"type": "boolean"},
                        "complet": {"type": "boolean"},
                        "consigne": {"type": "string"},
                        "script": {"type": "string"},
                        "silences": {"type": "string", "enum": ["", "bords", "tous"]},
                        "musique_ici": {"type": "boolean"},
                        "miroir": {"type": "boolean"},
                        "zoom_de": {"type": "number"},
                        "zoom_a": {"type": "number"},
                        "transition": {"type": "string",
                                       "enum": ["", "fondu", "noir", "flash", "glisse"]},
                        "transition_duree": {"type": "number"}}}}}},
        "reglages": {"type": "object", "additionalProperties": False,
                     "required": ["taille_texte", "style_texte", "musique", "musique_volume",
                                  "melanger_ordre"],
                     "properties": {
                         "taille_texte": {"type": "integer"},
                         "style_texte": {"type": "string", "enum": ["contour", "pastille", "nu"]},
                         "musique": {"type": "boolean"},
                         "musique_volume": {"type": "number"},
                         "melanger_ordre": {"type": "boolean"}}},
        "tournage": {"type": "array", "items": {"type": "string"}},
        "questions": {"type": "array", "items": {"type": "string"}},
    }}

CONSIGNES_CAMPAGNE = """\
Monte une campagne du plateau à partir du BRIEF du client et de la VIDÉO EXEMPLE
(ses plans sont au-dessus, une image par plan, avec leur durée).

Comment le plateau fabrique les vidéos: une SÉRIE est une suite de CATÉGORIES.
Chaque catégorie est un dossier de clips interchangeables que l'utilisateur
filme; à chaque vidéo, le plateau tire UN clip par catégorie, le coupe à la
durée de la catégorie, et pose le texte de la catégorie par-dessus. Des dizaines
de variantes sortent ainsi des mêmes clips.

LA VIDÉO EXEMPLE FAIT FOI POUR LE MONTAGE. Quand il y en a une, c'est ELLE
que tu refais : ses parties, leur ordre, leurs durées, où le texte apparaît
et où il n'apparaît pas, split screen ou non, musique ou voix. Le brief ne
décide PAS du montage : il sert au deal (paie, pays, plateformes, règles) et
à savoir de quel produit on parle pour adapter les mots. S'ils se
contredisent sur la forme de la vidéo, suis l'exemple.

Règles:
- Une catégorie = un plan. Regroupe deux plans consécutifs (« plans » liste
  leurs numéros) SEULEMENT si c'est la même prise coupée en deux : même cadre,
  même écran. Deux écrans différents de l'app, même filmés pareil, sont deux
  catégories : on doit pouvoir filmer chacun à part. Garde l'ordre.
- « duree » = la durée du plan dans l'exemple (somme si plusieurs plans), en
  secondes. « delta » = la variation permise, 0,2 par défaut (0 si le plan doit
  durer exactement ça, par exemple calé sur la musique).
- « texte » = le texte à l'écran du plan, RÉÉCRIT pour le produit du brief si
  l'exemple parle d'autre chose, en gardant le ton et la longueur. Garde la
  LANGUE des textes de l'exemple (le public visé est le même), sauf si le
  brief en demande une autre. Saut de ligne: « | ». Vide s'il n'y a pas de
  texte.
- « position » = où est le texte (haut, milieu, bas).
- « son » = vrai seulement si on doit entendre le son du clip (quelqu'un qui
  parle, une réaction). Sinon la musique remplace le son.
- « complet » = vrai si le clip doit passer en entier (une démo d'app, un
  enregistrement d'écran), faux sinon.
- « consigne » = ce que l'utilisateur doit FILMER pour cette catégorie, en une
  ou deux phrases concrètes (cadrage, action, expression, durée à filmer — un
  peu plus long que « duree », pour laisser du choix). Pas de consigne vague.
- « script » = les mots EXACTS à dire dans ce plan, MOT POUR MOT, prêts à être
  lus avant de filmer. Si les PAROLES DE L'EXEMPLE sont données, reprends
  celles de ce plan telles quelles, adaptées au produit du brief seulement
  là où elles parlent d'autre chose. Sinon, reprends TELLES QUELLES les
  répliques que le brief donne (entre guillemets, « script starters »,
  formules imposées : nom du produit, « free to play », « link in bio »…),
  et complète dans son ton en respectant ses mots interdits. Dans la LANGUE
  que la personne parlera (celle du public visé, l'anglais sauf si le brief
  dit autre chose). Plusieurs personnes : une réplique par ligne, séparées
  par « | », chacune précédée de qui parle (« Toi : … | Ton ami : … »). Une
  action sans parole entre parenthèses. Vide si personne ne parle dans ce
  plan (enregistrement d'écran muet, plan de décor).
- « parle » = vrai si la vidéo repose sur quelqu'un qui parle à la caméra
  (sous-titres automatiques).
- « prise » = vrai quand la vidéo est UN talking head filmé d'une traite et
  utilisé une seule fois (on dépose la prise du jour, on récupère la vidéo
  montée) — pas des clips qu'on mélange. Alors : la PREMIÈRE catégorie est
  la prise (son gardé, silences "tous"), et les catégories suivantes, s'il
  y en a, sont ce qui se réutilise d'un jour à l'autre (un plan de fin, une
  démo). Faux pour tout ce qui se remixe, et toujours faux en split.

LIRE LE MONTAGE COMME UN MONTEUR — le but n'est pas de copier CETTE vidéo,
c'est d'en comprendre la recette pour la refaire avec D'AUTRES clips, qui
n'auront ni la même durée ni les mêmes mots. Pour chaque plan, regarde ses
images (début, milieu, fin), ce qui y est DIT et le niveau du son, et dis
ce qui DÉCIDE DE SA LONGUEUR :
  • la PAROLE (quelqu'un parle et le plan coupe quand la phrase finit) →
    « son » vrai, « silences » "bords" (le clip ira du premier au dernier
    mot, quelle que soit sa durée) ; "tous" si l'exemple saute déjà les
    pauses en jump cuts à l'intérieur du plan. « duree » reste celle de
    l'exemple, comme repère ;
  • la MUSIQUE ou un rythme (coupes sur le beat, plans de même longueur) →
    durée fixe, « delta » 0 ;
  • une DÉMO / un écran qu'on doit voir en entier → « complet » vrai ;
  • sinon → la durée de l'exemple ± « delta ».
  « musique_ici » vrai sur la catégorie où la musique ENTRE si elle n'est
  pas là dès le début (le niveau du son monte sans parole). « miroir »
  faux. Le texte à l'écran se LIT sur les images : recopie-le tel quel
  (adapté au produit seulement s'il parle d'un autre), avec sa place.
  « parle » vrai seulement si l'exemple montre des SOUS-TITRES mot à mot de
  ce qui est dit ; une voix sans sous-titres = « son » vrai sur la
  catégorie, « parle » faux.
- ZOOM et TRANSITION de chaque catégorie. LA PLUPART DU TEMPS IL N'Y EN A
  PAS : une coupe sèche et un plan fixe. N'en mets que si la MESURE donnée
  avec le plan le dit, ou si tu le VOIS sur ses images — jamais « pour
  faire joli ».
  « zoom_de » / « zoom_a » = l'échelle de l'image au début et à la fin du
  plan (1 = l'image entière ; 1 et 1 = pas de zoom). Zoom avant lent :
  1 → 1,1 à 1,2. Zoom arrière : 1,15 → 1. Plan RESSERRÉ d'un coup (le
  « punch-in » d'un jump cut : même prise que le plan d'avant, en plus
  gros) : la même valeur aux deux, par exemple 1,2 et 1,2. Jamais plus de
  1,6. Un rapprochement de la PERSONNE vers la caméra n'est pas un zoom.
  « transition » = comment ce plan ENTRE, depuis le plan d'avant : ""
  (coupe sèche), "fondu" (fondu enchaîné, les deux plans se superposent),
  "noir" (fondu par le noir), "flash" (éclair blanc), "glisse" (le plan
  d'avant est poussé hors du cadre par celui-ci). « transition_duree » en
  secondes (0,3 par défaut, 0 sans transition). Sur la PREMIÈRE catégorie,
  seul "noir" a un sens (la vidéo s'ouvre du noir). Une transition qui
  n'est aucune de celles-là (zoom-transition, rotation, glitch, volet…) :
  prends la plus proche et DIS-LE dans « resume ».
- « reglages » : taille_texte = la taille du texte de l'exemple (70 =
  taille TikTok habituelle, 85–100 = gros, 55 = petit) ; style_texte
  « contour » (texte blanc cerné de noir, le plus courant), « pastille »
  (texte sur un fond plein) ou « nu » ; musique = vrai s'il y a une musique
  de fond ; musique_volume 1 (0,1 si on parle par-dessus) ; melanger_ordre
  faux. Sans vidéo exemple : 70, contour, musique vrai, 1, faux.
- FORMAT « split »: seulement si l'exemple montre DEUX vidéos empilées (une en
  haut, une en bas) avec une bande de texte entre les deux. Alors: d'abord les
  plans plein cadre (role ""), puis une ou plusieurs catégories role « haut »,
  UNE catégorie role « bas », et les textes de la bande en catégories role
  « etape » (texte + durée, sans clip, consigne vide). Sinon format « plein »
  et role "" partout.
- Le nom des catégories est court (2-4 mots) et dit ce qu'on y voit.
- « plateformes » = où le deal exige de POSTER, d'après le brief et le
  contrat: ig = Instagram, tt = TikTok, yt = YouTube (Shorts), fb = Facebook.
  Seulement celles qui sont demandées (« Instagram only » → ["ig"]). Si rien
  n'est dit, liste vide et mets la question dans « questions ».
- Si un CONTRAT suit le brief, il fait foi sur la paie, le rythme et les
  plateformes quand les deux ne disent pas la même chose.
- CAMPAGNE: nom du client/produit; « objectif_jour » = vidéos par jour exigées
  par le brief (0 si rien n'est dit); la paie seulement si le brief la donne
  (0 / "" sinon). CHAQUE CHIFFRE DANS SON CHAMP, jamais une phrase qui mélange
  tout — l'app les affiche et les corrige séparément :
    « paie_par_video » = le montant de base par vidéo (nombre, toutes
      plateformes comprises : 10 $ × 2 plateformes = 20) ;
    « base_pay » = la paie de base en TRÈS court (≤ 60 caractères), ex.
      « 10 $ par plateforme » ou « 750 $/mois » ;
    « min_vues » = les vues minimum pour être payé (0 si rien n'est dit) ;
    « bonus » = les bonus aux vues, en court (« +50 $ à 50K, +100 $ à 100K,
      par plateforme »), "" s'il n'y en a pas ;
    « cycle_paie » et « frequence » comme d'habitude.
  « notes » = les règles du client à ne pas oublier (interdits, mots à dire,
  hashtags, mentions), UNE RÈGLE PAR LIGNE, courte — et rien de ce qui est
  déjà dans les champs de paie ci-dessus.
- « tournage » = la liste de tournage, dans l'ordre: une ligne par chose à
  filmer, avec le nombre de prises conseillé (au moins 3 par catégorie pour que
  les vidéos varient).
- « questions » = ce que le brief ne dit pas et qu'il faudrait demander au
  client (vide si rien).
- « resume » = deux phrases: ce que montre la vidéo exemple et l'idée à garder.
"""


# La regle du script, partagee avec `ecrire_scripts` : une seule source,
# sinon les series creees et celles completees apres coup divergeraient.
SCRIPT_REGLE = " ".join(CONSIGNES_CAMPAGNE.split("lus avant de filmer.", 1)[1]
                        .split("plan de décor).", 1)[0].split()) + " plan de décor)."


# Sans video exemple, la campagne se monte sur le brief seul: la forme
# d'un UGC qui marche est assez connue pour partir d'elle, et l'exemple
# arrive souvent apres le brief (« je t'envoie une ref demain »). Il
# remplacera ces categories quand il arrivera (`/api/series/<id>/exemple`).
SANS_EXEMPLE = """
PAS DE VIDÉO EXEMPLE pour l'instant. Monte la série d'après le BRIEF seul :
la forme d'un UGC court qui marche sur TikTok/Reels pour ce produit (en
général : une accroche de 1 à 2 s, le problème ou la situation, la démo du
produit, le résultat, un appel à l'action), 4 à 7 catégories, des durées
typiques de ce format, « plans » vide partout, format « plein » sauf si le
brief décrit un split screen. Les textes à l'écran en anglais sauf si le
brief dit une autre langue. « resume » = deux phrases sur l'idée de la vidéo
et le fait que la structure sera recalée sur l'exemple quand il arrivera.
"""


def paroles_par_plan(chemin, pl):
    """Ce qui se DIT dans la video exemple, range par plan : la source du
    script mot pour mot. Vide si whisper manque ou si personne ne parle —
    le script vient alors du brief. Un mot va au plan ou il commence."""
    try:
        import transcription
        if not transcription.disponible():
            return ""
        mots = transcription.mots(chemin)
    except Exception:
        return ""
    if not mots or not pl:
        return ""
    lignes = []
    for i, (a, b) in enumerate(pl, 1):
        dit = " ".join(str(m[0]).strip() for m in mots
                       if a - 0.05 <= float(m[1]) < b - 0.05 or (i == len(pl) and float(m[1]) >= a))
        if dit.strip():
            lignes.append(f"Plan {i}: {dit.strip()}")
    return "\n".join(lignes)


SCHEMA_SCRIPTS = {
    "type": "object", "additionalProperties": False, "required": ["scripts"],
    "properties": {"scripts": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["id", "script"],
        "properties": {"id": {"type": "string"}, "script": {"type": "string"}}}}}}


def ecrire_scripts(brief, categories, paroles=""):
    """Le script mot pour mot de chaque categorie d'une serie DEJA creee
    (20/11 : les series d'avant n'en avaient pas). `categories` =
    [{"id", "nom", "consigne", "texte", "son"}]. Rend {id: script}."""
    liste = "\n".join(
        f"- id {c['id']} — « {c['nom']} »"
        + (f" ; à filmer : {c['consigne']}" if c.get("consigne") else "")
        + (f" ; texte à l'écran : {c['texte']}" if c.get("texte") else "")
        + ("" if c.get("son") else " ; (son du clip coupé : la musique passe dessus)")
        for c in categories)
    texte = ("Écris le SCRIPT de chaque catégorie de cette série UGC : ce que la "
             "personne dit dans ce plan.\n\nCatégories, dans l'ordre de la vidéo:\n"
             + liste + "\n\nRègle — « script » = les mots EXACTS à dire dans ce plan, "
             "MOT POUR MOT, prêts à être lus avant de filmer. " + SCRIPT_REGLE + "\n"
             "Les catégories se suivent : la vidéo doit se tenir d'un plan à l'autre."
             + ("\n\nPAROLES DE L'EXEMPLE (transcrites, plan par plan):\n" + paroles if paroles else "")
             + "\n\nBRIEF DU CLIENT:\n" + (brief or "(aucun brief)"))
    r = demander(texte, schema=SCHEMA_SCRIPTS, modele=SOIGNE, delai=300)
    return {str(x.get("id") or ""): str(x.get("script") or "").strip()
            for x in r.get("scripts") or []}


def niveaux_par_plan(chemin, pl):
    """Le niveau du son de chaque plan, en dB (0 = le maximum), ou []. Une
    seule extraction pour tout le film."""
    import audioop
    import tempfile
    import wave
    with tempfile.TemporaryDirectory() as t:
        wav = os.path.join(t, "s.wav")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(chemin), "-vn", "-ac", "1",
                            "-ar", "8000", "-c:a", "pcm_s16le", wav], capture_output=True)
        if r.returncode != 0 or not os.path.exists(wav):
            return []
        try:
            w = wave.open(wav)
            sr, data = w.getframerate(), w.readframes(w.getnframes())
            w.close()
        except (OSError, wave.Error):
            return []
    out = []
    for a, b in pl:
        bloc = data[int(a * sr) * 2:int(b * sr) * 2]
        if len(bloc) < 200:
            out.append(None)
            continue
        out.append(round(20 * math.log10((audioop.rms(bloc, 2) + 1) / 32768), 1))
    return out


# ------------------------------------------------------------------
# ZOOMS ET TRANSITIONS DE L'EXEMPLE : MESURES, PAS DEVINES (23/11)
# ------------------------------------------------------------------
# Trois images par plan ne suffisent pas a Claude pour dire « zoom avant
# de 12 % » : une personne qui s'avance d'un pas fait le meme effet a
# l'oeil. Meme regle que `qualite.py` — ce qui se mesure ne se demande
# pas. On mesure donc, sans dependance (des images grises de 64x114 lues
# dans ffmpeg, comparees en Python) :
#
#   le ZOOM d'un plan : l'echelle qui recale au mieux sa derniere image
#     sur sa premiere. Un zoom de montage agrandit TOUTE l'image, fond
#     compris ; une personne qui bouge ne recale rien, et on ne dit rien.
#   le PUNCH-IN : la meme mesure entre la fin d'un plan et le debut du
#     suivant — meme prise, resserree d'un coup.
#   la COUPE : sur une seconde autour d'elle, la luminosite (un creux noir,
#     un eclair blanc) et le nombre d'images sur lesquelles le changement
#     s'etale (une coupe seche tient en UNE image).
#
# Claude recoit ces chiffres avec les plans, et une PLANCHE d'images pour
# chaque coupe qui n'est pas seche : c'est lui qui nomme la transition,
# sur ce qu'il voit, avec la mesure pour garde-fou.
GW, GH = 64, 114


def _gris(chemin, t):
    """L'image a l'instant `t`, en gris GWxGH (bytes), ou None."""
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t):.3f}", "-i", str(chemin),
         "-frames:v", "1", "-vf", f"scale={GW}:{GH},format=gray",
         "-f", "rawvideo", "pipe:1"], capture_output=True)
    return p.stdout if len(p.stdout) == GW * GH else None


def _moitie(img, w, h):
    """La meme image deux fois plus petite (moyenne de 2x2)."""
    out = bytearray((w // 2) * (h // 2))
    k = 0
    for y in range(0, h - 1, 2):
        a, b = y * w, (y + 1) * w
        for x in range(0, w - 1, 2):
            out[k] = (img[a + x] + img[a + x + 1] + img[b + x] + img[b + x + 1]) >> 2
            k += 1
    return bytes(out), w // 2, h // 2


def _detail(img, w, h, mini=14):
    """Les pixels qui ont du DETAIL (un bord, une texture) : les seuls qui
    disent quelque chose de l'echelle. Un mur uni ou un ciel noir
    « s'aligne » a n'importe quel zoom — sur un plan de nuit, il faisait
    monter l'accord de partout et le danseur decidait seul (deux faux
    zooms, ×1,18 et ×0,90, le 23/11). -> un masque de 0/1, bords exclus."""
    m = bytearray(w * h)
    for y in range(1, h - 1):
        r0, r1, r2 = (y - 1) * w, y * w, (y + 1) * w
        for x in range(1, w - 1):
            if abs(img[r1 + x + 1] - img[r1 + x - 1]) + abs(img[r2 + x] - img[r0 + x]) >= mini:
                m[r1 + x] = 1
    return bytes(m)


def _accord(A, B, w, h, ech, dx, dy, tol=10, masque=None):
    """La part des pixels de B qui retrouvent leur valeur dans « A agrandi
    de `ech` puis glisse de (dx, dy) », a `tol` niveaux de gris pres.

    On COMPTE ce qui s'aligne au lieu de moyenner l'ecart : dans un plan,
    la personne bouge et le decor non. Un ecart moyen est domine par la
    personne (mesure : un zoom de 16 % ressortait a 4 %) ; un compte ne
    regarde que ce qui tient — le decor, qui, lui, ne grossit que si le
    CADRE grossit."""
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    xs = [int(round(cx + (x - cx) / ech + dx)) for x in range(w)]
    cols = [(x, xs[x]) for x in range(w) if 0 <= xs[x] < w]
    ok = n = 0
    for y in range(h):
        ya = int(round(cy + (y - cy) / ech + dy))
        if not 0 <= ya < h:
            continue
        ra, rb = A[ya * w:(ya + 1) * w], B[y * w:(y + 1) * w]
        if masque is None:
            ok += sum(1 for x, xa in cols if -tol <= rb[x] - ra[xa] <= tol)
            n += len(cols)
        else:
            mk = masque[y * w:(y + 1) * w]
            for x, xa in cols:
                if mk[x]:
                    n += 1
                    if -tol <= rb[x] - ra[xa] <= tol:
                        ok += 1
    if masque is not None:
        return ok / n if n > w * h * 0.06 else 0.0     # trop peu de detail : rien a dire
    return ok / n if n > w * h * 0.5 else 0.0


def _recale(A, B):
    """-> (echelle, accord au mieux, accord sans zoom). echelle > 1 : B est
    A en plus gros (zoom avant) ; < 1 : zoom arriere. Recherche grossiere
    sur des images de 32x57, affinee en 64x114. L'accord ne compte que les
    pixels qui ont du detail (`_detail`)."""
    a2, w2, h2 = _moitie(A, GW, GH)
    b2, _, _ = _moitie(B, GW, GH)
    ma2, mb2 = _detail(a2, w2, h2), _detail(b2, w2, h2)
    mA, mB = _detail(A, GW, GH), _detail(B, GW, GH)
    mieux = (0.0, 1.0, 0, 0)
    for k in range(0, 21):                       # 1,00 -> 1,40
        e = 1.0 + 0.02 * k
        for sens in ((1,) if k == 0 else (1, -1)):
            X, Y, M = (a2, b2, mb2) if sens == 1 else (b2, a2, ma2)
            for dx in (-2, -1, 0, 1, 2):
                for dy in (-2, -1, 0, 1, 2):
                    v = _accord(X, Y, w2, h2, e, dx, dy, masque=M)
                    if v > mieux[0]:
                        mieux = (v, e if sens == 1 else -e, dx, dy)
    _, e0, dx0, dy0 = mieux
    sens = 1 if e0 > 0 else -1
    X, Y, M = (A, B, mB) if sens == 1 else (B, A, mA)
    fin = (0.0, abs(e0))
    for de in (-0.02, -0.01, 0.0, 0.01, 0.02):
        e = max(1.0, abs(e0) + de)
        for dx in (2 * dx0 - 1, 2 * dx0, 2 * dx0 + 1):
            for dy in (2 * dy0 - 1, 2 * dy0, 2 * dy0 + 1):
                v = _accord(X, Y, GW, GH, e, dx, dy, masque=M)
                if v > fin[0]:
                    fin = (v, e)
    # « Sans zoom » a la MEME taille et sur le MEME masque, en laissant
    # l'image glisser : un cadre qui bouge sans grossir n'est pas un zoom.
    sans = max(_accord(X, Y, GW, GH, 1.0, dx, dy, masque=M)
               for dx in (-4, -2, -1, 0, 1, 2, 4) for dy in (-4, -2, -1, 0, 1, 2, 4))
    ech = fin[1] if sens == 1 else 1.0 / fin[1]
    return round(ech, 3), fin[0], sans


# Les seuils, regles le 23/11 sur 6 mesures dont on connait la reponse et
# 20 vrais clips sans zoom :
#   - sous 3,5 % on ne dit rien, c'est le tremblement d'une main ;
#   - le recalage doit aligner au moins 8 points de plus que l'image telle
#     quelle. Un plan sans zoom donne EXACTEMENT 0 (16 clips sur 20) ; les
#     vrais zooms, +15 a +21 ;
#   - et aligner au moins la moitie du detail de l'image. En dessous, c'est
#     la CAMERA qui se deplace (plan filme en marchant) : les 4 faux zooms
#     restants mesuraient 0,37 a 0,42, les vrais 0,54 a 0,65.
# La valeur est INDICATIVE : un indice pour Claude, qui tranche avec les
# images. Mesures : ×1,04 pour 1,055 reel, ×1,17 pour 1,16, ×1,22 pour 1,22.
ZOOM_MINI = 0.035
ZOOM_GAIN = 0.08
ZOOM_ACCORD = 0.5


def _zoom(A, B):
    if not A or not B:
        return None
    ech, accord, sans = _recale(A, B)
    if abs(ech - 1.0) < ZOOM_MINI or accord < ZOOM_ACCORD or accord - sans < ZOOM_GAIN:
        return None
    return ech


def mesurer_zoom(chemin, ta, tb, progressif=True):
    """L'echelle de l'image a `tb` par rapport a celle a `ta`, ou None si
    rien ne se recale (pas de zoom, ou trop de mouvement pour le dire).

    `progressif` (le zoom d'un plan) : mesure en DEUX MOITIES d'abord. Sur
    une demi-duree la personne a moins bouge et la lumiere moins change —
    un zoom de 16 % sur un plan ou la personne gesticule ne se recalait
    pas d'un bout a l'autre (accord 0,36), mais chaque moitie donnait
    ×1,08, accord 0,65. Deux moities dans le meme sens = un zoom continu."""
    A, B = _gris(chemin, ta), _gris(chemin, tb)
    if progressif and tb - ta >= 0.6:
        M = _gris(chemin, (ta + tb) / 2)
        z1, z2 = _zoom(A, M), _zoom(M, B)
        if z1 and z2 and (z1 > 1) == (z2 > 1):
            return round(z1 * z2, 3)
    return _zoom(A, B)


def mesurer_coupe(chemin, t):
    """Ce qui se passe autour de la coupe a l'instant `t` :
    {"type": "seche" | "noir" | "flash" | "fondu" | "etalee", "duree": s}.
    « etalee » = un changement sur plusieurs images qui n'est pas un
    melange des deux plans (un glissement, un volet…) : a lire sur l'image."""
    cad = 15
    t0 = max(0.0, t - 0.45)
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{t0:.3f}", "-t", "1.05", "-i", str(chemin),
         "-vf", f"fps={cad},scale=32:57,format=gray", "-f", "rawvideo", "pipe:1"],
        capture_output=True)
    n = len(p.stdout) // (32 * 57)
    if n < 6:
        return {"type": "seche", "duree": 0.0}
    F = [p.stdout[i * 1824:(i + 1) * 1824] for i in range(n)]
    L = [sum(f) / 1824.0 for f in F]
    dif = lambda a, b: sum(abs(x - y) for x, y in zip(a, b)) / 1824.0   # noqa: E731
    bords = min(L[0], L[-1])
    creux, pic = min(L), max(L)
    if creux < 22 and bords > creux + 20:
        k = sum(1 for v in L if v < creux + (bords - creux) * 0.6)
        return {"type": "noir", "duree": round(min(1.0, max(0.2, k / cad)), 2)}
    if pic > 215 and max(L[0], L[-1]) < pic - 35:
        k = sum(1 for v in L if v > pic - (pic - max(L[0], L[-1])) * 0.6)
        return {"type": "flash", "duree": round(min(1.0, max(0.2, k / cad)), 2)}
    D = [0.0] + [dif(F[i], F[i - 1]) for i in range(1, n)]
    im = max(range(n), key=lambda i: D[i])
    # L'etendue du passage : ce qui change au moins moitie autant que le
    # pic. A 30 %, le mouvement ordinaire du plan (4 a 6 par image) passait
    # le seuil et un fondu de 0,4 s etait mesure a 0,87 s.
    seuil = max(D[im] * 0.55, 3.0)
    a = b = im
    while a > 1 and D[a - 1] > seuil:
        a -= 1
    while b < n - 1 and D[b + 1] > seuil:
        b += 1
    k = b - a + 1
    if k < 3 or D[im] < 6:
        return {"type": "seche", "duree": 0.0}
    # Un fondu enchaine : chaque image du passage est un MELANGE du plan
    # d'avant et du plan d'apres. On cherche la part de chacun et on
    # regarde ce qui reste d'inexplique.
    P, Q = F[a - 1], F[b]
    base = dif(P, Q) or 1.0
    reste = []
    for i in range(a, b):
        num = sum((f - q) * (pp - q) for f, pp, q in zip(F[i], P, Q))
        den = sum((pp - q) ** 2 for pp, q in zip(P, Q)) or 1
        al = min(1.0, max(0.0, num / den))
        reste.append(sum(abs(f - (al * pp + (1 - al) * q))
                         for f, pp, q in zip(F[i], P, Q)) / 1824.0)
    melange = reste and (sum(reste) / len(reste)) < base * 0.3
    return {"type": "fondu" if melange else "etalee",
            "duree": round(min(1.0, max(0.2, k / cad)), 2)}


def planche(chemin, t):
    """Six images cote a cote autour de la coupe, pour que Claude VOIE la
    transition : une seule image a envoyer."""
    p = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t - 0.3):.3f}", "-t", "0.9",
         "-i", str(chemin), "-vf", "fps=7,scale=150:-2,tile=6x1", "-frames:v", "1",
         "-f", "image2pipe", "-vcodec", "mjpeg", "-q:v", "6", "pipe:1"],
        capture_output=True)
    return p.stdout or None


TRANSITION_NOM = {"noir": "fondu par le noir", "flash": "flash blanc",
                  "fondu": "fondu enchaîné",
                  "etalee": "transition étalée (regarde sa planche)"}


def mouvements(chemin, pl, coupes=True):
    """Zoom de chaque plan et nature de chaque coupe.
    -> ({numero de plan: phrase a ajouter a ses faits}, [(legende, image)])."""
    faits, images = {}, []
    nombre = lambda x: f"{x:.2f}".replace(".", ",")              # noqa: E731
    # Les coupes d'abord : le zoom d'un plan se mesure HORS de ses
    # transitions (une image prise dans un fondu par le noir ne se recale
    # sur rien, et le zoom du plan passait inapercu).
    entree = {}
    if coupes:
        for i in range(2, len(pl) + 1):
            entree[i] = mesurer_coupe(chemin, pl[i - 1][0])
    for i, (a, b) in enumerate(pl, 1):
        bouts = []
        e, sortie = entree.get(i), entree.get(i + 1)
        da = a + (e["duree"] + 0.05 if e and e["type"] != "seche" else 0.0)
        db = b - (sortie["duree"] / 2 + 0.1 if sortie and sortie["type"] in ("noir", "flash")
                  else 0.0)
        if db - da >= 0.5:
            m = min(0.12, (db - da) * 0.15)
            z = mesurer_zoom(chemin, da + m, db - m)
            if z:
                bouts.append(f"ZOOM MESURÉ ×{nombre(z)} entre le début et la fin du plan ("
                             + ("zoom avant" if z > 1 else "zoom arrière")
                             + ", valeur indicative)")
        if e and e["type"] != "seche":
            bouts.append(f"ENTRÉE MESURÉE : {TRANSITION_NOM[e['type']]}, "
                         f"~{nombre(e['duree'])} s")
            img = planche(chemin, a)
            if img:
                images.append((f"Coupe entre le plan {i - 1} et le plan {i} "
                               f"(à {a:.2f} s) : six images qui se suivent, de "
                               "gauche à droite", img))
        elif e:
            # Coupe seche : la meme prise, resserree d'un coup ?
            pa = pl[i - 2][0]
            z = mesurer_zoom(chemin, max(pa, a - 0.1), min(b, a + 0.1), False)
            if z:
                bouts.append(f"MÊME PRISE que le plan {i - 1}, "
                             + (f"RESSERRÉE ×{nombre(z)} d'un coup" if z > 1
                                else f"élargie ×{nombre(z)} d'un coup"))
        if bouts:
            faits[i] = " ; ".join(bouts)
    return faits, images


def lire_exemple(chemin, pl, progres=None, coupes=True):
    """Ce que Claude regarde pour comprendre le montage de l'exemple :
    (images, faits). Trois images par plan (debut, milieu, fin — deux au-
    dela de 12 plans, le message reste raisonnable), en 480 de large pour
    lire le texte a l'ecran ; et par plan, ce qui est DIT et le niveau du
    son. C'est ce qu'on regarde a la main quand on refait un reel."""
    if progres:
        progres(f"{len(pl)} plans — j'écoute la vidéo…")
    paroles = {}
    for ligne in paroles_par_plan(chemin, pl).splitlines():
        m = re.match(r"Plan (\d+): (.*)", ligne)
        if m:
            paroles[int(m.group(1))] = m.group(2)
    niveaux = niveaux_par_plan(chemin, pl)
    if progres:
        progres(f"{len(pl)} plans — je regarde chaque plan…")
    fractions = (0.12, 0.5, 0.88) if len(pl) <= 12 else (0.2, 0.8)
    images, faits = [], []
    for i, (a, b) in enumerate(pl, 1):
        for f in fractions:
            t = a + (b - a) * f
            images.append((f"Plan {i} ({a:.2f}–{b:.2f} s), image à {t:.2f} s",
                           image(chemin, t, 480)))
        db = niveaux[i - 1] if i - 1 < len(niveaux) else None
        son = ("silence" if db is not None and db < -50 else
               f"{db} dB" if db is not None else "?")
        faits.append(f"Plan {i} : {a:.2f}–{b:.2f} s ({b - a:.2f} s) ; son {son} ; dit : "
                     + (f"« {paroles[i]} »" if i in paroles else "rien"))
    # Zooms et transitions, MESURES (voir plus haut). `coupes=False` pour
    # les tranches d'une prise : leurs bords ne sont pas des coupes.
    if progres:
        progres(f"{len(pl)} plans — je mesure les zooms et les coupes…")
    try:
        mv, planches = mouvements(chemin, pl, coupes)
    except Exception:                                   # noqa: BLE001
        mv, planches = {}, []       # une mesure ratee ne bloque pas la lecture
    for i in mv:
        faits[i - 1] += " ; " + mv[i]
    if coupes:
        faits.append("Zooms et coupes : ce qui n'est PAS signalé ci-dessus a été mesuré "
                     "sans zoom et en coupe sèche.")
    return images + planches, "\n".join(faits)


def proposer_campagne(brief, exemple=None, progres=None):
    """La campagne, la serie et la liste de tournage proposees par Claude.
    Rien n'est cree: c'est une proposition que l'utilisateur relit.
    `exemple` facultatif: sans lui, tout part du brief."""
    pl, images = [], []
    if exemple:
        if progres:
            progres("Lecture de la vidéo exemple…")
        pl = plans(exemple)
        images, faits = lire_exemple(exemple, pl, progres)
        if progres:
            progres(f"{len(pl)} plans — Claude comprend le montage…")
        fin = (f"\n\nLa vidéo exemple dure {duree(exemple):.1f} s et a {len(pl)} plans. "
               "PAROLES DE L'EXEMPLE et son, plan par plan (le son en dB : 0 = le "
               "plus fort, sous −50 = silence) :\n" + faits)
    else:
        if progres:
            progres("Claude prépare la campagne à partir du brief…")
        fin = "\n" + SANS_EXEMPLE
    texte = (CONSIGNES_CAMPAGNE + "\n\nBRIEF DU CLIENT:\n" + (brief or "(aucun brief)") + fin)
    r = demander(texte, images, schema=SCHEMA_CAMPAGNE, modele=SOIGNE, delai=600)
    r["plans"] = [{"debut": a, "fin": b, "duree": round(b - a, 3)} for a, b in pl]
    return r


# ------------------------------------------------------------------
# Une serie DECRITE en mots (21/11)
# ------------------------------------------------------------------
# Ce que le moteur sait faire. Sert a deux choses : que Claude traduise la
# description en reglages qui existent, et qu'il dise HONNETEMENT ce qui
# n'existe pas (`manque`) — c'est ce que « Le construire » ajoute ensuite
# (fonctionnalites.py). Une fonctionnalite construite qui ajoute un
# reglage doit aussi l'ajouter ici, sinon Claude la croira absente.
# ------------------------------------------------------------------
# LES REPRISES D'UNE PRISE (22/11)
# ------------------------------------------------------------------
# Une prise de talking head filmee d'une traite contient presque toujours
# une phrase recommencee. Couper les silences ne l'enleve pas : elle est
# PARLEE. C'est le seul endroit du montage ou il faut COMPRENDRE ce qui
# est dit — donc Claude, sur la transcription seule (pas d'image : la
# question est dans les mots).
SCHEMA_REPRISES = {
    "type": "object", "additionalProperties": False, "required": ["retirer"],
    "properties": {"retirer": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["de", "a", "pourquoi"],
        "properties": {"de": {"type": "integer"}, "a": {"type": "integer"},
                       "pourquoi": {"type": "string"}}}}}}

CONSIGNES_REPRISES = """\
Voici la transcription MOT PAR MOT d'une prise de talking head, filmée
d'une traite pour une vidéo courte (TikTok / Reels). Chaque mot porte son
numéro ; « ‖0,8 s‖ » est une pause.

La personne ne coupe pas la caméra quand elle se trompe : elle recommence
sa phrase. Rends les passages à RETIRER pour qu'il reste UNE seule bonne
version de chaque phrase, dans l'ordre :
- une phrase (ou un début de phrase) dite plusieurs fois : garde la
  DERNIÈRE version complète, retire les précédentes — sauf si la dernière
  est elle-même coupée, alors garde la dernière qui va au bout ;
- un faux départ, un bafouillage repris tout de suite (« je veux, je veux
  te montrer » : retire le premier « je veux ») ;
- ce qui n'est pas la vidéo : « ok c'est parti », « attends », « je
  recommence », « merde », « c'est bon », un rire ou un commentaire entre
  deux prises, ce qui est dit avant de commencer ou après avoir fini.
« de » et « a » sont des numéros de mots, bornes COMPRISES.

Ne retire JAMAIS un mot au milieu d'une phrase gardée, ni une répétition
VOULUE (« très, très bon »), ni un « euh » isolé. Une prise propre : liste
vide. Dans le doute, garde — un mot en trop se voit moins qu'une phrase
coupée."""


def reprises(mots, script="", notes=""):
    """Les passages a retirer d'une prise. `mots` = [(mot, debut, fin)] en
    secondes. Rend [(de, a, pourquoi)], numeros de mots bornes comprises.
    `notes` = les precisions ecrites pour le monteur sur la serie : elles
    valent pour CHAQUE prise (« enleve quand je dis le nom du client »)."""
    if len(mots) < 4:
        return []
    bouts = []
    for n, (w, x, _y) in enumerate(mots):
        if n and x - mots[n - 1][2] >= 0.35:
            bouts.append("‖" + f"{x - mots[n - 1][2]:.1f}".replace(".", ",") + " s‖")
        bouts.append(f"{n}:{w}")
    texte = (CONSIGNES_REPRISES
             + ("\n\nLE SCRIPT PRÉVU (ce que la vidéo finie doit dire, à peu près) :\n"
                + script.strip() if (script or "").strip() else "")
             + ("\n\nPRÉCISIONS DE LA PERSONNE pour le monteur (elles l'emportent sur les "
                "règles ci-dessus pour ce qu'on garde ou retire ; ignore celles qui ne "
                "parlent pas des coupes) :\n" + notes.strip() if (notes or "").strip() else "")
             + "\n\nLA PRISE :\n" + " ".join(bouts))
    r = demander(texte, schema=SCHEMA_REPRISES, modele=SOIGNE, delai=180)
    out = []
    for x in r.get("retirer") or []:
        try:
            de, a = int(x.get("de")), int(x.get("a"))
        except (TypeError, ValueError):
            continue
        if 0 <= de <= a < len(mots):
            out.append((de, a, str(x.get("pourquoi") or "").strip()))
    return sorted(out)


POUVOIRS = """\
Ce que le plateau sait faire pour le montage d'une série :
- une suite de CATÉGORIES (un clip tiré au sort par catégorie), chacune avec
  sa durée (min/max), ses textes à l'écran (tirés au sort, position haut /
  milieu / bas), garder ou couper le son du clip, passer le clip en entier,
  miroir, faire entrer la musique à partir de cette catégorie ;
- les textes façon TikTok : taille, style (contour noir, pastille, nu) ;
- musique de fond tirée au sort (dossier de musiques), volume, ou aucune ;
- mélanger l'ordre des catégories à chaque vidéo ;
- SÉRIE PARLÉE : sous-titres automatiques mot à mot (whisper) de ce qui est
  dit, et une BANQUE D'IMAGES par mot déclencheur (quand la personne dit
  « argent », une image du dossier « argent » s'affiche jusqu'à la fin de
  la phrase ou jusqu'au mot suivant) ;
- COUPER LES SILENCES d'une catégorie où l'on parle : chaque clip commence
  au premier mot et finit au dernier (quelle que soit sa longueur), ou en
  plus les pauses du milieu sautent en jump cut ;
- SPLIT SCREEN : un clip en haut, un en bas, des étapes de texte dans la
  bande entre les deux ;
- la frise de l'éditeur (textes posés sur des catégories), les voix off.
- ZOOM d'une catégorie : zoom avant ou arrière progressif sur toute la
  durée du plan, ou plan resserré d'un coup (« punch-in ») ;
- TRANSITION à l'entrée d'une catégorie : fondu enchaîné, fondu par le
  noir, flash blanc, glissement (le plan d'avant est poussé hors du cadre).
  Sans transition : coupe sèche.
- UNE PRISE PAR VIDÉO (« prise ») : pour un talking head filmé chaque jour
  et utilisé UNE fois. On dépose la prise du jour, le plateau retire les
  phrases recommencées et les silences, applique le montage de la série et
  rend UNE vidéo par prise — rien n'est tiré au sort dans cette catégorie ;
Ce qui N'EXISTE PAS (exemples) : les autres transitions (zoom-transition,
rotation, glitch, volet), un zoom qui change À CHAQUE jump cut à
l'intérieur d'un même clip, un zoom qui suit le visage, effets sonores sur
un mot, textes animés mot par mot en couleur, filtres de couleur, émojis
animés, compteur à l'écran, fond flouté…
"""

SCHEMA_DECRIRE = json.loads(json.dumps({
    "type": "object", "additionalProperties": False,
    "required": ["nom", "resume", "serie", "reglages", "images_mots", "tournage", "manque"],
    "properties": {
        "nom": {"type": "string"},
        "resume": {"type": "string"},
        "serie": SCHEMA_CAMPAGNE["properties"]["serie"],
        "reglages": {"type": "object", "additionalProperties": False,
                     "required": ["taille_texte", "style_texte", "musique", "musique_volume",
                                  "melanger_ordre"],
                     "properties": {
                         "taille_texte": {"type": "integer"},
                         "style_texte": {"type": "string", "enum": ["contour", "pastille", "nu"]},
                         "musique": {"type": "boolean"},
                         "musique_volume": {"type": "number"},
                         "melanger_ordre": {"type": "boolean"}}},
        "images_mots": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["mot", "fin"],
            "properties": {"mot": {"type": "string"},
                           "fin": {"type": "string", "enum": ["phrase", "suivant"]}}}},
        "tournage": {"type": "array", "items": {"type": "string"}},
        "manque": {"type": "array", "items": {"type": "string"}}}}))
_cat = SCHEMA_DECRIRE["properties"]["serie"]["properties"]["categories"]["items"]
# (Les options miroir / musique_ici / silences sont deja dans le schema de
# campagne depuis le 22/11 : la lecture d'une video exemple les remplit.)
assert {"miroir", "musique_ici", "silences", "zoom_de", "transition"} <= set(_cat["required"])

CONSIGNES_DECRIRE = """\
L'utilisateur DÉCRIT en mots le montage qu'il veut pour une nouvelle série du
plateau. Traduis sa description en série : catégories, textes, réglages.

""" + POUVOIRS + """
Règles :
- Les catégories, durées, textes, « son », « complet », « consigne » et
  « script » suivent les mêmes règles que pour une campagne (ci-dessous).
  « plans » vide partout. « miroir » faux sauf demande. « musique_ici » vrai
  sur UNE catégorie seulement si la musique doit entrer en cours de vidéo.
  « silences » : "bords" ou "tous" sur les catégories où l'on parle quand il
  veut couper les silences (talking head : "bords" par défaut, "tous" s'il
  veut un montage serré / jump cuts), "" sinon.
  « zoom_de » / « zoom_a » 1 et 1, « transition » "" et « transition_duree »
  0, SAUF s'il demande un zoom ou une transition (voir plus bas).
- « prise » = vrai quand la vidéo est UN talking head filmé d'une traite et
  utilisé une seule fois (on dépose la prise du jour, on récupère la vidéo
  montée) — pas des clips qu'on mélange. Alors : la PREMIÈRE catégorie est
  la prise (son gardé, silences "tous"), et les catégories suivantes, s'il
  y en a, sont ce qui se réutilise d'un jour à l'autre (un plan de fin, une
  démo). Faux pour tout ce qui se remixe, et toujours faux en split.
- « parle » = vrai si la vidéo repose sur quelqu'un qui parle (sous-titres
  automatiques). Une banque d'images par mot (« images_mots ») n'a de sens
  QUE dans une série parlée : « mot » = le mot dit (un seul mot, minuscule),
  « fin » = « phrase » (l'image reste jusqu'à la fin de la phrase) ou
  « suivant » (jusqu'au mot suivant).
- « reglages » : taille_texte 70 par défaut (plus gros = 85–100), style
  « contour » par défaut, musique vrai sauf « sans musique », volume 1 (une
  série parlée : 0,1, la voix passe devant), melanger_ordre faux sauf
  demande.
- « manque » = ce que la description demande et que le plateau NE SAIT PAS
  faire, une phrase claire par chose, écrite comme une demande de
  fonctionnalité (« Un effet sonore quand un mot précis est dit »).
  Vide si tout existe. N'invente pas de réglage pour le remplacer.
- Il n'y a PAS de vidéo exemple : « duree » = ce qu'il dit, sinon une durée
  typique d'un UGC court ; le format split se choisit si SA DESCRIPTION
  parle de deux vidéos l'une sur l'autre.
- « nom » : court, si l'utilisateur n'en donne pas.
- « resume » : deux phrases sur la série obtenue.
- « tournage » : la liste de tournage, au moins 3 prises par catégorie.

Rappel des règles d'une campagne, pour les catégories :
""" + CONSIGNES_CAMPAGNE.split("Règles:", 1)[1].split("- « plateformes »", 1)[0]


def decrire_serie(description, brief="", progres=None):
    """-> la serie decrite, prete a etre creee (rien n'est cree ici)."""
    if progres:
        progres("Claude monte la série…")
    texte = (CONSIGNES_DECRIRE + "\n\nCE QUE L'UTILISATEUR VEUT :\n" + description
             + ("\n\nBRIEF DE LA CAMPAGNE (le produit, ses règles) :\n" + brief[:30000]
                if brief.strip() else ""))
    return demander(texte, schema=SCHEMA_DECRIRE, modele=SOIGNE, delai=600)


# ------------------------------------------------------------------
# Trier les clips deposes en vrac
# ------------------------------------------------------------------
SCHEMA_TRI = {
    "type": "object", "additionalProperties": False, "required": ["clips"],
    "properties": {"clips": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["clip", "categorie", "confiance", "remarque"],
        "properties": {
            "clip": {"type": "string"},
            "categorie": {"type": "string"},
            "confiance": {"type": "number"},
            "remarque": {"type": "string"}}}}}}

# Six clips par appel: deux images chacun plus les categories, ~5 000
# jetons — et un seul demarrage de Claude Code pour six.
TRI_LOT = 6


def trier(categories, clips, progres=None):
    """`categories` = [{"id", "nom", "consigne", "image": jpeg|None}],
    `clips` = [chemin]. Rend {nom du clip: {"categorie": id|"", "confiance",
    "remarque"}}."""
    refs = []
    for c in categories:
        if c.get("image"):
            refs.append((f"Exemple de la catégorie « {c['nom']} » (id {c['id']})", c["image"]))
    liste = "\n".join(f"- id {c['id']} — « {c['nom']} » : {c.get('consigne') or '(pas de consigne)'}"
                      for c in categories)
    out = {}
    for k in range(0, len(clips), TRI_LOT):
        lot = clips[k:k + TRI_LOT]
        if progres:
            progres(f"Tri des clips {k + 1} à {k + len(lot)} sur {len(clips)}…")
        images = list(refs)
        for ch in lot:
            d = duree(ch) or 1.0
            nom = os.path.basename(str(ch))
            images.append((f"Clip « {nom} » ({d:.1f} s) — début", image(ch, d * 0.25)))
            images.append((f"Clip « {nom} » — fin", image(ch, d * 0.75)))
        texte = (
            "Range chaque clip dans la catégorie de la série qui lui correspond.\n"
            "Catégories:\n" + liste + "\n\n"
            "Pour chaque clip: « categorie » = l'id de la catégorie la PLUS PROCHE. "
            "\"\" seulement si le clip n'a rien à voir avec aucune catégorie (autre "
            "sujet, autre produit). Un clip qui ne suit pas bien la consigne va quand "
            "même dans sa catégorie, et tu le dis dans la remarque. « confiance » entre "
            "0 et 1. « remarque » = 12 mots maximum, SEULEMENT s'il y a un problème "
            "que l'image montre (ne suit pas la consigne, mauvais cadrage, on ne voit "
            "pas le produit, contenu à risque pour le client), sinon \"\". Ne parle "
            "jamais de durée, de lumière ni de netteté: l'app les mesure déjà. "
            "Réponds pour chacun de ces clips: "
            + ", ".join(f"« {os.path.basename(str(c))} »" for c in lot))
        r = demander(texte, images, schema=SCHEMA_TRI, modele=RAPIDE)
        for x in r.get("clips") or []:
            out[str(x.get("clip") or "")] = {
                "categorie": str(x.get("categorie") or ""),
                "confiance": float(x.get("confiance") or 0),
                "remarque": str(x.get("remarque") or "")}
    return out


# ------------------------------------------------------------------
# Repondre a une question
# ------------------------------------------------------------------
def repondre(question, contexte, historique=()):
    """`contexte` = ce que le plateau sait de l'etat (texte), `historique`
    = [(qui, texte)] des derniers echanges."""
    passe = "\n".join(f"{'Utilisateur' if q == 'moi' else 'Toi'}: {t}"
                      for q, t in list(historique)[-8:])
    texte = (
        "ÉTAT ACTUEL DU PLATEAU (ce que l'app sait, à jour):\n" + contexte +
        ("\n\nCONVERSATION JUSQU'ICI:\n" + passe if passe else "") +
        "\n\nQUESTION: " + question +
        "\n\nRéponds en 1 à 5 phrases courtes, concrètes, en nommant les boutons "
        "et les écrans du plateau tels qu'ils sont décrits plus haut. Si la "
        "question demande quoi faire ensuite, donne UNE prochaine étape.")
    return demander(texte, modele=RAPIDE, systeme=SYSTEME + "\n\n" + GUIDE)


# ------------------------------------------------------------------
# Le monteur et le chef de campagne: une demande -> des changements
# ------------------------------------------------------------------
# Claude ne touche a rien lui-meme (aucun outil, `--tools ""`): il rend une
# LISTE D'ACTIONS, que le serveur traduit en requetes sur les routes
# existantes — celles de l'interface, avec leurs gardes — et que
# l'utilisateur applique d'un clic. Un objet plat plutot qu'une union par
# type: le schema reste lisible pour le modele, et le serveur ne lit que
# les champs qui ont un sens pour le type.
SCHEMA_PARLER = {
    "type": "object",
    "properties": {
        "reponse": {"type": "string"},
        "manque": {"type": "string"},
        "actions": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "type": {"type": "string", "enum": [
                    "categorie", "nouvelle_categorie", "ordre", "serie",
                    "campagne", "generer", "tache", "texte_video"]},
                "bloc": {"type": "string"},
                "de_categorie": {"type": "string"},
                "jusqua_categorie": {"type": "string"},
                "decalage_debut": {"type": "number"},
                "decalage_fin": {"type": "number"},
                "supprimer": {"type": "boolean"},
                "serie": {"type": "string"},
                "categorie": {"type": "string"},
                "nom": {"type": "string"},
                "dur_min": {"type": "number"},
                "dur_max": {"type": "number"},
                "textes": {"type": "array", "items": {"type": "string"}},
                "position_texte": {"type": "string", "enum": ["haut", "milieu", "bas"]},
                "son": {"type": "boolean"},
                "complet": {"type": "boolean"},
                "mise_de_cote": {"type": "boolean"},
                "consigne": {"type": "string"},
                "script": {"type": "string"},
                "miroir": {"type": "boolean"},
                "musique_ici": {"type": "boolean"},
                "role": {"type": "string", "enum": ["", "haut", "bas", "etape"]},
                "silences": {"type": "string", "enum": ["", "bords", "tous"]},
                "zoom_de": {"type": "number"},
                "zoom_a": {"type": "number"},
                "transition": {"type": "string",
                               "enum": ["", "fondu", "noir", "flash", "glisse"]},
                "transition_duree": {"type": "number"},
                "split": {"type": "boolean"},
                "parle": {"type": "boolean"},
                "prise": {"type": "boolean"},
                "images_mots": {"type": "array", "items": {
                    "type": "object", "properties": {
                        "mot": {"type": "string"},
                        "fin": {"type": "string", "enum": ["phrase", "suivant"]}},
                    "required": ["mot"]}},
                "ordre": {"type": "array", "items": {"type": "string"}},
                "envoi_auto_jour": {"type": "integer"},
                "taille_texte": {"type": "integer"},
                "style_texte": {"type": "string", "enum": ["contour", "pastille", "nu"]},
                "melanger_ordre": {"type": "boolean"},
                "musique_volume": {"type": "number"},
                "sans_musique": {"type": "boolean"},
                "legendes_post": {"type": "array", "items": {"type": "string"}},
                "objectif_jour": {"type": "integer"},
                "paie_video": {"type": "number"},
                "cycle_paie": {"type": "string"},
                "date_paie": {"type": "string"},
                "notes": {"type": "string"},
                "statut": {"type": "string"},
                "pause": {"type": "boolean"},
                "nombre": {"type": "integer"},
                "texte": {"type": "string"},
            },
            "required": ["type"],
        }},
    },
    "required": ["reponse", "actions"],
}

CONSIGNES_PARLER = """Tu es à la fois le MONTEUR et le CHEF DE CAMPAGNE de l'utilisateur. Il te
parle comme à un collègue : « raccourcis l'accroche », « mets le texte plus
gros », « passe cette campagne à 5 vidéos par jour », « exporte-m'en une ».

Si sa demande se traduit en changements, mets-les dans `actions` : l'app
les APPLIQUE TOUT DE SUITE, sans lui demander (il peut annuler d'un clic),
sauf l'envoi auto et la pause d'une campagne, qu'il confirme. Dans
`reponse`, dis en 1 à 3 phrases ce que tu as changé (ou réponds à sa
question s'il n'y a rien à changer, et laisse `actions` vide). Il veut que
ce soit FAIT : traduis la demande en actions plutôt que de lui expliquer
où cliquer.

Les types d'action et leurs champs :
- categorie (serie, categorie = son nom EXACT dans l'état) : nom (renommer),
  dur_min/dur_max (secondes ; une durée fixe = les deux égaux), textes (la
  liste COMPLÈTE des textes à l'écran de la catégorie, tirés au sort — elle
  remplace l'ancienne : recopie ceux à garder), position_texte, son (garder
  le son du clip), complet (passer chaque clip en entier), mise_de_cote
  (true = ne sort plus au tirage, false = revient), consigne (ce qu'il faut
  filmer), script (les mots exacts à dire dans ce plan, mot pour mot,
  répliques séparées par « | »), miroir, musique_ici (la musique entre à
  partir de cette catégorie), role (split screen : "" = plan plein cadre
  avant le split, « haut » = le clip du haut, « bas » = le clip du bas,
  « etape » = un texte de la bande du milieu, sans clip, avec sa durée),
  silences ("bords" = chaque clip commence au premier mot et finit au
  dernier, quelle que soit sa longueur ; "tous" = en plus, les pauses au
  milieu sautent en jump cut ; "" = rien n'est coupé). Pour un talking
  head, « enlève les silences » = silences sur CHAQUE catégorie où l'on
  parle (son gardé ou série parlée).
  zoom_de / zoom_a (l'échelle de l'image au début et à la fin du plan :
  1 → 1,15 = zoom avant lent, 1,15 → 1 = zoom arrière, 1,2 et 1,2 = plan
  resserré d'un coup ; 1 et 1 = retire le zoom ; donne TOUJOURS les deux),
  transition (comment la catégorie ENTRE depuis le plan d'avant : "fondu",
  "noir", "flash", "glisse" ; "" = coupe sèche) et transition_duree
  (secondes, 0,3 par défaut).
- nouvelle_categorie (serie, nom, + les mêmes champs que categorie).
- ordre (serie, ordre = les noms des catégories dans le nouvel ordre).
- serie (serie) : envoi_auto_jour (vidéos envoyées à Buffer par jour),
  taille_texte (taille des textes, 70 par défaut), style_texte,
  melanger_ordre, musique_volume (1 = normal), sans_musique, legendes_post
  (les légendes du post Instagram, liste complète), parle (série parlée :
  sous-titres automatiques), prise (true = UNE PRISE PAR VIDÉO : la
  première catégorie reçoit la prise du jour, reprises et silences retirés,
  une vidéo par prise — pour un talking head qu'on ne remixe pas), images_mots (la liste COMPLÈTE des mots
  déclencheurs d'images, [{mot, fin: phrase|suivant}] — seulement dans une
  série parlée ; chaque mot a son dossier où déposer les images), split
  (true = passer la série en SPLIT SCREEN). Pour passer une série en split :
  split true, ET des rôles sur les catégories — au moins une « haut » et UNE
  « bas » (crée-les avec nouvelle_categorie si besoin), les plans d'accroche
  gardent role "", et les textes de la bande deviennent des catégories
  « etape » (texte + dur_min = dur_max). Repasser en plein cadre : split
  false et role "" partout.
- campagne : nom, objectif_jour, paie_video, cycle_paie (hebdo, 2sem,
  mensuel), date_paie (AAAA-MM-JJ, un jour de paiement connu), notes (le
  texte COMPLET des notes), statut (ce qu'il reste à faire pour cette
  campagne, une phrase — "" pour le retirer), pause (true = arrêter de
  publier).
- generer (serie, nombre) : exporter des vidéos pour voir le résultat. Ajoute
  une action generer d'1 vidéo après un changement de montage quand il veut
  voir le résultat.
- tache (texte) : une ligne dans sa todo.
- texte_video (serie) : un texte de la FRISE DE L'ÉDITEUR — seulement si
  l'état dit « FRISE DE L'ÉDITEUR : ACTIVE » ; c'est alors elle qui dessine
  les textes de la vidéo, pas les catégories (n'utilise PAS `textes` d'une
  catégorie dans ce cas, ça ne se verrait pas). bloc = l'id du bloc dans
  l'état (vide = nouveau texte) ; texte (le nouveau texte) ; de_categorie
  (où il commence, nom exact ; obligatoire pour un nouveau) ;
  jusqua_categorie (il s'arrête au DÉBUT de cette catégorie ; « fin » =
  jusqu'au bout) ; decalage_debut / decalage_fin (secondes, + = plus tard) ;
  position_texte ; taille_texte (70 par défaut) ; style_texte ;
  supprimer (true = retirer le bloc).

Si la demande veut quelque chose que le plateau NE SAIT PAS faire (voir
ci-dessous), ne bricole pas avec un autre réglage : décris-le dans
`manque` (une phrase claire, écrite comme une demande de fonctionnalité),
et dis dans `reponse` que ça n'existe pas encore et qu'il peut le faire
construire. L'app lui proposera le bouton.

Règles :
- `serie` = le nom exact d'une série de l'état ; vide = la série ouverte.
- N'invente jamais une catégorie, une série ou une valeur que l'état ne
  donne pas. Si la demande est floue, pose UNE question dans `reponse` et
  ne propose rien.
- Une durée en dessous de 0,5 s ne se lit pas ; garde ±0,2 s d'écart entre
  dur_min et dur_max sauf s'il veut une durée exacte.
- Garde la langue des textes à l'écran telle qu'elle est (souvent l'anglais).
- Ne mets en pause une campagne ou ne coupe l'envoi auto que s'il le demande.
- Si des images de sa dernière vidéo sont jointes, sers-t'en pour comprendre
  de quoi il parle (« le texte du début », « le deuxième plan »).
"""


CONSIGNES_PARLER += "\n" + POUVOIRS


# La case « Decris le montage » d'une serie (22/11) : on lui ecrit son
# montage comme a un monteur humain, souvent sans etre precis. Il VOIT la
# matiere (images et paroles jointes) et DEDUIT au lieu de demander.
AUTONOME = """
MODE MONTEUR AUTONOME — les images et les paroles jointes sont la VRAIE
matière de cette série : la vidéo exemple du client (la référence à
imiter), un clip de chaque catégorie avec ce qui y est dit, et la dernière
vidéo exportée. Sers-t'en pour comprendre ce qu'il veut quand il n'est pas
précis : « mets une accroche » → écris-la d'après ce que montrent les clips
et ce que dit la personne ; « fais comme l'exemple » → reprends le rythme,
la place et le ton des textes de l'exemple ; « coupe le blabla » → raccourcis
les catégories où il ne se passe rien. Ne pose PAS de question pour un
détail : choisis ce que tu jugerais le mieux pour une vidéo qui marche,
FAIS-le, et dis en une phrase ce que tu as déduit (il corrigera). Une
question seulement si deux lectures opposées sont aussi probables et que se
tromper casserait la série.
"""


def parler(demande, contexte, historique=(), images=(), autonome=False):
    """-> {"reponse", "actions"}. Sonnet et pas Haiku: une action mal
    comprise touche une serie qui publie, et c'est un seul appel par
    message."""
    passe = "\n".join(f"{'Utilisateur' if q == 'moi' else 'Toi'}: {t}"
                      for q, t in list(historique)[-10:])
    texte = (
        "ÉTAT ACTUEL DU PLATEAU (à jour) :\n" + contexte +
        ("\n\nCONVERSATION JUSQU'ICI :\n" + passe if passe else "") +
        "\n\nDEMANDE : " + demande)
    r = demander(texte, images, schema=SCHEMA_PARLER, modele=SOIGNE,
                 systeme=SYSTEME + "\n\n" + GUIDE + "\n\n" + CONSIGNES_PARLER
                 + (AUTONOME if autonome else ""))
    if not isinstance(r, dict):
        raise IAError("Réponse de Claude illisible — réessaie")
    r.setdefault("actions", [])
    return r


# Ce que l'assistant sait de l'app. Court: c'est envoye a chaque question.
GUIDE = """\
Le plateau, en bref:
- Barre de gauche: Vue d'ensemble, Éditeur (les projets), File d'attente, Todo,
  Contenu, Prospection, Onboarding, puis la liste des CAMPAGNES et « Nouvelle
  campagne ».
- Une CAMPAGNE = un deal avec un client (comptes, paie, objectif par jour). Elle
  contient des SÉRIES. Une série = la recette de montage: des CATÉGORIES de clips.
- « Nouvelle campagne » → « Avec l'IA »: on colle le brief, on dépose la vidéo
  exemple, l'IA propose la campagne, la série et la liste de tournage.
- Dans une série, onglet « Clips »: chaque catégorie a sa case, avec ce qu'il
  faut y filmer. « Déposer tous les clips » envoie les clips d'un coup et l'IA
  les range dans la bonne catégorie, avec des avertissements (trop sombre, flou,
  horizontal, trop court, ne ressemble pas à la consigne).
- Onglet « Générer »: fabriquer des vidéos. Onglet « Vidéos »: les voir.
  Onglet « Publier »: Buffer, envoi automatique par jour.
- L'Éditeur: un projet = une série, montée comme dans CapCut (frise, textes,
  aperçu, Exporter).
- Le bouton « Tuto » en haut à droite explique chaque écran.
L'ordre normal: créer la campagne → filmer la liste de tournage → déposer les
clips → générer une vidéo pour vérifier → brancher Buffer → envoi automatique.
"""
